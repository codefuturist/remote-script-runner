# Tests - Testing Suite

## Purpose

Automated tests for validating templates, deployments, infrastructure, and overall system integrity.

## Structure

```text
tests/
├── unit/                         # Unit tests for individual components
│   ├── ansible/                  # Ansible playbook tests
│   ├── helm/                     # Helm chart tests
│   └── terraform/                # Terraform module tests
├── integration/                  # Integration tests
│   ├── infrastructure/           # Infrastructure integration tests
│   ├── applications/             # Application integration tests
│   └── end-to-end/               # Full workflow tests
├── compliance/                   # Compliance & policy tests
│   ├── security-scanning/        # Security vulnerability scanning
│   ├── policy-validation/        # OPA/policy validation
│   └── cost-analysis/            # Cost estimation and limits
└── performance/                  # Performance tests
    ├── benchmarks/               # Performance benchmarks
    ├── load-testing/             # Load testing scenarios
    └── stress-testing/           # Stress testing scenarios
```

## Test Categories

### Unit Tests (`unit/`)

Test individual templates and modules in isolation.

**What's tested:**
- Template syntax and structure
- Variable substitution
- Default values
- Template metadata
- Individual module functionality

**Run with:**

```bash
# Run all unit tests
make test-unit

# Run specific technology
make test-unit-terraform
make test-unit-ansible
make test-unit-helm
```

### Integration Tests (`integration/`)

Test how components work together.

**What's tested:**
- Infrastructure provisioning
- Application deployment
- Service connectivity
- Data flow
- End-to-end workflows

**Run with:**

```bash
# Run all integration tests
make test-integration

# Run specific category
make test-integration-infra
make test-integration-apps
make test-end-to-end
```

### Compliance Tests (`compliance/`)

Validate compliance with security, policy, and cost requirements.

**What's tested:**
- Security vulnerabilities
- Policy violations (OPA)
- Cost thresholds
- Regulatory compliance
- Best practices

**Run with:**

```bash
# Run all compliance tests
make test-compliance

# Run specific scans
make test-security
make test-policy
make test-cost
```

### Performance Tests (`performance/`)

Measure and validate system performance.

**What's tested:**
- Resource utilization
- Response times
- Throughput
- Scalability
- System limits

**Run with:**

```bash
# Run all performance tests
make test-performance

# Run specific tests
make test-benchmarks
make test-load
make test-stress
```

## Running Tests

### Quick Test Commands

```bash
# Run all tests
make test-all

# Run specific category
make test-unit
make test-integration
make test-compliance
make test-performance

# Run tests for specific environment
make test ENV=development
make test ENV=staging
```

### Detailed Test Commands

```bash
# Unit tests with coverage
make test-unit-coverage

# Integration tests with verbose output
make test-integration-verbose

# Compliance tests with report
make test-compliance-report

# Performance tests with metrics
make test-performance-metrics
```

## Test Development

### Creating New Tests

1. **Choose appropriate directory:**
   - `unit/` for component tests
   - `integration/` for workflow tests
   - `compliance/` for policy/security tests
   - `performance/` for performance tests

2. **Follow naming conventions:**
   - Test files: `test_*.py`, `*_test.py`, `*.test.js`
   - Test functions: `test_*` or `*_test`
   - Descriptive names: `test_postgres_deployment_creates_database`

3. **Write clear test cases:**

```python
# Example unit test
def test_template_has_required_metadata():
    """Test that template has required metadata fields."""
    template = load_template("catalog/self-hosted/databases/postgresql")
    
    assert "name" in template
    assert "version" in template
    assert "description" in template
    assert template["version"] matches_semver()
```

4. **Include test documentation:**

```python
"""
Test Suite: PostgreSQL Template

Tests the PostgreSQL database template for:
- Metadata completeness
- Variable validation
- Docker Compose syntax
- Health checks
- Backup configuration
"""
```

### Test Best Practices

1. **Keep tests isolated** - Each test should be independent
2. **Use fixtures** - Reuse test data and setup
3. **Clear assertions** - Make it obvious what's being tested
4. **Good error messages** - Failed tests should explain why
5. **Fast execution** - Unit tests should run quickly
6. **Clean up** - Remove test artifacts after running

## Test Frameworks

### Python Tests

**Framework:** pytest

```bash
# Run Python tests
pytest tests/unit/

# With coverage
pytest --cov=catalog tests/unit/

# Specific test file
pytest tests/unit/terraform/test_aws_modules.py
```

### Terraform Tests

**Framework:** Terratest

```bash
# Run Terraform tests
cd tests/unit/terraform
go test -v ./...
```

### Ansible Tests

**Framework:** Molecule

```bash
# Run Ansible tests
cd tests/unit/ansible
molecule test
```

### Kubernetes/Helm Tests

**Framework:** helm unittest, kube-score

```bash
# Run Helm tests
helm unittest catalog/containers/kubernetes/my-chart/

# Run kube-score
kube-score score manifest.yaml
```

## CI/CD Integration

### GitLab CI Example

```yaml
test:
  stage: test
  script:
    - make test-all
  coverage: '/TOTAL.*\s+(\d+%)$/'
```

### GitHub Actions Example

```yaml
- name: Run Tests
  run: make test-all
  
- name: Upload Coverage
  uses: codecov/codecov-action@v2
  with:
    files: ./coverage.xml
```

### Jenkins Example

```groovy
stage('Test') {
    steps {
        sh 'make test-all'
    }
    post {
        always {
            junit 'test-results/**/*.xml'
            publishHTML([
                reportDir: 'coverage',
                reportFiles: 'index.html',
                reportName: 'Coverage Report'
            ])
        }
    }
}
```

## Test Environments

### Development

- Fast, frequent tests
- Unit tests run on every commit
- Integration tests run on PR

### Staging

- Full test suite before production
- Integration and end-to-end tests
- Performance benchmarks

### Production

- Smoke tests after deployment
- Monitoring and alerting
- Continuous compliance scanning

## Troubleshooting Tests

### Test Failures

```bash
# Run with verbose output
pytest -v tests/unit/

# Run specific test
pytest tests/unit/test_postgres.py::test_template_valid

# Show full diff on assertion failure
pytest -vv tests/unit/

# Stop on first failure
pytest -x tests/unit/
```

### Debugging Tests

```bash
# Drop into debugger on failure
pytest --pdb tests/unit/

# Print output
pytest -s tests/unit/

# Show local variables on failure
pytest -l tests/unit/
```

### Common Issues

**Import errors:**

```bash
# Install test dependencies
pip install -r tests/requirements.txt
```

**Missing fixtures:**

```bash
# Check fixture is defined
grep -r "fixture_name" tests/
```

**Timeout errors:**

```bash
# Increase timeout
pytest --timeout=300 tests/integration/
```

## Test Coverage

### Measuring Coverage

```bash
# Run with coverage
make test-coverage

# Generate HTML report
coverage html

# View report
open htmlcov/index.html
```

### Coverage Goals

- **Unit tests:** > 80% code coverage
- **Integration tests:** > 60% workflow coverage
- **Compliance tests:** 100% policy coverage

## Test Reporting

### Generate Reports

```bash
# JUnit XML (for CI)
pytest --junit-xml=test-results/junit.xml tests/

# HTML report
pytest --html=test-results/report.html tests/

# Coverage report
pytest --cov-report=html tests/
```

### View Reports

```bash
# Open HTML report
open test-results/report.html

# Open coverage report
open htmlcov/index.html
```

## Related Documentation

- [STRUCTURE.md](../STRUCTURE.md) - Repository structure
- [CONTRIBUTING.md](../CONTRIBUTING.md) - Contribution guidelines
- [docs/guides/](../docs/guides/) - Testing guides

## Quick Start

```bash
# Install dependencies
pip install -r tests/requirements.txt

# Run all tests
make test-all

# Run specific category
make test-unit

# Run with coverage
make test-coverage

# View results
open htmlcov/index.html
```

---

**New to testing?** Start with unit tests in `tests/unit/` and work your way up to integration tests.
