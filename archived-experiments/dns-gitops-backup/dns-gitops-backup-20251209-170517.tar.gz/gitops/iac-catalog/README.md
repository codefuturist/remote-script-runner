# IaC Catalog - Infrastructure as Code Template System

A **template-based GitOps deployment system** for Infrastructure as Code that supports multi-environment, multi-target deployments with automated reconciliation.

## 🚀 Quick Start

```bash
# 1. See examples
cd examples/01-simple-webapp
cat README.md

# 2. Configure your first deployment
./scripts/cli/configure.sh \
  --template catalog/self-hosted/databases/postgresql \
  --instance my-db \
  --environment development \
  --target dev-server-01

# 3. Deploy via GitOps
git add deployments/development/my-db
git commit -m "feat: add database"
git push
```

## 📚 Documentation

- **[STRUCTURE.md](./STRUCTURE.md)** - Complete directory structure guide (START HERE!)
- **[QUICKSTART.md](./QUICKSTART.md)** - Get started in 5 minutes
- **[docs/ARCHITECTURE.md](./docs/ARCHITECTURE.md)** - Architecture deep dive
- **[examples/](./examples/)** - Working examples
- **[CONTRIBUTING.md](./CONTRIBUTING.md)** - How to contribute

## 🗂️ Repository Structure

```text
iac-catalog/
├── catalog/           # Reusable templates
├── deployments/       # Configured instances (GitOps watches here)
├── inventory/         # Infrastructure definitions
├── environments/      # Environment configurations
├── examples/          # Working examples ✨ NEW
├── ansible/           # Ansible integration
├── scripts/           # Automation tools
├── docs/              # Documentation
├── tests/             # Test suites
└── tools/             # Development utilities ✨ NEW
```

See **[STRUCTURE.md](./STRUCTURE.md)** for detailed explanations.

## 🎯 Core Concepts

### Templates (`catalog/`)

Reusable, versioned infrastructure and application templates organized by technology and use case.

### Deployments (`deployments/`)

Configured instances ready for deployment. GitOps agents watch this directory for changes.

### Inventory (`inventory/`)

Definitions of servers, clusters, and infrastructure targets.

### Environments (`environments/`)

Environment-specific configurations, defaults, and overrides.

## 💡 Key Features

- ✅ **Template-Based** - Reusable templates for consistency
- ✅ **GitOps-Driven** - All changes through Git
- ✅ **Multi-Environment** - Production, staging, development isolation
- ✅ **Multi-Target** - Deploy to single servers, groups, or clusters
- ✅ **Comprehensive Documentation** - README in every major directory
- ✅ **Working Examples** - Learn by doing

## 🛠️ Available Scripts

```bash
# Configure deployment
./scripts/cli/configure.sh --template catalog/... --instance my-app

# List deployments
./scripts/cli/list.sh --environment production

# Validate configuration
./scripts/automation/validate.sh --instance my-app

# Rollback deployment
./scripts/automation/rollback.sh --instance my-app
```

See [scripts/README.md](./scripts/README.md) for all available scripts.

## 📦 Template Categories

- **Cloud** - AWS, Azure, GCP resources
- **Containers** - Docker, Docker Swarm, Kubernetes
- **GitOps** - ArgoCD, Fleet, Flux
- **Self-Hosted** - Databases, monitoring, CI/CD, networking
- **Governance** - Policies, runbooks, standards
- **Patterns** - Application and infrastructure patterns

Browse [catalog/README.md](./catalog/README.md) for all templates.

## 🧪 Testing

```bash
# Run all tests
make test-all

# Run specific tests
make test-unit
make test-integration
make test-compliance
```

See [tests/README.md](./tests/README.md) for testing documentation.

## 🔧 Development Tools

```bash
# Validate template
./tools/validators/template-validator.py catalog/path/to/template

# Generate new template
./tools/generators/template-generator.sh --name my-app

# Lint templates
./tools/linters/template-linter.py catalog/
```

See [tools/README.md](./tools/README.md) for all available tools.

## 📖 Learning Resources

### For New Users

1. Read [STRUCTURE.md](./STRUCTURE.md) - Understand the layout
2. Complete [examples/01-simple-webapp](./examples/01-simple-webapp/) - First deployment
3. Explore [catalog/](./catalog/) - Browse templates
4. Try your own deployment

### For Existing Users

- [QUICKSTART.md](./QUICKSTART.md) - Quick command reference
- [docs/ARCHITECTURE.md](./docs/ARCHITECTURE.md) - Architecture details
- [docs/guides/](./docs/guides/) - Detailed guides

## 🤝 Contributing

Contributions welcome! Please see [CONTRIBUTING.md](./CONTRIBUTING.md) for:

- Code style guidelines
- Template creation guidelines
- Pull request process
- Development setup

## 📞 Support

- **Documentation**: [docs/](./docs/) and [STRUCTURE.md](./STRUCTURE.md)
- **Examples**: [examples/](./examples/)
- **Issues**: [GitHub Issues](https://github.com/codefuturist/iac-catalog/issues)

## 🆕 Recent Improvements

This repository recently added:

- ✅ **Comprehensive documentation** - STRUCTURE.md and README in every directory
- ✅ **Working examples** - Complete end-to-end examples in `examples/`
- ✅ **Development tools** - Validators, generators, converters in `tools/`
- ✅ **Better organization** - Clear purpose for every directory

See `suggested-1/` directory for detailed improvement documentation.

## 📄 License

MIT License - see [LICENSE](./LICENSE) for details.
