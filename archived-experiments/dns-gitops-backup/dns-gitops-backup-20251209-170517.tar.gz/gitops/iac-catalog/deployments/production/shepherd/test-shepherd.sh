#!/usr/bin/env bash
# Helper to test shepherd on remote host
set -euo pipefail
REMOTE=192.168.2.57
STACK_FILE=test-shepherd-stack.yml
REMOTE_PATH=/tmp/${STACK_FILE}
STACK_NAME=shepherd_test
SERVICE_NAME=${STACK_NAME}_update-demo

echo "Syncing stack file to ${REMOTE}:${REMOTE_PATH}"
scp ${STACK_FILE} ${REMOTE}:${REMOTE_PATH}

echo "Deploying stack on remote"
ssh ${REMOTE} "docker stack deploy -c ${REMOTE_PATH} ${STACK_NAME}"

echo "Waiting for service to be up..."
ssh ${REMOTE} "docker service ls --filter name=${SERVICE_NAME} --format '{{.Replicas}} {{.Name}}'"
# Wait for a running replica
for i in {1..20}; do
  STATUS=$(ssh ${REMOTE} "docker service ps ${SERVICE_NAME} --format '{{.CurrentState}}' | head -n1 || true")
  echo "Service status: ${STATUS}"
  if [[ "$STATUS" == *"Running"* ]]; then
    break
  fi
  sleep 1
done

echo "Service running. Now simulate an image update by changing service image to nginx:1.24.0"
ssh ${REMOTE} "docker service update --image nginx:1.24.0 ${SERVICE_NAME} || true"

echo "Force restarting shepherd to trigger an immediate check"
ssh ${REMOTE} "docker service update --force shepherd_shepherd || true"

echo "Waiting a few seconds then showing shepherd logs and service image"
sleep 5
ssh ${REMOTE} "docker service logs shepherd_shepherd --tail 30" || true
ssh ${REMOTE} "docker service ps ${SERVICE_NAME} --no-trunc --format 'ID: {{.ID}}  Node: {{.Node}}  Image: {{.Image}}  Desired: {{.DesiredState}}  Current: {{.CurrentState}}'"

echo "Done. Review logs above to confirm Shepherd actions."
