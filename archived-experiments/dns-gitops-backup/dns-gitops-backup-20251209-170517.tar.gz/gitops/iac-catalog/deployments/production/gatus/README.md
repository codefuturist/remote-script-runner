# Blog Application Deployment Example

This is a complete example of deploying a WordPress-based company blog using the iac-catalog system.

## Overview

This deployment creates:

- **WordPress 6.6** blog application
- **MySQL 8.0** database
- **Persistent storage** for content and data
- **Isolated network** for security

## Deployment Structure

```bash
blog-app/
├── manifest.yml      # Deployment metadata and configuration
├── target.yml        # Target host and deployment settings
├── docker-compose.yml # Container orchestration
└── .env             # Environment variables (secrets)
```

## Quick Deploy

### Prerequisites

1. **Target Server**: Ensure `server-dev-01` is configured in your inventory
2. **Ansible**: Ansible must be installed with docker-compose collection
3. **SSH Access**: SSH key access to target server

### Deploy Command

```bash
# Deploy to development environment
ansible-playbook -i ansible/inventory/dynamic.py \
  ansible/playbooks/docker-compose-deploy.yml \
  -e "deployment_path=deployments/development/blog-app" \
  -e "target_host=server-dev-01"
```

### Manual Deploy (Alternative)

If you prefer to deploy manually:

```bash
# 1. Copy files to server
scp -r deployments/development/blog-app user@server-dev-01:/tmp/

# 2. SSH to server and deploy
ssh user@server-dev-01
cd /tmp/blog-app
docker-compose up -d

# 3. Check status
docker-compose ps
```

## Configuration

### Environment Variables

| Variable | Value | Description |
|----------|-------|-------------|
| `WORDPRESS_VERSION` | 6.6 | WordPress version |
| `WORDPRESS_PORT` | 8080 | Exposed port (avoiding port 80 conflicts) |
| `DB_NAME` | blog_db | Database name |
| `DB_USER` | blog_user | Database user |
| `DB_PASSWORD` | secure_blog_password_2025! | Database password |
| `DB_ROOT_PASSWORD` | secure_root_password_2025! | MySQL root password |

### Ports

- **WordPress**: `http://server-dev-01:8080`
- **MySQL**: Internal only (not exposed)

## Post-Deployment

### Access the Blog

1. **Open browser**: `http://server-dev-01:8080`
2. **Complete setup**: Follow WordPress installation wizard
3. **Default admin**: `admin` / `password` (change immediately!)

### Verify Deployment

```bash
# Check running containers
docker-compose -f /opt/deployments/blog-app/docker-compose.yml ps

# View logs
docker-compose -f /opt/deployments/blog-app/docker-compose.yml logs

# Check services
curl http://localhost:8080
```

### Backup Strategy

```bash
# Backup database
docker exec blog-app_db_1 mysqldump -u blog_user -p blog_db > blog_backup.sql

# Backup WordPress files
docker cp blog-app_wordpress_1:/var/www/html ./wordpress_backup
```

## Troubleshooting

### Common Issues

1. **Port Conflict**: Change `WORDPRESS_PORT` if 8080 is in use
2. **Database Connection**: Check `DB_*` variables match
3. **Permissions**: Ensure deploy user has docker permissions

### Logs

```bash
# Application logs
docker-compose logs wordpress

# Database logs
docker-compose logs db

# All logs
docker-compose logs
```

## Customization

### Adding Plugins/Themes

1. **Via WordPress Admin**: Install through web interface
2. **Via Volume Mount**: Add to `docker-compose.yml` volumes
3. **Custom Image**: Build custom WordPress image

### Scaling

```yaml
# Add to docker-compose.yml for multiple WordPress instances
wordpress:
  scale: 3
  # Add load balancer configuration
```

## Cleanup

```bash
# Stop and remove containers
docker-compose down

# Remove volumes (WARNING: destroys data)
docker-compose down -v

# Remove images
docker-compose down --rmi all
```

## Next Steps

- **Production Deployment**: Copy to `deployments/production/blog-app`
- **SSL/TLS**: Add reverse proxy with Let's Encrypt
- **Monitoring**: Add to monitoring stack
- **Backup Automation**: Schedule automated backups

---

**Template Source**: `catalog/containers/docker/compose-stacks/wordpress`  
**Environment**: Development  
**Last Updated**: 2025-11-05


/var/local/docker/volumes/gatus/production/config/config.yaml