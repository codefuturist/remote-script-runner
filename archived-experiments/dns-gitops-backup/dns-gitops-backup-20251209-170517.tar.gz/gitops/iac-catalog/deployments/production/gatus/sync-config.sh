#!/bin/bash

# Sync Gatus config to remote server bind volume
# Usage: ./sync-config.sh

HOST="colin@192.168.2.57"
DOCKER_VOLUMES_PATH="/var/local/docker/volumes"
SERVICE_NAME="gatus"
ENVIRONMENT="production"
REMOTE_CONFIG_PATH="${DOCKER_VOLUMES_PATH}/${SERVICE_NAME}/${ENVIRONMENT}/config"
LOCAL_CONFIG="config.yaml"

echo "Syncing config to ${HOST}:${REMOTE_CONFIG_PATH}/"

# Create remote directory if it doesn't exist
ssh ${HOST} "mkdir -p ${REMOTE_CONFIG_PATH}"

# Sync config file
scp ${LOCAL_CONFIG} ${HOST}:${REMOTE_CONFIG_PATH}/config.yaml

echo "Config synced successfully to bind volume"
echo "Path: ${REMOTE_CONFIG_PATH}/config.yaml"
