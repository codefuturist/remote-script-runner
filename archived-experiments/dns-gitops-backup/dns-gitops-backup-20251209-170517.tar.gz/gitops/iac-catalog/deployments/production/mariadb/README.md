# MariaDB Production Deployment

Production-ready MariaDB 11.2 database with SOPS-encrypted secrets and GitOps auto-sync.

## Features

- **MariaDB 11.2**: Latest stable release
- **File-based Secrets**: Individual encrypted files for each secret
- **Docker Secrets**: Uses Docker's file-based secret mechanism
- **SOPS Encryption**: Each secret encrypted with age
- **Auto-Sync**: Automatically deployed via GitOps system
- **Health Checks**: Built-in health monitoring
- **Persistent Storage**: Data volumes for database and config
- **Network Isolation**: Dedicated database network

## Architecture

```
mariadb/
├── docker-compose.yml           # MariaDB stack with Docker secrets
├── secrets/
│   ├── .gitignore              # Ignore decrypted secrets
│   ├── mysql_root_password.sops      # Encrypted root password (in Git)
│   ├── mysql_password.sops           # Encrypted user password (in Git)
│   ├── mysql_root_password.example   # Template
│   └── mysql_password.example        # Template
└── README.md                    # This file
```

## Deployment

### Automatic (GitOps)

The GitOps auto-sync system handles everything:

1. **Commit encrypted secrets** to Git
2. **Servers auto-sync** within 15 minutes
3. **Secrets decrypted** using age key
4. **MariaDB deployed** automatically

```bash
# Already done! Just wait for auto-sync
# Or trigger manually:
ssh user@server sudo /opt/gitops/gitops-sync.sh
```

### Manual Deployment

```bash
# 1. Decrypt secrets
sops --decrypt secrets/mysql_root_password.sops > secrets/mysql_root_password
sops --decrypt secrets/mysql_password.sops > secrets/mysql_password

# 2. Deploy
docker compose up -d

# 3. Check status
docker compose ps
docker compose logs -f mariadb
```

## Configuration

### Secret Files

Secrets are stored as individual files and mounted into containers:

| File | Description | Docker Secret |
|------|-------------|---------------|
| `secrets/mysql_root_password` | Root password | `/run/secrets/mysql_root_password` |
| `secrets/mysql_password` | Application user password | `/run/secrets/mysql_password` |

### Environment Variables

Non-sensitive config via environment variables:

| Variable | Description | Default |
|----------|-------------|---------|
| `MYSQL_DATABASE` | Default database name | `appdb` |
| `MYSQL_USER` | Application user | `dbuser` |
| `TZ` | Timezone | `UTC` |
| `DB_NETWORK` | Docker network name | `db` |
| `MARIADB_PORT` | Host port binding | `3306` |

## Usage

### Connect from Another Container

```yaml
services:
  myapp:
    image: myapp:latest
    environment:
      - DB_HOST=mariadb
      - DB_PORT=3306
      - DB_NAME=appdb
      - DB_USER=dbuser
      - DB_PASSWORD=${MYSQL_PASSWORD}
    networks:
      - db

networks:
  db:
    external: true
```

### Connect from Host

```bash
# Using mysql client
mysql -h localhost -P 3306 -u dbuser -p

# Using Docker
docker exec -it mariadb mysql -u dbuser -p
```

### Access Root

```bash
docker exec -it mariadb mysql -u root -p
# Enter MYSQL_ROOT_PASSWORD
```

## Management

### Update Secrets

```bash
# 1. Decrypt specific secret
sops --decrypt secrets/mysql_root_password.sops > secrets/mysql_root_password

# 2. Edit
vi secrets/mysql_root_password

# 3. Re-encrypt
sops --encrypt secrets/mysql_root_password > secrets/mysql_root_password.sops

# 4. Commit
rm secrets/mysql_root_password
git add secrets/mysql_root_password.sops
git commit -m "chore: update mariadb root password"
git push

# Servers auto-sync and restart MariaDB
```

### Add New Secret

```bash
# 1. Create secret file
echo "my-new-secret-value" > secrets/my_new_secret

# 2. Encrypt
sops --encrypt secrets/my_new_secret > secrets/my_new_secret.sops

# 3. Add to docker-compose.yml
# In services.mariadb.secrets:
#   - my_new_secret
# In top-level secrets:
#   my_new_secret:
#     file: ./secrets/my_new_secret

# 4. Commit
rm secrets/my_new_secret
git add secrets/my_new_secret.sops docker-compose.yml
git commit -m "feat: add new secret"
git push
```

### Backup Database

```bash
# All databases
docker exec mariadb mysqldump -u root -p'${MYSQL_ROOT_PASSWORD}' --all-databases > backup.sql

# Specific database
docker exec mariadb mysqldump -u root -p'${MYSQL_ROOT_PASSWORD}' appdb > appdb_backup.sql

# With compression
docker exec mariadb mysqldump -u root -p'${MYSQL_ROOT_PASSWORD}' appdb | gzip > appdb_backup.sql.gz
```

### Restore Database

```bash
# From backup
docker exec -i mariadb mysql -u root -p'${MYSQL_ROOT_PASSWORD}' appdb < appdb_backup.sql

# From compressed backup
gunzip < appdb_backup.sql.gz | docker exec -i mariadb mysql -u root -p'${MYSQL_ROOT_PASSWORD}' appdb
```

### View Logs

```bash
docker compose logs -f mariadb
```

### Restart

```bash
docker compose restart mariadb
```

## Health Check

Built-in health monitoring:

```bash
# Check health status
docker inspect mariadb | grep -A 10 Health

# Manual health check
docker exec mariadb healthcheck.sh --connect --innodb_initialized
```

## Troubleshooting

### Cannot Connect

```bash
# Check if running
docker compose ps

# Check logs
docker compose logs mariadb

# Verify network
docker network inspect db

# Test connection from container
docker run --rm --network db mariadb:11.2 mysql -h mariadb -u dbuser -p
```

### Reset Root Password

```bash
# Stop MariaDB
docker compose down

# Start in safe mode
docker run --rm -v mariadb_data:/var/lib/mysql mariadb:11.2 mysqld --skip-grant-tables &

# Connect and reset
docker exec -it mariadb mysql -u root
# In MySQL:
# FLUSH PRIVILEGES;
# ALTER USER 'root'@'%' IDENTIFIED BY 'new_password';
# FLUSH PRIVILEGES;
# EXIT;

# Restart normally
docker compose up -d
```

### Performance Issues

```bash
# Check resource usage
docker stats mariadb

# Check slow queries
docker exec mariadb mysql -u root -p -e "SHOW FULL PROCESSLIST;"

# View configuration
docker exec mariadb mysql -u root -p -e "SHOW VARIABLES;"
```

## Security

- ✅ Secrets encrypted with SOPS
- ✅ Strong passwords required
- ✅ Network isolation (db network)
- ✅ Health checks enabled
- ✅ Automatic restarts on failure

## Production Considerations

1. **Backups**: Schedule regular database backups
2. **Monitoring**: Add metrics/alerts for database health
3. **Scaling**: Consider read replicas for high load
4. **SSL/TLS**: Enable encrypted connections for production
5. **Firewall**: Restrict port 3306 access at firewall level

## Resources

- [MariaDB Documentation](https://mariadb.com/kb/en/documentation/)
- [Docker Hub](https://hub.docker.com/_/mariadb)
- [GitOps Auto-Sync Docs](../../../docs/GITOPS_AUTOSYNC.md)
