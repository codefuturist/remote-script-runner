# GitOps Multi-Repository Support

## Overview

This enhancement adds clean support for managing multiple Git repositories in a GitOps workflow. The implementation follows best practices for:
- Repository isolation
- Error handling  
- Resource management
- Configuration management
- Scalability

## Architecture

### Directory Structure

```
/opt/gitops/
├── gitops-config.yml          # Central configuration file
├── gitops-sync-multi.sh       # Multi-repo sync script
├── repos/                     # Repository checkouts
│   ├── iac-catalog/
│   ├── app-configs/
│   └── secrets-vault/
├── keys/                      # Age encryption keys
│   ├── .age.key               # Default key
│   ├── .age-apps.key          # App-specific key
│   └── .age-secrets.key       # Secrets-specific key
└── logs/                      # Per-repo logs
    ├── gitops-sync.log        # Main log
    ├── iac-catalog.log        # Repo-specific log
    └── app-configs.log

/tmp/gitops-locks/             # Lock files
├── global.lock                # Global sync lock
├── iac-catalog.lock           # Per-repo locks
└── app-configs.lock

/var/log/gitops/               # Systemd logs location
└── gitops-sync.log
```

## Key Features

### 1. Configuration-Driven Design

All repositories are defined in `gitops-config.yml`:

```yaml
repositories:
  - name: iac-catalog
    enabled: true
    url: https://github.com/codefuturist/iac-catalog.git
    branch: develop
    local_path: /opt/gitops/repos/iac-catalog
    age_key: /opt/gitops/keys/.age.key
    priority: 1
    sync_paths:
      - deployments/production
    post_sync:
      restart_containers: true
      restart_strategy: changed
```

### 2. Repository Isolation

Each repository:
- Has its own directory under `/opt/gitops/repos/`
- Uses its own lock file to prevent concurrent syncs
- Has dedicated log file for troubleshooting
- Can use separate age encryption keys
- Syncs independently (failure doesn't affect others)

### 3. Multi-Level Locking

**Global Lock**: Prevents multiple full sync cycles
**Per-Repo Locks**: Allows concurrent repo syncs while preventing conflicts

### 4. Priority-Based Syncing

Repositories sync in priority order:
```yaml
repositories:
  - name: secrets-vault
    priority: 1              # Syncs first
  
  - name: iac-catalog
    priority: 2              # Syncs second
  
  - name: app-configs
    priority: 2              # Syncs in parallel with iac-catalog
```

### 5. Flexible Key Management

**Shared Key**: All repos use same key
```yaml
global:
  default_age_key: /opt/gitops/keys/.age.key

repositories:
  - name: iac-catalog
    # No age_key specified = uses default
```

**Per-Repo Keys**: Each repo has dedicated key
```yaml
repositories:
  - name: secrets-vault
    age_key: /opt/gitops/keys/.age-secrets.key
  
  - name: app-configs
    age_key: /opt/gitops/keys/.age-apps.key
```

### 6. Selective Syncing

Only process specific paths within repositories:
```yaml
repositories:
  - name: iac-catalog
    sync_paths:
      - deployments/production
      - deployments/staging
    exclude_paths:
      - "*.md"
      - "*/archive-*"
```

### 7. Post-Sync Actions

**Always Restart**: Restart all containers
```yaml
post_sync:
  restart_containers: true
  restart_strategy: all
```

**Smart Restart**: Only restart changed stacks
```yaml
post_sync:
  restart_containers: true
  restart_strategy: changed
```

**No Restart**: Secrets-only repos
```yaml
post_sync:
  restart_containers: false
```

### 8. Health Checks

Verify services after restart:
```yaml
post_sync:
  health_check:
    enabled: true
    timeout: 60
    endpoints:
      - https://traefik.pandia.io/ping
      - https://authentik.pandia.io/
```

### 9. Encrypted Configuration

The config file itself can be encrypted:
```bash
# Encrypt config
sops -e gitops-config.yml > gitops-config.yml.sops

# Script auto-detects and decrypts
export CONFIG_FILE=/opt/gitops/gitops-config.yml.sops
./gitops-sync-multi.sh
```

## Migration Guide

### From Single-Repo to Multi-Repo

#### Step 1: Install Multi-Repo Script

```bash
# Backup current setup
sudo cp /opt/gitops/gitops-sync.sh /opt/gitops/gitops-sync.sh.backup

# Copy new script
sudo cp gitops-sync-multi.sh /opt/gitops/gitops-sync-multi.sh
sudo chmod +x /opt/gitops/gitops-sync-multi.sh
```

#### Step 2: Create Configuration

```bash
# Copy example config
sudo cp gitops-config.yml /opt/gitops/gitops-config.yml

# Edit for your setup
sudo nano /opt/gitops/gitops-config.yml
```

#### Step 3: Migrate Existing Repository

Update config to match your current setup:
```yaml
repositories:
  - name: iac-catalog
    enabled: true
    url: https://github.com/codefuturist/iac-catalog.git
    branch: develop
    local_path: /opt/gitops/iac-catalog  # Keep existing path!
    age_key: /opt/gitops/.age.key        # Keep existing key!
    sync_paths:
      - deployments/production
    post_sync:
      restart_containers: true
```

#### Step 4: Test Migration

```bash
# Test sync manually
sudo /opt/gitops/gitops-sync-multi.sh

# Check logs
sudo tail -f /var/log/gitops/gitops-sync.log
```

#### Step 5: Update Systemd Service

```bash
# Edit service
sudo nano /etc/systemd/system/gitops-sync.service

# Change ExecStart to:
ExecStart=/opt/gitops/gitops-sync-multi.sh

# Reload and restart
sudo systemctl daemon-reload
sudo systemctl restart gitops-sync.service
```

### Adding Additional Repositories

#### Step 1: Update Configuration

```yaml
repositories:
  # Existing repo
  - name: iac-catalog
    enabled: true
    url: https://github.com/codefuturist/iac-catalog.git
    # ... existing config ...

  # New repo
  - name: app-configs
    enabled: true
    url: https://github.com/codefuturist/app-configs.git
    branch: main
    local_path: /opt/gitops/repos/app-configs
    age_key: /opt/gitops/keys/.age-apps.key
    priority: 2
    sync_paths:
      - configs/production
    post_sync:
      restart_containers: true
```

#### Step 2: Create Age Key (if needed)

```bash
# Generate new key
mkdir -p /opt/gitops/keys
age-keygen -o /opt/gitops/keys/.age-apps.key
chmod 600 /opt/gitops/keys/.age-apps.key

# Get public key for encryption
age-keygen -y /opt/gitops/keys/.age-apps.key
```

#### Step 3: Test New Repository

```bash
# Manual sync
sudo /opt/gitops/gitops-sync-multi.sh

# Check logs
sudo tail -f /var/log/gitops/app-configs.log
```

## Best Practices

### 1. Repository Organization

**Good**:
```
repos/
├── iac-catalog/        # Infrastructure as Code
├── app-configs/        # Application configurations
└── secrets-vault/      # Encrypted secrets only
```

**Avoid**:
```
repos/
├── everything/         # Single mega-repo (hard to manage)
```

### 2. Key Management

**For Teams**:
- One key per team/project
- Rotate keys regularly
- Use different keys for dev/staging/prod

**For Security Levels**:
- `secrets-vault`: Highly restricted key
- `app-configs`: Team-wide key
- `iac-catalog`: Shared infrastructure key

### 3. Priority Assignment

```yaml
# Secrets first
- name: secrets-vault
  priority: 1

# Infrastructure second (may need secrets)
- name: iac-catalog
  priority: 2

# Applications last (need infrastructure)
- name: app-configs
  priority: 3
```

### 4. Restart Strategies

**Production**:
```yaml
restart_strategy: changed  # Only restart what changed
health_check:
  enabled: true            # Verify health after restart
```

**Development**:
```yaml
restart_strategy: all      # Always restart everything
health_check:
  enabled: false           # Skip health checks
```

### 5. Sync Paths

**Minimize processing**:
```yaml
sync_paths:
  - deployments/production    # Only what's needed
exclude_paths:
  - "*.md"                    # Skip documentation
  - "*/tests/*"               # Skip test files
```

## Monitoring

### Logs

```bash
# Main log (all repos)
tail -f /var/log/gitops/gitops-sync.log

# Specific repo
tail -f /var/log/gitops/iac-catalog.log

# Watch sync in real-time
watch -n 1 'tail -20 /var/log/gitops/gitops-sync.log'
```

### Metrics

The script tracks:
- Total repositories processed
- Successfully synced repos
- Failed repos
- Skipped repos (disabled)
- Secrets decrypted per repo
- Containers restarted per repo

### Health Checks

```bash
# Check service status
systemctl status gitops-sync.service

# Check last run
journalctl -u gitops-sync.service -n 50

# Check locks (should be empty when idle)
ls -lh /tmp/gitops-locks/
```

## Troubleshooting

### Issue: Repository won't sync

**Check**:
1. Is it enabled? `enabled: true`
2. Is URL accessible? `git ls-remote <url>`
3. Check repo-specific log: `/var/log/gitops/<repo-name>.log`

### Issue: Secrets won't decrypt

**Check**:
1. Age key exists and has correct permissions (600)
2. Key matches the one used to encrypt
3. SOPS metadata in encrypted file

### Issue: Containers won't restart

**Check**:
1. `restart_containers: true` in config
2. Docker compose files exist and valid
3. Check repo log for docker errors

### Issue: Lock timeout

**Check**:
1. Another sync still running: `ps aux | grep gitops-sync`
2. Stale lock: `ls -lh /tmp/gitops-locks/`
3. Remove stale locks: `sudo rm /tmp/gitops-locks/*.lock`

## Comparison: Single vs Multi-Repo

| Feature | Single-Repo | Multi-Repo |
|---------|-------------|------------|
| Configuration | Environment variables | YAML file |
| Repositories | 1 | Unlimited |
| Isolation | N/A | Per-repo locks & logs |
| Key Management | Single key | Multiple keys |
| Error Handling | Global | Per-repo |
| Scalability | Limited | High |
| Complexity | Low | Medium |
| Flexibility | Low | High |

## Performance Considerations

### Concurrent Syncs

```yaml
global:
  max_concurrent_syncs: 3  # Sync up to 3 repos in parallel
```

**Trade-offs**:
- Higher = faster but more resource usage
- Lower = slower but safer
- Recommended: 2-5 for most setups

### Sync Interval

```yaml
global:
  sync_interval: 300  # 5 minutes
```

**Guidelines**:
- Production: 5-15 minutes
- Staging: 2-5 minutes  
- Development: 1-2 minutes

## Security Considerations

1. **Age Keys**: Store in `/opt/gitops/keys/` with 600 permissions
2. **Config File**: Can be SOPS-encrypted for sensitive URLs/tokens
3. **Logs**: Rotate regularly, avoid logging secrets
4. **Lock Directory**: Use `/tmp` (cleared on reboot)
5. **Git Authentication**: Use tokens, not passwords

## Future Enhancements

Potential additions:
- [ ] Webhook support for push-based syncs
- [ ] Dependency management between repos
- [ ] Slack/Discord notifications
- [ ] Prometheus metrics export
- [ ] Web dashboard for monitoring
- [ ] Rollback capability
- [ ] Dry-run mode
- [ ] Parallel sync support

## Support

For issues or questions:
1. Check logs: `/var/log/gitops/gitops-sync.log`
2. Enable debug: `LOG_LEVEL=DEBUG`
3. Test manually: `sudo /opt/gitops/gitops-sync-multi.sh`
4. Review config: `cat /opt/gitops/gitops-config.yml`
