# Authentik GitOps Deployment Checklist

## Current Status

✅ **Deployment Active**
- Stack: `authentik_production`
- Services: 3 (server, worker, redis)
- Networks: proxy, postgres, authentik_production
- Certificate: Valid Let's Encrypt wildcard (*.pandia.io)
- GitOps: Repository synced to /opt/gitops/iac-catalog

## GitOps Configuration

### Repository Structure
```
deployments/production/authentik/
├── docker-compose.yml          # Main service definition
├── .env.example                # Environment template (committed)
├── .env                        # Actual environment (NOT committed)
├── target.yml                  # GitOps target configuration
├── manifest.yml                # Deployment manifest
├── secrets/                    # SOPS-encrypted secrets
│   └── authentik.enc.yaml      # Encrypted secrets file
└── postgres/                   # PostgreSQL configuration
```

### GitOps Sync Process

1. **Automatic Sync** (via systemd timer)
   - Service: `gitops-sync.service`
   - Timer: `gitops-sync.timer`
   - Frequency: Every 5 minutes
   - Repository: https://github.com/codefuturist/iac-catalog.git
   - Branch: develop

2. **Manual Sync**
   ```bash
   ssh colin@192.168.2.57 "sudo systemctl start gitops-sync.service"
   ```

3. **Check Sync Status**
   ```bash
   ssh colin@192.168.2.57 "sudo journalctl -u gitops-sync.service -n 50"
   ```

## Certificate Configuration

### Traefik Labels (Applied)
```yaml
traefik.enable: "true"
traefik.http.routers.authentik.rule: "Host(`authentik.pandia.io`)"
traefik.http.routers.authentik.entrypoints: "https"
traefik.http.routers.authentik.tls: "true"
traefik.http.routers.authentik.tls.certresolver: "letsencrypt"
traefik.http.routers.authentik.tls.domains[0].main: "*.pandia.io"
traefik.http.routers.authentik.tls.domains[0].sans: "pandia.io"
```

### Certificate Verification
```bash
# Check certificate on server
ssh colin@192.168.2.57 "echo | openssl s_client -connect authentik.pandia.io:443 -servername authentik.pandia.io 2>/dev/null | openssl x509 -noout -dates -subject -issuer"

# Expected output:
# notBefore=Nov 24 15:50:54 2025 GMT
# notAfter=Feb 22 16:50:53 2026 GMT
# subject=CN = *.pandia.io
# issuer=C = US, O = Let's Encrypt, CN = E8
```

## Networks

### Connected Networks
- **proxy**: Traefik reverse proxy network (external)
- **postgres**: PostgreSQL database network (external)
- **authentik_production_authentik**: Internal service network

### Verify Network Connectivity
```bash
# Check service networks
ssh colin@192.168.2.57 "docker service inspect authentik_production_server --format '{{json .Spec.TaskTemplate.Networks}}' | jq"

# List all networks
ssh colin@192.168.2.57 "docker network ls | grep -E 'proxy|postgres|authentik'"
```

## Secrets Management

### Docker Secrets (Applied)
- `authentik_postgres_password_production_v1`
- `authentik_secret_key_production_v1`

### Verify Secrets
```bash
# List secrets
ssh colin@192.168.2.57 "docker secret ls | grep authentik"

# Check secret usage
ssh colin@192.168.2.57 "docker service inspect authentik_production_server --format '{{json .Spec.TaskTemplate.ContainerSpec.Secrets}}' | jq"
```

### SOPS Encryption
Secrets are encrypted with SOPS and AGE:
```bash
# Decrypt secrets (on server with AGE key)
ssh colin@192.168.2.57 "cd /opt/gitops/iac-catalog/deployments/production/authentik && sops -d secrets/authentik.enc.yaml"
```

## Deployment Commands

### Update Stack
```bash
# On server (GitOps will auto-apply changes)
ssh colin@192.168.2.57 "cd /opt/gitops/iac-catalog/deployments/production/authentik && docker stack deploy -c docker-compose.yml authentik_production"
```

### View Logs
```bash
# Server logs
ssh colin@192.168.2.57 "docker service logs authentik_production_server --tail 100 -f"

# Worker logs
ssh colin@192.168.2.57 "docker service logs authentik_production_worker --tail 100 -f"
```

### Scale Services
```bash
# Scale server replicas
ssh colin@192.168.2.57 "docker service scale authentik_production_server=2"
```

## Health Checks

### Service Status
```bash
# Check all services
ssh colin@192.168.2.57 "docker stack ps authentik_production --no-trunc"

# Check service health
ssh colin@192.168.2.57 "docker service ls | grep authentik"
```

### Application Health
```bash
# HTTP check
curl -I https://authentik.pandia.io

# Expected: HTTP/2 302 (redirect to login)
```

## Troubleshooting

### Common Issues

1. **Certificate not applying**
   - Check Traefik logs: `docker service logs traefik_traefik`
   - Verify Cloudflare API token in Traefik configuration
   - Ensure DNS is pointing correctly

2. **Service not reachable**
   - Verify service is on proxy network: `docker service inspect authentik_production_server`
   - Check Traefik router configuration
   - Verify DNS resolution

3. **Database connection issues**
   - Check postgres network connectivity
   - Verify secrets are properly mounted
   - Check PostgreSQL service status

### Debug Commands
```bash
# Check Traefik router
ssh colin@192.168.2.57 "docker exec \$(docker ps -q -f name=traefik) cat /etc/traefik/traefik.yml"

# Inspect service configuration
ssh colin@192.168.2.57 "docker service inspect authentik_production_server --pretty"

# Check network connectivity
ssh colin@192.168.2.57 "docker exec \$(docker ps -q -f name=authentik_production_server) ping -c 3 postgres_postgres"
```

## Maintenance

### Backup
- **Database**: Handled by PostgreSQL stack backup
- **Media files**: Volume `authentik_media_swarm-production`
- **Templates**: Volume `authentik_templates_swarm-production`
- **Certificates**: Volume `authentik_certs_swarm-production`

### Updates
1. Update version in `.env` or directly in `docker-compose.yml`
2. Commit changes to repository
3. GitOps will automatically sync and deploy
4. Or manually: `docker stack deploy -c docker-compose.yml authentik_production`

### Certificate Renewal
Automatic via Traefik. Certificates renew 30 days before expiry.

## Security Considerations

✅ **Implemented**
- HTTPS-only access via Traefik
- Secrets managed with Docker Swarm secrets
- Network isolation with overlay networks
- SOPS encryption for sensitive configuration
- GitOps workflow (no manual changes on server)

## References

- [Authentik Documentation](https://goauthentik.io/docs/)
- [Traefik Let's Encrypt](https://doc.traefik.io/traefik/https/acme/)
- [Docker Swarm Secrets](https://docs.docker.com/engine/swarm/secrets/)
- [SOPS Documentation](https://github.com/mozilla/sops)
