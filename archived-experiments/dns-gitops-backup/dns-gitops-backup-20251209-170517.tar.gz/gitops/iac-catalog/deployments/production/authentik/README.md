# Authentik Production Deployment

## Overview

Authentik is deployed as a Docker Swarm stack with:
- **Valid Let's Encrypt wildcard certificate** (*.pandia.io)
- **GitOps-friendly configuration**
- **SOPS-encrypted secrets**
- **Automatic certificate renewal via Traefik**

## Certificate Status

✅ **ACTIVE**: Valid Let's Encrypt wildcard certificate
- Domain: `*.pandia.io`
- Issuer: Let's Encrypt (E8)
- Valid until: February 22, 2026
- Certificate resolver: Traefik with Cloudflare DNS challenge

## Architecture

```
┌─────────────────┐
│   Traefik       │
│  (Reverse Proxy)│
│   + Let's       │
│   Encrypt       │
└────────┬────────┘
         │ HTTPS (*.pandia.io)
         │
         ▼
┌─────────────────┐     ┌──────────────┐
│  Authentik      │────▶│   Redis      │
│   Server        │     │   (Cache)    │
└────────┬────────┘     └──────────────┘
         │
         │
         ▼
┌─────────────────┐     ┌──────────────┐
│  Authentik      │────▶│  PostgreSQL  │
│   Worker        │     │  (Database)  │
└─────────────────┘     └──────────────┘
```

## GitOps Deployment

### Prerequisites

1. **SOPS Configuration**
   - AGE key available at `/root/.config/sops/age/keys.txt`
   - Public key configured in repository

2. **Docker Swarm**
   - Active swarm mode
   - Networks: `proxy`, `postgres`

3. **Traefik**
   - Configured with Let's Encrypt
   - Cloudflare DNS challenge enabled

### Secrets Management

All sensitive data is encrypted with SOPS:

```bash
# Directory structure
secrets/
├── .gitignore              # Protects plain text secrets
├── secret_key.example      # Example format
├── secret_key.sops         # SOPS encrypted (committed)
├── postgres_password.example
└── postgres_password.sops  # SOPS encrypted (committed)
```

#### Creating/Updating Secrets

```bash
# 1. Create or edit secret
echo "your-secret-value" > secrets/secret_key.txt

# 2. Encrypt with SOPS
sops --encrypt secrets/secret_key.txt > secrets/secret_key.sops

# 3. Remove plain text
rm secrets/secret_key.txt

# 4. Commit encrypted file
git add secrets/secret_key.sops
git commit -m "feat: update authentik secret key"
```

#### Syncing Secrets to Docker

```bash
# Sync all secrets for production
./sync-secrets.sh production v1

# Check secrets
docker secret ls | grep authentik
```

### Deployment Process

#### Manual Deployment

```bash
# 1. Sync secrets first
./sync-secrets.sh production v1

# 2. Deploy stack
docker stack deploy -c docker-compose.yml authentik_production

# 3. Verify
docker service ls | grep authentik
docker service logs authentik_production_server
```

#### GitOps Auto-Sync

This deployment is automatically synced via the multi-repo GitOps service:

```bash
# Configuration in: deployments/production/gitops-config.yml
# Service: gitops-sync-multi.service
# Sync interval: Every 5 minutes

# Manual trigger
sudo systemctl start gitops-sync-multi.service

# Check status
sudo systemctl status gitops-sync-multi.service
sudo journalctl -u gitops-sync-multi.service -f
```

## Configuration

### Environment Variables

Located in `.env`:

```bash
# Core settings
ENVIRONMENT=production
AUTHENTIK_DOMAIN=authentik.pandia.io
AUTHENTIK_TAG=2025.10.2

# Secrets versioning
SECRETS_VERSION=v1

# PostgreSQL
POSTGRES_DB=authentik
POSTGRES_USER=authentik
AUTHENTIK_POSTGRESQL__HOST=postgres_postgres
```

### Traefik Labels

Configured in `docker-compose.yml`:

```yaml
labels:
  - traefik.enable=true
  - traefik.http.routers.authentik.rule=Host(`authentik.pandia.io`)
  - traefik.http.routers.authentik.entrypoints=https
  - traefik.http.routers.authentik.tls=true
  - traefik.http.routers.authentik.tls.certresolver=letsencrypt
  # Wildcard certificate configuration
  - traefik.http.routers.authentik.tls.domains[0].main=*.pandia.io
  - traefik.http.routers.authentik.tls.domains[0].sans=pandia.io
```

## Verification

### Check Certificate

```bash
# Via OpenSSL
echo | openssl s_client -connect authentik.pandia.io:443 -servername authentik.pandia.io 2>/dev/null | openssl x509 -noout -dates -subject -issuer

# Via curl
curl -skI https://authentik.pandia.io | grep -i server
```

### Check Service Health

```bash
# Service status
docker service ps authentik_production_server --no-trunc

# Logs
docker service logs -f authentik_production_server

# Health checks
docker ps | grep authentik
```

### Access Authentik

```bash
# Web interface
https://authentik.pandia.io

# Direct access (if needed)
http://localhost:19000
https://localhost:19443
```

## Maintenance

### Updating Authentik

```bash
# 1. Update version in .env
sed -i 's/AUTHENTIK_TAG=.*/AUTHENTIK_TAG=2025.11.0/' .env

# 2. Commit change
git add .env
git commit -m "chore: update authentik to 2025.11.0"
git push

# 3. GitOps will auto-sync or manual deploy
docker stack deploy -c docker-compose.yml authentik_production
```

### Certificate Renewal

**Automatic**: Traefik handles renewal automatically with Cloudflare DNS challenge.

Check renewal logs:
```bash
docker service logs traefik | grep -i cert
```

### Rotating Secrets

```bash
# 1. Create new secret version
SECRETS_VERSION=v2 ./sync-secrets.sh production v2

# 2. Update .env
sed -i 's/SECRETS_VERSION=v1/SECRETS_VERSION=v2/' .env

# 3. Redeploy
docker stack deploy -c docker-compose.yml authentik_production

# 4. Remove old secrets (after verification)
docker secret rm authentik_secret_key_production_v1
docker secret rm authentik_postgres_password_production_v1
```

## Troubleshooting

### Certificate Issues

```bash
# Check Traefik certificates
docker exec traefik ls -la /acme/

# Check Traefik logs
docker service logs traefik | grep authentik

# Force certificate renewal
docker service update --force traefik
```

### Connection Issues

```bash
# Check networks
docker network inspect proxy
docker network inspect postgres

# Check DNS resolution
docker exec authentik_production_server nslookup authentik.pandia.io

# Check Traefik routing
docker exec traefik cat /etc/traefik/traefik.yml
```

### Database Issues

```bash
# Check PostgreSQL connection
docker exec -it authentik_production_server python -m authentik check_database

# Check PostgreSQL service
docker service ps postgres_postgres

# Check PostgreSQL logs
docker service logs postgres_postgres | grep authentik
```

## Security

### Secrets Protection

- ✅ All secrets SOPS encrypted
- ✅ Plain text secrets in .gitignore
- ✅ Docker secrets used (not environment variables)
- ✅ Secrets versioning enabled
- ✅ No secrets in docker-compose.yml

### Network Security

- ✅ TLS/HTTPS enforced
- ✅ Valid Let's Encrypt certificate
- ✅ Isolated networks (authentik, proxy, postgres)
- ✅ No direct port exposure (via Traefik only)

### Best Practices

- ✅ GitOps workflow
- ✅ Infrastructure as Code
- ✅ Automated secret rotation capability
- ✅ Health checks enabled
- ✅ Resource limits configured

## References

- [Authentik Documentation](https://goauthentik.io/docs/)
- [Traefik Documentation](https://doc.traefik.io/traefik/)
- [SOPS Documentation](https://github.com/mozilla/sops)
- [Let's Encrypt](https://letsencrypt.org/)

## Support

For issues or questions:
1. Check logs: `docker service logs authentik_production_server`
2. Verify certificate: `openssl s_client -connect authentik.pandia.io:443`
3. Check GitOps sync: `sudo journalctl -u gitops-sync-multi.service -f`
