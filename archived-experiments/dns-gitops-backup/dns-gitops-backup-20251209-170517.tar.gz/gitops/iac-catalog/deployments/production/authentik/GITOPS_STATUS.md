# Authentik GitOps Status

## Current Status

✅ **OPERATIONAL**

- **Service**: Authentik SSO/Identity Provider
- **Domain**: `https://authentik.pandia.io`
- **Certificate**: Valid Let's Encrypt wildcard (*.pandia.io)
- **Certificate Expiry**: February 22, 2026
- **Deployment Method**: Docker Swarm Stack via GitOps
- **GitOps Sync**: Active (every 5 minutes)

## Deployment Configuration

### Certificate Setup

```yaml
# Configured via Traefik labels in docker-compose.yml
traefik.http.routers.authentik.tls.certresolver: letsencrypt
traefik.http.routers.authentik.tls.domains[0].main: *.pandia.io
traefik.http.routers.authentik.tls.domains[0].sans: pandia.io
```

**Certificate Details:**
- Type: Let's Encrypt
- Challenge: DNS-01 (Cloudflare)
- Renewal: Automatic via Traefik
- Storage: `/acme/acme.json` (Traefik volume)

### GitOps Integration

```yaml
# From: deployments/production/gitops-config.yml
repositories:
  - name: iac-catalog
    enabled: true
    url: https://github.com/codefuturist/iac-catalog.git
    branch: develop
    local_path: /opt/gitops/repos/iac-catalog
    sync_paths:
      - deployments/production
    post_sync:
      health_check:
        endpoints:
          - https://authentik.pandia.io/
```

**Sync Process:**
1. Every 5 minutes, GitOps service pulls latest changes
2. SOPS-encrypted secrets are decrypted on server
3. Docker secrets are updated if changed
4. Stack is redeployed if configuration changes
5. Health check verifies service is responding

### Secrets Management

All secrets are SOPS-encrypted in Git:

```
secrets/
├── secret_key.sops               # Authentik secret key
└── postgres_password.sops        # PostgreSQL password
```

**Secret Sync:**
- Automatic via GitOps: `gitops-sync-multi.service`
- Manual sync: `./sync-secrets.sh production v1`
- Versioned: `SECRETS_VERSION=v1` in `.env`

## Repository Structure

```
deployments/production/authentik/
├── docker-compose.yml            # Swarm stack definition
├── .env                          # Environment variables
├── README.md                     # Main documentation
├── SOPS_INTEGRATION.md          # Secrets encryption guide
├── GITOPS_STATUS.md             # This file
├── sync-secrets.sh              # Secret sync script
└── secrets/
    ├── .gitignore               # Protects plain text
    ├── secret_key.example       # Template
    ├── secret_key.sops          # Encrypted ✅
    ├── postgres_password.example
    └── postgres_password.sops   # Encrypted ✅
```

## Verification Commands

### Check Certificate

```bash
# OpenSSL check
echo | openssl s_client -connect authentik.pandia.io:443 -servername authentik.pandia.io 2>/dev/null | openssl x509 -noout -dates -subject -issuer

# Expected output:
# notBefore=Nov 24 15:50:54 2025 GMT
# notAfter=Feb 22 15:50:53 2026 GMT
# subject=CN = *.pandia.io
# issuer=C = US, O = Let's Encrypt, CN = E8
```

### Check Service Health

```bash
# HTTPS check
curl -skI https://authentik.pandia.io

# Docker service status
docker service ps authentik_production_server

# Service logs
docker service logs authentik_production_server --tail 50
```

### Check GitOps Sync

```bash
# Service status
sudo systemctl status gitops-sync-multi.service

# View recent syncs
sudo journalctl -u gitops-sync-multi.service --since "1 hour ago"

# Manual sync trigger
sudo systemctl start gitops-sync-multi.service
```

## Change Management

### Making Changes

1. **Update Configuration**
   ```bash
   # Edit docker-compose.yml or .env
   git add deployments/production/authentik/
   git commit -m "chore(authentik): update configuration"
   git push origin develop
   ```

2. **Automatic Deployment**
   - GitOps service pulls changes within 5 minutes
   - Changes are applied automatically
   - Health check verifies deployment

3. **Manual Deployment (Optional)**
   ```bash
   ssh colin@192.168.2.57
   cd /opt/gitops/repos/iac-catalog/deployments/production/authentik
   docker stack deploy -c docker-compose.yml authentik_production
   ```

### Updating Secrets

1. **Update Encrypted Secret**
   ```bash
   # Edit secret directly (SOPS will decrypt/re-encrypt)
   sops deployments/production/authentik/secrets/secret_key.sops
   
   git add deployments/production/authentik/secrets/
   git commit -m "security(authentik): update secret key"
   git push origin develop
   ```

2. **Sync to Docker**
   ```bash
   # Automatic via GitOps within 5 minutes
   # Or manual:
   ssh colin@192.168.2.57
   cd /opt/gitops/repos/iac-catalog/deployments/production/authentik
   ./sync-secrets.sh production v1
   ```

### Rotating Secrets

1. **Create New Version**
   ```bash
   # Update secrets with new version
   sops secrets/secret_key.sops
   
   # Update .env
   sed -i 's/SECRETS_VERSION=v1/SECRETS_VERSION=v2/' .env
   
   # Commit
   git add .
   git commit -m "security(authentik): rotate secrets to v2"
   git push
   ```

2. **Sync New Version**
   ```bash
   ssh colin@192.168.2.57
   cd /opt/gitops/repos/iac-catalog/deployments/production/authentik
   ./sync-secrets.sh production v2
   ```

3. **Redeploy**
   ```bash
   docker stack deploy -c docker-compose.yml authentik_production
   ```

4. **Clean Up Old Version**
   ```bash
   # After verification
   docker secret rm authentik_secret_key_production_v1
   docker secret rm authentik_postgres_password_production_v1
   ```

## Monitoring

### Health Endpoints

- **Web UI**: `https://authentik.pandia.io`
- **Health Check**: Included in GitOps post-sync validation

### Logs

```bash
# Application logs
docker service logs -f authentik_production_server

# GitOps sync logs
sudo journalctl -u gitops-sync-multi.service -f

# Traefik certificate logs
docker service logs traefik | grep -i cert | grep authentik
```

### Metrics

- **Uptime**: Monitored via Traefik
- **Certificate**: Auto-renewed by Traefik/Let's Encrypt
- **Service Health**: Docker Swarm health checks

## Troubleshooting

### Issue: Certificate Not Valid

```bash
# Check Traefik certificate storage
docker exec traefik ls -la /acme/

# Check Traefik logs for certificate errors
docker service logs traefik | grep -i error | grep -i cert

# Force certificate renewal
docker service update --force traefik
```

### Issue: Service Not Responding

```bash
# Check service status
docker service ps authentik_production_server --no-trunc

# Check logs
docker service logs authentik_production_server --tail 100

# Check network connectivity
docker network inspect proxy
```

### Issue: GitOps Not Syncing

```bash
# Check service status
sudo systemctl status gitops-sync-multi.service

# Check for errors
sudo journalctl -u gitops-sync-multi.service --since "1 hour ago" | grep -i error

# Manually trigger sync
sudo systemctl start gitops-sync-multi.service
```

### Issue: Secrets Not Decrypting

```bash
# Check AGE key exists
sudo ls -la /root/.config/sops/age/keys.txt

# Test SOPS decryption
cd /opt/gitops/repos/iac-catalog/deployments/production/authentik
sops --decrypt secrets/secret_key.sops

# Check Docker secrets
docker secret ls | grep authentik
```

## Security Checklist

- ✅ Valid Let's Encrypt wildcard certificate
- ✅ HTTPS enforced via Traefik
- ✅ Secrets encrypted with SOPS in Git
- ✅ Docker secrets used (not environment variables)
- ✅ Secrets versioning enabled
- ✅ GitOps automated deployment
- ✅ Health checks configured
- ✅ Network isolation (proxy, postgres, authentik networks)
- ✅ Resource limits configured
- ✅ Automatic certificate renewal

## Next Steps

### Recommended Actions

1. **Set Up Monitoring**
   - Configure alerts for certificate expiry
   - Monitor service health
   - Track GitOps sync failures

2. **Backup Strategy**
   - Regular PostgreSQL backups
   - AGE key backup (secure storage)
   - Configuration backup (already in Git)

3. **Regular Maintenance**
   - Review logs weekly
   - Update Authentik image quarterly
   - Rotate secrets annually
   - Test disaster recovery procedure

## References

- [Authentik Documentation](https://goauthentik.io/docs/)
- [Main README](./README.md)
- [SOPS Integration Guide](./SOPS_INTEGRATION.md)
- [GitOps Multi-Repo Config](../gitops-config.yml)

---

**Last Updated**: 2025-11-24  
**Status**: ✅ Operational  
**Certificate Valid Until**: 2026-02-22
