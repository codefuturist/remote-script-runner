#!/bin/bash
set -euo pipefail

# Authentik Secrets Sync Script
# Syncs SOPS encrypted secrets to Docker Swarm secrets
# Usage: ./sync-secrets.sh [environment]

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SECRETS_DIR="${SCRIPT_DIR}/secrets"
ENVIRONMENT="${1:-production}"
SECRETS_VERSION="${2:-v1}"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if SOPS is installed
if ! command -v sops &> /dev/null; then
    log_error "SOPS is not installed. Install with: brew install sops"
    exit 1
fi

# Check if we're in a Docker Swarm
if ! docker info 2>/dev/null | grep -q "Swarm: active"; then
    log_error "Docker Swarm is not active"
    exit 1
fi

# Function to create or update Docker secret from SOPS file
sync_secret() {
    local secret_file="$1"
    local secret_name="$2"
    local docker_secret_name="${secret_name}_${ENVIRONMENT}_${SECRETS_VERSION}"
    
    if [ ! -f "${secret_file}" ]; then
        log_warn "Secret file not found: ${secret_file}"
        return 1
    fi
    
    log_info "Processing secret: ${secret_name}"
    
    # Decrypt with SOPS
    if ! sops --decrypt "${secret_file}" > /tmp/secret_temp 2>/dev/null; then
        log_error "Failed to decrypt ${secret_file}"
        rm -f /tmp/secret_temp
        return 1
    fi
    
    # Check if secret already exists
    if docker secret inspect "${docker_secret_name}" &>/dev/null; then
        log_info "Secret ${docker_secret_name} already exists"
        
        # Get existing secret value (we can't actually read it, so we'll just recreate with new version)
        log_warn "Cannot update existing secret. To update, increment SECRETS_VERSION or remove old secret"
    else
        # Create new secret
        if docker secret create "${docker_secret_name}" /tmp/secret_temp 2>/dev/null; then
            log_info "Created secret: ${docker_secret_name}"
        else
            log_error "Failed to create secret: ${docker_secret_name}"
            rm -f /tmp/secret_temp
            return 1
        fi
    fi
    
    # Clean up
    rm -f /tmp/secret_temp
    return 0
}

# Main execution
main() {
    log_info "Starting Authentik secrets sync for environment: ${ENVIRONMENT}"
    log_info "Secrets version: ${SECRETS_VERSION}"
    
    local failed=0
    
    # Sync secret_key
    if [ -f "${SECRETS_DIR}/secret_key.sops" ]; then
        if ! sync_secret "${SECRETS_DIR}/secret_key.sops" "authentik_secret_key"; then
            ((failed++))
        fi
    else
        log_warn "secret_key.sops not found, skipping..."
    fi
    
    # Sync postgres_password
    if [ -f "${SECRETS_DIR}/postgres_password.sops" ]; then
        if ! sync_secret "${SECRETS_DIR}/postgres_password.sops" "authentik_postgres_password"; then
            ((failed++))
        fi
    else
        log_warn "postgres_password.sops not found, skipping..."
    fi
    
    # Summary
    echo ""
    if [ $failed -eq 0 ]; then
        log_info "All secrets synced successfully!"
        log_info "Secrets are available as:"
        log_info "  - authentik_secret_key_${ENVIRONMENT}_${SECRETS_VERSION}"
        log_info "  - authentik_postgres_password_${ENVIRONMENT}_${SECRETS_VERSION}"
    else
        log_error "$failed secret(s) failed to sync"
        exit 1
    fi
    
    # List current secrets
    echo ""
    log_info "Current Authentik secrets:"
    docker secret ls | grep "authentik" || log_warn "No Authentik secrets found"
}

# Run main function
main "$@"
