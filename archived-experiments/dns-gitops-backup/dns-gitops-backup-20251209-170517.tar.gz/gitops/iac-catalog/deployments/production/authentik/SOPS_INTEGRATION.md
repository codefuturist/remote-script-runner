# Authentik SOPS Integration Guide

## Overview

This guide explains how to manage Authentik secrets using SOPS (Secrets OPerationS) encryption with AGE for secure GitOps workflows.

## Prerequisites

### 1. Install SOPS

```bash
# macOS
brew install sops

# Linux
wget https://github.com/mozilla/sops/releases/download/v3.8.1/sops-v3.8.1.linux.amd64
sudo mv sops-v3.8.1.linux.amd64 /usr/local/bin/sops
sudo chmod +x /usr/local/bin/sops
```

### 2. Install AGE

```bash
# macOS
brew install age

# Linux
sudo apt-get install age
```

### 3. AGE Key Setup

The AGE public key for encryption is configured in the repository's `.sops.yaml` file.

For decryption on the server, ensure the private key is available:

```bash
# Server: /root/.config/sops/age/keys.txt
# Format: AGE-SECRET-KEY-1...
```

## Secret Files Structure

```
deployments/production/authentik/secrets/
├── .gitignore                    # Protects plain text files
├── secret_key.example            # Template
├── secret_key.sops              # Encrypted (safe to commit)
├── postgres_password.example     # Template
└── postgres_password.sops       # Encrypted (safe to commit)
```

## Creating New Secrets

### Method 1: Direct Encryption

```bash
# Create secret content
echo -n "your-secret-value-here" | sops --encrypt --input-type binary --output-type binary /dev/stdin > secrets/secret_key.sops

# Verify encryption
sops --decrypt secrets/secret_key.sops
```

### Method 2: Edit Existing Secret

```bash
# Edit encrypted file directly (opens in editor)
sops secrets/secret_key.sops

# SOPS will decrypt, open editor, then re-encrypt on save
```

### Method 3: From Plain Text File

```bash
# Create temporary plain text file
echo "your-secret-value" > /tmp/secret.txt

# Encrypt
sops --encrypt /tmp/secret.txt > secrets/secret_key.sops

# Clean up
rm /tmp/secret.txt
```

## Authentik-Specific Secrets

### 1. Authentik Secret Key

The main secret key for Authentik encryption:

```bash
# Generate a secure random key
openssl rand -base64 50 > /tmp/authentik_secret_key.txt

# Encrypt with SOPS
sops --encrypt /tmp/authentik_secret_key.txt > secrets/secret_key.sops

# Clean up
rm /tmp/authentik_secret_key.txt

# Verify
sops --decrypt secrets/secret_key.sops
```

### 2. PostgreSQL Password

Database password for Authentik:

```bash
# Generate secure password
openssl rand -base64 32 > /tmp/postgres_password.txt

# Encrypt
sops --encrypt /tmp/postgres_password.txt > secrets/postgres_password.sops

# Clean up
rm /tmp/postgres_password.txt
```

## Syncing Secrets to Docker Swarm

Once secrets are encrypted and committed to Git, they need to be synced to Docker Swarm secrets:

### Manual Sync

```bash
# From the authentik directory
./sync-secrets.sh production v1

# Verify
docker secret ls | grep authentik
```

### Automated Sync (GitOps)

The secrets are automatically synced via the GitOps multi-repo service:

```bash
# Check GitOps sync service
sudo systemctl status gitops-sync-multi.service

# View sync logs
sudo journalctl -u gitops-sync-multi.service -f

# Manual trigger
sudo systemctl start gitops-sync-multi.service
```

## Secret Rotation

### Rotating Secrets

```bash
# 1. Generate new secret
openssl rand -base64 50 > /tmp/new_secret.txt

# 2. Encrypt with new version
sops --encrypt /tmp/new_secret.txt > secrets/secret_key.sops

# 3. Commit to Git
git add secrets/secret_key.sops
git commit -m "security: rotate authentik secret key"
git push

# 4. Sync with new version number
SECRETS_VERSION=v2 ./sync-secrets.sh production v2

# 5. Update .env to use new version
sed -i 's/SECRETS_VERSION=v1/SECRETS_VERSION=v2/' .env

# 6. Redeploy
docker stack deploy -c docker-compose.yml authentik_production

# 7. After verification, remove old secret
docker secret rm authentik_secret_key_production_v1
```

## Verification

### Check Encryption Status

```bash
# View encrypted content (shows metadata)
cat secrets/secret_key.sops

# Decrypt to verify
sops --decrypt secrets/secret_key.sops
```

### Check Docker Secrets

```bash
# List all Authentik secrets
docker secret ls | grep authentik

# Inspect secret metadata (cannot view actual content)
docker secret inspect authentik_secret_key_production_v1
```

### Test Decryption in Service

```bash
# View logs to check secret mounting
docker service logs authentik_production_server | grep -i secret

# The service should show secrets loaded from /run/secrets/
```

## Troubleshooting

### Cannot Decrypt Secret

```bash
# Check AGE key is present
ls -la ~/.config/sops/age/keys.txt  # Local
ssh colin@192.168.2.57 "sudo ls -la /root/.config/sops/age/keys.txt"  # Server

# Verify SOPS configuration
cat ../../.sops.yaml  # Check public key matches
```

### Wrong AGE Key

If you need to re-encrypt with a different key:

```bash
# Decrypt with old key
sops --decrypt secrets/secret_key.sops > /tmp/secret.txt

# Update .sops.yaml with new public key

# Re-encrypt
sops --encrypt /tmp/secret.txt > secrets/secret_key.sops

# Clean up
rm /tmp/secret.txt
```

### Sync Script Fails

```bash
# Check SOPS installation
which sops
sops --version

# Check Docker Swarm status
docker info | grep Swarm

# Check file permissions
ls -la secrets/*.sops

# Run sync with verbose output
bash -x ./sync-secrets.sh production v1
```

## Security Best Practices

### ✅ Do

- Always use SOPS to encrypt secrets before committing
- Use .gitignore to prevent plain text secrets in Git
- Rotate secrets regularly (quarterly recommended)
- Use versioned secrets for safe rotation
- Keep AGE private keys secure and backed up
- Use strong random values for all secrets

### ❌ Don't

- Never commit plain text secrets to Git
- Never share AGE private keys via insecure channels
- Don't skip secret encryption
- Don't use weak or predictable secret values
- Don't remove old secret versions until verified new ones work

## References

- [SOPS Documentation](https://github.com/mozilla/sops)
- [AGE Encryption](https://github.com/FiloSottile/age)
- [Docker Secrets](https://docs.docker.com/engine/swarm/secrets/)
- [Authentik Configuration](https://goauthentik.io/docs/installation/configuration)

## Example Workflow

Complete workflow for setting up Authentik secrets:

```bash
# 1. Navigate to authentik directory
cd deployments/production/authentik

# 2. Generate secrets
openssl rand -base64 50 > /tmp/secret_key.txt
openssl rand -base64 32 > /tmp/postgres_password.txt

# 3. Encrypt secrets
sops --encrypt /tmp/secret_key.txt > secrets/secret_key.sops
sops --encrypt /tmp/postgres_password.txt > secrets/postgres_password.sops

# 4. Clean up plain text
rm /tmp/secret_key.txt /tmp/postgres_password.txt

# 5. Commit to Git
git add secrets/*.sops
git commit -m "feat: add encrypted authentik secrets"
git push

# 6. On server, sync secrets
ssh colin@192.168.2.57
cd /opt/docker/deployments/production/authentik
./sync-secrets.sh production v1

# 7. Deploy
docker stack deploy -c docker-compose.yml authentik_production

# 8. Verify
docker service logs authentik_production_server
curl -skI https://authentik.pandia.io
```
