#!/usr/bin/env bash
# Manual GitOps sync script for Traefik and Authentik configurations
# Use this when automatic sync is not working or for manual deployments

set -euo pipefail

# Configuration
TARGET_HOST="${TARGET_HOST:-colin@192.168.2.57}"
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

log_info() {
    echo -e "${GREEN}[INFO]${NC} $*"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $*"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $*"
}

# Sync Traefik configuration
sync_traefik() {
    log_info "Syncing Traefik configuration..."
    
    local source_dir="$REPO_ROOT/deployments/production/traefik"
    local target_dir="/opt/traefik"
    
    # Sync traefik.yml (static config)
    log_info "Copying traefik.yml..."
    scp "$source_dir/traefik/traefik.yml" "$TARGET_HOST:$target_dir/traefik/traefik.yml"
    
    # Sync dynamic config files
    log_info "Copying dynamic configurations..."
    scp "$source_dir/traefik/config/"*.yml "$TARGET_HOST:$target_dir/traefik/config/" 2>/dev/null || true
    
    # Sync docker-compose.yml
    log_info "Copying docker-compose.yml..."
    scp "$source_dir/docker-compose.yml" "$TARGET_HOST:$target_dir/docker-compose.yml"
    
    # Restart Traefik if requested
    if [ "${RESTART_TRAEFIK:-false}" = "true" ]; then
        log_info "Restarting Traefik..."
        ssh "$TARGET_HOST" "cd $target_dir && docker compose restart traefik"
    fi
    
    log_info "✓ Traefik sync complete"
}

# Sync Authentik configuration
sync_authentik() {
    log_info "Syncing Authentik configuration..."
    
    local source_dir="$REPO_ROOT/deployments/production/authentik"
    local target_dir="/opt/gitops/iac-catalog/deployments/production/authentik"
    
    # Sync docker-compose.yml
    log_info "Copying docker-compose.yml..."
    ssh "$TARGET_HOST" "mkdir -p $target_dir"
    scp "$source_dir/docker-compose.yml" "$TARGET_HOST:$target_dir/docker-compose.yml"
    
    # Redeploy stack if requested
    if [ "${RESTART_AUTHENTIK:-false}" = "true" ]; then
        log_info "Redeploying Authentik stack..."
        ssh "$TARGET_HOST" "cd $target_dir && docker stack deploy -c docker-compose.yml authentik_production"
    fi
    
    log_info "✓ Authentik sync complete"
}

# Main function
main() {
    echo "===================================="
    echo "  Manual GitOps Configuration Sync"
    echo "===================================="
    echo ""
    
    # Check if we're in the right directory
    if [ ! -f "$REPO_ROOT/deployments/production/traefik/docker-compose.yml" ]; then
        log_error "Not in repository root or repository structure is invalid"
        exit 1
    fi
    
    # Parse arguments
    local sync_traefik=false
    local sync_authentik=false
    
    while [[ $# -gt 0 ]]; do
        case $1 in
            --traefik)
                sync_traefik=true
                shift
                ;;
            --authentik)
                sync_authentik=true
                shift
                ;;
            --all)
                sync_traefik=true
                sync_authentik=true
                shift
                ;;
            --restart)
                export RESTART_TRAEFIK=true
                export RESTART_AUTHENTIK=true
                shift
                ;;
            --help)
                echo "Usage: $0 [OPTIONS]"
                echo ""
                echo "Options:"
                echo "  --traefik     Sync Traefik configuration"
                echo "  --authentik   Sync Authentik configuration"
                echo "  --all         Sync all configurations"
                echo "  --restart     Restart services after sync"
                echo "  --help        Show this help message"
                echo ""
                echo "Environment variables:"
                echo "  TARGET_HOST   SSH target (default: colin@192.168.2.57)"
                exit 0
                ;;
            *)
                log_error "Unknown option: $1"
                echo "Use --help for usage information"
                exit 1
                ;;
        esac
    done
    
    # If no options specified, show help
    if [ "$sync_traefik" = "false" ] && [ "$sync_authentik" = "false" ]; then
        log_warn "No sync target specified. Use --traefik, --authentik, or --all"
        echo "Use --help for more information"
        exit 1
    fi
    
    # Perform syncs
    if [ "$sync_traefik" = "true" ]; then
        sync_traefik
        echo ""
    fi
    
    if [ "$sync_authentik" = "true" ]; then
        sync_authentik
        echo ""
    fi
    
    log_info "All syncs completed successfully!"
}

main "$@"
