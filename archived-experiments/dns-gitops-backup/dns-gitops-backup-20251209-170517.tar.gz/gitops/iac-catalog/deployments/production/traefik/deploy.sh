#!/usr/bin/env bash
# Traefik Deployment Helper (manual fallback to Portainer GitOps)

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

TARGET_HOST="${TARGET_HOST:-colin@192.168.2.57}"
REMOTE_PATH="${REMOTE_PATH:-/opt/traefik}"
SSH_OPTS="${SSH_OPTS:-}"

ENV_PATH="${SCRIPT_DIR}/.env"
COMPOSE_PATH="${SCRIPT_DIR}/docker-compose.yml"

EXCLUDES=(
    "--exclude" ".git"
    "--exclude" "traefik/acme/"
    "--exclude" "traefik/logs/"
)

echo "🚀 Traefik manual deployment"
echo "============================"
echo "Source: ${SCRIPT_DIR}"
echo "Target: ${TARGET_HOST}:${REMOTE_PATH}"
echo ""

if [[ ! -f "${ENV_PATH}" ]]; then
    echo "❌ .env file not found. Copy .env.example first."
    exit 1
fi

if [[ ! -f "${COMPOSE_PATH}" ]]; then
    echo "❌ docker-compose.yml missing"
    exit 1
fi

SSH_CMD=(ssh)
if [[ -n "${SSH_OPTS}" ]]; then
    # shellcheck disable=SC2206
    SSH_CMD+=( ${SSH_OPTS} )
fi
SSH_CMD+=("${TARGET_HOST}")

echo "📂 Ensuring remote path exists"
"${SSH_CMD[@]}" "mkdir -p '${REMOTE_PATH}'"

echo "📦 Syncing files (excluding certificates/logs)"
rsync -avz --delete "${EXCLUDES[@]}" "${SCRIPT_DIR}/" "${TARGET_HOST}:${REMOTE_PATH}"

read -r -d '' REMOTE_CMD <<'EOF'
set -euo pipefail
cd "${REMOTE_PATH}"
if command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then
    DC=(docker compose)
else
    DC=(docker-compose)
fi
"${DC[@]}" --env-file .env pull traefik
"${DC[@]}" --env-file .env up -d
"${DC[@]}" ps
EOF

echo "🐳 Applying compose stack on remote host"
"${SSH_CMD[@]}" "REMOTE_PATH=${REMOTE_PATH} bash -s" <<<"${REMOTE_CMD}"

echo ""
echo "✅ Deployment complete. Use ./validate.sh to double-check health."