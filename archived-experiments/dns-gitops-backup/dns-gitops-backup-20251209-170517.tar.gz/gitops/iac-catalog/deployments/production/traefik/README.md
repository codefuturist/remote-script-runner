# Traefik GitOps Stack (Production)

This deployment packages the production Traefik edge router that fronts `pandia.io`. The stack is designed to be GitOps-friendly and can be pulled directly into Portainer as a Git-based stack while still supporting manual deployments for break-glass scenarios.

## Features

- Traefik v3.5 with Let's Encrypt (DNS challenge via Cloudflare)
- Wildcard certificate support (`*.pandia.io`)
- Opinionated security headers and Basic Auth protected dashboard
- Host-mode listeners on 80/443 plus dashboard on 8081
- Read-only Docker socket access and resource limits
- Git-friendly layout (`acme` and `logs` folders ignored, `.env` template provided)
- File-based provider for routing to Docker Swarm services
- Cloudflare API tokens via environment variables (no Docker secrets needed)

## Repository Layout

```bash
deployments/production/traefik/
├── docker-compose.yml        # Stack definition pulled by Portainer
├── .env.example              # Copy to .env and fill locally (never commit secrets)
├── PORTAINER.md              # Step-by-step Portainer GitOps guide
├── manifest.yml              # Metadata for IaC catalog tooling
├── target.yml                # Target definition (Portainer stack + host info)
├── traefik/
│   ├── traefik.yml           # Static Traefik configuration
│   ├── config/               # Dynamic config files (file provider)
│   │   ├── .gitkeep          # Ensures directory exists in Git
│   │   └── authentik.yml     # Example: Swarm service routing
│   ├── acme/                 # Certificates (gitignored)
│   └── logs/                 # Log output (gitignored)
├── deploy.sh                 # Optional helper to push to the edge host via SSH
├── validate.sh               # Sanity checks after deployment
└── demo.sh                   # Guided workflow (review → deploy → validate)
```

## Quick Start

1. **Prepare environment variables**

   ```bash
   cd deployments/production/traefik
   cp .env.example .env
   # Edit .env with your domain, ACME email, and Cloudflare token
   ```

2. **Review the Portainer instructions** (Git-based stack flow, required env vars, webhook tips): `PORTAINER.md`

3. **(Optional) Encrypt secrets with SOPS**: See `SOPS_INTEGRATION.md` for encrypted secret management with GitOps. Allows committing `.env.sops` to Git as encrypted backup.

4. **Create (if needed) the shared proxy network** on the Docker host:

   ```bash
   docker network create proxy || true
   ```

5. **Add the stack to Portainer** using the Git repository method. Point to `deployments/production/traefik/docker-compose.yml` and paste the `.env` values into the Portainer stack editor. Enable "Pull latest image" so updates flow automatically.

## Manual Deployment (Optional)

Manual deployments should only be used for validation or when Portainer is unavailable.

```bash
./deploy.sh                   # rsync files to the host and run docker compose up
./validate.sh                 # verify container health, ports, and certificates
```

By default, the scripts target `colin@192.168.2.57` and deploy into `/opt/traefik`. Override via `TARGET_HOST`, `REMOTE_PATH`, and `SSH_OPTS` environment variables.

## Adding Services Behind Traefik

### Option 1: Docker Labels (Recommended for standalone containers)

1. Attach the service container to the shared `proxy` network.
2. Add Traefik labels similar to:

    ```yaml
    labels:
       - "traefik.enable=true"
       - "traefik.http.routers.myapp.rule=Host(`myapp.${DOMAIN}`)"
       - "traefik.http.routers.myapp.entrypoints=https"
       - "traefik.http.routers.myapp.tls.certresolver=letsencrypt"
       - "traefik.http.services.myapp.loadbalancer.server.port=8080"
    ```

3. Commit and push changes. Portainer will pull the new compose file and redeploy automatically if a webhook is configured.

### Option 2: File-based Configuration (For Docker Swarm services)

When services run in Docker Swarm mode but Traefik runs in standalone mode, use file-based routing:

1. Create a YAML file in `traefik/config/` directory (e.g., `myapp.yml`):

    ```yaml
    http:
      routers:
        myapp:
          rule: "Host(`myapp.pandia.io`)"
          entryPoints:
            - https
          service: myapp
          tls:
            certResolver: letsencrypt
            domains:
              - main: "*.pandia.io"  # Wildcard cert
                sans:
                  - "pandia.io"
      
      services:
        myapp:
          loadBalancer:
            servers:
              - url: "http://10.0.3.X:PORT"  # IP from proxy network
    ```

2. Find the service IP on the proxy network:
    ```bash
    docker network inspect proxy | jq -r '.[0].Containers'
    ```

3. Traefik will automatically reload the configuration (watch: true).

### Wildcard Certificates

The deployment is configured to obtain wildcard certificates for `*.pandia.io` using DNS-01 challenge with Cloudflare. To request a wildcard certificate, add the `tls.domains` configuration:

```yaml
tls:
  certResolver: letsencrypt
  domains:
    - main: "*.pandia.io"
      sans:
        - "pandia.io"
```

The first service that requests the wildcard will trigger the certificate issuance, and all subsequent services will reuse it.

## Troubleshooting

- **Certificates not issuing**: Ensure the Cloudflare token has `Zone:DNS:Edit`, confirm DNS records, and check `traefik/logs/traefik.log`.
- **Dashboard 404/401**: Verify DNS for `traefik.${DOMAIN}`, confirm `DASHBOARD_USERS` hash is escaped, and ensure port 8081 is reachable internally.
- **Services unreachable**: Confirm they share the `proxy` network and include the required Traefik labels.
- **Portainer not updating**: Use Portainer's "Pull & redeploy" or trigger the webhook configured in `PORTAINER.md`.

## References

- `PORTAINER.md` – GitOps stack guide
- `SOPS_INTEGRATION.md` – SOPS encryption for secret management (optional)
- `manifest.yml` / `target.yml` – metadata consumed by the IaC catalog tooling
- Traefik docs: <https://doc.traefik.io/>
- Portainer docs: <https://docs.portainer.io/>
