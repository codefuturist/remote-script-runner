# Traefik GitOps Deployment Guide for Portainer

## Overview

This Traefik deployment is configured for GitOps workflows with Portainer. All configuration is managed via Git, and secrets are handled through Portainer's environment variable management.

## Prerequisites

1. **Docker Network**: Create the `proxy` network before deployment
   ```bash
   docker network create proxy
   ```

2. **Directory Permissions**: Ensure the `traefik/acme` directory is writable by the container
   ```bash
   chmod 755 traefik/acme
   ```

## Portainer Stack Deployment

### Method 1: Git Repository (Recommended)

1. **Navigate to Portainer** → Stacks → Add Stack
2. **Stack Name**: `traefik`
3. **Build Method**: Select "Repository"
4. **Repository Configuration**:
   - Repository URL: Your Git repository URL
   - Repository Reference: `main` or your branch
   - Compose Path: `deployments/production/traefik/docker-compose.yml`
   - Authentication: Configure if private repository

5. **Environment Variables**: Add these in Portainer's environment section:
   ```
   DOMAIN=your-domain.com
   SUBDOMAIN=your-subdomain
   ACME_EMAIL=your-email@example.com
   CF_DNS_API_TOKEN=your-cloudflare-token
   CLOUDFLARE_DNS_API_TOKEN=your-cloudflare-token
   CF_API_TOKEN=your-cloudflare-token
   DASHBOARD_USERS=admin:$$2y$$05$$hashed-password
   ALLOWED_HOSTS=*.your-domain.com
   ALLOWED_ORIGINS=https://*.your-domain.com
   LOG_LEVEL=INFO
   ENVIRONMENT=production
   ```

6. **Deploy**: Enable "Pull latest image" and click "Deploy the stack"

### Method 2: Web Editor

1. Copy the contents of `docker-compose.yml`
2. Add environment variables as shown above
3. Deploy

## Secret Management

### Generating Dashboard Password

```bash
# Install apache2-utils if not available
apt-get install apache2-utils

# Generate password hash
htpasswd -nB admin

# For Portainer, escape dollar signs by doubling them
# Example: $2y$05$abc... becomes $$2y$$05$$abc...
```

### Cloudflare API Token

1. Go to https://dash.cloudflare.com/profile/api-tokens
2. Create Token → "Edit zone DNS" template
3. Permissions: Zone → DNS → Edit
4. Zone Resources: Include → Specific zone → Your domain
5. Copy the token to Portainer environment variables

## GitOps Workflow

### File Structure
```
deployments/production/traefik/
├── .env.example              # Template for environment variables
├── .gitignore                # Prevents committing secrets
├── docker-compose.yml        # Main compose file
├── README.md                 # Stack overview
├── PORTAINER.md              # This guide
├── manifest.yml              # Deployment manifest
└── traefik/
    ├── traefik.yml           # Static configuration
    ├── config/               # Dynamic configuration
    ├── acme/                 # Certificate storage (gitignored)
    └── logs/                 # Logs (gitignored)
```

### Updating Configuration

1. **Static Configuration** (requires restart):
   - Edit `traefik/traefik.yml`
   - Commit and push to Git
   - Redeploy stack in Portainer

2. **Dynamic Configuration** (hot reload):
   - Add files to `traefik/config/`
   - Traefik automatically detects changes

3. **Environment Variables**:
   - Update in Portainer stack editor
   - Redeploy stack

## Auto-Update with Webhook

Enable Portainer's webhook feature for automatic deployments on Git push:

1. In Portainer Stack settings, enable "Enable webhook"
2. Copy the webhook URL
3. Add to your Git repository's webhooks:
   - GitHub: Settings → Webhooks → Add webhook
   - GitLab: Settings → Webhooks → Add webhook
   - Paste the Portainer webhook URL

## Monitoring

### Health Check
```bash
# Check Traefik health
curl http://localhost:8081/ping

# View logs
docker logs traefik

# Access dashboard
https://traefik.your-domain.com
```

### Common Issues

**Certificate Generation Fails**:
- Verify Cloudflare API token has DNS edit permissions
- Check `traefik/logs/traefik.log` for errors
- Ensure email in ACME_EMAIL is valid

**Dashboard Not Accessible**:
- Verify DNS points to server
- Check DASHBOARD_USERS password hash is properly escaped
- Confirm ports 80/443 are not blocked by firewall

**Services Not Routing**:
- Ensure services are on the `proxy` network
- Check service labels include `traefik.enable=true`
- Verify routing rules in service labels

## Security Considerations

1. **Never commit** `.env` files with secrets
2. **Use strong passwords** for dashboard authentication
3. **Rotate API tokens** periodically
4. **Enable firewall** rules for ports 80/443 only
5. **Monitor access logs** regularly
6. **Keep Traefik updated** via Portainer auto-pull

## Network Integration

Services that need Traefik routing must:

1. Be on the `proxy` network
2. Have `traefik.enable=true` label
3. Define routing rules via labels

Example service labels:
```yaml
labels:
  - "traefik.enable=true"
  - "traefik.http.routers.myapp.rule=Host(`myapp.${DOMAIN}`)"
  - "traefik.http.routers.myapp.entrypoints=https"
  - "traefik.http.routers.myapp.tls.certresolver=letsencrypt"
  - "traefik.http.services.myapp.loadbalancer.server.port=8080"
```

## Backup and Recovery

### Backup
```bash
# Backup certificates
tar -czf traefik-acme-backup.tar.gz traefik/acme/

# Backup configuration
git commit -am "Backup configuration"
```

### Recovery
```bash
# Restore certificates
tar -xzf traefik-acme-backup.tar.gz

# Pull latest configuration
git pull origin main

# Redeploy in Portainer
```

## Advanced: SOPS Encryption

For encrypted secret management with GitOps, see `SOPS_INTEGRATION.md`. This optional feature allows you to:

- Commit encrypted `.env.sops` to Git for backup and audit trail
- Use Portainer environment variables (recommended)
- Or automate decryption with init containers (advanced)

Benefits:

- **Disaster Recovery**: Restore secrets from Git if Portainer fails
- **Audit Trail**: Track secret changes in Git history
- **Key Management**: Leverage existing SOPS/age infrastructure

## Resources

- Traefik Documentation: <https://doc.traefik.io/traefik/>
- Portainer Documentation: <https://docs.portainer.io/>
- Let's Encrypt Rate Limits: <https://letsencrypt.org/docs/rate-limits/>
