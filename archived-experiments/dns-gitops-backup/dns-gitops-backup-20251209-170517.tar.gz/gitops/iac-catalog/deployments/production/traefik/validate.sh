#!/usr/bin/env bash
# Validate the Traefik production deployment

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

TARGET_HOST="${TARGET_HOST:-colin@192.168.2.57}"
REMOTE_PATH="${REMOTE_PATH:-/opt/traefik}"
SSH_OPTS="${SSH_OPTS:-}"

ENV_PATH="${SCRIPT_DIR}/.env"
if [[ -f "${ENV_PATH}" ]]; then
    # shellcheck disable=SC1090
    source "${ENV_PATH}"
fi

DASHBOARD_HOST="traefik.${DOMAIN:-example.com}"
if [[ -n "${SUBDOMAIN:-}" ]]; then
    DASHBOARD_HOST_SECONDARY="traefik.${SUBDOMAIN}.${DOMAIN:-example.com}"
fi

SSH_CMD=(ssh -o ConnectTimeout=5)
if [[ -n "${SSH_OPTS}" ]]; then
    # shellcheck disable=SC2206
    SSH_CMD+=( ${SSH_OPTS} )
fi
SSH_CMD+=("${TARGET_HOST}")

echo "🔍 Validating Traefik Deployment"
echo "================================"
echo "Host: ${TARGET_HOST}"
echo "Remote path: ${REMOTE_PATH}"
echo "Dashboard host: ${DASHBOARD_HOST}"
[[ -n "${DASHBOARD_HOST_SECONDARY:-}" ]] && echo "Alt dashboard host: ${DASHBOARD_HOST_SECONDARY}"
echo ""

echo "📡 Checking SSH connectivity"
if ! "${SSH_CMD[@]}" "echo ok" >/dev/null 2>&1; then
    echo "❌ Unable to reach ${TARGET_HOST}"
    exit 1
fi
echo "✅ SSH reachable"
echo ""

REMOTE_CHECK=$(cat <<'EOF'
set -euo pipefail
if [[ ! -d "${REMOTE_PATH}" ]]; then
  echo "missing_dir"
  exit 0
fi
cd "${REMOTE_PATH}"
if [[ ! -f docker-compose.yml ]]; then
  echo "missing_compose"
  exit 0
fi
if [[ ! -f .env ]]; then
  echo "missing_env"
  exit 0
fi
if command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then
  DC=(docker compose)
else
  DC=(docker-compose)
fi
echo "compose_ok"
"${DC[@]}" ps traefik
docker exec traefik traefik healthcheck --ping >/dev/null 2>&1 && echo "health_ok" || echo "health_fail"
if command -v curl >/dev/null 2>&1; then
  curl -fsS https://"${DASHBOARD_HOST}"/ping >/dev/null 2>&1 && echo "https_ok" || echo "https_fail"
fi
EOF
)

RESULTS=$("${SSH_CMD[@]}" "REMOTE_PATH=${REMOTE_PATH} DASHBOARD_HOST=${DASHBOARD_HOST} bash -s" <<<"${REMOTE_CHECK}" || true)

if grep -q "missing_dir" <<<"${RESULTS}"; then
    echo "❌ Remote path ${REMOTE_PATH} not found"
    exit 1
fi
if grep -q "missing_compose" <<<"${RESULTS}"; then
    echo "❌ docker-compose.yml missing on remote host"
    exit 1
fi
if grep -q "missing_env" <<<"${RESULTS}"; then
    echo "❌ .env missing on remote host"
    exit 1
fi

echo "✅ Compose bundle present"
echo ""

if grep -q "health_ok" <<<"${RESULTS}"; then
    echo "💚 Traefik healthcheck: PASS"
else
    echo "⚠️  Traefik healthcheck failed. Inspect logs." && EXIT_CODE=1
fi

if grep -q "https_ok" <<<"${RESULTS}"; then
    echo "🔐 Dashboard ping over HTTPS succeeded"
else
    echo "⚠️  HTTPS dashboard probe failed (DNS/SSL?)."
fi

echo ""
echo "📊 Raw remote output"
echo "--------------------"
echo "${RESULTS}"

if [[ ${EXIT_CODE:-0} -ne 0 ]]; then
    exit "${EXIT_CODE}"
fi

echo ""
echo "🎉 Validation complete"