# SOPS Integration for Traefik GitOps Deployment

## Overview

This guide explains how to use SOPS encryption with Portainer GitOps for managing Traefik secrets securely.

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│ Developer Workflow                                          │
├─────────────────────────────────────────────────────────────┤
│ 1. Edit .env (local, never committed)                      │
│ 2. Encrypt: iac secrets encrypt traefik --env production   │
│ 3. Commit .env.sops to Git                                 │
│ 4. Git push triggers Portainer webhook (optional)          │
└─────────────────────────────────────────────────────────────┘
                         ↓
┌─────────────────────────────────────────────────────────────┐
│ Portainer GitOps                                            │
├─────────────────────────────────────────────────────────────┤
│ Option A: Manual Entry (Current - Simplest)                │
│   • Pull docker-compose.yml from Git                       │
│   • Paste secrets into Portainer stack environment UI      │
│   • Portainer injects vars at deployment time              │
│                                                             │
│ Option B: SOPS Decryption (Advanced - True GitOps)         │
│   • Pull docker-compose.yml + .env.sops from Git          │
│   • Deploy sops-decrypt sidecar with age key               │
│   • Sidecar decrypts .env.sops → .env before Traefik       │
└─────────────────────────────────────────────────────────────┘
                         ↓
┌─────────────────────────────────────────────────────────────┐
│ Runtime                                                     │
├─────────────────────────────────────────────────────────────┤
│ Traefik container reads environment variables              │
└─────────────────────────────────────────────────────────────┘
```

## Option A: Portainer Environment Variables (Recommended)

### Pros & Cons

**Advantages:**

- ✅ Simple to implement (already working)
- ✅ No host dependencies (SOPS not needed on server)
- ✅ Portainer UI for secret management
- ✅ RBAC via Portainer access controls

**Limitations:**

- ⚠️ Secrets not in Git (partial GitOps)
- ⚠️ Portainer database is secret source of truth
- ⚠️ Manual sync between `.env.sops` and Portainer UI

### Workflow

#### 1. Encrypt Secrets Locally

```bash
# From repository root
cd deployments/production/traefik

# Ensure .env has real secrets
# Then encrypt it
export SOPS_AGE_KEY_FILE=../../../age.agekey
sops --encrypt .env > .env.sops

# Or using iac-manager:
iac secrets encrypt traefik --environment production
```

#### 2. Commit Encrypted Version

```bash
git add .env.sops
git commit -m "chore: update traefik encrypted secrets"
git push
```

#### 3. Portainer Stack Configuration

1. Navigate to Portainer → Stacks → traefik
2. Build method: **Git Repository**
3. Repository URL: `https://github.com/codefuturist/iac-catalog.git`
4. Repository reference: `develop`
5. Compose path: `deployments/production/traefik/docker-compose.yml`
6. **Environment variables** (paste values from decrypted `.env`):

```env
DOMAIN=pandia.io
SUBDOMAIN=pi-nvme-1
ACME_EMAIL=your-email@example.com
CF_DNS_API_TOKEN=your-cloudflare-token
CLOUDFLARE_DNS_API_TOKEN=your-cloudflare-token
CF_API_TOKEN=your-cloudflare-token
DASHBOARD_USERS=admin:$$2y$$05$$hashed-password
ALLOWED_HOSTS=*.pandia.io,*.pi-nvme-1.pandia.io
ALLOWED_ORIGINS=https://*.pandia.io,https://*.pi-nvme-1.pandia.io
LOG_LEVEL=INFO
TRAEFIK_CPU_LIMIT=1.0
TRAEFIK_MEMORY_LIMIT=512M
TRAEFIK_CPU_RESERVATION=0.25
TRAEFIK_MEMORY_RESERVATION=128M
PROXY_NETWORK=proxy
ENVIRONMENT=production
```

#### 4. Decrypt When Needed

```bash
# Decrypt for local testing or updates
sops --decrypt .env.sops > .env

# Or using iac-manager:
iac secrets decrypt traefik --environment production
```

### Benefits of This Approach

1. **Backup in Git**: `.env.sops` serves as encrypted backup
2. **Auditability**: Git history tracks secret changes
3. **Disaster Recovery**: Restore from `.env.sops` if Portainer fails
4. **No Runtime Dependencies**: Server doesn't need SOPS installed

## Option B: Automated SOPS Decryption (True GitOps)

### Requirements

- SOPS and age installed on Docker host
- Age private key distributed to hosts
- Init container pattern in docker-compose

### Implementation

Create `docker-compose.sops.yml` with SOPS decryption:

```yaml
services:
  sops-decrypt:
    image: mozilla/sops:v3.8.1
    container_name: traefik-sops-decrypt
    volumes:
      - ./:/stack:rw
      - traefik-age-key:/keys:ro
    environment:
      - SOPS_AGE_KEY_FILE=/keys/age.agekey
    command: >
      sh -c "
        if [ -f /stack/.env.sops ]; then
          sops --decrypt /stack/.env.sops > /stack/.env
          echo 'Secrets decrypted successfully'
        else
          echo 'No .env.sops found, skipping decryption'
        fi
      "
    restart: "no"

  traefik:
    depends_on:
      sops-decrypt:
        condition: service_completed_successfully
    # ... rest of traefik config

secrets:
  age_key:
    file: /etc/traefik/age.agekey

volumes:
  traefik-age-key:
    driver: local
    driver_opts:
      type: none
      o: bind
      device: /etc/traefik/keys
```

### Setup Steps

1. **Install SOPS on host:**

   ```bash
   ssh colin@192.168.2.57
   
   # Install SOPS
   curl -LO https://github.com/mozilla/sops/releases/download/v3.8.1/sops-v3.8.1.linux.amd64
   sudo mv sops-v3.8.1.linux.amd64 /usr/local/bin/sops
   sudo chmod +x /usr/local/bin/sops
   
   # Install age
   sudo apt-get install age  # or brew install age
   ```

2. **Deploy age key to host:**

   ```bash
   # From local machine
   scp age.agekey colin@192.168.2.57:/tmp/
   
   # On remote host
   sudo mkdir -p /etc/traefik/keys
   sudo mv /tmp/age.agekey /etc/traefik/keys/
   sudo chmod 600 /etc/traefik/keys/age.agekey
   sudo chown root:root /etc/traefik/keys/age.agekey
   ```

3. **Update .gitignore to allow .env.sops:**

   ```gitignore
   # Environment files with secrets
   .env
   .env.*
   !.env.example
   !.env.sops  # Allow encrypted version
   ```

4. **Portainer configuration:**
   - Repository path: `deployments/production/traefik/docker-compose.sops.yml`
   - No environment variables needed (secrets come from .env.sops)

### Pros & Cons

**Advantages:**

- ✅ True GitOps (everything in Git)
- ✅ Automated decryption
- ✅ No manual Portainer secret entry
- ✅ Consistent with FluxCD workflow

**Limitations:**

- ❌ Requires SOPS on Docker host
- ❌ Age key distribution to hosts
- ❌ More complex operational model
- ❌ Init container dependency

## Comparison Matrix

| Feature | Option A (Portainer Vars) | Option B (SOPS Decrypt) |
|---------|---------------------------|-------------------------|
| GitOps compliance | Partial (compose only) | Full (compose + secrets) |
| Setup complexity | Low | High |
| Host dependencies | None | SOPS + age |
| Key management | Portainer UI | Age key distribution |
| Secret rotation | Update in Portainer | Commit .env.sops to Git |
| Disaster recovery | Restore from .env.sops | Git clone + deploy |
| Audit trail | Portainer + Git (partial) | Full Git history |
| RBAC | Portainer access control | Git repository access |
| Operational burden | Low | Medium |

## Recommended Approach: Hybrid

1. **Primary**: Use **Option A** (Portainer environment variables)
   - Simplest to operate
   - Portainer-native secret management
   - Works immediately

2. **Backup**: Maintain `.env.sops` in Git
   - Encrypted backup of secrets
   - Git history for secret changes
   - Disaster recovery capability

3. **Workflow**:

   ```bash
   # 1. Update secrets locally
   vim .env
   
   # 2. Encrypt and commit
   sops --encrypt .env > .env.sops
   git add .env.sops
   git commit -m "chore: update traefik secrets"
   git push
   
   # 3. Update Portainer stack
   # - Open Portainer UI
   # - Edit stack environment variables
   # - Copy values from decrypted .env
   # - Deploy
   ```

## Quick Commands

### Encrypt

```bash
# Manual
export SOPS_AGE_KEY_FILE=../../../age.agekey
sops --encrypt .env > .env.sops

# With iac-manager
iac secrets encrypt traefik --environment production
```

### Decrypt

```bash
# Manual
export SOPS_AGE_KEY_FILE=../../../age.agekey
sops --decrypt .env.sops > .env

# With iac-manager
iac secrets decrypt traefik --environment production

# View only (no file creation)
sops --decrypt .env.sops
```

### Validate

```bash
# Check if encrypted
grep "sops:" .env.sops

# Verify can decrypt
sops --decrypt .env.sops > /dev/null && echo "OK" || echo "FAIL"
```

## Security Best Practices

1. **Never commit `.env`** - Always gitignored
2. **Backup age.agekey** - Store securely offline
3. **Rotate keys periodically** - Use `sops updatekeys`
4. **Audit access** - Track who decrypts secrets
5. **Use different keys per environment** - dev/staging/production
6. **Limit key distribution** - Only to necessary hosts/users

## Troubleshooting

### Can't decrypt .env.sops

**Problem**: `sops --decrypt` fails with "no key could decrypt"

**Solution**:

```bash
# Ensure age key is correct
export SOPS_AGE_KEY_FILE=../../../age.agekey
cat $SOPS_AGE_KEY_FILE | grep "public key"
# Should show: age1t8gm5avm9z5pquta4w2kaud7zn3c588mkk2shdpdskvp76wxh3gsxctyst

# Check .sops.yaml config
grep "age:" ../../../.sops.yaml
```

### Portainer not pulling latest .env.sops

**Problem**: Stack deploys but uses old secrets

**Solution**:

- Portainer doesn't auto-decrypt `.env.sops`
- Must manually update environment variables in Portainer UI
- Or switch to Option B (automated decryption)

### Age key not found on host

**Problem**: Init container fails with "age key not found"

**Solution**:

```bash
# Verify key exists
ssh colin@192.168.2.57 "ls -la /etc/traefik/keys/"

# Check permissions
ssh colin@192.168.2.57 "cat /etc/traefik/keys/age.agekey | head -1"
# Should show: AGE-SECRET-KEY-...
```

## References

- [SOPS Documentation](https://github.com/mozilla/sops)
- [Age Encryption](https://github.com/FiloSottile/age)
- [Portainer Stack Documentation](https://docs.portainer.io/user/docker/stacks)
- Repository `.sops.yaml` configuration
- FluxCD SOPS integration (similar pattern)

## Next Steps

1. Choose Option A or B based on your requirements
2. Encrypt current `.env` → `.env.sops`
3. Commit `.env.sops` to Git
4. Configure Portainer stack
5. Test deployment
6. Document secret rotation procedures
