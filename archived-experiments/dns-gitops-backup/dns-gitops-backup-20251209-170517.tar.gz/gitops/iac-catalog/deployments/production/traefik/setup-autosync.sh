#!/usr/bin/env bash
# Setup script for automatic secret sync on servers

set -euo pipefail

SERVER="${1:-}"
SUDO_PASS="${2:-12345}"

if [ -z "$SERVER" ]; then
    echo "Usage: $0 <server-ip> [sudo-password]"
    echo "Example: $0 192.168.2.57 12345"
    exit 1
fi

echo "=== Setting up automatic secret sync on $SERVER ==="

# Copy age key to server
echo "📦 Copying age key to server..."
scp ../../../age.agekey "colin@$SERVER:/tmp/.age.key"
ssh "colin@$SERVER" "echo '$SUDO_PASS' | sudo -S mv /tmp/.age.key /opt/traefik/.age.key && \
    echo '$SUDO_PASS' | sudo -S chown colin:colin /opt/traefik/.age.key && \
    chmod 600 /opt/traefik/.age.key"

# Install SOPS if not present
echo "📦 Installing SOPS..."
ssh "colin@$SERVER" "command -v sops >/dev/null 2>&1 || \
    (curl -LO https://github.com/mozilla/sops/releases/download/v3.8.1/sops-v3.8.1.linux.amd64 && \
    echo '$SUDO_PASS' | sudo -S mv sops-v3.8.1.linux.amd64 /usr/local/bin/sops && \
    echo '$SUDO_PASS' | sudo -S chmod +x /usr/local/bin/sops)"

# Copy sync scripts to server
echo "📦 Copying sync scripts..."
scp sync-secrets.sh webhook-receiver.sh "colin@$SERVER:/opt/traefik/"
ssh "colin@$SERVER" "chmod +x /opt/traefik/sync-secrets.sh /opt/traefik/webhook-receiver.sh"

# Setup systemd service and timer
echo "⚙️  Setting up systemd service..."
scp traefik-sync.service traefik-sync.timer "colin@$SERVER:/tmp/"
ssh "colin@$SERVER" "echo '$SUDO_PASS' | sudo -S mv /tmp/traefik-sync.service /etc/systemd/system/ && \
    echo '$SUDO_PASS' | sudo -S mv /tmp/traefik-sync.timer /etc/systemd/system/ && \
    echo '$SUDO_PASS' | sudo -S systemctl daemon-reload && \
    echo '$SUDO_PASS' | sudo -S systemctl enable traefik-sync.timer && \
    echo '$SUDO_PASS' | sudo -S systemctl start traefik-sync.timer"

# Create log file
ssh "colin@$SERVER" "touch /tmp/traefik-sync.log"

# Run initial sync
echo "🔄 Running initial secret sync..."
ssh "colin@$SERVER" "/opt/traefik/sync-secrets.sh"

# Check status
echo "✅ Checking service status..."
ssh "colin@$SERVER" "systemctl status traefik-sync.timer --no-pager"

echo ""
echo "=== Setup complete for $SERVER ==="
echo ""
echo "📋 Service Information:"
echo "  • Sync script: /opt/traefik/sync-secrets.sh"
echo "  • Log file: /tmp/traefik-sync.log"
echo "  • Timer: Runs every 15 minutes"
echo "  • Manual sync: ssh $SERVER /opt/traefik/sync-secrets.sh"
echo "  • View logs: ssh $SERVER tail -f /tmp/traefik-sync.log"
echo "  • Check timer: ssh $SERVER systemctl status traefik-sync.timer"
echo ""
