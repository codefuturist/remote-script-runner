# Traefik Production Deployment Checklist

## ✅ Pre-Deployment (Server Setup)

### 1. Network Configuration
- [x] Created Docker network: `docker network create proxy`
- [x] Verified network exists: `docker network ls | grep proxy`

### 2. Directory Structure
- [x] Created directories on server:
  ```bash
  sudo mkdir -p /opt/traefik/traefik/{config,acme,logs}
  sudo chown -R colin:colin /opt/traefik
  chmod 755 /opt/traefik/traefik/acme
  ```

### 3. Files Synced
- [x] Synced deployment files (excluding secrets):
  ```bash
  rsync -avz --delete --exclude='.env' --exclude='traefik/acme/' \
    --exclude='traefik/logs/' --exclude='.git' \
    ./ colin@192.168.2.57:/opt/traefik/
  ```

## ✅ Secret Management (SOPS)

### 1. Encrypted Secrets
- [x] Created `.env.sops` with encrypted environment variables
- [x] Verified encryption: `head .env.sops` shows `#ENC[AES256_GCM...]`
- [x] Tested decryption: `sops --decrypt .env.sops` works

### 2. Auto-Sync Setup
- [x] Installed SOPS on both servers
- [x] Deployed age encryption keys to servers
- [x] Created systemd timer for automatic secret sync (every 15 minutes)
- [x] Verified sync service is running

### 3. Git Commits
- [x] Staged encrypted secrets: `git add .env.sops`
- [x] Staged documentation: `git add SOPS_INTEGRATION.md PORTAINER.md`
- [x] Ready to commit (do not commit yet if testing)

## 🔄 Portainer Setup (Next Steps)

### 1. Get Environment Variables

Run the helper script to display variables for Portainer:

```bash
./portainer-env.sh
```

This will decrypt and display all environment variables in Portainer-ready format.

### 2. Create Stack in Portainer

1. **Navigate to**: Portainer → Stacks → Add Stack
2. **Stack name**: `traefik`
3. **Build method**: Select "Git repository"
4. **Repository configuration**:
   - Repository URL: `https://github.com/codefuturist/iac-catalog.git`
   - Repository reference: `develop`
   - Compose path: `deployments/production/traefik/docker-compose.yml`
   - Authentication: Configure if private repo

5. **Environment variables**: Copy from `./portainer-env.sh` output:
   ```
   DOMAIN=pandia.io
   SUBDOMAIN=pi-nvme-1
   ACME_EMAIL=letsencrypt@example.com
   CF_DNS_API_TOKEN=your-cloudflare-token
   CLOUDFLARE_DNS_API_TOKEN=your-cloudflare-token
   CF_API_TOKEN=your-cloudflare-token
   DASHBOARD_USERS=admin:$$2y$$05$$hashedpasswordhere  # Note: doubled $$
   ALLOWED_HOSTS=*.pandia.io,*.pi-nvme-1.pandia.io
   ALLOWED_ORIGINS=https://*.pandia.io,https://*.pi-nvme-1.pandia.io
   LOG_LEVEL=INFO
   TRAEFIK_CPU_LIMIT=1.0
   TRAEFIK_MEMORY_LIMIT=512M
   TRAEFIK_CPU_RESERVATION=0.25
   TRAEFIK_MEMORY_RESERVATION=128M
   PROXY_NETWORK=proxy
   ENVIRONMENT=production
   ```

   ⚠️ **Important**: Double the dollar signs in `DASHBOARD_USERS`:
   - `$2y$05$...` → `$$2y$$05$$...`

6. **Options**:
   - ✅ Enable "Pull latest image"
   - ✅ Enable "Prune unused images"

7. **Deploy**: Click "Deploy the stack"

### 3. Configure Webhook (Optional)

Enable automatic deployments on Git push:

1. In Portainer Stack settings → Enable webhook
2. Copy webhook URL
3. Add to GitHub repository:
   - Settings → Webhooks → Add webhook
   - Paste Portainer webhook URL
   - Content type: application/json
   - Events: Just the push event

## 🔍 Validation

### 1. Check Container Status

```bash
ssh colin@192.168.2.57 "docker ps | grep traefik"
```

Expected output:
```
traefik   Up X minutes   80/tcp, 443/tcp, 8080/tcp
```

### 2. Health Check

```bash
ssh colin@192.168.2.57 "docker exec traefik traefik healthcheck --ping"
```

Expected: `OK: 1 pings received`

### 3. Test Endpoints

```bash
# Ping endpoint
curl http://192.168.2.57:8081/ping

# Dashboard (requires auth)
curl -u admin:password https://traefik.pandia.io
```

### 4. View Logs

```bash
ssh colin@192.168.2.57 "docker logs traefik --tail 50"
```

Check for:
- ✅ "Configuration loaded"
- ✅ "Server listening"
- ✅ ACME certificate generation (if new)
- ❌ No error messages

### 5. Certificate Status

```bash
ssh colin@192.168.2.57 "ls -la /opt/traefik/traefik/acme/"
```

Should show `acme.json` with certificates after first Let's Encrypt request.

## 🔄 Ongoing Operations

### Update Secrets

When secrets need to be updated:

1. **Edit locally**:
   ```bash
   vim .env
   ```

2. **Re-encrypt**:
   ```bash
   export SOPS_AGE_KEY_FILE=../../../age.agekey
   sops --encrypt .env > .env.sops
   ```

3. **Commit**:
   ```bash
   git add .env.sops
   git commit -m "chore: update traefik secrets"
   git push
   ```

4. **Update Portainer**:
   - Open Portainer → Stacks → traefik → Editor
   - Update environment variables
   - Click "Update the stack"

### Update Configuration

For `traefik.yml` or `docker-compose.yml` changes:

1. **Edit and commit**:
   ```bash
   vim docker-compose.yml  # or traefik/traefik.yml
   git add .
   git commit -m "feat: update traefik configuration"
   git push
   ```

2. **Redeploy in Portainer**:
   - If webhook enabled: Automatic
   - If manual: Click "Pull and redeploy"

### View Encrypted Secrets

```bash
# Decrypt to view
sops --decrypt .env.sops

# Edit encrypted file (decrypts, opens editor, re-encrypts)
export SOPS_AGE_KEY_FILE=../../../age.agekey
sops .env.sops
```

## 🛠️ Troubleshooting

### Certificates Not Generating

```bash
# Check ACME logs
ssh colin@192.168.2.57 "cat /opt/traefik/traefik/logs/traefik.log | grep -i acme"

# Verify Cloudflare token
ssh colin@192.168.2.57 "docker exec traefik env | grep CF_"
```

### Dashboard 404/401

```bash
# Check dashboard route
ssh colin@192.168.2.57 "docker exec traefik traefik version"

# Verify labels
ssh colin@192.168.2.57 "docker inspect traefik | grep -A 20 Labels"
```

### Services Not Routing

```bash
# Check proxy network
ssh colin@192.168.2.57 "docker network inspect proxy"

# Verify Traefik can see Docker
ssh colin@192.168.2.57 "docker exec traefik ls -la /var/run/docker.sock"
```

## 📚 Documentation

- **README.md** - Stack overview and quick start
- **PORTAINER.md** - Detailed Portainer GitOps guide
- **SOPS_INTEGRATION.md** - SOPS encryption deep dive
- **portainer-env.sh** - Helper to display Portainer variables

## ✅ Final Checklist

Before going live:

- [ ] Proxy network created
- [ ] Directory structure in place
- [ ] Files synced to server
- [ ] `.env.sops` committed to Git
- [ ] Portainer stack configured with environment variables
- [ ] Stack deployed successfully
- [ ] Health check passes
- [ ] Dashboard accessible at `https://traefik.pandia.io`
- [ ] Test service routes correctly through Traefik
- [ ] Certificates generated (check `acme.json`)
- [ ] Webhook configured (optional)
- [ ] Team notified of new deployment

## 🎉 Success Criteria

✅ Traefik running and healthy
✅ Dashboard accessible with authentication
✅ Let's Encrypt certificates issued
✅ Services route through Traefik correctly
✅ Secrets encrypted in Git
✅ Portainer manages stack from Git
✅ Webhook triggers deployments (if enabled)
