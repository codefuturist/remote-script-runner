#!/usr/bin/env bash
# Traefik Secret Sync Service
# Automatically pulls and decrypts secrets from Git repository

set -euo pipefail

# Configuration
REPO_URL="${REPO_URL:-https://github.com/codefuturist/iac-catalog.git}"
REPO_BRANCH="${REPO_BRANCH:-develop}"
DEPLOY_PATH="${DEPLOY_PATH:-/opt/traefik}"
SECRETS_PATH="deployments/production/traefik"
AGE_KEY_FILE="${AGE_KEY_FILE:-/opt/traefik/.age.key}"
LOCK_FILE="/tmp/traefik-sync.lock"
LOG_FILE="${LOG_FILE:-/tmp/traefik-sync.log}"

# Logging
log() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] $*" | tee -a "$LOG_FILE"
}

# Acquire lock to prevent concurrent runs
acquire_lock() {
    if [ -f "$LOCK_FILE" ]; then
        local pid=$(cat "$LOCK_FILE")
        if kill -0 "$pid" 2>/dev/null; then
            log "Another sync is already running (PID: $pid)"
            exit 0
        else
            log "Removing stale lock file"
            rm -f "$LOCK_FILE"
        fi
    fi
    echo $$ > "$LOCK_FILE"
}

# Release lock
release_lock() {
    rm -f "$LOCK_FILE"
}

# Ensure cleanup on exit
trap release_lock EXIT

# Check prerequisites
check_prerequisites() {
    local missing=()
    
    command -v git >/dev/null 2>&1 || missing+=("git")
    command -v sops >/dev/null 2>&1 || missing+=("sops")
    command -v docker >/dev/null 2>&1 || missing+=("docker")
    
    if [ ${#missing[@]} -gt 0 ]; then
        log "ERROR: Missing required tools: ${missing[*]}"
        exit 1
    fi
    
    if [ ! -f "$AGE_KEY_FILE" ]; then
        log "ERROR: Age key not found at $AGE_KEY_FILE"
        exit 1
    fi
}

# Clone or update repository
sync_repo() {
    local tmp_dir="/tmp/traefik-sync-$$"
    
    log "Syncing repository from $REPO_URL (branch: $REPO_BRANCH)"
    
    # Clone to temp directory
    if ! git clone --depth 1 --branch "$REPO_BRANCH" "$REPO_URL" "$tmp_dir" 2>&1 | tee -a "$LOG_FILE"; then
        log "ERROR: Failed to clone repository"
        rm -rf "$tmp_dir"
        exit 1
    fi
    
    echo "$tmp_dir"
}

# Decrypt secrets
decrypt_secrets() {
    local repo_path="$1"
    local env_sops="$repo_path/$SECRETS_PATH/.env.sops"
    local env_file="$DEPLOY_PATH/.env"
    
    if [ ! -f "$env_sops" ]; then
        log "WARNING: No .env.sops found in repository"
        return 1
    fi
    
    log "Decrypting secrets..."
    export SOPS_AGE_KEY_FILE="$AGE_KEY_FILE"
    
    if ! sops --decrypt "$env_sops" > "$env_file" 2>&1 | tee -a "$LOG_FILE"; then
        log "ERROR: Failed to decrypt secrets"
        return 1
    fi
    
    chmod 600 "$env_file"
    log "Secrets decrypted successfully"
    return 0
}

# Restart Traefik container
restart_traefik() {
    log "Restarting Traefik container..."
    
    cd "$DEPLOY_PATH"
    
    if docker compose ps | grep -q "traefik"; then
        if docker compose restart traefik 2>&1 | tee -a "$LOG_FILE"; then
            log "Traefik restarted successfully"
            return 0
        else
            log "ERROR: Failed to restart Traefik"
            return 1
        fi
    else
        log "WARNING: Traefik container not running"
        return 1
    fi
}

# Main sync process
main() {
    log "=== Starting Traefik secret sync ==="
    
    acquire_lock
    check_prerequisites
    
    local repo_path=$(sync_repo)
    
    if decrypt_secrets "$repo_path"; then
        log "Secrets updated successfully"
        
        # Optional: Restart Traefik to pick up new secrets
        if [ "${AUTO_RESTART:-true}" = "true" ]; then
            restart_traefik || log "WARNING: Container restart failed"
        fi
        
        log "=== Sync completed successfully ==="
    else
        log "=== Sync completed with warnings ==="
    fi
    
    # Cleanup
    rm -rf "$repo_path"
}

main "$@"
