#!/usr/bin/env bash
# Extract environment variables from .env.sops for Portainer
# This script decrypts and formats the variables for easy copy-paste into Portainer UI

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
AGE_KEY="${AGE_KEY_FILE:-${SCRIPT_DIR}/../../../age.agekey}"
ENV_SOPS="${SCRIPT_DIR}/.env.sops"

if [[ ! -f "${AGE_KEY}" ]]; then
    echo "❌ Age key not found: ${AGE_KEY}"
    echo "Set AGE_KEY_FILE environment variable to the key location"
    exit 1
fi

if [[ ! -f "${ENV_SOPS}" ]]; then
    echo "❌ Encrypted env file not found: ${ENV_SOPS}"
    exit 1
fi

if ! command -v sops >/dev/null 2>&1; then
    echo "❌ SOPS is not installed"
    echo "Install with: brew install sops"
    exit 1
fi

echo "🔓 Decrypting environment variables for Portainer..."
echo ""
echo "═══════════════════════════════════════════════════════════"
echo "Copy-paste these into Portainer Stack Environment Variables"
echo "═══════════════════════════════════════════════════════════"
echo ""

export SOPS_AGE_KEY_FILE="${AGE_KEY}"
sops --decrypt "${ENV_SOPS}" | grep -v "^#" | grep -v "^$"

echo ""
echo "═══════════════════════════════════════════════════════════"
echo ""
echo "📝 Instructions:"
echo "1. Open Portainer → Stacks → Add Stack"
echo "2. Name: traefik"
echo "3. Build method: Git repository"
echo "4. Repository URL: https://github.com/codefuturist/iac-catalog.git"
echo "5. Reference: develop"
echo "6. Compose path: deployments/production/traefik/docker-compose.yml"
echo "7. Copy the variables above into 'Environment variables' section"
echo "8. Enable 'Pull latest image'"
echo "9. Click 'Deploy the stack'"
echo ""
echo "⚠️  Remember to double the dollar signs in DASHBOARD_USERS:"
echo "   \$2y\$05\$... → \$\$2y\$\$05\$\$..."
echo ""
