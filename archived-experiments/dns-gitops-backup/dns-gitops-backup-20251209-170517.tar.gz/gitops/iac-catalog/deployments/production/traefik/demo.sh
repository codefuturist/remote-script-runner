#!/usr/bin/env bash
# Guided walkthrough for the Traefik GitOps deployment

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

step() {
    echo ""
    echo "=== $1 ==="
}

step "Traefik GitOps Demo"
echo "This helper walks through review → deploy → validate so you can mirror the flow Portainer follows."

step "1. Review stack contents"
tree -a -I 'traefik/acme|traefik/logs' || ls -la
echo ""
echo "Key files:"
echo "- docker-compose.yml (stack definition)"
echo "- .env (never committed; copy from .env.example)"
echo "- traefik/traefik.yml (static configuration)"
echo "- PORTAINER.md (GitOps instructions)"

read -r -p "Continue to manual deployment? (y/N) " ANSWER
if [[ ! ${ANSWER} =~ ^[Yy]$ ]]; then
    echo "Skipping deployment per user request."
    exit 0
fi

step "2. Manual deployment"
if ./deploy.sh; then
    echo "Deployment succeeded."
else
    echo "Deployment failed." >&2
    exit 1
fi

step "3. Validation"
if ./validate.sh; then
    echo "Validation passed."
else
    echo "Validation reported issues."
fi

step "All done"
echo "Remember: Portainer should own day-2 operations. Use this flow only for verification or emergency fixes."