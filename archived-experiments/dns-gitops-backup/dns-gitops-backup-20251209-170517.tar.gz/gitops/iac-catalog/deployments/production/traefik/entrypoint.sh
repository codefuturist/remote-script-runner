#!/bin/sh
# Traefik entrypoint script to load secrets from files

set -e

# Read secrets from files if they exist
if [ -f /run/secrets/cf_dns_api_token ]; then
    export CF_DNS_API_TOKEN=$(cat /run/secrets/cf_dns_api_token)
fi

if [ -f /run/secrets/cloudflare_dns_api_token ]; then
    export CLOUDFLARE_DNS_API_TOKEN=$(cat /run/secrets/cloudflare_dns_api_token)
fi

if [ -f /run/secrets/cf_api_token ]; then
    export CF_API_TOKEN=$(cat /run/secrets/cf_api_token)
fi

# Start Traefik with all arguments
exec traefik "$@"
