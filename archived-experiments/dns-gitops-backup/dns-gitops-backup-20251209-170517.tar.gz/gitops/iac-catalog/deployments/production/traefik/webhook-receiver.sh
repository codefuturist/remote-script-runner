#!/usr/bin/env bash
# Webhook receiver for Traefik secret sync
# Listens for GitHub/GitLab webhooks and triggers secret sync

set -euo pipefail

PORT="${WEBHOOK_PORT:-9000}"
SECRET="${WEBHOOK_SECRET:-}"
SYNC_SCRIPT="/opt/traefik/sync-secrets.sh"
LOG_FILE="/var/log/traefik-webhook.log"

log() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] $*" | tee -a "$LOG_FILE"
}

# Simple HTTP server that triggers sync on POST
handle_webhook() {
    while true; do
        log "Webhook server listening on port $PORT"
        
        # Use netcat to listen for incoming requests
        echo -e "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\nWebhook received" | \
            nc -l -p "$PORT" -q 1 > /tmp/webhook-payload 2>/dev/null
        
        if [ -s /tmp/webhook-payload ]; then
            log "Webhook triggered, starting secret sync..."
            
            # Run sync in background
            if [ -x "$SYNC_SCRIPT" ]; then
                "$SYNC_SCRIPT" >> "$LOG_FILE" 2>&1 &
                log "Sync job started (PID: $!)"
            else
                log "ERROR: Sync script not found or not executable: $SYNC_SCRIPT"
            fi
            
            rm -f /tmp/webhook-payload
        fi
    done
}

log "Starting webhook receiver on port $PORT"
handle_webhook
