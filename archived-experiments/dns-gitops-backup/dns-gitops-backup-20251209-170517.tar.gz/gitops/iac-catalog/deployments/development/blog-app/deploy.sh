#!/usr/bin/env bash
# Blog App Deployment Script
# Quick deployment of the blog application example

set -euo pipefail

# Determine the directory where this script lives (deployment directory)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Assume repository root is two levels up from the deployment dir (deployments/<env>/<name>)
REPO_ROOT="$(cd "${SCRIPT_DIR}/../.." && pwd)"

# Compute repository-relative deployment path (used by the Ansible playbook)
if [[ "${SCRIPT_DIR}" == "${REPO_ROOT}"* ]]; then
    DEPLOYMENT_PATH_REL="${SCRIPT_DIR#${REPO_ROOT}/}"
else
    # Fallback to known relative path
    DEPLOYMENT_PATH_REL="deployments/development/blog-app"
fi

# Files to validate (absolute)
MANIFEST_PATH="${SCRIPT_DIR}/manifest.yml"
COMPOSE_PATH="${SCRIPT_DIR}/docker-compose.yml"
ENV_PATH="${SCRIPT_DIR}/.env"

# Configuration
TARGET_HOST="server-dev-01"
INVENTORY="${REPO_ROOT}/ansible/inventory/dynamic.py"
PLAYBOOK="${REPO_ROOT}/ansible/playbooks/docker-compose-deploy.yml"

echo "🚀 Deploying Blog Application"
echo "=============================="
echo "Deployment (repo-relative): ${DEPLOYMENT_PATH_REL}"
echo "Deployment dir: ${SCRIPT_DIR}"
echo "Target Host: ${TARGET_HOST}"
echo "Playbook: ${PLAYBOOK}"
echo ""

echo "📋 Validating deployment files..."
if [[ ! -f "${MANIFEST_PATH}" ]]; then
    echo "❌ Error: manifest.yml not found at ${MANIFEST_PATH}"
    exit 1
fi

if [[ ! -f "${COMPOSE_PATH}" ]]; then
    echo "❌ Error: docker-compose.yml not found at ${COMPOSE_PATH}"
    exit 1
fi

if [[ ! -f "${ENV_PATH}" ]]; then
    echo "❌ Error: .env not found at ${ENV_PATH}"
    exit 1
fi

echo "✅ All deployment files found"
echo ""

echo "🔧 Running Ansible deployment..."
ansible-playbook -i "${INVENTORY}" "${PLAYBOOK}" \
    -e "deployment_path=${DEPLOYMENT_PATH_REL}" \
    -e "target_host=${TARGET_HOST}"

echo ""
echo "🎉 Deployment completed!"
echo ""
echo "📝 Next steps:"
echo "1. Open http://$TARGET_HOST:8080 in your browser"
echo "2. Complete WordPress setup wizard"
echo "3. Change default admin password"
echo ""
echo "🔍 Check deployment status:" 
echo "   docker-compose -f /opt/deployments/blog-app/docker-compose.yml ps"
echo ""
echo "📊 View logs:" 
echo "   docker-compose -f /opt/deployments/blog-app/docker-compose.yml logs"