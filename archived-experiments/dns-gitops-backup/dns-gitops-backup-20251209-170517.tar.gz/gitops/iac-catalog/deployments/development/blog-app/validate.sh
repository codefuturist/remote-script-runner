#!/bin/bash
# Blog App Validation Script
# Validate the blog application deployment

set -e

TARGET_HOST="server-dev-01"
REMOTE_PATH="/opt/deployments/blog-app"

echo "🔍 Validating Blog Application Deployment"
echo "=========================================="

# Check if we can connect to the target host
echo "📡 Checking connectivity to $TARGET_HOST..."
if ! ssh -o ConnectTimeout=5 "$TARGET_HOST" "echo 'SSH connection successful'" 2>/dev/null; then
    echo "❌ Cannot connect to $TARGET_HOST"
    echo "   Make sure the server is running and SSH is configured"
    exit 1
fi

echo "✅ SSH connection successful"
echo ""

# Check if deployment directory exists
echo "📁 Checking deployment directory..."
if ! ssh "$TARGET_HOST" "test -d $REMOTE_PATH"; then
    echo "❌ Deployment directory $REMOTE_PATH not found"
    echo "   Run the deployment first: ./deploy.sh"
    exit 1
fi

echo "✅ Deployment directory exists"
echo ""

# Check docker-compose file
echo "🐳 Checking Docker Compose configuration..."
if ! ssh "$TARGET_HOST" "test -f $REMOTE_PATH/docker-compose.yml"; then
    echo "❌ docker-compose.yml not found"
    exit 1
fi

echo "✅ Docker Compose file found"
echo ""

# Check environment file
echo "🔐 Checking environment configuration..."
if ! ssh "$TARGET_HOST" "test -f $REMOTE_PATH/.env"; then
    echo "❌ .env file not found"
    exit 1
fi

echo "✅ Environment file found"
echo ""

# Check running containers
echo "🚀 Checking running containers..."
CONTAINERS=$(ssh "$TARGET_HOST" "cd $REMOTE_PATH && docker-compose ps --services --filter 'status=running' 2>/dev/null || echo ''")

if [[ -z "$CONTAINERS" ]]; then
    echo "❌ No running containers found"
    echo ""
    echo "🔧 Try starting the services:"
    echo "   ssh $TARGET_HOST 'cd $REMOTE_PATH && docker-compose up -d'"
    exit 1
fi

echo "✅ Running containers: $CONTAINERS"
echo ""

# Check service health
echo "💚 Checking service health..."
if ! ssh "$TARGET_HOST" "curl -f http://localhost:8080 --max-time 10" 2>/dev/null; then
    echo "⚠️  WordPress service may not be ready yet"
    echo "   This is normal during initial startup"
    echo "   Try again in a few minutes"
else
    echo "✅ WordPress service is responding"
fi

echo ""
echo "📊 Deployment Status Summary:"
echo "=============================="
echo "Host: $TARGET_HOST"
echo "Path: $REMOTE_PATH"
echo "URL: http://$TARGET_HOST:8080"
echo "Containers: $CONTAINERS"
echo ""
echo "🎉 Validation completed!"
echo ""
echo "🌐 Access your blog at: http://$TARGET_HOST:8080"