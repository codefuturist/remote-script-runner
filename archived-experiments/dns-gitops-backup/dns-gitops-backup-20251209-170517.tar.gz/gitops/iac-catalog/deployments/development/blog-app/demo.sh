#!/bin/bash
# Complete Blog App Demo
# Demonstrates the full iac-catalog deployment workflow

set -e

echo "🎭 IaC Catalog - Complete Deployment Demo"
echo "=========================================="
echo ""
echo "This demo will show you how to:"
echo "1. 📋 Review the deployment configuration"
echo "2. 🚀 Deploy the blog application"
echo "3. 🔍 Validate the deployment"
echo "4. 🧹 Clean up (optional)"
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check prerequisites
print_status "Checking prerequisites..."

if ! command -v ansible-playbook &> /dev/null; then
    print_error "Ansible is not installed. Please install Ansible first."
    exit 1
fi

if ! command -v docker &> /dev/null; then
    print_warning "Docker not found locally (this is OK if deploying remotely)"
fi

print_success "Prerequisites check passed"
echo ""

# Step 1: Review configuration
print_status "Step 1: Reviewing deployment configuration"
echo "Files in this deployment:"
ls -la
echo ""
echo "Key configuration:"
echo "- manifest.yml: Deployment metadata"
echo "- target.yml: Target server configuration"
echo "- docker-compose.yml: Container orchestration"
echo "- .env: Environment variables"
echo ""

read -p "Press Enter to continue to deployment..."

# Step 2: Deploy
print_status "Step 2: Deploying blog application"
echo "Running deployment script..."
echo ""

if ./deploy.sh; then
    print_success "Deployment completed successfully!"
else
    print_error "Deployment failed. Check the output above for details."
    exit 1
fi

echo ""

# Step 3: Validate
print_status "Step 3: Validating deployment"
echo "Running validation script..."
echo ""

if ./validate.sh; then
    print_success "Validation completed successfully!"
else
    print_warning "Validation found some issues. Check the output above."
fi

echo ""

# Step 4: Summary
print_success "Demo completed!"
echo ""
echo "🎉 Your blog application is now deployed!"
echo ""
echo "📋 What was deployed:"
echo "   - WordPress 6.6 blog application"
echo "   - MySQL 8.0 database"
echo "   - Persistent storage for content"
echo "   - Isolated Docker network"
echo ""
echo "🌐 Access your blog:"
echo "   URL: http://server-dev-01:8080"
echo "   Admin: admin / password (change immediately!)"
echo ""
echo "🛠️  Management commands:"
echo "   View logs: docker-compose logs"
echo "   Stop app: docker-compose down"
echo "   Restart: docker-compose restart"
echo ""
echo "📚 Learn more:"
echo "   Read the README.md for detailed documentation"
echo "   Check STRUCTURE.md for repository navigation"
echo "   Explore examples/ for more deployment examples"
echo ""

# Optional cleanup
read -p "Would you like to see cleanup options? (y/N): " -n 1 -r
echo ""
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo ""
    echo "🧹 Cleanup Options:"
    echo "=================="
    echo "Stop and remove containers:"
    echo "  docker-compose down"
    echo ""
    echo "Remove containers AND volumes (DESTROYS DATA):"
    echo "  docker-compose down -v"
    echo ""
    echo "Remove everything including images:"
    echo "  docker-compose down --rmi all -v"
    echo ""
    echo "Remove deployment files from server:"
    echo "  ssh server-dev-01 'rm -rf /opt/deployments/blog-app'"
    echo ""
fi

print_success "Demo finished! Happy deploying! 🚀"