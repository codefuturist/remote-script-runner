# IaC Catalog - README

This directory contains the **deployments** for the IaC catalog - actual configured instances ready for deployment via GitOps.

## Directory Structure

```
deployments/
├── production/          # Production deployments
│   ├── inventory.yml    # Environment inventory reference
│   └── {instance-id}/   # Individual instance deployments
│       ├── manifest.yml         # Instance metadata
│       ├── docker-compose.yml   # Application configuration
│       ├── .env                 # Environment variables
│       └── target.yml           # Deployment target (single or multiple servers)
├── staging/             # Staging deployments
└── development/         # Development deployments
```

## How It Works

1. **Templates** are stored in `catalog/`
2. **CLI tool** (`scripts/cli/configure.sh`) generates instance configurations here
3. **GitOps agent** watches this directory for changes
4. Changes committed to Git are **automatically deployed** to target servers

## Examples

### Single Server Deployment
```
deployments/production/app-wordpress-server01/
├── manifest.yml              # What template + metadata
├── docker-compose.yml        # Application config
├── .env                      # Instance-specific variables
└── target.yml                # Deploy to ONE server
```

### Multi-Server Deployment
```
deployments/production/monitoring-stack/
├── manifest.yml              # What template + metadata
├── docker-compose.yml        # Application config
├── .env                      # Instance-specific variables
└── targets.yml               # Deploy to MULTIPLE servers (group)
```

## Creating a New Deployment

Use the CLI tool:

```bash
# Single server
./scripts/cli/configure.sh \
  --template catalog/containers/docker/compose-stacks/wordpress \
  --instance app-wordpress-server01 \
  --environment production \
  --target server-web-01 \
  --param domain=blog.example.com

# Multi-server (group)
./scripts/cli/configure.sh \
  --template catalog/containers/docker/compose-stacks/monitoring-stack \
  --instance monitoring-stack \
  --environment production \
  --target monitoring-nodes
```

## Deployment Workflow

1. Configure instance with CLI tool
2. Review generated files
3. Commit to Git: `git add deployments/production/my-app && git commit -m "feat: deploy my-app"`
4. Push: `git push`
5. GitOps agent automatically deploys to target servers

## See Also

- `inventory/` - Infrastructure inventory (servers, clusters, groups)
- `environments/` - Environment-wide defaults and overrides
- `catalog/` - Template library
- `.gitops/` - GitOps agent configuration
