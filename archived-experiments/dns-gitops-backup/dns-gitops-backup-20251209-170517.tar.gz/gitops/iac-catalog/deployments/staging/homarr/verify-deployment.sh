#!/usr/bin/env bash
# Deploy and verify Homarr on k3s-develop cluster
# This script checks the current state and ensures Homarr is properly deployed

set -euo pipefail

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

CONTEXT="k3s-develop"
NAMESPACE="dashboard"

echo -e "${BLUE}════════════════════════════════════════════════════════${NC}"
echo -e "${BLUE}   Homarr Deployment Verification - k3s-develop${NC}"
echo -e "${BLUE}════════════════════════════════════════════════════════${NC}"
echo ""

# Check if kubectl is available
if ! command -v kubectl &> /dev/null; then
    echo -e "${RED}✗ kubectl not found. Please install kubectl.${NC}"
    exit 1
fi

echo -e "${GREEN}✓ kubectl found${NC}"

# Check if context exists
if ! kubectl config get-contexts | grep -q "$CONTEXT"; then
    echo -e "${RED}✗ Context '$CONTEXT' not found in kubeconfig${NC}"
    exit 1
fi

echo -e "${GREEN}✓ Context '$CONTEXT' exists${NC}"

# Check cluster connectivity
if ! kubectl --context "$CONTEXT" cluster-info &> /dev/null; then
    echo -e "${RED}✗ Cannot connect to cluster '$CONTEXT'${NC}"
    exit 1
fi

echo -e "${GREEN}✓ Connected to cluster '$CONTEXT'${NC}"
echo ""

# Check if flux-system namespace exists
echo -e "${YELLOW}Checking FluxCD installation...${NC}"
if kubectl --context "$CONTEXT" get namespace flux-system &> /dev/null; then
    echo -e "${GREEN}✓ FluxCD namespace exists${NC}"
else
    echo -e "${RED}✗ FluxCD namespace not found. FluxCD must be installed first.${NC}"
    exit 1
fi

# Check if FluxCD controllers are running
FLUX_PODS=$(kubectl --context "$CONTEXT" get pods -n flux-system --no-headers 2>/dev/null | wc -l)
if [ "$FLUX_PODS" -gt 0 ]; then
    echo -e "${GREEN}✓ FluxCD controllers running ($FLUX_PODS pods)${NC}"
else
    echo -e "${RED}✗ No FluxCD pods found${NC}"
    exit 1
fi

echo ""

# Check dashboard namespace
echo -e "${YELLOW}Checking dashboard namespace...${NC}"
if kubectl --context "$CONTEXT" get namespace "$NAMESPACE" &> /dev/null; then
    echo -e "${GREEN}✓ Namespace '$NAMESPACE' exists${NC}"
else
    echo -e "${YELLOW}⚠ Namespace '$NAMESPACE' does not exist${NC}"
    echo -e "${YELLOW}  FluxCD should create it from infrastructure manifests${NC}"
fi

echo ""

# Check for HelmRepository
echo -e "${YELLOW}Checking Helm repositories...${NC}"
if kubectl --context "$CONTEXT" get helmrepository -n "$NAMESPACE" homarr-labs &> /dev/null; then
    echo -e "${GREEN}✓ HelmRepository 'homarr-labs' exists${NC}"
    kubectl --context "$CONTEXT" get helmrepository -n "$NAMESPACE" homarr-labs -o jsonpath='{.status.conditions[?(@.type=="Ready")].status}' | grep -q "True" && \
        echo -e "${GREEN}✓ HelmRepository is ready${NC}" || \
        echo -e "${YELLOW}⚠ HelmRepository not ready yet${NC}"
else
    echo -e "${YELLOW}⚠ HelmRepository 'homarr-labs' not found${NC}"
fi

echo ""

# Check for HelmRelease
echo -e "${YELLOW}Checking Homarr HelmRelease...${NC}"
if kubectl --context "$CONTEXT" get helmrelease -n "$NAMESPACE" homarr &> /dev/null; then
    echo -e "${GREEN}✓ HelmRelease 'homarr' exists${NC}"
    
    # Check HelmRelease status
    RELEASE_STATUS=$(kubectl --context "$CONTEXT" get helmrelease -n "$NAMESPACE" homarr -o jsonpath='{.status.conditions[?(@.type=="Ready")].status}' 2>/dev/null || echo "Unknown")
    if [ "$RELEASE_STATUS" == "True" ]; then
        echo -e "${GREEN}✓ HelmRelease is ready${NC}"
    else
        echo -e "${YELLOW}⚠ HelmRelease status: $RELEASE_STATUS${NC}"
        echo -e "${YELLOW}  Checking for issues...${NC}"
        kubectl --context "$CONTEXT" get helmrelease -n "$NAMESPACE" homarr -o jsonpath='{.status.conditions[?(@.type=="Ready")].message}' 2>/dev/null || echo ""
    fi
else
    echo -e "${YELLOW}⚠ HelmRelease 'homarr' not found${NC}"
fi

echo ""

# Check for Homarr pods
echo -e "${YELLOW}Checking Homarr pods...${NC}"
HOMARR_PODS=$(kubectl --context "$CONTEXT" get pods -n "$NAMESPACE" -l app=homarr --no-headers 2>/dev/null | wc -l)
if [ "$HOMARR_PODS" -gt 0 ]; then
    echo -e "${GREEN}✓ Homarr pods found: $HOMARR_PODS${NC}"
    kubectl --context "$CONTEXT" get pods -n "$NAMESPACE" -l app=homarr
    echo ""
    
    # Check pod status
    RUNNING_PODS=$(kubectl --context "$CONTEXT" get pods -n "$NAMESPACE" -l app=homarr --field-selector=status.phase=Running --no-headers 2>/dev/null | wc -l)
    if [ "$RUNNING_PODS" -gt 0 ]; then
        echo -e "${GREEN}✓ Homarr is running ($RUNNING_PODS pods)${NC}"
    else
        echo -e "${YELLOW}⚠ Homarr pods exist but none are running${NC}"
    fi
else
    echo -e "${YELLOW}⚠ No Homarr pods found${NC}"
fi

echo ""

# Check for secrets
echo -e "${YELLOW}Checking secrets...${NC}"
if kubectl --context "$CONTEXT" get secret -n "$NAMESPACE" db-encryption &> /dev/null; then
    echo -e "${GREEN}✓ Secret 'db-encryption' exists${NC}"
else
    echo -e "${YELLOW}⚠ Secret 'db-encryption' not found${NC}"
    echo -e "${YELLOW}  This secret is required for Homarr to work properly${NC}"
fi

echo ""

# Check for services
echo -e "${YELLOW}Checking services...${NC}"
if kubectl --context "$CONTEXT" get service -n "$NAMESPACE" homarr &> /dev/null; then
    echo -e "${GREEN}✓ Service 'homarr' exists${NC}"
    SERVICE_TYPE=$(kubectl --context "$CONTEXT" get service -n "$NAMESPACE" homarr -o jsonpath='{.spec.type}')
    echo -e "  Type: $SERVICE_TYPE"
else
    echo -e "${YELLOW}⚠ Service 'homarr' not found${NC}"
fi

echo ""

# Check for ingress
echo -e "${YELLOW}Checking ingress...${NC}"
INGRESS_COUNT=$(kubectl --context "$CONTEXT" get ingress -n "$NAMESPACE" --no-headers 2>/dev/null | grep -i homarr | wc -l)
if [ "$INGRESS_COUNT" -gt 0 ]; then
    echo -e "${GREEN}✓ Ingress found for Homarr${NC}"
    kubectl --context "$CONTEXT" get ingress -n "$NAMESPACE" | grep -i homarr
else
    echo -e "${YELLOW}⚠ No ingress found for Homarr${NC}"
fi

echo ""

# Check FluxCD kustomizations
echo -e "${YELLOW}Checking FluxCD kustomizations...${NC}"
kubectl --context "$CONTEXT" get kustomization -n flux-system -o wide 2>/dev/null || echo "No kustomizations found"

echo ""
echo -e "${BLUE}════════════════════════════════════════════════════════${NC}"
echo -e "${BLUE}   Verification Complete${NC}"
echo -e "${BLUE}════════════════════════════════════════════════════════${NC}"
echo ""

# Summary
if [ "$HOMARR_PODS" -gt 0 ] && [ "$RUNNING_PODS" -gt 0 ]; then
    echo -e "${GREEN}✓ Homarr is deployed and running!${NC}"
    echo ""
    echo -e "Access Homarr at: ${GREEN}http://homarr.staging.local${NC}"
    echo ""
    echo -e "To view logs:"
    echo -e "  ${BLUE}kubectl --context $CONTEXT logs -n $NAMESPACE -l app=homarr -f${NC}"
    echo ""
    echo -e "To port-forward for local access:"
    echo -e "  ${BLUE}kubectl --context $CONTEXT port-forward -n $NAMESPACE svc/homarr 7575:7575${NC}"
else
    echo -e "${YELLOW}⚠ Homarr is not fully deployed yet${NC}"
    echo ""
    echo -e "Possible actions:"
    echo -e "1. Wait for FluxCD to reconcile (usually happens within 2 minutes)"
    echo -e "2. Force reconciliation:"
    echo -e "   ${BLUE}flux reconcile kustomization apps --with-source${NC}"
    echo -e "3. Check FluxCD logs:"
    echo -e "   ${BLUE}kubectl --context $CONTEXT logs -n flux-system -l app=kustomize-controller -f${NC}"
fi

echo ""
