# Homarr Dashboard - Staging Deployment

## Overview

Homarr is a sleek, modern dashboard that puts all of your apps and services at your fingertips. This deployment is configured for the k3s-develop staging cluster using FluxCD for GitOps management.

## Deployment Information

- **Instance ID**: homarr-dashboard
- **Environment**: Staging
- **Cluster**: k3s-develop
- **Namespace**: dashboard
- **Managed By**: FluxCD

## Architecture

- **Chart Repository**: https://homarr-labs.github.io/charts/
- **Deployment Method**: Kubernetes HelmRelease via FluxCD
- **Database**: SQLite (1Gi persistent volume)
- **Ingress**: Traefik
- **Access URL**: http://homarr.staging.local

## Features

- **Customizable Widgets**: Create personalized dashboard layouts
- **Application Integration**: Connect and monitor your services
- **Modern UI**: Clean, responsive interface
- **Self-hosted**: Full control over your data
- **Credential Authentication**: Secure access with username/password

## Configuration

### Resources

- **CPU Requests**: 50m
- **Memory Requests**: 256Mi
- **CPU Limits**: 300m
- **Memory Limits**: 512Mi

### Storage

- **Type**: Persistent Volume
- **Size**: 1Gi
- **StorageClass**: Default
- **Access Mode**: ReadWriteOnce
- **Mount Path**: /app/database

### Health Checks

- **Liveness Probe**: `/api/health/live` (port 7575)
  - Initial Delay: 30s
  - Timeout: 5s
  - Period: 15s
  - Failure Threshold: 5

- **Readiness Probe**: `/api/health/ready` (port 7575)
  - Initial Delay: 20s
  - Timeout: 5s
  - Period: 10s
  - Failure Threshold: 5

## Secret Management

Homarr requires a database encryption key stored in a Kubernetes secret:

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: db-encryption
  namespace: dashboard
type: Opaque
stringData:
  db-encryption-key: "<encryption-key>"
```

The secret is managed via SOPS and referenced in the FluxCD manifests at:
`catalog/gitops/flux/clusters/staging/apps/production/homarr/homarr-db-secret.yaml`

## FluxCD Configuration

### Source Manifests

The FluxCD manifests are located at:
```
catalog/gitops/flux/clusters/staging/apps/production/homarr/
├── homarr-db-secret.yaml
├── homarr-helmrelease.yaml
├── kustomization.yaml
└── README.md
```

### Sync Configuration

- **Interval**: 2m
- **Timeout**: 30m
- **Max History**: 3
- **Auto Remediation**: Enabled (3 retries)

## Deployment Steps

### Prerequisites

1. Ensure k3s-develop cluster is running
2. Verify FluxCD is installed and operational
3. Confirm dashboard namespace exists
4. Check that Traefik ingress controller is deployed

### Deploy Homarr

The application is automatically deployed by FluxCD when the manifests are present in the Git repository and referenced in the apps kustomization:

```bash
# Verify FluxCD is tracking the application
kubectl get helmrelease -n dashboard homarr

# Check deployment status
kubectl get pods -n dashboard -l app=homarr

# View logs
kubectl logs -n dashboard -l app=homarr

# Check ingress
kubectl get ingress -n dashboard
```

### Verify Deployment

```bash
# Check HelmRelease status
flux get helmrelease -n dashboard homarr

# Check if the pod is running
kubectl get pods -n dashboard

# Test health endpoints
kubectl port-forward -n dashboard svc/homarr 7575:7575
curl http://localhost:7575/api/health/live
curl http://localhost:7575/api/health/ready
```

## Access

Once deployed, access Homarr at:
- **URL**: http://homarr.staging.local
- **Default Port**: 7575

Add the following to your `/etc/hosts` file for local access:
```
<k3s-node-ip> homarr.staging.local
```

## Troubleshooting

### Pod Not Starting

```bash
# Check pod status
kubectl describe pod -n dashboard -l app=homarr

# Check events
kubectl get events -n dashboard --sort-by='.lastTimestamp'
```

### Secret Issues

```bash
# Verify secret exists
kubectl get secret -n dashboard db-encryption

# Check secret contents (be careful with sensitive data)
kubectl get secret -n dashboard db-encryption -o yaml
```

### Ingress Issues

```bash
# Check ingress status
kubectl describe ingress -n dashboard

# Verify Traefik is running
kubectl get pods -n kube-system -l app.kubernetes.io/name=traefik
```

### Database Issues

```bash
# Check PVC status
kubectl get pvc -n dashboard

# Check if volume is mounted
kubectl exec -n dashboard -it <pod-name> -- ls -la /app/database
```

## Maintenance

### Update Configuration

1. Modify the HelmRelease values in `catalog/gitops/flux/clusters/staging/apps/production/homarr/homarr-helmrelease.yaml`
2. Commit and push changes
3. FluxCD will automatically reconcile the changes

### Rotate Database Encryption Key

⚠️ **Warning**: Rotating the encryption key requires careful planning as it may affect existing data.

1. Generate a new key: `openssl rand -base64 60`
2. Update the secret in `homarr-db-secret.yaml`
3. Encrypt with SOPS: `sops --encrypt --in-place homarr-db-secret.yaml`
4. Commit and push changes

### Backup and Restore

The SQLite database is stored in the persistent volume at `/app/database`. Use Velero or manual backup methods to secure the data.

## Integration

Homarr integrates with Homepage dashboard via annotations:

```yaml
annotations:
  gethomepage.dev/enabled: "true"
  gethomepage.dev/name: "Homarr"
  gethomepage.dev/description: "Customizable Dashboard"
  gethomepage.dev/group: "Dashboard"
  gethomepage.dev/icon: "homarr.png"
```

## References

- [Homarr Documentation](https://homarr.dev/)
- [Homarr GitHub](https://github.com/ajnart/homarr)
- [Homarr Helm Charts](https://github.com/homarr-labs/charts)
- [FluxCD Documentation](https://fluxcd.io/docs/)

## Support

For issues specific to this deployment, check:
1. FluxCD reconciliation status
2. Kubernetes events in the dashboard namespace
3. Application logs in the pod
4. Ingress controller logs
