# Operators

This directory contains Kubernetes operators for database management.

## CloudNativePG

PostgreSQL operator that manages the full lifecycle of PostgreSQL clusters.

- **File**: `cloudnative-pg/cloudnative-pg-operator.yaml`
- **Namespace**: `database`
- **Version**: 0.26.1 (chart), 1.27.1 (app)
- **Repository**: https://cloudnative-pg.github.io/charts

### Features
- Declarative cluster management via CRDs
- Automated failover and recovery
- Continuous backup and point-in-time recovery
- Connection pooling with PgBouncer
- Monitoring with Prometheus metrics

## MariaDB Operator

MariaDB operator providing Database, User, and Grant CRDs for declarative management.

- **File**: `mariadb/mariadb-operator.yaml`
- **Namespace**: `mariadb-system`
- **Version**: 0.31.x
- **Repository**: https://mariadb-operator.github.io/mariadb-operator

### Features
- Declarative Database/User/Grant CRDs
- Galera cluster support (multi-master)
- Automated backups and restores
- MaxScale integration for load balancing
- Prometheus metrics and monitoring

## Deployment

Both operators are deployed automatically via the root `kustomization.yaml`:

```yaml
resources:
  - operators/cloudnative-pg/cloudnative-pg-operator.yaml
  - operators/mariadb/mariadb-operator.yaml
```

## Verification

```bash
# Check CloudNativePG operator
kubectl get deployment -n database cloudnative-pg
kubectl get crd | grep postgresql

# Check MariaDB operator
kubectl get deployment -n mariadb-system mariadb-operator
kubectl get crd | grep mariadb

# Check API resources
kubectl api-resources | grep -E "cluster|database|user|grant"
```
