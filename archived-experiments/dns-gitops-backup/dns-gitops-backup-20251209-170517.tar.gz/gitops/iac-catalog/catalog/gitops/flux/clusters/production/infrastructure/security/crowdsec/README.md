# CrowdSec Security Engine

CrowdSec is a collaborative security engine that provides threat intelligence and automated remediation.

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                        Internet                             │
└─────────────────────────┬───────────────────────────────────┘
                          │
        ┌─────────────────┼─────────────────┐
        │                 │                 │
        ▼                 ▼                 ▼
   ┌─────────┐      ┌─────────┐      ┌─────────┐
   │ Traefik │      │  nginx  │      │  Other  │
   │ Ingress │      │ Ingress │      │ Services│
   └────┬────┘      └────┬────┘      └─────────┘
        │                │
        │  ForwardAuth   │  auth_request
        ▼                ▼
   ┌─────────────────────────────┐
   │   CrowdSec Traefik Bouncer  │  ◄── Checks decisions
   └─────────────┬───────────────┘
                 │
                 ▼
   ┌─────────────────────────────┐
   │      CrowdSec LAPI          │  ◄── Stores decisions
   │   (Local API + Agent)       │
   └─────────────┬───────────────┘
                 │
                 ▼
   ┌─────────────────────────────┐
   │   CrowdSec Central API      │  ◄── Shared threat intel
   │   (Community Blocklists)    │
   └─────────────────────────────┘
```

## Components

### 1. CrowdSec LAPI (Local API)
- Central decision store
- Manages bouncer registrations
- Syncs with CrowdSec Central API for threat intelligence

### 2. CrowdSec Agent
- Parses ingress controller logs
- Detects attacks based on scenarios
- Sends alerts to LAPI

### 3. Traefik Bouncer
- Integrates with Traefik via ForwardAuth middleware
- Also works with nginx via auth_request

## Admin-Tolerant Features

This setup is configured to be tolerant for administrators:

### Whitelisted Networks
The following networks are **never blocked**:
- `10.0.0.0/8` - Private networks
- `172.16.0.0/12` - Private networks
- `192.168.0.0/16` - Private networks
- `10.43.0.0/16` - k3s cluster CIDR

### Fallback Behavior
When LAPI is unreachable, the bouncer **allows all traffic** rather than blocking.

### Short Ban Duration
Initial ban duration is **4 hours** (not permanent) to allow recovery from false positives.

### Excluded Paths
Health check and metrics endpoints are excluded from protection:
- `/health`, `/healthz`, `/ready`
- `/metrics`
- `/.well-known`

## Usage

### Traefik Integration

Add the `crowdsec-bouncer` middleware to your IngressRoute:

```yaml
apiVersion: traefik.io/v1alpha1
kind: IngressRoute
metadata:
  name: my-app
  namespace: my-namespace
spec:
  entryPoints:
    - websecure
  routes:
    - kind: Rule
      match: Host(`app.example.com`)
      middlewares:
        # Option 1: Just CrowdSec
        - name: crowdsec-bouncer
          namespace: ingress-system

        # Option 2: Chain with security headers
        - name: chain-crowdsec-public
          namespace: ingress-system

        # Option 3: Chain for large files (Nextcloud)
        - name: chain-crowdsec-large-files
          namespace: ingress-system
      services:
        - name: my-app
          port: 80
  tls:
    secretName: my-tls-secret
```

### nginx-ingress Integration

Add these annotations to your Ingress:

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: my-app
  annotations:
    nginx.ingress.kubernetes.io/auth-url: "http://crowdsec-traefik-bouncer.crowdsec.svc.cluster.local:8080/api/v1/forwardAuth"
    nginx.ingress.kubernetes.io/auth-response-headers: "X-Crowdsec-Decision"
    nginx.ingress.kubernetes.io/auth-snippet: |
      proxy_set_header X-Real-IP $remote_addr;
      proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
spec:
  # ... rest of ingress spec
```

## Initial Setup

### Generate Bouncer API Key

After deploying CrowdSec LAPI, generate an API key for the bouncer:

```bash
# Generate API key
API_KEY=$(kubectl exec -n crowdsec deploy/crowdsec-lapi -- cscli bouncers add traefik-bouncer -o raw)

# Create secret
kubectl create secret generic crowdsec-bouncer-api-key \
  --namespace crowdsec \
  --from-literal=api-key="$API_KEY"
```

The bouncer HelmRelease references this secret via `valuesFrom`.

## Administration

### Check Decisions

```bash
# Get a shell in the LAPI pod
kubectl exec -it -n crowdsec deploy/crowdsec-lapi -- /bin/bash

# List current decisions (bans)
cscli decisions list

# List alerts
cscli alerts list

# Check hub status
cscli hub list
```

### Unban an IP

```bash
kubectl exec -it -n crowdsec deploy/crowdsec-lapi -- cscli decisions delete --ip <IP_ADDRESS>
```

### Add Manual Whitelist

```bash
kubectl exec -it -n crowdsec deploy/crowdsec-lapi -- cscli decisions add --ip <IP_ADDRESS> --type whitelist --duration 8760h
```

### View Metrics

```bash
# Port-forward to LAPI metrics
kubectl port-forward -n crowdsec svc/crowdsec-service 6060:6060

# Access metrics at http://localhost:6060/metrics
```

## Monitoring

### Prometheus Metrics

Enable ServiceMonitor if using prometheus-operator:

```yaml
# In crowdsec.yaml values:
lapi:
  metrics:
    serviceMonitor:
      enabled: true
```

### Dashboard

Enable Metabase dashboard for visualization:

```yaml
# In crowdsec.yaml values:
lapi:
  dashboard:
    enabled: true
    ingress:
      enabled: true
      ingressClassName: nginx
      host: crowdsec-dashboard.example.com
```

## Troubleshooting

### Bouncer Not Blocking

1. Check bouncer logs:
   ```bash
   kubectl logs -n crowdsec -l app.kubernetes.io/name=crowdsec-traefik-bouncer
   ```

2. Verify LAPI connection:
   ```bash
   kubectl exec -it -n crowdsec deploy/crowdsec-traefik-bouncer -- wget -qO- http://crowdsec-service:8080/health
   ```

3. Check decisions exist:
   ```bash
   kubectl exec -it -n crowdsec deploy/crowdsec-lapi -- cscli decisions list
   ```

### False Positives

1. Check which scenario triggered:
   ```bash
   kubectl exec -it -n crowdsec deploy/crowdsec-lapi -- cscli alerts list
   ```

2. Whitelist the IP:
   ```bash
   kubectl exec -it -n crowdsec deploy/crowdsec-lapi -- cscli decisions add --ip <IP> --type whitelist --duration 8760h
   ```

3. Consider adjusting scenario thresholds in `config.scenarios`

### Agent Not Collecting Logs

1. Verify agent pods are running:
   ```bash
   kubectl get pods -n crowdsec -l app.kubernetes.io/component=agent
   ```

2. Check agent logs:
   ```bash
   kubectl logs -n crowdsec -l app.kubernetes.io/component=agent
   ```

3. Verify acquisition configuration matches your ingress controller pods

## Files

- `namespace.yaml` - CrowdSec namespace
- `crowdsec.yaml` - Main CrowdSec deployment (LAPI + Agent)
- `bouncer-traefik.yaml` - Traefik bouncer + middlewares
- `bouncer-nginx.yaml` - nginx integration examples
