# Quick Reference - Using Staging Certificates

## Certificate Information

All staging certificates use:
- **Issuer**: `letsencrypt-staging` ClusterIssuer
- **Challenge Type**: DNS-01 via Cloudflare
- **Algorithm**: ECDSA P-384
- **Renewal**: 30 days before expiration

## Available Certificates

| Domain | Secret Name | Certificate Name |
|--------|-------------|------------------|
| *.colinrey.ch | colinrey.ch-tls-staging | colinrey-ch-staging |
| *.colinrey.com | colinrey.com-tls-staging | colinrey-com-staging |
| *.pandia.io | pandia.io-tls-staging | pandia-io-staging |
| *.reyitsolutions.ch | reyitsolutions.ch-tls-staging | reyitsolutions-ch-staging |
| *.reyitsolutions.com | reyitsolutions.com-tls-staging | reyitsolutions-com-staging |

## Using Certificates in Ingress

### Method 1: Automatic Certificate Request (Recommended)

Add annotation to automatically request and use a certificate:

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: my-app
  namespace: staging-apps
  annotations:
    cert-manager.io/cluster-issuer: letsencrypt-staging
spec:
  ingressClassName: traefik
  tls:
  - hosts:
    - myapp.colinrey.ch
    secretName: myapp-colinrey-ch-tls  # Will be created automatically
  rules:
  - host: myapp.colinrey.ch
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: my-app
            port:
              number: 80
```

### Method 2: Use Existing Wildcard Certificate

Reference an existing wildcard certificate:

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: my-app
  namespace: staging-apps
spec:
  ingressClassName: traefik
  tls:
  - hosts:
    - myapp.colinrey.ch
    secretName: colinrey.ch-tls-staging  # Use existing wildcard cert
  rules:
  - host: myapp.colinrey.ch
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: my-app
            port:
              number: 80
```

**Note**: Wildcard certificates are automatically reflected to these namespaces:
- cert-manager
- flux-system
- ingress
- monitoring
- staging-apps

## Verification Commands

```bash
# Check certificate status
kubectl get certificates -n cert-manager

# Detailed certificate info
kubectl describe certificate colinrey-ch-staging -n cert-manager

# Check if secret exists
kubectl get secret colinrey.ch-tls-staging -n cert-manager

# Check secret in another namespace (via reflection)
kubectl get secret colinrey.ch-tls-staging -n staging-apps

# Watch certificate issuance
watch kubectl get certificates -n cert-manager

# Follow cert-manager logs
kubectl logs -n cert-manager deployment/cert-manager -f
```

## Testing Certificate

Since staging certificates are not trusted by browsers, use curl with `-k` flag:

```bash
# Test with curl (ignore certificate warning)
curl -k https://myapp.colinrey.ch

# Check certificate details
curl -vk https://myapp.colinrey.ch 2>&1 | grep -A 10 "Server certificate"

# Or use openssl
openssl s_client -connect myapp.colinrey.ch:443 -servername myapp.colinrey.ch
```

Expected certificate details:
- **Issuer**: CN = Fake LE Intermediate X1
- **Subject**: CN = *.colinrey.ch

## Creating New Certificates

To create a new certificate for a different domain:

```yaml
apiVersion: cert-manager.io/v1
kind: Certificate
metadata:
  name: newdomain-staging
  namespace: cert-manager
spec:
  commonName: '*.newdomain.com'
  dnsNames:
    - newdomain.com
    - '*.newdomain.com'
  issuerRef:
    kind: ClusterIssuer
    name: letsencrypt-staging
  renewBefore: 720h
  secretName: newdomain.com-tls-staging
  privateKey:
    algorithm: ECDSA
    encoding: PKCS8
    size: 384
    rotationPolicy: Always
  secretTemplate:
    annotations:
      reflector.v1.k8s.emberstack.com/reflection-allowed: 'true'
      reflector.v1.k8s.emberstack.com/reflection-auto-enabled: 'true'
      reflector.v1.k8s.emberstack.com/reflection-auto-namespaces: "cert-manager,flux-system,ingress,monitoring,staging-apps"
```

## Troubleshooting

### Certificate Not Issued

```bash
# Check certificate events
kubectl describe certificate <cert-name> -n cert-manager

# Check certificate request
kubectl get certificaterequest -n cert-manager

# Check orders
kubectl get orders -n cert-manager

# Check challenges
kubectl get challenges -n cert-manager
```

### Secret Not Available in Namespace

```bash
# Check if reflector is running
kubectl get pods -n kube-system | grep reflector

# Check secret annotations
kubectl get secret <secret-name> -n cert-manager -o yaml | grep reflector

# Manually check if secret exists
kubectl get secrets -A | grep <secret-name>
```

### DNS Challenge Fails

```bash
# Verify Cloudflare token
kubectl get secret cloudflare-token-secret -n cert-manager -o yaml

# Check DNS propagation
dig TXT _acme-challenge.myapp.colinrey.ch

# Check cert-manager logs for Cloudflare errors
kubectl logs -n cert-manager deployment/cert-manager | grep cloudflare
```

## Switching to Production

When ready to use production certificates:

1. Update `issuerRef.name` from `letsencrypt-staging` to `letsencrypt-production`
2. Update `secretName` to remove `-staging` suffix
3. Update all ingress resources to reference new secret names
4. Delete old staging certificates and secrets

See `STAGING_TO_PRODUCTION_MIGRATION.md` for detailed instructions.

## Rate Limits

- **Staging**: 30,000 certificates per week per IP (very generous)
- **Production**: 50 certificates per week per domain (be careful!)

Always test with staging first before switching to production.
