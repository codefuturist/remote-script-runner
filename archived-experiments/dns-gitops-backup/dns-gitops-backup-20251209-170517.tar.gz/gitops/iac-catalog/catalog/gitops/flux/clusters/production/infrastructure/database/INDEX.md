# Database Infrastructure - Organization

## 📁 Directory Structure

```
infrastructure/database/
├── operators/              # Database operators
│   ├── cloudnative-pg/     # PostgreSQL operator (v0.26.1)
│   ├── mariadb/            # MariaDB operator (v0.31.x)
│   └── README.md           # Operator documentation
│
├── clusters/               # Database cluster definitions
│   ├── postgresql/         # PostgreSQL clusters
│   │   ├── postgres-single-node.yaml      (DEFAULT)
│   │   └── postgres-cluster-example.yaml  (Reference)
│   ├── mariadb/            # MariaDB clusters
│   │   └── mariadb-single-node.yaml       (DEFAULT)
│   └── README.md           # Cluster documentation
│
├── applications/           # Application database examples
│   ├── wordpress-database.yaml
│   ├── mealie-database.yaml
│   ├── test-database.yaml
│   └── README.md           # Application database guide
│
├── monitoring/             # Prometheus monitoring (OPTIONAL)
│   ├── mariadb-monitoring.yaml
│   └── README.md           # Monitoring setup guide
│
├── backup/                 # Backup configurations (OPTIONAL)
│   ├── mariadb-backup.yaml
│   └── README.md           # Backup and restore guide
│
├── ha-optional/            # High availability configs (OPTIONAL)
│   ├── mariadb-cluster-ha.yaml.optional
│   ├── mariadb-proxysql.yaml.optional
│   └── README.md           # HA setup guide
│
├── templates/              # Reusable YAML templates
│   ├── PostgreSQL templates (Database CRD)
│   ├── MariaDB templates (Database/User/Grant CRDs)
│   └── Automation scripts
│
├── examples/               # Complete example setups
│   └── Multi-application deployments
│
├── docs/                   # Comprehensive documentation
│   ├── centralized-postgres-guide.md
│   ├── centralized-mariadb-guide.md
│   ├── HA-GUIDE.md
│   ├── MIGRATION_STRATEGY.md
│   ├── QUICK_REFERENCE.md
│   └── TEST_VERIFICATION.md
│
├── scripts/                # Automation and validation
│   ├── validate-cloudnative-pg.sh
│   └── verify-setup.sh
│
├── kustomization.yaml      # Main deployment config
└── README.md               # This file
```

## 🚀 Quick Start

### Deploy Default Configuration

```bash
# Deploy operators and single-node clusters
kubectl apply -k .

# Verify deployment
kubectl get mariadb,cluster -n database
kubectl get pods -n database
```

### Create Application Database

```bash
# Using automation script
cd templates/
./onboard-mariadb-app.sh wordpress wordpress wordpress_user

# Or manually
kubectl apply -f applications/wordpress-database.yaml
```

## 📦 What's Deployed by Default

From `kustomization.yaml`:

✅ **Operators**
- CloudNativePG operator (PostgreSQL management)
- MariaDB operator (MariaDB management)

✅ **Clusters**
- `postgres-single` - 1 instance, 20Gi
- `mariadb-single` - 1 replica, 20Gi

❌ **Not Deployed** (commented out)
- Monitoring configs
- Backup configs
- Application databases
- HA configurations

## 🔧 Optional Components

Enable by uncommenting in `kustomization.yaml`:

### Monitoring
```yaml
resources:
  - monitoring/mariadb-monitoring.yaml
```
Provides: ServiceMonitor, 7 PrometheusRules

### Backup
```yaml
resources:
  - backup/mariadb-backup.yaml
```
Provides: Daily/weekly backups to S3/MinIO

### High Availability
```yaml
resources:
  # Comment out single-node
  # - clusters/mariadb/mariadb-single-node.yaml
  
  # Enable HA (after renaming .optional files)
  - ha-optional/mariadb-cluster-ha.yaml
  - ha-optional/mariadb-proxysql.yaml
```
Provides: 3-node Galera cluster, ProxySQL pooling

## 📚 Documentation Index

| Document | Purpose |
|----------|---------|
| **operators/README.md** | Operator details and verification |
| **clusters/README.md** | Cluster configurations and switching |
| **applications/README.md** | Application database examples |
| **monitoring/README.md** | Prometheus monitoring setup |
| **backup/README.md** | Backup and restore procedures |
| **ha-optional/README.md** | High availability configuration |
| **docs/centralized-postgres-guide.md** | Complete PostgreSQL guide |
| **docs/centralized-mariadb-guide.md** | Complete MariaDB guide |
| **docs/HA-GUIDE.md** | HA setup and switching guide |
| **docs/MIGRATION_STRATEGY.md** | PostgreSQL ↔ MariaDB migration |
| **docs/QUICK_REFERENCE.md** | Common commands cheatsheet |

## 🎯 Common Tasks

### View Current Databases
```bash
kubectl get cluster,mariadb -n database
kubectl get database,user,grant -n database
```

### Add Application Database (MariaDB)
```bash
cd templates/
./onboard-mariadb-app.sh myapp myapp myapp_user
kubectl apply -f applications/myapp-database.yaml
```

### Add Application Database (PostgreSQL)
```bash
cd templates/
./onboard-app.sh myapp myapp myapp_user
kubectl apply -f applications/myapp-database.yaml
```

### Enable Monitoring
```bash
# Uncomment in kustomization.yaml
vi kustomization.yaml
# Uncomment: - monitoring/mariadb-monitoring.yaml

kubectl apply -k .
```

### Switch to HA
```bash
cd ha-optional/
mv mariadb-cluster-ha.yaml.optional mariadb-cluster-ha.yaml
vi ../kustomization.yaml  # Update resources
kubectl apply -k ..
```

## 🔍 Verification Commands

```bash
# Check operators
kubectl get deployment -n database cloudnative-pg
kubectl get deployment -n mariadb-system mariadb-operator

# Check clusters
kubectl get cluster postgres-single -n database
kubectl get mariadb mariadb-single -n database

# Check databases
kubectl get database,user,grant -n database

# Check pods
kubectl get pods -n database
kubectl get pods -n mariadb-system

# Test database connection
kubectl exec -n database mariadb-single-0 -- \
  mariadb -u wordpress_user -p... wordpress -e "SELECT 1;"
```

## 🏗️ Architecture Principles

1. **Separation of Concerns**: Operators, clusters, applications, and optional components in separate directories
2. **Default Single-Node**: Development-friendly defaults, HA as opt-in
3. **Clear Documentation**: README in each directory explaining contents
4. **Template-Driven**: Reusable templates for common patterns
5. **GitOps Ready**: Kustomize-based, FluxCD compatible
6. **Progressive Enhancement**: Start simple, add features as needed

## 🚦 Best Practices

- **Start with single-node** for development/staging
- **Use templates** for consistent database creation
- **Enable monitoring early** to establish baselines
- **Test backups regularly** to ensure DR readiness
- **Document custom changes** in application-specific READMEs
- **Review HA guide** before production deployment
- **Keep secrets external** (use sealed-secrets or external-secrets)

## 📞 Support

For issues or questions:
1. Check directory-specific READMEs
2. Review comprehensive guides in `docs/`
3. Run verification scripts in `scripts/`
4. Consult operator documentation (links in `operators/README.md`)
