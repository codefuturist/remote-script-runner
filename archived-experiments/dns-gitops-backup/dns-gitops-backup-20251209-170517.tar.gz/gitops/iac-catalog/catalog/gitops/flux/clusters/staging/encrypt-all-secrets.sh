#!/usr/bin/env bash
set -euo pipefail

# Script to encrypt all staging cluster secrets with SOPS
# Usage: ./encrypt-all-secrets.sh

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CLUSTER_DIR="${SCRIPT_DIR}/catalog/gitops/flux/clusters/staging"
AGE_KEY="age1t8gm5avm9z5pquta4w2kaud7zn3c588mkk2shdpdskvp76wxh3gsxctyst"

echo "🔐 Encrypting all staging cluster secrets with SOPS..."
echo "📍 Cluster directory: ${CLUSTER_DIR}"
echo "🔑 Age key: ${AGE_KEY}"
echo

# Function to generate secure password
generate_password() {
    </dev/random LC_ALL=C tr -dc '[:graph:]' | head -c32
}

# Function to encrypt a file with SOPS
encrypt_file() {
    local file="$1"
    if [[ ! -f "${file}" ]]; then
        echo "  ⚠️  File not found: ${file}"
        return 1
    fi
    
    # Check if already encrypted
    if grep -q "sops:" "${file}" 2>/dev/null; then
        echo "  ⏭️  Already encrypted: ${file}"
        return 0
    fi
    
    echo "  🔒 Encrypting: ${file}"
    sops --encrypt \
        --age "${AGE_KEY}" \
        --encrypted-regex '^(data|stringData)$' \
        --in-place "${file}" 2>/dev/null || {
        echo "  ❌ Failed to encrypt: ${file}"
        return 1
    }
    echo "  ✅ Encrypted: ${file}"
}

# Function to replace placeholder and encrypt
process_database_yaml() {
    local file="$1"
    local app_name="$2"
    
    if [[ ! -f "${file}" ]]; then
        echo "  ⚠️  File not found: ${file}"
        return 1
    fi
    
    # Check if already encrypted
    if grep -q "sops:" "${file}" 2>/dev/null; then
        echo "  ⏭️  Already encrypted: ${app_name}"
        return 0
    fi
    
    # Generate password
    local password=$(generate_password)
    echo "  🔑 Generated password for ${app_name}"
    
    # Replace placeholder (macOS sed requires -i with empty string for in-place)
    if [[ "$OSTYPE" == "darwin"* ]]; then
        sed -i '' "s/PLACEHOLDER_GENERATE_SECURE_PASSWORD_32_CHARS/${password}/g" "${file}"
        sed -i '' "s/PLACEHOLDER_PASSWORD/${password}/g" "${file}"
    else
        sed -i "s/PLACEHOLDER_GENERATE_SECURE_PASSWORD_32_CHARS/${password}/g" "${file}"
        sed -i "s/PLACEHOLDER_PASSWORD/${password}/g" "${file}"
    fi
    
    # Encrypt
    encrypt_file "${file}"
}

echo "📦 Processing application secrets..."
echo

# Web Applications
echo "🌐 Web Applications:"
process_database_yaml "${CLUSTER_DIR}/apps/production/web/colins-blog/colins-blog-database.yaml" "colins-blog"
process_database_yaml "${CLUSTER_DIR}/apps/production/web/rey-it-solutions/rey-it-solutions-database.yaml" "rey-it-solutions"
echo

# CI/CD Applications
echo "⚙️  CI/CD Applications:"
process_database_yaml "${CLUSTER_DIR}/apps/ci-cd/gitea/gitea-database.yaml" "gitea"
echo

# Monitoring Applications
echo "📊 Monitoring Applications:"
process_database_yaml "${CLUSTER_DIR}/apps/production/mattermost/mattermost-database.yaml" "mattermost"
process_database_yaml "${CLUSTER_DIR}/apps/production/mattermost/mattermost-helmrelease.yaml" "mattermost-connection"
echo

echo "✅ All secrets have been encrypted with SOPS!"
echo
echo "📋 Summary:"
echo "   - Web apps: colins-blog, rey-it-solutions"
echo "   - CI/CD: gitea"
echo "   - Monitoring: mattermost, uptime-kuma (no DB)"
echo
echo "🔍 Verify encryption:"
echo "   grep -l 'sops:' ${CLUSTER_DIR}/apps/production/*/***-database.yaml"
echo
echo "🚀 Next steps:"
echo "   1. Review the encrypted files"
echo "   2. git add catalog/gitops/flux/clusters/staging/"
echo "   3. git commit -m 'feat: add monitoring and ci-cd apps with encrypted secrets'"
echo "   4. git push origin develop"
echo
echo "📚 Documentation:"
echo "   - Web apps: ${CLUSTER_DIR}/apps/production/web/README.md"
echo "   - CI/CD: ${CLUSTER_DIR}/apps/ci-cd/README.md"
