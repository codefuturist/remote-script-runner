# Database HA Configuration Guide

This directory contains both default single-node and optional HA configurations.

## Default Configurations (Single-Node)

Used automatically via `kustomization.yaml`:

- **`postgres-single-node.yaml`** - CloudNativePG single-instance cluster
  - 1 replica, 20Gi storage
  - Suitable for development/staging
  - Resource requests: 500m CPU, 512Mi memory

- **`mariadb-single-node.yaml`** - MariaDB Operator single-instance cluster
  - 1 replica, 20Gi storage
  - Suitable for development/staging
  - Resource requests: 500m CPU, 512Mi memory

## Optional HA Configurations

For production workloads, rename `.optional` files to `.yaml` and update `kustomization.yaml`:

### MariaDB HA Setup

1. **Enable HA cluster:**
   ```bash
   mv mariadb-cluster-ha.yaml.optional mariadb-cluster-ha.yaml
   ```

2. **Enable ProxySQL (recommended for HA):**
   ```bash
   mv mariadb-proxysql.yaml.optional mariadb-proxysql.yaml
   ```

3. **Update kustomization.yaml:**
   ```yaml
   resources:
     - mariadb-operator.yaml
     # - mariadb-single-node.yaml  # Comment out single-node
     - mariadb-cluster-ha.yaml      # Add HA cluster
     - mariadb-proxysql.yaml        # Add ProxySQL
   ```

**MariaDB HA Features:**
- 3-node Galera cluster (multi-master replication)
- 50Gi fast-ssd storage per node
- Pod anti-affinity and topology spread
- PodDisruptionBudget (maxUnavailable: 1)
- ProxySQL connection pooling and load balancing
- Auto-scaling (2-10 ProxySQL replicas)

### PostgreSQL HA Setup

For PostgreSQL HA, create a new file based on `postgres-single-node.yaml`:

```yaml
# postgres-cluster-ha.yaml
spec:
  instances: 3
  storage:
    size: 50Gi
    storageClass: fast-ssd
```

## Switching Between Configurations

### From Single-Node to HA:

1. **Backup data** before switching
2. Enable HA configuration files
3. Update `kustomization.yaml`
4. Apply: `kubectl apply -k .`
5. Migrate data if needed

### From HA to Single-Node:

**⚠️ Warning:** This will lose HA redundancy!

1. **Backup data** first
2. Update `kustomization.yaml` to use single-node configs
3. Apply changes
4. Restore data if needed

## Resource Requirements

| Configuration | Nodes | CPU | Memory | Storage |
|--------------|-------|-----|--------|---------|
| Single-Node PostgreSQL | 1 | 0.5-2 | 512Mi-2Gi | 20Gi |
| Single-Node MariaDB | 1 | 0.5-2 | 512Mi-2Gi | 20Gi |
| HA MariaDB (Galera) | 3 | 1-4 each | 2-8Gi each | 50Gi each |
| ProxySQL | 2-10 | 0.2-1 each | 256Mi-1Gi each | - |

## When to Use HA

**Use Single-Node for:**
- Development environments
- Staging with non-critical data
- Cost-sensitive deployments
- Low-traffic applications

**Use HA for:**
- Production environments
- Critical data requiring high availability
- High-traffic applications
- Zero-downtime requirement
- Multi-region deployments

## Notes

- Default configurations use `local-path` storage (K3s default)
- HA configurations use `fast-ssd` storage class (update for your cluster)
- All configurations include monitoring (metrics exporters)
- Backup configurations available in `mariadb-backup.yaml`
