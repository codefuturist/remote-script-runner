# High Availability (Optional)

This directory contains optional HA configurations that are not deployed by default.

## Files

### mariadb-cluster-ha.yaml.optional
3-node Galera cluster configuration:
- 3 replicas with multi-master replication
- 50Gi fast-ssd storage per node
- Resources: 1-4 CPU, 2-8Gi memory per node
- Pod anti-affinity and topology spread
- PodDisruptionBudget (maxUnavailable: 1)
- NetworkPolicy for access control

### mariadb-proxysql.yaml.optional
ProxySQL connection pooling and load balancing:
- 2-10 replicas (HPA enabled)
- Distributes connections across Galera nodes
- Connection pooling (2048 max connections)
- Query routing rules
- Monitoring on port 6032

## Enabling HA

1. **Rename files** (remove `.optional` extension):
   ```bash
   cd ha-optional/
   mv mariadb-cluster-ha.yaml.optional mariadb-cluster-ha.yaml
   mv mariadb-proxysql.yaml.optional mariadb-proxysql.yaml
   ```

2. **Update kustomization.yaml**:
   ```yaml
   resources:
     # Comment out single-node
     # - clusters/mariadb/mariadb-single-node.yaml
     
     # Add HA components
     - ha-optional/mariadb-cluster-ha.yaml
     - ha-optional/mariadb-proxysql.yaml
   ```

3. **Update storage class** in HA files:
   - Change `storageClassName: fast-ssd` to your cluster's SSD storage class

4. **Deploy**:
   ```bash
   kubectl apply -k .
   ```

## Verification

```bash
# Check Galera cluster
kubectl get mariadb -n database mariadb-cluster
kubectl get pods -n database -l app.kubernetes.io/instance=mariadb-cluster

# Check ProxySQL
kubectl get deployment -n database proxysql
kubectl get hpa -n database proxysql-hpa

# Test connections
kubectl exec -n database mariadb-cluster-0 -- \
  mariadb -e "SHOW STATUS LIKE 'wsrep%';"
```

## Rolling Back

To revert to single-node:

1. Backup data
2. Rename files back to `.optional`
3. Update `kustomization.yaml` to use single-node configs
4. Apply changes
5. Restore data if needed

## Documentation

See `../docs/HA-GUIDE.md` for detailed instructions and best practices.
