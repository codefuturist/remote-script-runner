# Quick Start: Encrypt Secrets for Staging Cluster

## Automated Setup (Recommended)

Generate secure values and encrypt all secrets automatically:

```bash
cd /Users/colin/Developer/Projects/personal/iac-catalog
chmod +x scripts/generate-and-encrypt-secrets.sh
./scripts/generate-and-encrypt-secrets.sh
```

This script will:
1. ✅ Generate secure random passwords and keys
2. ✅ Encrypt secrets with SOPS using your age key
3. ✅ Create a temporary credentials file for your records
4. ✅ Prepare everything for deployment

**After running the script:**
1. Save the credentials from the temporary file to your password manager
2. Delete the temporary credentials file
3. Commit the encrypted secrets to Git
4. Deploy to your cluster

## Manual Setup

If you prefer to set values manually:

```bash
cd /Users/colin/Developer/Projects/personal/iac-catalog
export SOPS_AGE_KEY_FILE="$PWD/age.agekey"

# Edit and update the authentik secret
sops catalog/gitops/flux/clusters/staging/apps/production/authentik/authentik-secret.yaml

# Edit and update the homarr secret
sops catalog/gitops/flux/clusters/staging/apps/production/homarr/homarr-secret.yaml
```

Replace `CHANGE_ME_*` values with secure random strings:
```bash
# Generate passwords
openssl rand -base64 32   # For passwords
openssl rand -base64 60   # For secret keys
```

## Verify Encryption

```bash
# Check that secrets are encrypted (should show ENC[...] in data fields)
cat catalog/gitops/flux/clusters/staging/apps/production/authentik/authentik-secret.yaml
cat catalog/gitops/flux/clusters/staging/apps/production/homarr/homarr-secret.yaml
```

## Deploy to Cluster

Ensure FluxCD has the age key for decryption:

```bash
# Create the SOPS age secret in the cluster (one-time setup)
cat age.agekey | kubectl create secret generic sops-age \
  --namespace=flux-system \
  --from-file=age.agekey=/dev/stdin
```

Then deploy:
```bash
kubectl apply -k catalog/gitops/flux/clusters/staging
```

## Files Created

- ✅ `authentik/authentik-secret.yaml` - Authentik credentials (Redis, PostgreSQL, secret key)
- ✅ `homarr/homarr-secret.yaml` - Homarr database encryption key
- ✅ `SECRETS_MANAGEMENT.md` - Detailed secrets management guide
- ✅ `scripts/generate-and-encrypt-secrets.sh` - Automated setup script
- ✅ `scripts/encrypt-staging-secrets.sh` - Re-encryption helper script

## Security Notes

- 🔒 All secrets are encrypted with SOPS using age encryption
- 🔒 Safe to commit encrypted secrets to Git repository
- ⚠️  Never commit the `age.agekey` file itself
- ⚠️  Store the age key securely offline
