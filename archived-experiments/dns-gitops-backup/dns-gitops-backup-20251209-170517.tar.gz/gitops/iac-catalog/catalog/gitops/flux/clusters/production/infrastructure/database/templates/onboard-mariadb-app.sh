#!/usr/bin/env bash
# MariaDB Application Onboarding Script
# Automates the creation of database, user, and grants for new applications

set -euo pipefail

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TEMPLATE_FILE="${SCRIPT_DIR}/mariadb-app-template.yaml"

# Function to print colored output
print_info() { echo -e "${BLUE}ℹ${NC} $1"; }
print_success() { echo -e "${GREEN}✓${NC} $1"; }
print_warning() { echo -e "${YELLOW}⚠${NC} $1"; }
print_error() { echo -e "${RED}✗${NC} $1"; }

# Function to display usage
usage() {
    cat <<EOF
Usage: $0 [OPTIONS]

Onboard a new application to centralized MariaDB

OPTIONS:
    -a, --app-name NAME         Application name (required)
    -d, --database NAME         Database name (default: same as app-name)
    -c, --charset CHARSET       Character set (default: utf8mb4)
    -l, --collation COLLATION   Collation (default: utf8mb4_unicode_ci)
    -n, --namespace NS          Kubernetes namespace (default: database)
    -x, --max-connections NUM   Max connections (default: 20)
    -o, --output FILE           Output file (default: stdout)
    -h, --help                  Show this help message

EXAMPLES:
    # Basic onboarding
    $0 --app-name wordpress

    # Custom database name
    $0 --app-name my-app --database myapp_prod

    # Save to file
    $0 --app-name nextcloud --output nextcloud-mariadb.yaml

    # Full customization
    $0 -a gitea -d gitea -c utf8mb4 -l utf8mb4_general_ci -x 50

EOF
    exit 1
}

# Parse arguments
APP_NAME=""
DB_NAME=""
CHARSET="utf8mb4"
COLLATION="utf8mb4_unicode_ci"
NAMESPACE="database"
MAX_CONNECTIONS="20"
OUTPUT_FILE=""

while [[ $# -gt 0 ]]; do
    case $1 in
        -a|--app-name)
            APP_NAME="$2"
            shift 2
            ;;
        -d|--database)
            DB_NAME="$2"
            shift 2
            ;;
        -c|--charset)
            CHARSET="$2"
            shift 2
            ;;
        -l|--collation)
            COLLATION="$2"
            shift 2
            ;;
        -n|--namespace)
            NAMESPACE="$2"
            shift 2
            ;;
        -x|--max-connections)
            MAX_CONNECTIONS="$2"
            shift 2
            ;;
        -o|--output)
            OUTPUT_FILE="$2"
            shift 2
            ;;
        -h|--help)
            usage
            ;;
        *)
            print_error "Unknown option: $1"
            usage
            ;;
    esac
done

# Validate required arguments
if [[ -z "$APP_NAME" ]]; then
    print_error "Application name is required"
    usage
fi

# Set database name to app name if not specified
if [[ -z "$DB_NAME" ]]; then
    DB_NAME="$APP_NAME"
fi

# Validate app name format (alphanumeric and hyphens only)
if ! [[ "$APP_NAME" =~ ^[a-z0-9-]+$ ]]; then
    print_error "Application name must contain only lowercase letters, numbers, and hyphens"
    exit 1
fi

# Validate database name format
if ! [[ "$DB_NAME" =~ ^[a-zA-Z0-9_]+$ ]]; then
    print_error "Database name must contain only letters, numbers, and underscores"
    exit 1
fi

# Check if template file exists
if [[ ! -f "$TEMPLATE_FILE" ]]; then
    print_error "Template file not found: $TEMPLATE_FILE"
    exit 1
fi

print_info "Onboarding application: $APP_NAME"
print_info "Database name: $DB_NAME"
print_info "Character set: $CHARSET"
print_info "Collation: $COLLATION"
print_info "Namespace: $NAMESPACE"
print_info "Max connections: $MAX_CONNECTIONS"
echo ""

# Generate secure password
PASSWORD=$(</dev/random LC_ALL=C tr -dc '[:graph:]' | head -c32)
print_success "Generated secure password"

# Create temporary file
TEMP_FILE=$(mktemp)
trap "rm -f $TEMP_FILE" EXIT

# Replace placeholders in template
sed -e "s/APP_NAME/${APP_NAME}/g" \
    -e "s/DB_NAME/${DB_NAME}/g" \
    -e "s/CHARSET/${CHARSET}/g" \
    -e "s/COLLATION/${COLLATION}/g" \
    -e "s/maxUserConnections: 20/maxUserConnections: ${MAX_CONNECTIONS}/g" \
    -e "s/password: \"\"/password: \"${PASSWORD}\"/g" \
    "$TEMPLATE_FILE" > "$TEMP_FILE"

# Update namespace if not default
if [[ "$NAMESPACE" != "database" ]]; then
    sed -i.bak "s/namespace: database/namespace: ${NAMESPACE}/g" "$TEMP_FILE"
    rm -f "${TEMP_FILE}.bak"
fi

print_success "Generated configuration from template"

# Output to file or stdout
if [[ -n "$OUTPUT_FILE" ]]; then
    cp "$TEMP_FILE" "$OUTPUT_FILE"
    print_success "Saved configuration to: $OUTPUT_FILE"
else
    cat "$TEMP_FILE"
fi

echo ""
print_info "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
print_info "Next Steps:"
print_info "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
print_info "1. Review the generated configuration:"
if [[ -n "$OUTPUT_FILE" ]]; then
    echo "   cat $OUTPUT_FILE"
else
    echo "   Save output to a file first"
fi
echo ""
print_info "2. Store password securely (using External Secrets or SOPS):"
echo "   Password: ${PASSWORD}"
echo ""
print_info "3. Apply the configuration:"
if [[ -n "$OUTPUT_FILE" ]]; then
    echo "   kubectl apply -f $OUTPUT_FILE"
else
    echo "   kubectl apply -f <your-file>.yaml"
fi
echo ""
print_info "4. Wait for resources to be ready (30-60 seconds):"
echo "   kubectl wait --for=condition=Ready database/mariadb-single-${APP_NAME} -n ${NAMESPACE} --timeout=120s"
echo ""
print_info "5. Verify database creation:"
echo "   kubectl get database,user,grant -n ${NAMESPACE} -l app=${APP_NAME}"
echo ""
print_info "6. Configure application to connect:"
echo "   Host: mariadb-single-primary.${NAMESPACE}.svc.cluster.local"
echo "   Port: 3306"
echo "   Database: ${DB_NAME}"
echo "   Username: ${APP_NAME}_user"
echo "   Password: <from secret mariadb-single-${APP_NAME}-user>"
echo ""
print_info "7. Test connection from application pod:"
echo "   kubectl run -it --rm mariadb-client --image=mariadb:11.4 --restart=Never -- \\"
echo "     mariadb -h mariadb-single-primary.${NAMESPACE}.svc.cluster.local \\"
echo "     -u ${APP_NAME}_user -p ${DB_NAME}"
echo ""
print_success "Application onboarding configuration ready!"
