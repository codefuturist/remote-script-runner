# Frontend Applications

Frontend tier applications are user-facing web applications and dashboards.

## Active Applications

### Homepage - Application Dashboard
- **Description**: Customizable application dashboard
- **Resources**: Minimal (static + API)
- **Dependencies**: None
- **Access**: Public via ingress

### Compass Web - Management Interface
- **Description**: Compass system management
- **Resources**: Minimal
- **Dependencies**: Backend API
- **Access**: Internal via ingress

### Mealie - Recipe Management
- **Description**: Recipe organization and meal planning
- **Resources**: Moderate
- **Dependencies**: Database (PostgreSQL)
- **Access**: Public via ingress

## Suspended Applications

### Homarr - Dashboard
- **Status**: Suspended due to CPU constraints
- **Reason**: Cluster running at 99% CPU (single node)

### Home Assistant - Home Automation
- **Status**: Suspended due to CPU constraints
- **Reason**: Resource-intensive automation engine

## Deployment Notes

- Frontend apps typically serve static assets + API calls
- Enable CDN/caching for better performance
- Consider resource limits to prevent noisy neighbor issues
- Most frontends use ingress for external access

