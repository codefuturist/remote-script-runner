# FluxCD Application Structure

This directory contains production applications managed by FluxCD.

## Structure

```
apps/production/
├── mealie/
│   ├── kustomization.yaml          # Kustomize config
│   ├── mealie-database.yaml        # PostgreSQL database, user, grants
│   └── mealie-helmrelease.yaml     # Helm chart deployment
└── wordpress/
    ├── kustomization.yaml          # Kustomize config
    └── wordpress-database.yaml     # MariaDB database, user, grants
```

## FluxCD Best Practices

### 1. Application Ownership
Each application directory owns all its resources:
- Database configuration (database, user, grants)
- Application deployment (HelmRelease or Deployment)
- Secrets (encrypted with SOPS)
- ConfigMaps
- Service, Ingress, etc.

### 2. Resource Organization
```yaml
# kustomization.yaml structure
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization
namespace: <app-namespace>
resources:
  - database.yaml        # Database resources
  - helmrelease.yaml     # Application deployment
  - secrets.yaml         # Encrypted secrets (SOPS)
```

### 3. Dependencies
Applications depend on infrastructure:
- Database operators (CloudNativePG, MariaDB Operator)
- Database clusters (postgres-single, mariadb-single)
- Ingress controllers (Traefik)
- Certificate managers (cert-manager)

FluxCD handles these dependencies via the `apps` Kustomization which depends on `infrastructure`.

### 4. Secret Management
**Current State**: Secrets are plain text in YAML files.

**Recommended Approach** (choose one):

#### Option A: SOPS Encryption (Recommended)
```yaml
apiVersion: v1
kind: Secret
metadata:
  name: app-credentials
type: Opaque
data:
  password: ENC[AES256_GCM,data:...,tag:...,type:str]
```

Encrypt with:
```bash
sops --encrypt --age $(cat age.agekey | grep "# public key" | cut -d ":" -f 2 | tr -d " ") \
  --encrypted-regex '^(data|stringData)$' secrets.yaml
```

#### Option B: External Secrets Operator
```yaml
apiVersion: external-secrets.io/v1beta1
kind: ExternalSecret
metadata:
  name: app-credentials
spec:
  secretStoreRef:
    name: vault-backend
    kind: SecretStore
  target:
    name: app-credentials
  data:
    - secretKey: password
      remoteRef:
        key: app/credentials
        property: password
```

### 5. Database Resource Pattern

Each application that needs a database should include:

**For PostgreSQL:**
```yaml
# Create a role/user (managed by CloudNativePG)
# This is done via the Cluster's managed.roles section
```

**For MariaDB:**
```yaml
---
apiVersion: k8s.mariadb.com/v1alpha1
kind: Database
metadata:
  name: app-db
  namespace: database
spec:
  mariaDbRef:
    name: mariadb-single
  name: app
  characterSet: utf8mb4
  collate: utf8mb4_unicode_ci
---
apiVersion: k8s.mariadb.com/v1alpha1
kind: User
metadata:
  name: app-user
  namespace: database
spec:
  mariaDbRef:
    name: mariadb-single
  name: app_user
  passwordSecretKeyRef:
    name: app-credentials
    key: password
  maxUserConnections: 50
---
apiVersion: k8s.mariadb.com/v1alpha1
kind: Grant
metadata:
  name: app-grant
  namespace: database
spec:
  mariaDbRef:
    name: mariadb-single
  privileges: ["ALL PRIVILEGES"]
  database: "app"
  table: "*"
  username: app_user
  grantOption: false
```

## Adding a New Application

1. Create application directory:
   ```bash
   mkdir -p apps/production/myapp
   ```

2. Create kustomization.yaml:
   ```bash
   cat > apps/production/myapp/kustomization.yaml <<EOF
   ---
   apiVersion: kustomize.config.k8s.io/v1beta1
   kind: Kustomization
   namespace: myapp
   resources:
     - namespace.yaml
     - database.yaml
     - helmrelease.yaml
   EOF
   ```

3. Add namespace resource:
   ```bash
   cat > apps/production/myapp/namespace.yaml <<EOF
   ---
   apiVersion: v1
   kind: Namespace
   metadata:
     name: myapp
     labels:
       app.kubernetes.io/name: myapp
   EOF
   ```

4. Add database resources (if needed)

5. Add HelmRelease or Deployment

6. Add to production kustomization:
   ```bash
   # Edit apps/production/kustomization.yaml
   # Add: - myapp
   ```

7. Commit and push:
   ```bash
   git add apps/production/myapp/
   git commit -m "feat: add myapp application"
   git push
   ```

## Deployment Flow

1. FluxCD detects changes in Git
2. `infrastructure` Kustomization deploys first:
   - Namespaces
   - Database operators
   - Database clusters
3. `apps` Kustomization deploys after infrastructure is ready:
   - Application namespaces
   - Database resources (databases, users, grants)
   - Application deployments (HelmReleases)

## Troubleshooting

### Check FluxCD status:
```bash
flux get kustomizations
flux get helmreleases -A
```

### Check application resources:
```bash
kubectl get databases,users,grants -n database
kubectl get pods -n <app-namespace>
kubectl describe helmrelease <app-name> -n <app-namespace>
```

### Check logs:
```bash
kubectl logs -n flux-system -l app=kustomize-controller
kubectl logs -n flux-system -l app=helm-controller
```

### Force reconciliation:
```bash
flux reconcile kustomization apps --with-source
flux reconcile helmrelease <app-name> -n <app-namespace>
```
