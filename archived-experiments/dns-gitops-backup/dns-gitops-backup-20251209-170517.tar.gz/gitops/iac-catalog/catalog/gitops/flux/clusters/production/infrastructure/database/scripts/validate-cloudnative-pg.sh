#!/bin/bash
# CloudNativePG Validation Script
# Checks the status of CloudNativePG operator deployment

set -e

echo "======================================"
echo "CloudNativePG Operator Status Check"
echo "======================================"
echo ""

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Check namespace
echo "1. Checking database namespace..."
if kubectl get namespace database &> /dev/null; then
    echo -e "${GREEN}✓${NC} Namespace 'database' exists"
else
    echo -e "${RED}✗${NC} Namespace 'database' not found"
    exit 1
fi
echo ""

# Check HelmRepository
echo "2. Checking CloudNativePG HelmRepository..."
if kubectl get helmrepository cloudnative-pg -n flux-system &> /dev/null; then
    STATUS=$(kubectl get helmrepository cloudnative-pg -n flux-system -o jsonpath='{.status.conditions[?(@.type=="Ready")].status}')
    if [ "$STATUS" = "True" ]; then
        echo -e "${GREEN}✓${NC} HelmRepository is ready"
    else
        echo -e "${YELLOW}⚠${NC} HelmRepository exists but not ready yet"
    fi
else
    echo -e "${RED}✗${NC} HelmRepository not found"
fi
echo ""

# Check HelmRelease
echo "3. Checking CloudNativePG HelmRelease..."
if kubectl get helmrelease cloudnative-pg-operator -n database &> /dev/null; then
    STATUS=$(kubectl get helmrelease cloudnative-pg-operator -n database -o jsonpath='{.status.conditions[?(@.type=="Ready")].status}')
    if [ "$STATUS" = "True" ]; then
        echo -e "${GREEN}✓${NC} HelmRelease is ready"
    else
        echo -e "${YELLOW}⚠${NC} HelmRelease exists but not ready yet"
        echo "   Status: $(kubectl get helmrelease cloudnative-pg-operator -n database -o jsonpath='{.status.conditions[?(@.type=="Ready")].message}')"
    fi
else
    echo -e "${RED}✗${NC} HelmRelease not found"
    exit 1
fi
echo ""

# Check Operator Deployment
echo "4. Checking operator deployment..."
if kubectl get deployment cloudnative-pg -n database &> /dev/null; then
    READY=$(kubectl get deployment cloudnative-pg -n database -o jsonpath='{.status.readyReplicas}')
    DESIRED=$(kubectl get deployment cloudnative-pg -n database -o jsonpath='{.spec.replicas}')
    if [ "$READY" = "$DESIRED" ]; then
        echo -e "${GREEN}✓${NC} Operator deployment is ready ($READY/$DESIRED)"
    else
        echo -e "${YELLOW}⚠${NC} Operator deployment not ready yet ($READY/$DESIRED)"
    fi
else
    echo -e "${RED}✗${NC} Operator deployment not found"
fi
echo ""

# Check Operator Pod
echo "5. Checking operator pod..."
POD=$(kubectl get pods -n database -l app.kubernetes.io/name=cloudnative-pg -o jsonpath='{.items[0].metadata.name}' 2>/dev/null)
if [ -n "$POD" ]; then
    STATUS=$(kubectl get pod $POD -n database -o jsonpath='{.status.phase}')
    if [ "$STATUS" = "Running" ]; then
        echo -e "${GREEN}✓${NC} Operator pod is running: $POD"
    else
        echo -e "${YELLOW}⚠${NC} Operator pod status: $STATUS"
    fi
else
    echo -e "${RED}✗${NC} Operator pod not found"
fi
echo ""

# Check CRDs
echo "6. Checking CloudNativePG CRDs..."
CRDS=(
    "backups.postgresql.cnpg.io"
    "clusters.postgresql.cnpg.io"
    "poolers.postgresql.cnpg.io"
    "scheduledbackups.postgresql.cnpg.io"
)

CRD_COUNT=0
for crd in "${CRDS[@]}"; do
    if kubectl get crd $crd &> /dev/null; then
        echo -e "${GREEN}✓${NC} $crd"
        ((CRD_COUNT++))
    else
        echo -e "${RED}✗${NC} $crd not found"
    fi
done

if [ $CRD_COUNT -eq ${#CRDS[@]} ]; then
    echo -e "\n${GREEN}All CRDs are installed${NC}"
else
    echo -e "\n${YELLOW}Some CRDs are missing${NC}"
fi
echo ""

# Check for existing clusters
echo "7. Checking for PostgreSQL clusters..."
CLUSTERS=$(kubectl get clusters.postgresql.cnpg.io -n database --no-headers 2>/dev/null | wc -l)
if [ "$CLUSTERS" -gt 0 ]; then
    echo -e "${GREEN}✓${NC} Found $CLUSTERS PostgreSQL cluster(s)"
    kubectl get clusters.postgresql.cnpg.io -n database
else
    echo -e "${YELLOW}ℹ${NC} No PostgreSQL clusters deployed yet"
    echo "   To deploy a cluster, see: infrastructure/database/postgres-cluster-example.yaml"
fi
echo ""

# Check monitoring
echo "8. Checking monitoring integration..."
if kubectl get podmonitor -n database &> /dev/null 2>&1; then
    PM_COUNT=$(kubectl get podmonitor -n database --no-headers 2>/dev/null | wc -l)
    if [ "$PM_COUNT" -gt 0 ]; then
        echo -e "${GREEN}✓${NC} PodMonitors configured"
    else
        echo -e "${YELLOW}ℹ${NC} No PodMonitors found yet"
    fi
else
    echo -e "${YELLOW}ℹ${NC} PodMonitor CRD not available (Prometheus not installed?)"
fi
echo ""

# Summary
echo "======================================"
echo "Summary"
echo "======================================"
if kubectl get deployment cloudnative-pg -n database &> /dev/null; then
    READY=$(kubectl get deployment cloudnative-pg -n database -o jsonpath='{.status.readyReplicas}')
    DESIRED=$(kubectl get deployment cloudnative-pg -n database -o jsonpath='{.spec.replicas}')
    if [ "$READY" = "$DESIRED" ]; then
        echo -e "${GREEN}CloudNativePG operator is fully deployed and ready!${NC}"
        echo ""
        echo "Next steps:"
        echo "1. Review the example: infrastructure/database/postgres-cluster-example.yaml"
        echo "2. Create your PostgreSQL cluster configuration"
        echo "3. Apply with: kubectl apply -f your-cluster.yaml"
        echo "4. Monitor with: kubectl get clusters -n database -w"
    else
        echo -e "${YELLOW}CloudNativePG operator is deploying...${NC}"
        echo "Run this script again in a few moments to check status."
    fi
else
    echo -e "${RED}CloudNativePG operator is not deployed yet.${NC}"
    echo "Check the logs: kubectl logs -n database -l app.kubernetes.io/name=cloudnative-pg"
fi
echo ""
