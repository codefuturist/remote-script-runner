# Example: Complete Multi-Application Setup

This directory contains a complete example of setting up multiple applications with isolated databases in a centralized PostgreSQL cluster.

## Architecture

```
postgres-single (Cluster)
├── webapp (Database)
│   └── webapp_user (Owner)
├── payments (Database)
│   └── payments_user (Owner)
└── analytics (Database)
    └── analytics_user (Owner)
```

## Files

- `cluster-with-roles.yaml` - PostgreSQL cluster with managed roles
- `webapp-database.yaml` - Web application database
- `payments-database.yaml` - Payment service database
- `analytics-database.yaml` - Analytics dashboard database

## Deployment Order

```bash
# 1. Update the main cluster with managed roles
kubectl apply -f cluster-with-roles.yaml

# 2. Wait for cluster to be ready
kubectl wait --for=condition=Ready cluster/postgres-single -n database --timeout=300s

# 3. Create all application databases
kubectl apply -f webapp-database.yaml
kubectl apply -f payments-database.yaml
kubectl apply -f analytics-database.yaml

# 4. Verify all databases are created
kubectl get databases -n database
```

## Verification

```bash
# Check database status
kubectl get databases -n database

# Port-forward to database
kubectl port-forward -n database svc/postgres-single-rw 5432:5432 &

# List all databases
PGPASSWORD=$(kubectl get secret postgres-single-superuser -n database -o jsonpath='{.data.password}' | base64 -d)
psql -h localhost -U postgres -c "\l"

# List all roles
psql -h localhost -U postgres -c "\du"
```

## Testing Connections

### Web Application

```bash
# Get credentials
WEBAPP_USER=$(kubectl get secret postgres-single-webapp-user -n database -o jsonpath='{.data.username}' | base64 -d)
WEBAPP_PASS=$(kubectl get secret postgres-single-webapp-user -n database -o jsonpath='{.data.password}' | base64 -d)

# Test connection
PGPASSWORD=$WEBAPP_PASS psql -h localhost -U $WEBAPP_USER -d webapp -c "SELECT current_database(), current_user;"
```

### Payment Service

```bash
# Get credentials
PAYMENTS_USER=$(kubectl get secret postgres-single-payments-user -n database -o jsonpath='{.data.username}' | base64 -d)
PAYMENTS_PASS=$(kubectl get secret postgres-single-payments-user -n database -o jsonpath='{.data.password}' | base64 -d)

# Test connection
PGPASSWORD=$PAYMENTS_PASS psql -h localhost -U $PAYMENTS_USER -d payments -c "SELECT current_database(), current_user;"
```

### Analytics Dashboard

```bash
# Get credentials
ANALYTICS_USER=$(kubectl get secret postgres-single-analytics-user -n database -o jsonpath='{.data.username}' | base64 -d)
ANALYTICS_PASS=$(kubectl get secret postgres-single-analytics-user -n database -o jsonpath='{.data.password}' | base64 -d)

# Test connection
PGPASSWORD=$ANALYTICS_PASS psql -h localhost -U $ANALYTICS_USER -d analytics -c "SELECT current_database(), current_user;"
```

## Application Deployment Examples

See `deployment-examples/` for Kubernetes deployment manifests showing how applications connect to their respective databases.
