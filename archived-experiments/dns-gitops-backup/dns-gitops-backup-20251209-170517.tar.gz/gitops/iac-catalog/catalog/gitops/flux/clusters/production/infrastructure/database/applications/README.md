# Application Database Examples

This directory contains example database configurations for applications.

## Files

### wordpress-database.yaml
Complete WordPress database setup using MariaDB Operator CRDs:
- Database: `wordpress` (utf8mb4_unicode_ci)
- User: `wordpress_user` (50 max connections)
- Grant: ALL PRIVILEGES on wordpress.*
- Secrets in both `database` and `web` namespaces

### mealie-database.yaml
Mealie application database setup:
- Database: `mealie` (utf8mb4_unicode_ci)
- User: `mealie_user`
- Grant: ALL PRIVILEGES on mealie.*

### test-database.yaml
Test database for validation:
- Database: `testapp_db`
- User: `testapp_user`
- Grant: ALL PRIVILEGES

### test-application.yaml
Test application deployment for validation

## Usage

Uncomment in `../kustomization.yaml` to deploy:

```yaml
resources:
  # Application Databases
  - applications/wordpress-database.yaml
  - applications/mealie-database.yaml
```

## Creating New Application Databases

Use templates from `../templates/`:

```bash
cd ../templates/
./onboard-app.sh myapp myapp myapp_user "production"
```

Or manually using templates:
- PostgreSQL: `../templates/app-database-template.yaml`
- MariaDB: `../templates/mariadb-database-template.yaml`

## Verification

```bash
# Check database resources
kubectl get database,user,grant -n database

# Test database connection
kubectl exec -n database mariadb-single-0 -- \
  mariadb -u wordpress_user -p... wordpress -e "SHOW TABLES;"
```
