# CI/CD Applications

This directory contains CI/CD application deployments managed by FluxCD.

## Applications

### Gitea
- **Purpose**: Self-hosted Git service with a web UI
- **URL**: https://git.staging.local (TODO: Update domain)
- **Database**: PostgreSQL (gitea)
- **Chart**: Official Gitea Helm chart
- **Namespace**: ci-cd

### Harbor (Planned)
- **Purpose**: Container registry with security scanning
- **URL**: https://harbor.staging.local
- **Database**: PostgreSQL
- **Chart**: Official Harbor Helm chart
- **Namespace**: ci-cd

## Structure

Each application follows the FluxCD best practices:

```
app-name/
├── kustomization.yaml          # Kustomize configuration
├── app-name-database.yaml      # PostgreSQL database, user (with SOPS-encrypted password)
└── app-name-helmrelease.yaml   # Helm chart deployment
```

## Database Setup

All CI/CD apps use the centralized **CloudNativePG** managed PostgreSQL cluster (`postgres-single`) in the `database` namespace.

**Resources created:**
- `Database`: Creates isolated database in PostgreSQL cluster
- `Secret`: Stores user credentials (SOPS-encrypted, reflected to ci-cd namespace via Reflector)

## Secret Management

**Encryption**: SOPS with Age encryption
**Key**: `age1t8gm5avm9z5pquta4w2kaud7zn3c588mkk2shdpdskvp76wxh3gsxctyst`

### Generate and Encrypt Secrets

```bash
# Generate secure password
openssl rand -base64 32 | tr -d "=+/" | cut -c1-32

# Replace placeholder in database YAML files
# Then encrypt with SOPS
sops --encrypt \
    --age age1t8gm5avm9z5pquta4w2kaud7zn3c588mkk2shdpdskvp76wxh3gsxctyst \
    --encrypted-regex '^(data|stringData)$' \
    --in-place gitea/gitea-database.yaml
```

## Deployment

Applications are automatically deployed via FluxCD when changes are committed to git.

**Dependencies:**
- CloudNativePG Operator (infrastructure/database)
- PostgreSQL single-node cluster (infrastructure/database)
- Traefik ingress (infrastructure/ingress)
- cert-manager (infrastructure/cert-manager)
- Reflector (infrastructure/utility)

## Gitea Configuration

### Initial Setup
1. First login will prompt for initial configuration
2. Admin user: `gitea_admin`
3. Database is pre-configured via environment variables
4. SSH and HTTP Git access enabled

### Features
- Git repository hosting
- Pull requests and code review
- Issue tracking
- Wiki pages
- Git LFS support
- SSH and HTTPS access
- Webhook integrations

## Maintenance

### View Database Status
```bash
kubectl get databases -n database | grep gitea
kubectl get secret postgres-single-gitea-user -n database
kubectl get secret postgres-single-gitea-user -n ci-cd  # Reflected
```

### Access Gitea Logs
```bash
kubectl logs -n ci-cd -l app.kubernetes.io/name=gitea
```

### Test Database Connection
```bash
# Get password
kubectl get secret postgres-single-gitea-user -n database -o jsonpath='{.data.password}' | base64 -d

# Connect to database
kubectl exec -it postgres-single-1 -n database -- psql -U gitea_user -d gitea
```

### Backup Gitea Data
```bash
# Backup PVC data
kubectl exec -n ci-cd <gitea-pod> -- tar czf - /data > gitea-backup.tar.gz

# Restore
kubectl exec -n ci-cd <gitea-pod> -- tar xzf - -C / < gitea-backup.tar.gz
```

## Troubleshooting

### Application won't start
1. Check HelmRelease: `kubectl get hr -n ci-cd`
2. Check pod logs: `kubectl logs -n ci-cd -l app.kubernetes.io/name=gitea`
3. Check events: `kubectl get events -n ci-cd --sort-by='.lastTimestamp'`

### Database connection failed
1. Verify secret exists: `kubectl get secret postgres-single-gitea-user -n ci-cd`
2. Check PostgreSQL cluster: `kubectl get cluster -n database`
3. Test connection: `kubectl exec -it <gitea-pod> -n ci-cd -- nc -zv postgres-single-rw.database.svc.cluster.local 5432`

### SSH Git access not working
1. Verify SSH service: `kubectl get svc -n ci-cd gitea-ssh`
2. Check SSH port mapping
3. Test SSH: `ssh -T -p 22 git@git.staging.local`

### Certificate issues
1. Check cert-manager logs: `kubectl logs -n cert-manager -l app=cert-manager`
2. Check certificate: `kubectl get certificate -n ci-cd`
3. Verify ClusterIssuer: `kubectl get clusterissuer letsencrypt-production`
