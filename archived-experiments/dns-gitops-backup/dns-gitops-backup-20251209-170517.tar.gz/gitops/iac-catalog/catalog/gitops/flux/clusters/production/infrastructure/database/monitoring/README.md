# Monitoring

This directory contains monitoring configurations for database clusters.

## Files

### mariadb-monitoring.yaml
Prometheus monitoring for MariaDB:
- **ServiceMonitor**: Scrapes metrics from mysqld_exporter (port 9104)
- **PrometheusRule**: 7 alert rules
  - MariaDBDown (critical)
  - MariaDBHighConnections (warning, >80%)
  - MariaDBSlowQueries (warning, >10/sec)
  - MariaDBReplicationLag (warning, >30sec)
  - MariaDBHighDiskUsage (info)
  - MariaDBHighTableLocks (warning, >10/sec)
  - MariaDBLowBufferPoolEfficiency (info, <90%)

## Enabling Monitoring

Uncomment in `../kustomization.yaml`:

```yaml
resources:
  # Monitoring
  - monitoring/mariadb-monitoring.yaml
```

## Requirements

- Prometheus Operator installed
- ServiceMonitor CRD available
- MariaDB cluster with metrics enabled (default)

## Grafana Dashboard

Import the MariaDB Galera dashboard:
- Dashboard ID: 10595
- Datasource: Prometheus

Or create custom dashboard using these metrics:
- `mysql_up` - Database availability
- `mysql_global_status_threads_connected` - Active connections
- `mysql_global_status_slow_queries` - Slow query rate
- `mysql_global_status_wsrep_local_state` - Galera state
- `mysql_global_variables_max_connections` - Max connections limit

## Verification

```bash
# Check ServiceMonitor
kubectl get servicemonitor -n database mariadb-single

# Check PrometheusRule
kubectl get prometheusrule -n database mariadb-alerts

# Check metrics endpoint
kubectl port-forward -n database mariadb-single-metrics-xxx 9104:9104
curl http://localhost:9104/metrics

# Check if Prometheus is scraping
kubectl port-forward -n monitoring prometheus-xxx 9090:9090
# Visit: http://localhost:9090/targets
```

## Alert Configuration

Alerts are sent to Alertmanager (if configured). Configure routes in Alertmanager:

```yaml
route:
  routes:
    - match:
        alertname: MariaDBDown
      receiver: pagerduty
      continue: false
    
    - match_re:
        alertname: MariaDB.*
      receiver: slack-database
```

## Silence Alerts

```bash
# Silence MariaDBHighConnections during maintenance
kubectl exec -n monitoring alertmanager-xxx -- \
  amtool silence add alertname=MariaDBHighConnections \
  --duration 2h --comment "Maintenance window"
```
