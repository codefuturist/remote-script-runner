# Database Infrastructure

This directory contains database operator deployments and cluster configurations for the staging environment.

## 📁 Directory Structure

```
database/
├── operators/           # Database operators
│   ├── cloudnative-pg/  # PostgreSQL operator
│   └── mariadb/         # MariaDB operator
├── clusters/            # Database cluster definitions
│   ├── postgresql/      # PostgreSQL clusters
│   └── mariadb/         # MariaDB clusters
├── applications/        # Application database examples
├── monitoring/          # Prometheus monitoring configs
├── backup/              # Backup configurations
├── ha-optional/         # High availability configs (optional)
├── templates/           # Reusable templates
├── examples/            # Complete examples
├── docs/                # Documentation
└── scripts/             # Automation scripts
```

## 📦 Active Deployments (Single-Node - Default)

- **PostgreSQL**: `clusters/postgresql/postgres-single-node.yaml`
  - CloudNativePG, PostgreSQL 16, 1 replica, 20Gi
- **MariaDB**: `clusters/mariadb/mariadb-single-node.yaml`
  - MariaDB Operator, MariaDB 11.4, 1 replica, 20Gi

## 🔧 Optional Components

Enable by uncommenting in `kustomization.yaml`:

- **Monitoring**: `monitoring/mariadb-monitoring.yaml` - Prometheus metrics & alerts
- **Backup**: `backup/mariadb-backup.yaml` - Daily/weekly S3 backups
- **HA Cluster**: `ha-optional/mariadb-cluster-ha.yaml.optional` - 3-node Galera
- **Connection Pooling**: `ha-optional/mariadb-proxysql.yaml.optional` - ProxySQL

## 📚 Documentation

- **[PostgreSQL Guide](docs/centralized-postgres-guide.md)** - Complete PostgreSQL setup
- **[MariaDB Guide](docs/centralized-mariadb-guide.md)** - Complete MariaDB setup
- **[HA Guide](docs/HA-GUIDE.md)** - High availability configurations
- **[Migration Strategy](docs/MIGRATION_STRATEGY.md)** - PostgreSQL ↔ MariaDB migration
- **[Quick Reference](docs/QUICK_REFERENCE.md)** - Common commands

## Overview

- **[CloudNativePG](https://cloudnative-pg.io/)** - PostgreSQL operator with streaming replication
- **[MariaDB Operator](https://github.com/mariadb-operator/mariadb-operator)** - MariaDB operator with declarative CRDs

## 🚀 Quick Start: Centralized Multi-Application Database

This setup uses a **single PostgreSQL cluster** with **multiple isolated databases** for different applications. Each application gets its own database and dedicated user.

**Documentation:**

- 📖 [Complete Guide](centralized-postgres-guide.md) - Comprehensive documentation
- ⚡ [Quick Reference](QUICK_REFERENCE.md) - Common commands and troubleshooting
- 📁 [Templates](templates/) - Ready-to-use YAML templates and automation scripts
- 💡 [Examples](examples/) - Complete multi-app setup examples

### Create New Application Database (2 ways)

#### Option 1: Automated Script (Recommended)

```bash
cd templates/
./onboard-app.sh myapp myapp myapp_user "development,staging"
```

#### Option 2: Manual YAML

```bash
# Edit templates/app-database-template.yaml
kubectl apply -f templates/app-database-template.yaml
```

### Verify Database

```bash
kubectl get databases -n database
kubectl describe database postgres-single-myapp -n database
```

## Components

### 1. CloudNativePG Operator

**File:** `cloudnative-pg-operator.yaml`

The operator manages PostgreSQL clusters, providing:
- Automated failover and high availability
- Continuous backup and Point-in-Time Recovery (PITR)
- Rolling updates
- Declarative configuration
- Connection pooling (via PgBouncer)
- Monitoring integration (Prometheus)

**Configuration Highlights:**
- PostgreSQL 17.2 as default image
- Monitoring enabled with PodMonitor
- Grafana dashboard auto-discovery
- Secure defaults (non-root, read-only filesystem)
- Resource limits: 500m CPU, 512Mi memory

### 2. PostgreSQL Cluster Example

**File:** `postgres-cluster-example.yaml`

Template for creating PostgreSQL clusters. Features:
- 3 instances (1 primary + 2 replicas)
- High availability with automatic failover
- Optimized PostgreSQL configuration
- Monitoring integration
- Resource management
- Backup configuration (commented out)

## Quick Start

### Deploy the Operator

The operator is automatically deployed via FluxCD. To check status:

```bash
# Check operator deployment
kubectl get pods -n database -l app.kubernetes.io/name=cloudnative-pg

# Check operator logs
kubectl logs -n database -l app.kubernetes.io/name=cloudnative-pg -f

# Check CRDs
kubectl get crd | grep cnpg
```

### Create a PostgreSQL Cluster

1. **Copy and customize the example:**

```bash
cp postgres-cluster-example.yaml my-postgres-cluster.yaml
# Edit the file and uncomment the resources
```

2. **Important configurations to change:**
   - Cluster name
   - Database name
   - Storage size and class
   - Resource limits
   - Passwords in secrets (use SOPS encryption!)

3. **Enable in kustomization:**

```yaml
# In kustomization.yaml
resources:
  - cloudnative-pg-operator.yaml
  - my-postgres-cluster.yaml
```

4. **Commit and push - FluxCD will deploy it**

### Access the Database

After cluster creation, CloudNativePG creates services:

```bash
# List services
kubectl get svc -n database

# Services created:
# - <cluster-name>-rw  (read-write, connects to primary)
# - <cluster-name>-ro  (read-only, connects to replicas)
# - <cluster-name>-r   (read, connects to any instance)
```

**Connection strings:**

```bash
# Read-Write (Primary)
postgresql://app:password@postgres-example-rw.database.svc.cluster.local:5432/app

# Read-Only (Replicas)
postgresql://app:password@postgres-example-ro.database.svc.cluster.local:5432/app
```

## Managing Secrets

### Using SOPS (Recommended)

```bash
# Create a secret file
cat > my-postgres-secrets.yaml <<EOF
apiVersion: v1
kind: Secret
metadata:
  name: my-postgres-superuser
  namespace: database
type: kubernetes.io/basic-auth
stringData:
  username: postgres
  password: MyStrongPassword123!
EOF

# Encrypt with SOPS
sops --encrypt --in-place my-postgres-secrets.yaml

# Add to kustomization
# FluxCD will automatically decrypt during deployment
```

### Using kubectl (Quick Testing)

```bash
# Create superuser secret
kubectl create secret generic my-postgres-superuser \
  --from-literal=username=postgres \
  --from-literal=password=MyStrongPassword123! \
  -n database

# Create app user secret
kubectl create secret generic my-postgres-app-user \
  --from-literal=username=app \
  --from-literal=password=MyAppPassword123! \
  -n database
```

## Monitoring

### Prometheus Integration

CloudNativePG exposes metrics automatically. The operator creates PodMonitors.

```bash
# Check PodMonitors
kubectl get podmonitors -n database

# View metrics endpoint
kubectl port-forward -n database svc/postgres-example-r 9187:9187
curl localhost:9187/metrics
```

### Grafana Dashboards

Dashboards are automatically created in the monitoring namespace:

```bash
# List dashboards
kubectl get configmaps -n monitoring -l grafana_dashboard=1
```

Import the CloudNativePG dashboard: **Dashboard ID: 20417**

### Check Cluster Status

```bash
# Get cluster status
kubectl get cluster -n database

# Detailed cluster info
kubectl describe cluster postgres-example -n database

# Check instances
kubectl get pods -n database -l cnpg.io/cluster=postgres-example
```

## Backup and Recovery

### Configure Backups

Uncomment the backup section in your cluster configuration:

```yaml
backup:
  barmanObjectStore:
    destinationPath: s3://your-bucket/postgres-backups
    s3Credentials:
      accessKeyId:
        name: aws-credentials
        key: ACCESS_KEY_ID
      secretAccessKey:
        name: aws-credentials
        key: SECRET_ACCESS_KEY
    wal:
      compression: gzip
      maxParallel: 2
    data:
      compression: gzip
  retentionPolicy: "30d"
```

### Create Backup

```bash
# Trigger manual backup
kubectl cnpg backup postgres-example -n database

# List backups
kubectl get backups -n database
```

### Restore from Backup

```yaml
apiVersion: postgresql.cnpg.io/v1
kind: Cluster
metadata:
  name: postgres-restored
spec:
  instances: 3
  bootstrap:
    recovery:
      source: postgres-example
      recoveryTarget:
        targetTime: "2024-01-15 10:00:00"
  externalClusters:
    - name: postgres-example
      barmanObjectStore:
        destinationPath: s3://your-bucket/postgres-backups
        # ... credentials
```

## Operations

### Scaling

```bash
# Scale up replicas (edit cluster)
kubectl edit cluster postgres-example -n database
# Change instances: 3 to instances: 5
```

### Updates

CloudNativePG performs rolling updates automatically:

```yaml
# Update PostgreSQL version
spec:
  imageName: ghcr.io/cloudnative-pg/postgresql:17.3-1
```

### Failover Testing

```bash
# Get primary instance
kubectl get cluster postgres-example -n database -o jsonpath='{.status.currentPrimary}'

# Delete primary pod (triggers failover)
kubectl delete pod -n database postgres-example-1

# Watch failover
kubectl get cluster postgres-example -n database -w
```

### Connection Pooling

Deploy PgBouncer for connection pooling:

```yaml
apiVersion: postgresql.cnpg.io/v1
kind: Pooler
metadata:
  name: postgres-example-pooler
spec:
  cluster:
    name: postgres-example
  instances: 3
  type: rw
  pgbouncer:
    poolMode: transaction
    parameters:
      max_client_conn: "1000"
      default_pool_size: "25"
```

## Troubleshooting

### Check Operator Logs

```bash
kubectl logs -n database -l app.kubernetes.io/name=cloudnative-pg --tail=100 -f
```

### Check Cluster Events

```bash
kubectl describe cluster postgres-example -n database
kubectl get events -n database --sort-by='.lastTimestamp'
```

### Check PostgreSQL Logs

```bash
# Get current primary
PRIMARY=$(kubectl get cluster postgres-example -n database -o jsonpath='{.status.currentPrimary}')

# View logs
kubectl logs -n database $PRIMARY -c postgres
```

### Common Issues

**Pods not starting:**
- Check storage class exists and can provision volumes
- Verify resource quotas in namespace
- Check node resources

**Connection refused:**
- Verify service exists: `kubectl get svc -n database`
- Check pod status: `kubectl get pods -n database`
- Verify credentials in secrets

**Backup failures:**
- Check S3 credentials
- Verify bucket permissions
- Check backup logs: `kubectl logs -n database -l cnpg.io/backup=true`

## Best Practices

1. **Always use secrets management** (SOPS, External Secrets Operator)
2. **Enable backups** with appropriate retention
3. **Set resource limits** based on your workload
4. **Use replicas** for high availability (minimum 3 instances)
5. **Monitor metrics** and set up alerts
6. **Test failover** regularly
7. **Use connection pooling** (PgBouncer) for high-traffic applications
8. **Keep operator updated** for security patches
9. **Use separate clusters** for different applications
10. **Enable TLS** for connections in production

## References

- [CloudNativePG Documentation](https://cloudnative-pg.io/documentation/)
- [API Reference](https://cloudnative-pg.io/documentation/current/api_reference/)
- [Backup & Recovery Guide](https://cloudnative-pg.io/documentation/current/backup_recovery/)
- [Monitoring Guide](https://cloudnative-pg.io/documentation/current/monitoring/)
- [GitHub Repository](https://github.com/cloudnative-pg/cloudnative-pg)

## Architecture

```
┌─────────────────────────────────────────────┐
│         CloudNativePG Operator              │
│  (Manages PostgreSQL Clusters)             │
└─────────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────────┐
│         PostgreSQL Cluster                  │
│  ┌────────────┐  ┌────────────┐            │
│  │  Primary   │─▶│  Replica 1 │            │
│  │  (R/W)     │  │  (R/O)     │            │
│  └────────────┘  └────────────┘            │
│         │                                    │
│         ▼                                    │
│  ┌────────────┐                             │
│  │  Replica 2 │                             │
│  │  (R/O)     │                             │
│  └────────────┘                             │
└─────────────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────────┐
│          Services                           │
│  - cluster-rw  (Primary)                    │
│  - cluster-ro  (Replicas)                   │
│  - cluster-r   (Any)                        │
└─────────────────────────────────────────────┘
```
