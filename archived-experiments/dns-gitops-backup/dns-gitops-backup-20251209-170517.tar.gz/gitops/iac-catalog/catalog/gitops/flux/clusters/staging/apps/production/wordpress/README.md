# WordPress - Production Application

This directory contains the WordPress deployment for the staging environment.

## Overview

WordPress is a free and open-source content management system (CMS) written in PHP.

## Configuration

- **Namespace**: `wordpress`
- **Image**: `wordpress:6.4-apache`
- **Database**: MariaDB (centralized in `database` namespace)
- **Storage**: 10Gi persistent volume for WordPress files
- **Ingress**: Enabled with Traefik and Let's Encrypt staging certificates

## Dependencies

- MariaDB Single instance (database namespace)
- Database: `wordpress`
- Database User: `wordpress_user`
- cert-manager for TLS certificates

## Resources

- **Requests**: 100m CPU, 256Mi memory
- **Limits**: 500m CPU, 512Mi memory

## Database Configuration

The database is created via MariaDB operator resources in:
`infrastructure/database/applications/wordpress-databases.yaml`

## Secrets

- `wordpress-secret.yaml` - Database password (SOPS encrypted)
- `wordpress-deployment.yaml` - Contains database credentials secret

The deployment references the `wordpress-db-credentials` secret which includes:
- Database host
- Database name
- Database user
- Database password

## Deployment

This application is deployed via FluxCD from the main cluster kustomization.

## Access

- **Host**: `wordpress.staging.local`
- **Protocol**: HTTPS (Let's Encrypt staging)
- **Port**: 443

## Notes

- Uses `ReadWriteOnce` storage mode
- Deployment strategy: `Recreate` (required for RWO volumes)
- Includes health checks (liveness and readiness probes)
