# OpenEBS Backup Infrastructure

Modern backup solution for OpenEBS volumes using Velero with CSI snapshot support.

## Overview

This backup infrastructure provides automated volume backups with:
- **CSI snapshots** for space-efficient backups (LVM/ZFS prioritized)
- **Database-aware hooks** for PostgreSQL and MariaDB consistency
- **External MinIO** storage for backup retention
- **Automated validation** via CronJob

## Components

### 1. CSI Snapshot Controller
- **File**: `storage/snapshot-controller.yaml`
- Kubernetes CSI snapshot controller from Piraeus charts
- Manages VolumeSnapshot and VolumeSnapshotContent resources
- Single replica for staging (increase to 2 for production)

### 2. VolumeSnapshotClasses
- **File**: `storage/volumesnapshotclasses.yaml`
- **Priority 1**: `openebs-lvm-snapclass` (default) - Space-efficient LVM snapshots
- **Priority 2**: `openebs-zfs-snapclass` - Native ZFS CoW snapshots
- **Fallback**: `openebs-hostpath-snapclass` - Filesystem-level snapshots

### 3. Velero
- **File**: `backup/velero.yaml`
- Backup orchestration with CSI plugin
- AWS S3 plugin for MinIO compatibility
- Node agent for filesystem fallback

### 4. Backup Schedules
- **File**: `backup/schedules.yaml`
- **Hourly**: Critical databases (7-day retention)
- **Daily**: Full cluster backup (30-day retention)
- **Weekly**: Long-term backup (90-day retention)

### 5. Validation CronJob
- **File**: `backup/validation-cronjob.yaml`
- Weekly validation of backup health
- Alerts on failed backups
- Checks storage location status

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     Velero Backup Flow                      │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  1. Schedule triggers backup                                │
│     ↓                                                       │
│  2. Pre-backup hooks (PostgreSQL/MariaDB)                   │
│     - pg_start_backup() / FLUSH TABLES WITH READ LOCK      │
│     ↓                                                       │
│  3. CSI Snapshot creation (LVM/ZFS prioritized)             │
│     - VolumeSnapshot → VolumeSnapshotContent                │
│     ↓                                                       │
│  4. Post-backup hooks                                       │
│     - pg_stop_backup() / UNLOCK TABLES                      │
│     ↓                                                       │
│  5. Backup metadata uploaded to MinIO                       │
│     - External MinIO at minio.pandia.io:9000                │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## Storage Class Priorities

1. **LVM** (`lvm.csi.openebs.io`) - Block-level, thin-provisioned snapshots
2. **ZFS** (`zfs.csi.openebs.io`) - Native CoW snapshots with instant creation
3. **Hostpath** (`local.csi.openebs.io`) - Filesystem copies (fallback)

## Database Backup Hooks

### PostgreSQL
```yaml
labels:
  app.kubernetes.io/name: postgresql
  backup: critical  # For hourly backups
```
- **Pre**: `pg_start_backup()` - Creates consistent snapshot point
- **Post**: `pg_stop_backup()` - Completes backup sequence

### MariaDB/MySQL
```yaml
labels:
  app.kubernetes.io/name: mariadb
  backup: critical  # For hourly backups
```
- **Pre**: `FLUSH TABLES WITH READ LOCK` - Ensures table consistency
- **Post**: `UNLOCK TABLES` - Releases locks

## Configuration

### 1. Update MinIO Credentials
Edit `backup/minio-credentials-secret.yaml`:
```yaml
stringData:
  cloud: |
    [default]
    aws_access_key_id=YOUR_ACCESS_KEY
    aws_secret_access_key=YOUR_SECRET_KEY
```

**Recommended**: Use SOPS encryption:
```bash
sops --encrypt --age $(cat .sops.yaml | yq '.creation_rules[0].age') \
  backup/minio-credentials-secret.yaml > backup/minio-credentials-secret.enc.yaml
```

### 2. Verify External MinIO
Update `backup/velero.yaml` if using different MinIO endpoint:
```yaml
s3Url: https://your-minio.example.com:9000
```

### 3. Create MinIO Bucket
```bash
# Using mc (MinIO Client)
mc alias set external-minio https://minio.pandia.io:9000 ACCESS_KEY SECRET_KEY
mc mb external-minio/openebs-velero-backups
mc ilm add external-minio/openebs-velero-backups --expiry-days 90
```

## Deployment

### Apply via FluxCD
```bash
# Commit changes
git add catalog/gitops/flux/clusters/staging/infrastructure/
git commit -m "feat(backup): implement OpenEBS backup with Velero"

# Reconcile Flux
make flux-reconcile-all

# Or manual reconcile
flux reconcile kustomization infrastructure -n flux-system
```

### Verify Deployment
```bash
# Check snapshot controller
kubectl -n kube-system get pods -l app=snapshot-controller

# Check Velero
kubectl -n velero get pods
velero version

# Check VolumeSnapshotClasses
kubectl get volumesnapshotclass

# Verify backup storage location
velero backup-location get

# Check schedules
velero schedule get
```

## Usage

### Manual Backup
```bash
# Backup specific namespace with LVM snapshots
velero backup create manual-backup-$(date +%Y%m%d-%H%M%S) \
  --include-namespaces database \
  --snapshot-volumes \
  --volume-snapshot-locations openebs-lvm \
  --wait

# Check backup status
velero backup describe BACKUP_NAME
velero backup logs BACKUP_NAME
```

### Restore from Backup
```bash
# List available backups
velero backup get

# Restore entire backup
velero restore create --from-backup BACKUP_NAME

# Restore specific namespace
velero restore create --from-backup BACKUP_NAME \
  --include-namespaces database

# Monitor restore
velero restore get
velero restore describe RESTORE_NAME
```

### Test Restore (Non-Destructive)
```bash
# Restore to different namespace
velero restore create test-restore-$(date +%Y%m%d-%H%M%S) \
  --from-backup BACKUP_NAME \
  --namespace-mappings database:test-database

# Validate restored resources
kubectl get all -n test-database

# Cleanup test namespace
kubectl delete namespace test-database
```

## Monitoring

### Check Backup Status
```bash
# Recent backups
velero backup get

# Failed backups
velero backup get | grep -v Completed

# Backup details
velero backup describe BACKUP_NAME --details

# Volume snapshots
kubectl get volumesnapshots -A
```

### Validation CronJob
Runs every Monday at 6 AM:
- Checks for failed backups
- Validates storage location
- Lists recent volume snapshots
- Sends alerts on failures

```bash
# Check validation logs
kubectl -n velero logs -l app=backup-validation --tail=100
```

## Troubleshooting

### Backup Fails with "no node was specified"
**Cause**: PVC using `Immediate` binding mode instead of `WaitForFirstConsumer`

**Fix**: Ensure StorageClass uses `WaitForFirstConsumer`:
```bash
kubectl get storageclass -o yaml | grep volumeBindingMode
```

### CSI Snapshot Timeout
**Cause**: Large volumes or slow storage

**Fix**: Increase timeout in schedule:
```yaml
csiSnapshotTimeout: 30m  # Default is 10m
```

### Database Hooks Fail
**Cause**: Missing environment variables or incorrect container name

**Fix**: Verify pod labels and environment variables:
```bash
kubectl -n database get pods --show-labels
kubectl -n database describe pod POD_NAME
```

### MinIO Connection Error
**Cause**: Incorrect credentials or endpoint

**Fix**: Verify credentials and test connection:
```bash
mc alias set test-minio https://minio.pandia.io:9000 ACCESS_KEY SECRET_KEY
mc ls test-minio/openebs-velero-backups
```

## Production Considerations

### Single-Node → 3-Node Migration

1. **Update Snapshot Controller**:
   ```yaml
   replicas: 2  # High availability
   ```

2. **Enable Mayastor** (replicated storage):
   ```yaml
   engines:
     replicated:
       mayastor:
         enabled: true
   ```

3. **Update Backup Schedules**:
   - Increase frequency for critical workloads
   - Add offsite backup location (AWS S3, Azure Blob)

4. **Distributed MinIO**:
   ```yaml
   minio:
     replicas: 3
     mode: distributed
   ```

### Security Hardening

1. **Encrypt Secrets with SOPS**:
   ```bash
   sops --encrypt backup/minio-credentials-secret.yaml
   ```

2. **Use External Secrets Operator**:
   - Integrate with Vault or AWS Secrets Manager
   - Rotate credentials regularly

3. **Network Policies**:
   - Restrict Velero egress to MinIO only
   - Limit backup-validator permissions

### Compliance

- **Retention**: Adjust TTL per compliance requirements
- **Encryption**: Enable MinIO server-side encryption
- **Audit**: Enable Velero audit logs
- **Testing**: Schedule quarterly DR drills

## References

- [Velero Documentation](https://velero.io/docs/v1.14/)
- [OpenEBS CSI Snapshots](https://openebs.io/docs/user-guides/cstor-csi-snapshot)
- [Kubernetes CSI Snapshots](https://kubernetes.io/docs/concepts/storage/volume-snapshots/)
- [MinIO Lifecycle Management](https://min.io/docs/minio/linux/administration/object-management/object-lifecycle-management.html)
