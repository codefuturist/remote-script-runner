# FluxCD Production Cluster Restructure - Migration Guide

## Overview

The production cluster has been restructured to follow modern GitOps best practices with improved organization, granular dependency management, and tier-based application deployment.

## What Changed

### 1. **Granular Infrastructure Kustomizations**

**Before**: Single monolithic `infrastructure-kustomization.yaml`

**After**: Layered Kustomizations with explicit dependencies

```
infrastructure-sources           (no deps)
    ↓
infrastructure-namespaces        (depends: sources)
infrastructure-configs           (depends: sources)
    ↓
infrastructure-network           (depends: sources, namespaces)
infrastructure-security          (depends: sources, namespaces, network)
infrastructure-storage           (depends: sources, namespaces)
infrastructure-utility           (depends: sources, namespaces)
    ↓
infrastructure-monitoring        (depends: network, storage)
infrastructure-logging           (depends: network, storage)
infrastructure-database          (depends: storage, network)
infrastructure-backup            (depends: storage, configs)
```

**Benefits**:
- Faster reconciliation (parallel deployment where possible)
- Better failure isolation
- Clearer dependency chains
- Easier debugging

### 2. **Network Layer Consolidation**

**Before**: Components scattered across directories
```
infrastructure/
├── ingress/
├── dns/
├── metallb/
├── cert-manager/
└── traefik-middlewares/
```

**After**: Consolidated under `network/`
```
infrastructure/network/
├── kustomization.yaml  (references existing directories)
└── README.md          (documentation)
```

**Migration Strategy**:
- Phase 1: ✅ Create `network/kustomization.yaml` that references existing locations
- Phase 2: 📅 Gradually move components into `network/` subdirectories
- Phase 3: 📅 Update all references and remove old structure

### 3. **Enhanced Security Layer**

**Added Components**:
- `security/rbac/` - Cluster-wide RBAC policies
  - Cluster admin roles
  - View-only roles
  - Namespace admin templates
  - Flux reconciler service account
- `security/external-secrets/` - External secret store integration (optional, disabled)
  - Template for AWS Secrets Manager
  - Template for HashiCorp Vault
  - Example SecretStore configurations

**Current**: Using SOPS for secrets (no change needed)

**Future**: Can enable external-secrets when integrating with cloud providers

### 4. **Tier-Based Application Organization**

**Before**: Flat structure
```
apps/
├── n8n/
├── mattermost/
├── homepage/
├── mealie/
└── phpmyadmin/
```

**After**: Organized by tier
```
apps/
├── backend/           (API services, business logic)
│   ├── n8n/
│   ├── mattermost/
│   ├── mailrise/
│   └── paperless-ngx/
├── frontend/          (User-facing applications)
│   ├── homepage/
│   ├── mealie/
│   └── compass-web/
├── data/              (Database tools)
│   ├── phpmyadmin/
│   └── redisinsight/
└── jobs/              (Batch jobs, scheduled tasks)
    └── (placeholder for future jobs)
```

**Migration Strategy**:
- Phase 1: ✅ Create tier directories with kustomizations
- Phase 2: ✅ Reference existing apps from tier kustomizations (using `../../app-name`)
- Phase 3: 📅 Move app directories into tiers
- Phase 4: 📅 Update paths to remove `../../` references

**Current State**: Apps remain in original locations, referenced from tier directories

### 5. **Enhanced Notifications**

**Added**:
- PagerDuty provider for critical infrastructure alerts
- Generic webhook provider for custom integrations
- Granular alert routing:
  - Critical infrastructure → PagerDuty + Slack
  - Infrastructure errors → Slack critical
  - App deployments → Slack general
  - App failures → Slack critical
  - Git sync issues → Slack critical
- Inclusion/exclusion lists to reduce noise

**Configuration Required**:
```bash
# Slack webhooks (existing)
kubectl create secret generic slack-webhook-url \
  --from-literal=address=https://hooks.slack.com/services/YOUR/WEBHOOK/URL \
  --namespace=flux-system

# Slack critical channel (new)
kubectl create secret generic slack-webhook-critical \
  --from-literal=address=https://hooks.slack.com/services/YOUR/WEBHOOK/URL \
  --namespace=flux-system

# PagerDuty (new, optional)
kubectl create secret generic pagerduty-integration-key \
  --from-literal=address=https://events.pagerduty.com/v2/enqueue \
  --from-literal=token=YOUR_INTEGRATION_KEY \
  --namespace=flux-system
```

## Impact Assessment

### Breaking Changes
**None** - All changes are backward compatible

### New Resources
- 11 new infrastructure Kustomization CRDs in `flux-system/`
- 1 new network layer consolidation kustomization
- 4 new RBAC policy files
- 1 new external-secrets template (disabled)
- 4 new app tier directories
- Multiple new documentation files

### Deprecated Resources
- `flux-system/infrastructure-kustomization.yaml` - Replaced by granular Kustomizations
  - **Action**: Can be removed after validating new structure works
  - **Rollback**: Keep file for 1 release cycle as backup

## Deployment Process

### Automatic Deployment (Recommended)

1. **Merge changes to main branch**
2. **Flux will automatically**:
   - Detect new Kustomization CRDs in flux-system/
   - Deploy infrastructure layers in dependency order
   - Apply new app tier structure
   - Update notifications

3. **Monitor deployment**:
```bash
flux get kustomizations
watch kubectl get kustomizations -n flux-system
```

### Manual Validation (Optional)

Before merging, test in staging:

```bash
# Validate Kustomize builds
kustomize build catalog/gitops/flux/clusters/production/flux-system
kustomize build catalog/gitops/flux/clusters/production/infrastructure/network
kustomize build catalog/gitops/flux/clusters/production/apps/backend

# Dry-run apply
kubectl apply --dry-run=server -k catalog/gitops/flux/clusters/production/flux-system
```

## Rollback Plan

If issues occur:

### Option 1: Revert Granular Kustomizations
```bash
# Suspend new Kustomizations
flux suspend kustomization infrastructure-sources
flux suspend kustomization infrastructure-network
# ... (suspend all new ones)

# Re-enable old monolithic one
# Uncomment infrastructure-kustomization.yaml in flux-system/kustomization.yaml
```

### Option 2: Git Revert
```bash
git revert <commit-sha>
git push origin main
# Flux will automatically roll back
```

## Validation Checklist

After deployment, verify:

- [ ] All infrastructure Kustomizations are Ready
  ```bash
  kubectl get kustomizations -n flux-system
  ```

- [ ] All HelmReleases are Ready
  ```bash
  kubectl get helmreleases -A
  ```

- [ ] Applications are accessible
  - [ ] Homepage dashboard
  - [ ] Mealie
  - [ ] phpMyAdmin
  - [ ] Other critical apps

- [ ] Notifications are working
  ```bash
  # Check alerts are created
  kubectl get alerts -n flux-system

  # Check providers are ready
  kubectl get providers -n flux-system
  ```

- [ ] Metrics are flowing
  - [ ] Check Prometheus targets
  - [ ] Check Grafana dashboards

## Timeline

- **2024-12-09**: Initial restructure implemented
- **2024-12-16**: Validation period (1 week)
- **2024-12-23**: Remove old infrastructure-kustomization.yaml
- **2025-Q1**: Complete app directory migration to tiers

## Benefits Realized

1. **Faster Reconciliation**: Parallel deployment of independent layers
2. **Better Failure Isolation**: Issues in monitoring don't block app deployments
3. **Clearer Dependencies**: Explicit dependency chains in Kustomization CRDs
4. **Improved Documentation**: READMEs in every major directory
5. **Enhanced Security**: RBAC templates, external-secrets ready
6. **Better Organization**: Tier-based apps improve discoverability
7. **Granular Alerting**: Right alert to right channel
8. **Future-Proof**: Structure supports growth and new patterns

## Questions & Support

- **FluxCD Issues**: Check `flux logs --all-namespaces`
- **Kustomization Status**: `flux get kustomizations`
- **Rollback Help**: See "Rollback Plan" section above

## References

- [Production Cluster README](./README.md)
- [FluxCD Kustomization API](https://fluxcd.io/flux/components/kustomize/kustomization/)
- [Kustomize Dependencies](https://fluxcd.io/flux/components/kustomize/kustomization/#dependencies)
- [Original Example Structure](../../../docs/fluxcd-example-structure.md)

