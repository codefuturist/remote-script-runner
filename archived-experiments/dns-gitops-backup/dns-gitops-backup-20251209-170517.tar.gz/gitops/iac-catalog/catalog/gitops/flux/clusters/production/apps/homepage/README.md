# Homepage - Application Dashboard

This directory contains the Flux HelmRelease configuration for Homepage in the staging environment.

## Overview

Homepage is a modern, fully static, fast, secure fully proxied, highly customizable application dashboard with integrations for over 100 services.

## Configuration

- **Namespace**: `dashboard`
- **Chart Repository**: https://jameswynn.github.io/helm-charts
- **Ingress**: Enabled with Traefik ingress class
- **RBAC**: Enabled for Kubernetes integration

## Features

- Kubernetes cluster resource monitoring
- Service discovery via annotations
- Customizable bookmarks and services
- Search integration

## Resources

- 50m CPU / 128Mi memory (requests)
- 200m CPU / 256Mi memory (limits)

## Deployment

This application is deployed via FluxCD from the main cluster kustomization.
