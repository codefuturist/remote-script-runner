# Centralized PostgreSQL Database Management

## Architecture Overview

**Single PostgreSQL Cluster → Multiple Application Databases → Dedicated Users**

This guide demonstrates how to manage a centralized PostgreSQL instance with per-application isolation using CloudNativePG's declarative database management.

## Key Features

✅ **Single PostgreSQL Instance** (`postgres-single`)  
✅ **Multiple Isolated Databases** (one per application)  
✅ **Dedicated Application Users** (each owns their database)  
✅ **Declarative Management** (via Database CRDs)  
✅ **Automated Lifecycle** (create, update, delete)  
✅ **GitOps-Ready** (FluxCD reconciliation)

## Architecture Diagram

```
┌─────────────────────────────────────────────────────┐
│  PostgreSQL Cluster: postgres-single               │
│  ├─ Instance: postgres-single-1 (16.4)             │
│  ├─ Storage: 20Gi (local-path)                     │
│  └─ Services:                                       │
│     ├─ postgres-single-rw (read-write)             │
│     ├─ postgres-single-ro (read-only)              │
│     └─ postgres-single-r (read)                    │
└─────────────────────────────────────────────────────┘
                         │
        ┌────────────────┼────────────────┐
        │                │                │
        ▼                ▼                ▼
┌──────────────┐  ┌──────────────┐  ┌──────────────┐
│  App1 DB     │  │  App2 DB     │  │  App3 DB     │
│  Owner: app1 │  │  Owner: app2 │  │  Owner: app3 │
│  Database:   │  │  Database:   │  │  Database:   │
│  myapp       │  │  payments    │  │  analytics   │
└──────────────┘  └──────────────┘  └──────────────┘
```

## Best Practices

### 1. Database Isolation
- **One database per application**: Provides clear boundaries
- **Dedicated owner user**: Each app owns its database
- **Schema management**: Applications control their schemas
- **No superuser access**: Apps use regular PostgreSQL roles

### 2. Naming Conventions
- **Database names**: Descriptive (e.g., `myapp`, `payments`, `analytics`)
- **User names**: Match database or use prefix (e.g., `myapp_user`, `payments_owner`)
- **Kubernetes resources**: Include cluster prefix (e.g., `postgres-single-myapp`)

### 3. Secret Management
- **Per-application secrets**: Each app gets dedicated credentials
- **Secret naming**: `<cluster>-<database>-user` (e.g., `postgres-single-myapp-user`)
- **Auto-generated passwords**: Use CloudNativePG's secret generation
- **Rotation**: Update secrets via Database CRD

### 4. Connection Management
- **Use read-write service**: For transactional workloads (`postgres-single-rw`)
- **Use read-only service**: For read replicas (future: `postgres-single-ro`)
- **Connection pooling**: Consider PgBouncer for high-connection apps
- **Service discovery**: Use Kubernetes DNS (`postgres-single-rw.database.svc.cluster.local`)

### 5. Extension Management
- **Shared extensions**: Install at cluster level (pg_stat_statements, pgcrypto)
- **App-specific extensions**: Install per database (postgis, hstore, etc.)
- **Security**: Only superuser can install trusted extensions

## Implementation Guide

### Step 1: Create Application User Secret

Each application needs credentials stored in a Kubernetes Secret:

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: postgres-single-myapp-user
  namespace: database
type: kubernetes.io/basic-auth
stringData:
  username: myapp_user
  password: <GENERATE_SECURE_PASSWORD>  # Use: openssl rand -base64 32
```

**Best Practice**: Use external secret management (e.g., Sealed Secrets, External Secrets Operator, SOPS)

### Step 2: Create Database CRD

```yaml
apiVersion: postgresql.cnpg.io/v1
kind: Database
metadata:
  name: postgres-single-myapp  # Kubernetes resource name
  namespace: database
spec:
  cluster:
    name: postgres-single  # Target PostgreSQL cluster
  
  # Database configuration
  name: myapp  # PostgreSQL database name
  owner: myapp_user  # PostgreSQL role (must exist)
  
  # Lifecycle policy
  databaseReclaimPolicy: retain  # or 'delete' for auto-cleanup
  
  # Optional: Schema management
  schemas:
    - name: public
      owner: myapp_user
  
  # Optional: Extensions
  extensions:
    - name: pgcrypto
      ensure: present
    - name: uuid-ossp
      ensure: present
```

### Step 3: Create PostgreSQL Role

CloudNativePG doesn't auto-create roles from Database CRD. You have two options:

#### Option A: Declarative Role Management (Recommended)

Edit the cluster manifest (`postgres-single-node.yaml`):

```yaml
apiVersion: postgresql.cnpg.io/v1
kind: Cluster
metadata:
  name: postgres-single
spec:
  # ... existing configuration ...
  
  managed:
    roles:
      - name: myapp_user
        ensure: present
        login: true
        connectionLimit: 20
        passwordSecret:
          name: postgres-single-myapp-user
        inRoles:
          - app  # Inherit default app role permissions
```

#### Option B: Manual Role Creation

Connect to PostgreSQL and create roles manually:

```bash
# Port-forward to database
kubectl port-forward -n database svc/postgres-single-rw 5432:5432 &

# Get superuser password
export PGPASSWORD=$(kubectl get secret postgres-single-superuser -n database -o jsonpath='{.data.password}' | base64 -d)

# Create role
psql -h localhost -U postgres -d postgres -c "CREATE ROLE myapp_user WITH LOGIN PASSWORD '<password>' CONNECTION LIMIT 20;"
```

**Recommendation**: Use Option A for GitOps compatibility and automated management.

### Step 4: Application Configuration

Applications connect using standard PostgreSQL connection strings:

```yaml
# Application deployment
apiVersion: apps/v1
kind: Deployment
metadata:
  name: myapp
  namespace: development
spec:
  template:
    spec:
      containers:
      - name: myapp
        env:
        - name: DATABASE_URL
          value: "postgresql://$(DB_USER):$(DB_PASSWORD)@postgres-single-rw.database.svc.cluster.local:5432/myapp"
        - name: DB_USER
          valueFrom:
            secretKeyRef:
              name: postgres-single-myapp-user  # Replicated via Reflector
              key: username
        - name: DB_PASSWORD
          valueFrom:
            secretKeyRef:
              name: postgres-single-myapp-user
              key: password
```

### Step 5: Secret Replication (if needed)

If applications run in different namespaces, use Reflector to replicate secrets:

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: postgres-single-myapp-user
  namespace: database
  annotations:
    reflector.v1.k8s.emberstack.com/reflection-allowed: "true"
    reflector.v1.k8s.emberstack.com/reflection-allowed-namespaces: "development,staging,ci-cd"
    reflector.v1.k8s.emberstack.com/reflection-auto-enabled: "true"
    reflector.v1.k8s.emberstack.com/reflection-auto-namespaces: "development,staging,ci-cd"
type: kubernetes.io/basic-auth
stringData:
  username: myapp_user
  password: <password>
```

## Complete Example: Multi-Application Setup

### Application 1: Web Application

```yaml
---
# User secret
apiVersion: v1
kind: Secret
metadata:
  name: postgres-single-webapp-user
  namespace: database
  annotations:
    reflector.v1.k8s.emberstack.com/reflection-allowed: "true"
    reflector.v1.k8s.emberstack.com/reflection-auto-enabled: "true"
    reflector.v1.k8s.emberstack.com/reflection-auto-namespaces: "development"
type: kubernetes.io/basic-auth
stringData:
  username: webapp_user
  password: <SECURE_PASSWORD>

---
# Database
apiVersion: postgresql.cnpg.io/v1
kind: Database
metadata:
  name: postgres-single-webapp
  namespace: database
spec:
  cluster:
    name: postgres-single
  name: webapp
  owner: webapp_user
  databaseReclaimPolicy: retain
  extensions:
    - name: pgcrypto
```

### Application 2: Payment Service

```yaml
---
# User secret
apiVersion: v1
kind: Secret
metadata:
  name: postgres-single-payments-user
  namespace: database
  annotations:
    reflector.v1.k8s.emberstack.com/reflection-allowed: "true"
    reflector.v1.k8s.emberstack.com/reflection-auto-enabled: "true"
    reflector.v1.k8s.emberstack.com/reflection-auto-namespaces: "development,production"
type: kubernetes.io/basic-auth
stringData:
  username: payments_user
  password: <SECURE_PASSWORD>

---
# Database
apiVersion: postgresql.cnpg.io/v1
kind: Database
metadata:
  name: postgres-single-payments
  namespace: database
spec:
  cluster:
    name: postgres-single
  name: payments
  owner: payments_user
  databaseReclaimPolicy: retain
  extensions:
    - name: pgcrypto
    - name: uuid-ossp
```

### Application 3: Analytics Dashboard

```yaml
---
# User secret (read-only analytics)
apiVersion: v1
kind: Secret
metadata:
  name: postgres-single-analytics-user
  namespace: database
  annotations:
    reflector.v1.k8s.emberstack.com/reflection-allowed: "true"
    reflector.v1.k8s.emberstack.com/reflection-auto-enabled: "true"
    reflector.v1.k8s.emberstack.com/reflection-auto-namespaces: "monitoring"
type: kubernetes.io/basic-auth
stringData:
  username: analytics_user
  password: <SECURE_PASSWORD>

---
# Database
apiVersion: postgresql.cnpg.io/v1
kind: Database
metadata:
  name: postgres-single-analytics
  namespace: database
spec:
  cluster:
    name: postgres-single
  name: analytics
  owner: analytics_user
  databaseReclaimPolicy: retain
  extensions:
    - name: pg_stat_statements
```

### Cluster with Managed Roles

Update `postgres-single-node.yaml` to include all roles:

```yaml
apiVersion: postgresql.cnpg.io/v1
kind: Cluster
metadata:
  name: postgres-single
  namespace: database
spec:
  instances: 1
  imageName: ghcr.io/cloudnative-pg/postgresql:16.4
  
  storage:
    size: 20Gi
    storageClass: local-path
  
  resources:
    requests:
      memory: "512Mi"
      cpu: "500m"
    limits:
      memory: "2Gi"
      cpu: "2000m"
  
  managed:
    roles:
      # Web application role
      - name: webapp_user
        ensure: present
        login: true
        connectionLimit: 50
        passwordSecret:
          name: postgres-single-webapp-user
        inRoles:
          - app
      
      # Payments service role
      - name: payments_user
        ensure: present
        login: true
        connectionLimit: 30
        passwordSecret:
          name: postgres-single-payments-user
        inRoles:
          - app
      
      # Analytics role (read-only)
      - name: analytics_user
        ensure: present
        login: true
        connectionLimit: 10
        passwordSecret:
          name: postgres-single-analytics-user
        inRoles:
          - app
  
  bootstrap:
    initdb:
      database: app
      owner: app
      postInitApplicationSQL:
        - CREATE EXTENSION IF NOT EXISTS pg_stat_statements
        - CREATE EXTENSION IF NOT EXISTS pgcrypto
  
  postgresql:
    parameters:
      max_connections: "200"
      shared_buffers: "512MB"
      effective_cache_size: "1536MB"
      maintenance_work_mem: "128MB"
      checkpoint_completion_target: "0.9"
      wal_buffers: "16MB"
      default_statistics_target: "100"
      random_page_cost: "1.1"
      effective_io_concurrency: "200"
      work_mem: "2621kB"
      huge_pages: "off"
      min_wal_size: "1GB"
      max_wal_size: "4GB"
```

## Automation Workflow

### 1. New Application Onboarding

```bash
# 1. Generate secure password
PASSWORD=$(openssl rand -base64 32)

# 2. Create secret
cat <<EOF | kubectl apply -f -
apiVersion: v1
kind: Secret
metadata:
  name: postgres-single-newapp-user
  namespace: database
  annotations:
    reflector.v1.k8s.emberstack.com/reflection-allowed: "true"
    reflector.v1.k8s.emberstack.com/reflection-auto-enabled: "true"
    reflector.v1.k8s.emberstack.com/reflection-auto-namespaces: "development"
type: kubernetes.io/basic-auth
stringData:
  username: newapp_user
  password: $PASSWORD
EOF

# 3. Add role to cluster (edit postgres-single-node.yaml)
# managed:
#   roles:
#     - name: newapp_user
#       ensure: present
#       login: true
#       connectionLimit: 20
#       passwordSecret:
#         name: postgres-single-newapp-user

# 4. Create database
cat <<EOF | kubectl apply -f -
apiVersion: postgresql.cnpg.io/v1
kind: Database
metadata:
  name: postgres-single-newapp
  namespace: database
spec:
  cluster:
    name: postgres-single
  name: newapp
  owner: newapp_user
  databaseReclaimPolicy: retain
EOF

# 5. Verify
kubectl get database -n database
kubectl wait --for=condition=Ready database/postgres-single-newapp -n database --timeout=60s
```

### 2. Application Decommissioning

```bash
# Option A: Retain database (default, manual cleanup)
kubectl delete database postgres-single-oldapp -n database

# Option B: Auto-delete database (if databaseReclaimPolicy: delete)
kubectl delete database postgres-single-oldapp -n database
# Database automatically removed from PostgreSQL

# 3. Remove role from cluster manifest
# Edit postgres-single-node.yaml and remove the role entry

# 4. Clean up secrets
kubectl delete secret postgres-single-oldapp-user -n database
```

## Monitoring & Operations

### Check Database Status

```bash
# List all databases
kubectl get databases -n database

# Check specific database
kubectl describe database postgres-single-myapp -n database

# View reconciliation status
kubectl get database postgres-single-myapp -n database -o jsonpath='{.status}'
```

### Verify PostgreSQL State

```bash
# Port-forward
kubectl port-forward -n database svc/postgres-single-rw 5432:5432 &

# List databases
PGPASSWORD=$(kubectl get secret postgres-single-superuser -n database -o jsonpath='{.data.password}' | base64 -d)
psql -h localhost -U postgres -d postgres -c "\l"

# List roles
psql -h localhost -U postgres -d postgres -c "\du"

# Check database ownership
psql -h localhost -U postgres -d postgres -c "SELECT datname, datdba::regrole FROM pg_database WHERE datname NOT IN ('template0', 'template1', 'postgres');"
```

### Troubleshooting

```bash
# Check Database CRD events
kubectl describe database postgres-single-myapp -n database

# Check CloudNativePG operator logs
kubectl logs -n database -l app.kubernetes.io/name=cloudnative-pg --tail=100

# Check PostgreSQL logs
kubectl logs -n database postgres-single-1 -c postgres --tail=50

# Verify role exists
kubectl get cluster postgres-single -n database -o jsonpath='{.spec.managed.roles}' | jq
```

## Migration from Existing PostgreSQL

If you have existing databases to migrate:

1. **Dump existing database**:
   ```bash
   pg_dump -h old-server -U user -d olddb -F c -f olddb.dump
   ```

2. **Create Database CRD** (without extensions initially)

3. **Create user and grant ownership**:
   ```sql
   CREATE ROLE newapp_user WITH LOGIN PASSWORD 'password';
   GRANT ALL PRIVILEGES ON DATABASE newapp TO newapp_user;
   ```

4. **Restore data**:
   ```bash
   pg_restore -h postgres-single-rw.database.svc.cluster.local -U postgres -d newapp --no-owner --role=newapp_user olddb.dump
   ```

5. **Update Database CRD** with extensions

## Security Considerations

1. **Password Management**:
   - Use external secret management (SOPS, Sealed Secrets, Vault)
   - Rotate passwords regularly
   - Never commit plaintext passwords to Git

2. **Network Policies**:
   ```yaml
   apiVersion: networking.k8s.io/v1
   kind: NetworkPolicy
   metadata:
     name: postgres-access
     namespace: database
   spec:
     podSelector:
       matchLabels:
         cnpg.io/cluster: postgres-single
     policyTypes:
       - Ingress
     ingress:
       - from:
           - namespaceSelector:
               matchLabels:
                 environment: development
           - namespaceSelector:
               matchLabels:
                 environment: production
         ports:
           - protocol: TCP
             port: 5432
   ```

3. **RBAC**:
   - Restrict Database CRD creation to platform teams
   - Applications should only receive connection credentials
   - Use least-privilege principle for PostgreSQL roles

4. **Audit Logging**:
   - Enable PostgreSQL audit logging
   - Monitor connection attempts
   - Track DDL changes via pg_stat_statements

## Backup & Recovery

### Backup Strategy

```yaml
# Add to postgres-single-node.yaml
spec:
  backup:
    barmanObjectStore:
      destinationPath: s3://postgres-backups/postgres-single
      s3Credentials:
        accessKeyId:
          name: backup-credentials
          key: ACCESS_KEY_ID
        secretAccessKey:
          name: backup-credentials
          key: ACCESS_SECRET_KEY
      wal:
        compression: gzip
        maxParallel: 2
    retentionPolicy: "30d"
```

### Point-in-Time Recovery (PITR)

All databases in the cluster are backed up together. Individual database recovery requires:

```yaml
apiVersion: postgresql.cnpg.io/v1
kind: Cluster
metadata:
  name: postgres-single-recovery
spec:
  instances: 1
  bootstrap:
    recovery:
      source: postgres-single
      recoveryTarget:
        targetTime: "2024-11-18 20:00:00"
```

Then extract the specific database you need.

## Performance Optimization

### Connection Pooling with PgBouncer

For high-connection applications:

```yaml
apiVersion: postgresql.cnpg.io/v1
kind: Pooler
metadata:
  name: postgres-single-pooler
  namespace: database
spec:
  cluster:
    name: postgres-single
  instances: 3
  type: rw  # or 'ro' for read-only
  pgbouncer:
    poolMode: transaction
    parameters:
      max_client_conn: "1000"
      default_pool_size: "25"
      reserve_pool_size: "5"
```

Applications connect to `postgres-single-pooler-rw` instead of `postgres-single-rw`.

### Resource Scaling

```bash
# Scale cluster resources (requires rolling update)
kubectl patch cluster postgres-single -n database --type=merge -p '
spec:
  resources:
    requests:
      memory: "1Gi"
      cpu: "1000m"
    limits:
      memory: "4Gi"
      cpu: "4000m"
'
```

## Summary

This centralized PostgreSQL approach provides:

✅ **Single instance management** - One cluster, multiple databases  
✅ **Application isolation** - Dedicated databases and users  
✅ **Declarative lifecycle** - GitOps-friendly Database CRDs  
✅ **Automated provisioning** - Self-service database creation  
✅ **Security** - No superuser access for applications  
✅ **Cost efficiency** - Shared infrastructure, isolated data  
✅ **Scalability** - Easy to add new applications  

## Next Steps

1. Review and apply the complete example
2. Set up secret management (SOPS/Sealed Secrets)
3. Configure backup strategy
4. Implement monitoring (Prometheus/Grafana)
5. Create automated onboarding scripts
6. Document application connection patterns
