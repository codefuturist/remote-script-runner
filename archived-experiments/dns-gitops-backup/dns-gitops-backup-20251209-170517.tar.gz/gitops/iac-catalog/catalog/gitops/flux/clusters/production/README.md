# Production Cluster Configuration

This directory contains the complete GitOps configuration for the production Kubernetes cluster using FluxCD.

## 🏗️ Architecture

The production cluster follows a **layered architecture** with clear separation of concerns:

```
Production Cluster
├── Infrastructure Layer  → Platform components (network, security, storage, monitoring)
├── Governance Layer      → Policies, quotas, tenant management
├── Configuration Layer   → Cluster configs, certificates, backup schedules
└── Application Layer     → Business applications (organized by tier)
```

## 📂 Directory Structure

```
clusters/production/
├── flux-system/           # FluxCD controllers and Kustomization CRDs
│   ├── gotk-*.yaml       # Flux components (managed by bootstrap)
│   ├── infrastructure-*.yaml  # Granular infrastructure Kustomizations
│   ├── apps-kustomization.yaml
│   ├── policies-kustomization.yaml
│   └── tenants-kustomization.yaml
│
├── infrastructure/        # Platform components (deployed in order)
│   ├── sources/          # Helm/Git/OCI repositories (foundation)
│   ├── namespaces/       # Infrastructure namespaces
│   ├── configs/          # Cluster-wide configurations
│   ├── network/          # Ingress, DNS, cert-manager, MetalLB
│   ├── security/         # CrowdSec, RBAC, external-secrets
│   ├── storage/          # OpenEBS, storage classes, snapshots
│   ├── utility/          # Reflector, helper tools
│   ├── monitoring/       # Prometheus, Grafana, Gatus
│   ├── logging/          # Loki, Alloy
│   ├── database/         # PostgreSQL operators
│   └── backup/           # Velero backup solution
│
├── apps/                  # Application deployments (tier-based)
│   ├── namespaces/       # App namespace definitions
│   ├── backend/          # API services (n8n, mattermost, paperless-ngx)
│   ├── frontend/         # User-facing apps (homepage, mealie, compass-web)
│   ├── data/             # Database tools (phpmyadmin, redisinsight)
│   └── jobs/             # Batch jobs and scheduled tasks
│
├── tenants/               # Multi-tenant namespaces with RBAC
│   ├── team-platform/    # Platform team resources
│   ├── team-operations/  # Operations team resources
│   └── team-dev/         # Development team resources
│
├── policies/              # Governance and security policies
│   ├── security-policies/    # Pod security standards
│   ├── resource-quotas/      # Namespace resource limits
│   └── network-policies/     # Pod communication rules
│
├── patches/               # Production-specific overlays
│   ├── increase-replicas.yaml    # HA configurations
│   ├── resource-limits.yaml      # Production resource constraints
│   └── affinity-rules.yaml       # Pod distribution rules
│
├── notifications.yaml     # Alert routing (Slack, PagerDuty)
└── kustomization.yaml    # Root orchestrator (minimal)
```

## 🚀 Deployment Order

FluxCD deploys resources in the following order (managed by Kustomization CRDs):

### 1. **Bootstrap** (Manual)
```bash
flux bootstrap github \
  --owner=your-org \
  --repository=iac-catalog \
  --branch=main \
  --path=catalog/gitops/flux/clusters/production \
  --personal
```

### 2. **Infrastructure Layer** (Automated)
```
sources → namespaces → configs
    ↓
network (ingress, DNS, cert-manager)
    ↓
security (CrowdSec, RBAC)
    ↓
storage (OpenEBS)
    ↓
utility (reflector)
    ↓
monitoring (Prometheus, Grafana)
    ↓
logging (Loki)
    ↓
database (PostgreSQL operators)
    ↓
backup (Velero)
```

### 3. **Governance Layer**
- Policies (security, quotas, network)
- Tenants (team namespaces with RBAC)

### 4. **Configuration Overlays**
- Namespace configurations
- Certificate configurations
- Backup schedules

### 5. **Application Layer**
- Backend services
- Frontend applications
- Data tools
- Batch jobs

## 🔧 Key Features

### High Availability
- **3+ replicas** for critical components
- **Pod anti-affinity** for node distribution
- **PodDisruptionBudgets** to maintain availability
- **Automated rollbacks** on deployment failures

### Security
- **Pod Security Standards** enforced via namespace labels
- **Network Policies** restrict pod-to-pod communication
- **RBAC** with least-privilege access
- **CrowdSec** for intrusion detection
- **SOPS** for GitOps-native secret encryption

### Observability
- **Prometheus** for metrics collection
- **Grafana** for visualization
- **Loki** for log aggregation
- **Gatus** for service health monitoring
- **ServiceMonitors** for automatic metric discovery

### Disaster Recovery
- **Velero** for cluster backups
- **Volume snapshots** for persistent data
- **SOPS-encrypted** backup credentials
- **Off-site backup** storage (MinIO)

### Resource Management
- **ResourceQuotas** per namespace
- **LimitRanges** for default limits
- **Production patches** for resource constraints
- **Autoscaling** where appropriate

## 📊 Monitoring & Alerts

### Alert Routing

| Severity | Channel | Response |
|----------|---------|----------|
| Critical Infrastructure | PagerDuty + Slack | Immediate on-call response |
| Infrastructure Errors | Slack Critical | Team notification |
| App Deployments | Slack General | Info tracking |
| App Failures | Slack Critical | Team investigation |
| Git Sync Issues | Slack Critical | Immediate fix required |

### Metrics & Dashboards

Access Grafana at: `https://grafana.your-domain.com`

Key dashboards:
- Flux reconciliation status
- Resource utilization
- Application health
- Network traffic
- Storage usage

## 🔐 Secret Management

Secrets are encrypted using **SOPS** with **age** encryption:

```bash
# Create age key (one-time setup)
age-keygen -o age.agekey

# Add to cluster
cat age.agekey | kubectl create secret generic sops-age \
  --namespace=flux-system \
  --from-file=age.agekey=/dev/stdin

# Encrypt secret
sops --encrypt --age $(cat age.agekey | grep public | cut -d' ' -f4) \
  secret.yaml > secret.enc.yaml
```

## 🛠️ Common Operations

### Check Flux Status
```bash
flux get all
flux get kustomizations
flux get helmreleases --all-namespaces
```

### Force Reconciliation
```bash
flux reconcile source git flux-system
flux reconcile kustomization infrastructure-network
flux reconcile helmrelease ingress-nginx -n flux-system
```

### Suspend/Resume Resources
```bash
flux suspend kustomization apps
flux resume kustomization apps
```

### View Logs
```bash
flux logs --follow --all-namespaces
kubectl logs -n flux-system deploy/kustomize-controller
```

### Debug Failed Reconciliation
```bash
flux get kustomization infrastructure-network
kubectl describe kustomization infrastructure-network -n flux-system
```

## 📈 Scaling Guidelines

### Adding a New Application

1. **Choose the appropriate tier**: backend, frontend, data, or jobs
2. **Create app directory**: `apps/<tier>/<app-name>/`
3. **Add HelmRelease or manifests**
4. **Update tier kustomization.yaml**
5. **Add monitoring** (ServiceMonitor)
6. **Document** in tier README

### Expanding Infrastructure

1. **Create component directory** in `infrastructure/<layer>/`
2. **Add HelmRelease or Kustomization**
3. **Update layer kustomization.yaml**
4. **Update dependencies** in flux-system Kustomization CRD
5. **Test in staging** first

## 🔄 Migration Strategy

The cluster is currently migrating to the tiered app structure:

- **Phase 1**: ✅ Create tier directories (backend, frontend, data, jobs)
- **Phase 2**: ✅ Reference existing apps from tier kustomizations
- **Phase 3**: 🔄 Gradually move app directories into tiers
- **Phase 4**: 📅 Remove flat structure references

During transition, apps use relative paths (`../../app-name`) from tier directories.

## 📚 References

- [FluxCD Documentation](https://fluxcd.io/flux/)
- [Kustomize Documentation](https://kustomize.io/)
- [Kubernetes Best Practices](https://kubernetes.io/docs/concepts/configuration/overview/)
- [GitOps Principles](https://opengitops.dev/)

## 🆘 Troubleshooting

### Kustomization Stuck
```bash
flux suspend kustomization <name>
flux resume kustomization <name>
```

### Secret Decryption Failed
```bash
# Verify SOPS age secret exists
kubectl get secret sops-age -n flux-system

# Recreate if needed
cat age.agekey | kubectl create secret generic sops-age \
  --namespace=flux-system \
  --from-file=age.agekey=/dev/stdin
```

### Resource Conflicts
```bash
# Force prune resources
flux reconcile kustomization <name> --with-source
```

### Performance Issues
- Check resource utilization: `kubectl top nodes`
- Review resource quotas: `kubectl get resourcequotas -A`
- Suspend non-critical apps to free resources

## 🤝 Contributing

When making changes:

1. **Test in staging** first
2. **Follow Git Flow** branching strategy
3. **Run validation**: `make flux-validate`
4. **Document changes** in relevant READMEs
5. **Monitor deployment** after merge

---

**Cluster Status**: Production
**FluxCD Version**: v2.x
**Kubernetes Version**: v1.28+
**Last Updated**: 2024-12-09

