# Backend Services
- Monitor resource usage to prevent OOM kills
- Consider enabling PodDisruptionBudgets for critical services
- Backend services typically require database connections

## Deployment Notes

None currently

## Suspended Applications

- **Access**: Public via ingress with OIDC
- **Dependencies**: Database (PostgreSQL), Redis
- **Resources**: Moderate
- **Description**: Document scanning and organization
### Paperless-NGX - Document Management

- **Access**: Internal only
- **Dependencies**: SMTP server
- **Resources**: Minimal
- **Description**: Converts notification services to email
### Mailrise - Email Bridge

- **Access**: Public via ingress with SSO
- **Dependencies**: Database (PostgreSQL)
- **Resources**: Moderate
- **Description**: Open-source Slack alternative
### Mattermost - Team Communication

- **Access**: Internal via ingress
- **Dependencies**: Database (PostgreSQL)
- **Resources**: Minimal (workflow engine)
- **Description**: Low-code workflow automation platform
### n8n - Workflow Automation

## Active Applications

Backend tier applications provide API services, business logic, and integrations.


