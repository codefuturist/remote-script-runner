# n8n Workflow Automation

n8n is a free and open fair-code licensed workflow automation tool. This deployment uses the [8gears Helm chart](https://github.com/8gears/n8n-helm-chart).

## Architecture

- **Single instance** deployment for minimal resource usage
- **PostgreSQL** backend (CloudNative PG operator)
- **Traefik** ingress with rate limiting
- **Persistent storage** for binary execution data

## Resource Configuration

| Resource | Request | Limit | Notes |
|----------|---------|-------|-------|
| CPU | 50m | 1000m | Bursts to 1 CPU when available |
| Memory | 256Mi | 1024Mi | Bursts to 1Gi when available |
| Storage | 5Gi | - | For execution binary data |

## Prerequisites

1. **PostgreSQL cluster** - `postgres-single` must be running in the `database` namespace
2. **Reflector** - For secret synchronization across namespaces
3. **Traefik** - Ingress controller with rate limiting middleware

## Configuration Required

### 1. Generate Secrets

Before deploying, generate secure values for:

```bash
# Database password
openssl rand -base64 24

# n8n encryption key (for credential storage)
openssl rand -hex 32
```

### 2. Update Secrets with SOPS

Replace the `PLACEHOLDER_CHANGE_ME` values in:

- `n8n-database.yaml` - Database user password
- `n8n-helmrelease.yaml` - Database password and encryption key

Then encrypt with SOPS:

```bash
sops -e -i n8n-database.yaml
sops -e -i n8n-helmrelease.yaml
```

## Access

- **URL**: `http://n8n.production.local`
- **First Setup**: Create admin account on first access

## Scaling (Optional)

For high availability, enable queue mode in `n8n-helmrelease.yaml`:

```yaml
scaling:
  enabled: true
  worker:
    replicaCount: 2
  webhook:
    replicaCount: 1

valkey:
  enabled: true
```

This requires additional Redis/Valkey resources.

## Monitoring

Health endpoints:
- `/healthz` - Kubernetes health checks
- `/metrics` - Prometheus metrics (if enabled)

## Troubleshooting

### Check pod status
```bash
kubectl get pods -n n8n
kubectl logs -n n8n deployment/n8n
```

### Check database connectivity
```bash
kubectl exec -n n8n deployment/n8n -- \
  env | grep -i database
```

### Verify HelmRelease
```bash
flux get helmrelease n8n -n n8n
```
