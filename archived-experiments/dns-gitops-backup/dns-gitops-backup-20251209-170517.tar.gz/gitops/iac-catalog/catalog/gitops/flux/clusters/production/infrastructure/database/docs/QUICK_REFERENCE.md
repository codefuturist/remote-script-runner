# Quick Reference: Centralized PostgreSQL Database Management

## Quick Commands

### Create New Application Database

```bash
# Automated (recommended)
cd templates/
./onboard-app.sh myapp myapp myapp_user "development,staging"

# Manual
kubectl apply -f templates/app-database-template.yaml  # After editing
```

### Check Database Status

```bash
# List all databases
kubectl get databases -n database

# Check specific database
kubectl describe database postgres-single-myapp -n database

# View all application databases
kubectl get databases -n database -l '!cnpg.io/cluster'
```

### Get Database Credentials

```bash
# Get username
kubectl get secret postgres-single-myapp-user -n database -o jsonpath='{.data.username}' | base64 -d

# Get password
kubectl get secret postgres-single-myapp-user -n database -o jsonpath='{.data.password}' | base64 -d

# Get full connection string
echo "postgresql://$(kubectl get secret postgres-single-myapp-user -n database -o jsonpath='{.data.username}' | base64 -d):$(kubectl get secret postgres-single-myapp-user -n database -o jsonpath='{.data.password}' | base64 -d)@postgres-single-rw.database.svc.cluster.local:5432/myapp"
```

### Connect to Database

```bash
# Port-forward
kubectl port-forward -n database svc/postgres-single-rw 5432:5432 &

# Connect as application user
PGPASSWORD=$(kubectl get secret postgres-single-myapp-user -n database -o jsonpath='{.data.password}' | base64 -d)
USERNAME=$(kubectl get secret postgres-single-myapp-user -n database -o jsonpath='{.data.username}' | base64 -d)
psql -h localhost -U $USERNAME -d myapp

# Connect as superuser
PGPASSWORD=$(kubectl get secret postgres-single-superuser -n database -o jsonpath='{.data.password}' | base64 -d)
psql -h localhost -U postgres
```

### Verify PostgreSQL State

```bash
# List all databases
psql -h localhost -U postgres -c "\l"

# List all roles
psql -h localhost -U postgres -c "\du"

# Check database ownership
psql -h localhost -U postgres -c "SELECT datname, datdba::regrole AS owner FROM pg_database WHERE datname NOT IN ('template0', 'template1', 'postgres');"

# Check extensions
psql -h localhost -U postgres -d myapp -c "\dx"
```

### Delete Application Database

```bash
# Option 1: Retain database in PostgreSQL (default)
kubectl delete database postgres-single-myapp -n database
# Database remains in PostgreSQL for manual cleanup

# Option 2: Auto-delete from PostgreSQL (if databaseReclaimPolicy: delete)
kubectl delete database postgres-single-myapp -n database
# Database automatically dropped from PostgreSQL

# Clean up secrets
kubectl delete secret postgres-single-myapp-user -n database
```

### Troubleshooting

```bash
# Check Database CRD status
kubectl describe database postgres-single-myapp -n database

# Check operator logs
kubectl logs -n database -l app.kubernetes.io/name=cloudnative-pg --tail=100 -f

# Check PostgreSQL logs
kubectl logs -n database postgres-single-1 -c postgres --tail=50

# Check cluster status
kubectl get cluster postgres-single -n database

# Verify role exists in cluster
kubectl get cluster postgres-single -n database -o jsonpath='{.spec.managed.roles[?(@.name=="myapp_user")]}'
```

## Connection String Formats

### Standard Format

```
postgresql://username:password@host:port/database
```

### With SSL (Production)

```
postgresql://username:password@host:port/database?sslmode=require
```

### For Kubernetes Applications

```yaml
env:
- name: DATABASE_URL
  value: "postgresql://$(DB_USER):$(DB_PASSWORD)@postgres-single-rw.database.svc.cluster.local:5432/myapp"
- name: DB_USER
  valueFrom:
    secretKeyRef:
      name: postgres-single-myapp-user
      key: username
- name: DB_PASSWORD
  valueFrom:
    secretKeyRef:
      name: postgres-single-myapp-user
      key: password
```

## Database CRD Fields

### Required Fields

```yaml
spec:
  cluster:
    name: postgres-single  # Target cluster
  name: myapp              # Database name in PostgreSQL
  owner: myapp_user        # Database owner role
```

### Common Optional Fields

```yaml
spec:
  databaseReclaimPolicy: retain  # or 'delete'
  encoding: UTF8
  locale: en_US.UTF-8
  connectionLimit: 50
  
  extensions:
    - name: pgcrypto
    - name: uuid-ossp
  
  schemas:
    - name: public
      owner: myapp_user
```

## Role Management

### Add Role to Cluster

Edit `postgres-single-node.yaml`:

```yaml
spec:
  managed:
    roles:
      - name: myapp_user
        ensure: present
        login: true
        connectionLimit: 50
        passwordSecret:
          name: postgres-single-myapp-user
        inRoles:
          - app
```

### Role Attributes

```yaml
- name: myapp_user
  ensure: present          # or 'absent'
  login: true              # Allow login
  superuser: false         # Default: false
  createdb: false          # Default: false
  createrole: false        # Default: false
  inherit: true            # Default: true (inherit parent role permissions)
  replication: false       # Default: false
  bypassrls: false         # Default: false (bypass row-level security)
  connectionLimit: 50      # Default: -1 (unlimited)
  passwordSecret:
    name: postgres-single-myapp-user
  inRoles:
    - app                  # Membership in other roles
```

## Secret Annotations for Reflector

```yaml
metadata:
  annotations:
    # Allow reflection
    reflector.v1.k8s.emberstack.com/reflection-allowed: "true"
    
    # Auto-reflect to namespaces
    reflector.v1.k8s.emberstack.com/reflection-auto-enabled: "true"
    reflector.v1.k8s.emberstack.com/reflection-auto-namespaces: "development,staging,production"
    
    # Or allow specific namespaces to pull
    reflector.v1.k8s.emberstack.com/reflection-allowed-namespaces: "development,staging"
```

## PostgreSQL Services

| Service | Purpose | Use Case |
|---------|---------|----------|
| `postgres-single-rw` | Read-write | Primary for writes and consistent reads |
| `postgres-single-ro` | Read-only replicas | Read-heavy workloads (future: with replicas) |
| `postgres-single-r` | Load-balanced reads | Distributed read queries (future: with replicas) |

## Common Extensions

```yaml
extensions:
  # Cryptographic functions
  - name: pgcrypto
  
  # UUID generation
  - name: uuid-ossp
  
  # Key-value store
  - name: hstore
  
  # Full-text search
  - name: pg_trgm
  
  # JSON functions
  - name: btree_gin
  - name: btree_gist
  
  # Geographic data (requires PostGIS image)
  - name: postgis
  - name: postgis_topology
```

## Useful PostgreSQL Queries

```sql
-- List all databases
SELECT datname, pg_size_pretty(pg_database_size(datname)) AS size
FROM pg_database
WHERE datistemplate = false
ORDER BY pg_database_size(datname) DESC;

-- List all roles
SELECT rolname, rolsuper, rolcreatedb, rolcanlogin
FROM pg_roles
WHERE rolname NOT LIKE 'pg_%'
ORDER BY rolname;

-- Check active connections
SELECT datname, usename, count(*) AS connections
FROM pg_stat_activity
WHERE datname IS NOT NULL
GROUP BY datname, usename
ORDER BY connections DESC;

-- Check database ownership
SELECT d.datname AS database,
       r.rolname AS owner
FROM pg_database d
JOIN pg_roles r ON d.datdba = r.oid
WHERE d.datistemplate = false;

-- Check table sizes in current database
SELECT schemaname,
       tablename,
       pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) AS size
FROM pg_tables
WHERE schemaname NOT IN ('pg_catalog', 'information_schema')
ORDER BY pg_total_relation_size(schemaname||'.'||tablename) DESC
LIMIT 20;
```

## File Locations

- **Guide**: `centralized-postgres-guide.md`
- **Templates**: `templates/`
  - `app-database-template.yaml` - YAML template
  - `onboard-app.sh` - Automated onboarding script
- **Examples**: `examples/`
  - `cluster-with-roles.yaml` - Complete cluster configuration
  - `webapp-database.yaml` - Web app example
  - `payments-database.yaml` - Payment service example
  - `analytics-database.yaml` - Analytics example

## Best Practices Checklist

- [ ] Use descriptive database and role names
- [ ] Generate secure passwords (`openssl rand -base64 32`)
- [ ] Store secrets in external secret management (SOPS/Vault)
- [ ] Set appropriate connection limits per application
- [ ] Use `retain` reclaim policy for production databases
- [ ] Enable Reflector annotations for cross-namespace access
- [ ] Document database ownership and purpose
- [ ] Configure backups for production
- [ ] Monitor database size and connections
- [ ] Rotate passwords regularly
- [ ] Use read-only service for analytics workloads
- [ ] Test database connections before deploying applications

## Emergency Procedures

### Database Not Creating

```bash
# 1. Check Database CRD status
kubectl describe database postgres-single-myapp -n database

# 2. Check if role exists
kubectl get cluster postgres-single -n database -o yaml | grep -A 5 "name: myapp_user"

# 3. Check operator logs
kubectl logs -n database -l app.kubernetes.io/name=cloudnative-pg --tail=100

# 4. Check PostgreSQL logs
kubectl logs -n database postgres-single-1 -c postgres --tail=50
```

### Cannot Connect to Database

```bash
# 1. Verify service exists
kubectl get svc -n database postgres-single-rw

# 2. Verify credentials
kubectl get secret postgres-single-myapp-user -n database

# 3. Test from within cluster
kubectl run -it --rm psql-test --image=postgres:16 --restart=Never -- \
  psql -h postgres-single-rw.database.svc.cluster.local -U myapp_user -d myapp

# 4. Check connection limits
psql -h localhost -U postgres -c "SELECT rolname, rolconnlimit FROM pg_roles WHERE rolname = 'myapp_user';"
```

### Database Full

```bash
# 1. Check database sizes
psql -h localhost -U postgres -c "SELECT datname, pg_size_pretty(pg_database_size(datname)) FROM pg_database;"

# 2. Scale storage (if supported by storage class)
kubectl patch cluster postgres-single -n database --type=merge -p '{"spec":{"storage":{"size":"40Gi"}}}'

# 3. Clean up old data (application-specific)
```

## Support & Documentation

- CloudNativePG Docs: https://cloudnative-pg.io/
- Database CRD API: See `centralized-postgres-guide.md`
- Examples: See `examples/` directory
- Troubleshooting: Check operator and PostgreSQL logs
