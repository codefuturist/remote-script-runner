# Harbor - Cloud Native Container Registry

Harbor is an open source container image registry that secures images with role-based access control, scans images for vulnerabilities, and signs images as trusted.

## Configuration

| Setting | Value |
|---------|-------|
| **URL** | https://harbor.pandia.io |
| **Chart** | harbor/harbor v1.16.x |
| **Database** | External PostgreSQL (CloudNativePG) |
| **Redis** | Internal |
| **Storage** | OpenEBS hostpath (50Gi registry) |

## OIDC Authentication

Harbor supports OIDC authentication via Authentik. After deployment, configure in Harbor admin:

1. Go to **Administration > Configuration > Authentication**
2. Set **Auth Mode** to `OIDC`
3. Configure:
   - **OIDC Provider Name**: `Authentik`
   - **OIDC Endpoint**: `https://authentik.pandia.io/application/o/harbor/`
   - **OIDC Client ID**: (from secret)
   - **OIDC Client Secret**: (from secret)
   - **OIDC Scope**: `openid,profile,email,groups`
   - **Verify Certificate**: `true`
   - **Automatic Onboard**: `true`
   - **User Claim**: `preferred_username`
   - **Group Claim**: `groups`
   - **Admin Group**: `harbor-admins`

### Authentik Configuration

Create OAuth2/OpenID Provider in Authentik:
- **Application slug**: `harbor`
- **Redirect URI**: `https://harbor.pandia.io/c/oidc/callback`
- **Scopes**: `openid`, `email`, `profile`, `groups`

## Post-Deployment Steps

1. **Change admin password** via Harbor UI
2. **Configure OIDC** (see above)
3. **Create projects** for your container images
4. **Configure robot accounts** for CI/CD pipelines
5. **Set up replication** if needed

## Docker Login

```bash
docker login harbor.pandia.io
```

## Pushing Images

```bash
docker tag myimage:latest harbor.pandia.io/library/myimage:latest
docker push harbor.pandia.io/library/myimage:latest
```

## Resources

| Component | CPU Request | Memory Request | CPU Limit | Memory Limit |
|-----------|-------------|----------------|-----------|--------------|
| Portal | 10m | 64Mi | 200m | 256Mi |
| Core | 25m | 128Mi | 500m | 512Mi |
| Registry | 25m | 128Mi | 500m | 512Mi |
| Jobservice | 10m | 64Mi | 300m | 256Mi |
| Trivy | 50m | 256Mi | 1000m | 1Gi |
| Redis | 10m | 32Mi | 200m | 128Mi |
| Exporter | 10m | 32Mi | 100m | 64Mi |

## Secrets Required

Before deployment, update these secrets with actual values:

1. `harbor-secret.yaml`:
   - `HARBOR_ADMIN_PASSWORD`
   - `secretKey` (16 characters)

2. `harbor-database.yaml`:
   - Database user password

3. `harbor-oidc-secret.yaml`:
   - OIDC client ID and secret from Authentik
