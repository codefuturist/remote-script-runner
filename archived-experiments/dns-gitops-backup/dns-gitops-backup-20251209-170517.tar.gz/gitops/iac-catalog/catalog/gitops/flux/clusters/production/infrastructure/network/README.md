# Network Infrastructure Layer

This directory consolidates all network-related infrastructure components following GitOps best practices.

## Components

### 1. **Ingress Controllers**
- **Traefik** - Primary ingress with advanced routing and middlewares
- **NGINX** - Alternative ingress controller for specific use cases
- **Middlewares** - Traffic management, rate limiting, authentication

### 2. **Certificate Management**
- **cert-manager** - Automated TLS certificate provisioning
- **Let's Encrypt** integration for public certificates
- **Internal CA** support for private certificates

### 3. **DNS Management**
- **external-dns** - Automatic DNS record synchronization
- Integrates with Cloudflare, Route53, and other providers

### 4. **Load Balancing**
- **MetalLB** - Load balancer for bare metal clusters
- Assigns external IPs to LoadBalancer services

## Deployment Order

The network layer follows this dependency chain:

```
MetalLB (IP allocation)
    ↓
cert-manager (TLS certificates)
    ↓
Ingress Controllers (Traefik/NGINX)
    ↓
external-dns (DNS records)
    ↓
Middlewares (Traffic policies)
```

## Configuration

All network components are configured via:
- **HelmReleases** for chart-based deployments
- **Kustomizations** for manifest overlays
- **SOPS-encrypted secrets** for sensitive data

## High Availability

Production network layer ensures:
- **3+ replicas** for ingress controllers
- **Pod anti-affinity** for node distribution
- **PodDisruptionBudgets** to maintain availability
- **Health checks** for automatic failover

## Monitoring

Network components expose metrics for:
- Request rates and latencies
- Error rates and status codes
- Certificate expiration
- DNS query performance

## References

- [Traefik Documentation](https://doc.traefik.io/traefik/)
- [cert-manager Documentation](https://cert-manager.io/docs/)
- [external-dns Documentation](https://github.com/kubernetes-sigs/external-dns)
- [MetalLB Documentation](https://metallb.universe.tf/)

