# Production FluxCD Replicas & Resource Configuration

## Overview

All HelmReleases in production are configured with **minimal replicas (1 by default)** and conservative resource requests, following Kubernetes best practices for resource-constrained environments.

This configuration ensures:
- **Cost efficiency**: Single instances reduce resource consumption
- **Reliability**: Conservative resource requests prevent pod eviction
- **Flexibility**: Overlay patches allow scaling for high-availability when needed
- **Consistency**: Tier-based approach ensures uniformity across deployments

## Current Configuration Status

### Infrastructure Components (21 files)
✅ **All updated with replicas=1**

- **Ingress**: Traefik (public + internal) - `deployment.replicas: 1`
- **Cert-Manager**: Controller, Webhook, CAInjector - `replicaCount: 1`
- **Monitoring**: Prometheus - `replicas: 1`, Alertmanager - `replicas: 1`, Gatus - `deployment.replicas: 1`, Loki - `gateway.replicas: 1`
- **Security**: CrowdSec LAPI - `replicas: 1`, Traefik Bouncer - `replicaCount: 1`
- **Other**: Velero (auto), OpenEBS, Metallb, kube-vip, snapshot-controller, reflector, alloy, graylog

### Application Components (11 files)
✅ **All configured with replicaCount: 1**

- Homepage, Homarr, N8N, Mattermost, Gitea, PicoShare, Mealie, PhopmyAdmin
- ERPNext (nginx: 1, worker: 1)
- WordPress (colins-blog, rey-it-solutions): 1
- Test deployments (Redis, PostgreSQL): 1

## Resource Tiers

### Tier 1 - Lightweight (50m CPU / 128Mi Memory)
**For**: Utility services, simple monitoring, exporters
- **Requests**: 50m CPU, 128Mi memory
- **Limits**: 500m CPU, 256Mi memory
- **Examples**: Gatus, Reflector, Bouncer

### Tier 2 - Standard (100m CPU / 256Mi Memory)
**For**: Most applications, mid-weight infrastructure
- **Requests**: 100m CPU, 256Mi memory
- **Limits**: 500m-1000m CPU, 512Mi memory
- **Examples**: Mealie, Homepage, Alloy, cert-manager

### Tier 3 - Heavy (200m+ CPU / 512Mi+ Memory)
**For**: Large applications, complex infrastructure
- **Requests**: 200-500m CPU, 512Mi-1Gi memory
- **Limits**: 1-2Gi memory, 1-2 CPUs
- **Examples**: ERPNext, N8N, Prometheus, Graylog, Loki, Mattermost

## Scaling for High-Availability

To increase replicas for production HA, create kustomize strategic merge patches in the production overlay.

### Example Patches

#### 1. Increase Traefik Replicas (infrastructure/ingress-ha.yaml)
```yaml
apiVersion: helm.toolkit.fluxcd.io/v2
kind: HelmRelease
metadata:
  name: traefik-public
spec:
  values:
    deployment:
      replicas: 3  # HA configuration
    autoscaling:
      enabled: true
      minReplicas: 3
      maxReplicas: 10
```

#### 2. Increase Prometheus Replicas (infrastructure/monitoring-ha.yaml)
```yaml
apiVersion: helm.toolkit.fluxcd.io/v2
kind: HelmRelease
metadata:
  name: prometheus-stack
spec:
  values:
    prometheus:
      prometheusSpec:
        replicas: 3  # HA with 3 instances
        retention: 30d  # Longer retention for distributed setup
        storageSpec:
          volumeClaimTemplate:
            spec:
              storageClassName: openebs-hostpath
              accessModes: ["ReadWriteOnce"]
              resources:
                requests:
                  storage: 100Gi
```

#### 3. Increase Cert-Manager Replicas (infrastructure/cert-manager-ha.yaml)
```yaml
apiVersion: helm.toolkit.fluxcd.io/v2
kind: HelmRelease
metadata:
  name: cert-manager
spec:
  values:
    replicaCount: 3
    webhook:
      replicaCount: 3
    cainjector:
      replicaCount: 3
    podDisruptionBudget:
      enabled: true
      minAvailable: 2
```

#### 4. Increase Application Replicas (apps/application-ha.yaml)
```yaml
apiVersion: helm.toolkit.fluxcd.io/v2
kind: HelmRelease
metadata:
  name: n8n
spec:
  values:
    main:
      replicaCount: 2  # At least 2 for HA with persistent storage
      resources:
        requests:
          cpu: 200m
          memory: 512Mi
        limits:
          cpu: 1000m
          memory: 1Gi
```

## Deployment Locations

### Infrastructure Components
- Base configs: `catalog/gitops/flux/clusters/production/infrastructure/`
- Each service has dedicated subdirectory (e.g., `ingress/`, `monitoring/`, `logging/`)

### Application Components
- Base configs: `catalog/gitops/flux/clusters/production/apps/`
- Grouped by function (e.g., `ci-cd/`, `web/`, `database/`)

## To Scale to HA

1. **Create overlay patch file** in production cluster directory
2. **Add reference** to production kustomization.yaml
3. **Test in staging** first (if available)
4. **Update PodDisruptionBudgets** for critical services
5. **Monitor resource utilization** after scaling

## Best Practices Followed

✅ **Default to 1 Replica**
- Minimizes resource usage
- Perfect for single-node or resource-constrained clusters
- Easily scalable via overlays

✅ **Conservative Resource Requests**
- Requests represent guaranteed resources
- Set to ~10-50% of limits
- Allows oversubscription with safeguards

✅ **Reasonable Resource Limits**
- Prevent runaway consumption
- Allow short-term bursts when cluster has capacity
- Tier-based approach maintains consistency

✅ **Proper Health Checks**
- All deployments have readiness/liveness probes
- Configured with appropriate timeouts
- Restart policy set for reliability

✅ **GitOps-Ready**
- Changes tracked in version control
- Reproducible via Flux reconciliation
- Overlay-based customization for different environments

## Monitoring & Validation

### Check Replica Status
```bash
kubectl get deployments -A -o wide | grep -v "1/1"
kubectl get statefulsets -A -o wide | grep -v "1/1"
```

### Monitor Resources
```bash
kubectl top nodes
kubectl top pods -A --sort-by=memory
```

### Verify Configuration
```bash
flux get helmrelease -A
kubectl describe hr <name> -n <namespace>
```

## Resources

- [Kubernetes Resource Management](https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/)
- [Pod Disruption Budgets](https://kubernetes.io/docs/concepts/workloads/pods/disruptions/)
- [Replica Configuration Best Practices](https://kubernetes.io/docs/concepts/workloads/controllers/deployment/#replicas)
- [Helm Values Best Practices](https://helm.sh/docs/developing_charts/#values)
