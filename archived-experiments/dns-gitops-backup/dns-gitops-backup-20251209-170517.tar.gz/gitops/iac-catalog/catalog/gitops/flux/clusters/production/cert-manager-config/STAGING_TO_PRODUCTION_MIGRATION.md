# Let's Encrypt Staging to Production Migration Guide

## Overview

This guide explains how to migrate from Let's Encrypt staging certificates to production certificates in the staging cluster.

## Current Configuration

The staging cluster is currently configured to use **Let's Encrypt STAGING** certificates. These certificates:

- ✅ Have high rate limits (30,000 per week per IP)
- ✅ Perfect for testing cert-manager integration
- ✅ Validate DNS challenges and ACME flow
- ❌ Not trusted by browsers (will show security warnings)
- ❌ Cannot be used for production traffic

## Certificate Status

### Staging Certificates (Current)

| Domain | Certificate Name | Secret Name | Issuer |
|--------|-----------------|-------------|--------|
| *.colinrey.ch | colinrey-ch-staging | colinrey.ch-tls-staging | letsencrypt-staging |
| *.colinrey.com | colinrey-com-staging | colinrey.com-tls-staging | letsencrypt-staging |
| *.pandia.io | pandia-io-staging | pandia.io-tls-staging | letsencrypt-staging |
| *.reyitsolutions.ch | reyitsolutions-ch-staging | reyitsolutions.ch-tls-staging | letsencrypt-staging |
| *.reyitsolutions.com | reyitsolutions-com-staging | reyitsolutions.com-tls-staging | letsencrypt-staging |

## Migration Steps

### Step 1: Verify Staging Certificates Work

First, ensure all staging certificates are successfully issued:

```bash
# Check certificate status
kubectl get certificates -n cert-manager

# Check certificate details
kubectl describe certificate colinrey-ch-staging -n cert-manager

# Check for certificate issuance errors
kubectl get certificaterequests -n cert-manager
kubectl logs -n cert-manager -l app=cert-manager
```

Expected output:
```
NAME                        READY   SECRET                        AGE
colinrey-ch-staging         True    colinrey.ch-tls-staging       1m
colinrey-com-staging        True    colinrey.com-tls-staging      1m
pandia-io-staging           True    pandia.io-tls-staging         1m
reyitsolutions-ch-staging   True    reyitsolutions.ch-tls-staging 1m
reyitsolutions-com-staging  True    reyitsolutions.com-tls-staging 1m
```

### Step 2: Test Certificate with Sample Application

Create a test ingress to verify the certificate works:

```yaml
# test-ingress.yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: test-staging-cert
  namespace: cert-manager
  annotations:
    cert-manager.io/cluster-issuer: letsencrypt-staging
spec:
  ingressClassName: traefik
  tls:
  - hosts:
    - test.colinrey.ch
    secretName: colinrey.ch-tls-staging
  rules:
  - host: test.colinrey.ch
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: test-service
            port:
              number: 80
```

Apply and test:
```bash
kubectl apply -f test-ingress.yaml
curl -k https://test.colinrey.ch  # -k flag ignores cert warning for staging
```

### Step 3: Migrate to Production Certificates

Once staging certificates work correctly, migrate to production:

**Option A: Switch Existing Certificates (Recommended for Staging Cluster)**

Update each certificate to use the production issuer:

```bash
# Edit the cert-manager-extras.yaml file
# Change all references from:
#   name: letsencrypt-staging
# To:
#   name: letsencrypt-production
#
# And update secret names from:
#   secretName: colinrey.ch-tls-staging
# To:
#   secretName: colinrey.ch-tls-production
```

**Option B: Create Separate Production Certificates**

Keep staging certificates and add production ones side-by-side:

```yaml
---
# Production Certificate - colinrey.ch
apiVersion: cert-manager.io/v1
kind: Certificate
metadata:
  name: colinrey-ch-production
  namespace: cert-manager
spec:
  commonName: '*.colinrey.ch'
  dnsNames:
    - colinrey.ch
    - '*.colinrey.ch'
  issuerRef:
    kind: ClusterIssuer
    name: letsencrypt-production
  renewBefore: 720h
  secretName: colinrey.ch-tls-production
  privateKey:
    algorithm: ECDSA
    encoding: PKCS8
    size: 384
    rotationPolicy: Always
  secretTemplate:
    annotations:
      reflector.v1.k8s.emberstack.com/reflection-allowed: 'true'
      reflector.v1.k8s.emberstack.com/reflection-auto-enabled: 'true'
      reflector.v1.k8s.emberstack.com/reflection-auto-namespaces: "cert-manager,flux-system,ingress,monitoring,staging-apps"
```

### Step 4: Update Ingress Resources

Update all ingress resources to use the new production certificates:

```bash
# Find all ingresses using staging certificates
kubectl get ingress -A -o yaml | grep "tls-staging"

# Update each ingress to use production certificates
# Change secretName from "*-tls-staging" to "*-tls-production"
```

### Step 5: Verify Production Certificates

```bash
# Check production certificate status
kubectl get certificates -n cert-manager | grep production

# Verify certificate details
kubectl describe certificate colinrey-ch-production -n cert-manager

# Test with curl (should not need -k flag)
curl https://test.colinrey.ch
```

### Step 6: Clean Up Staging Certificates (Optional)

Once production certificates are working:

```bash
# Delete staging certificates
kubectl delete certificate colinrey-ch-staging -n cert-manager
kubectl delete certificate colinrey-com-staging -n cert-manager
kubectl delete certificate pandia-io-staging -n cert-manager
kubectl delete certificate reyitsolutions-ch-staging -n cert-manager
kubectl delete certificate reyitsolutions-com-staging -n cert-manager

# Delete staging secrets
kubectl delete secret colinrey.ch-tls-staging -n cert-manager
kubectl delete secret colinrey.com-tls-staging -n cert-manager
kubectl delete secret pandia.io-tls-staging -n cert-manager
kubectl delete secret reyitsolutions.ch-tls-staging -n cert-manager
kubectl delete secret reyitsolutions.com-tls-staging -n cert-manager
```

## Rate Limits

### Let's Encrypt Staging
- **30,000 certificates** per week per IP address
- No other significant limits
- Perfect for testing

### Let's Encrypt Production
- **50 certificates** per week per registered domain
- **5 duplicate certificates** per week
- **300 new orders** per account per 3 hours
- Be careful when testing!

## Troubleshooting

### Certificate Stuck in "Pending" State

```bash
# Check certificate request status
kubectl get certificaterequest -n cert-manager

# Check cert-manager logs
kubectl logs -n cert-manager deployment/cert-manager -f

# Check certificate events
kubectl describe certificate <cert-name> -n cert-manager
```

### DNS Challenge Fails

```bash
# Verify Cloudflare token secret exists
kubectl get secret cloudflare-token-secret -n cert-manager

# Check DNS records
dig TXT _acme-challenge.colinrey.ch

# Verify Cloudflare API token has permissions:
# - Zone:DNS:Edit
# - Zone:Zone:Read
```

### Rate Limit Exceeded

If you hit Let's Encrypt production rate limits:

1. Switch back to staging temporarily
2. Wait for the rate limit window to expire (typically 1 week)
3. Test thoroughly with staging before retrying production

## Reference

- [Let's Encrypt Rate Limits](https://letsencrypt.org/docs/rate-limits/)
- [cert-manager Documentation](https://cert-manager.io/docs/)
- [Cloudflare API Token Docs](https://developers.cloudflare.com/fundamentals/api/get-started/create-token/)

## Quick Commands

```bash
# Watch certificate status
watch kubectl get certificates -n cert-manager

# Follow cert-manager logs
kubectl logs -n cert-manager deployment/cert-manager -f

# Check all secrets
kubectl get secrets -n cert-manager | grep tls

# Describe all certificates
kubectl get certificates -n cert-manager -o wide

# Force certificate renewal
kubectl delete secret <secret-name> -n cert-manager
# cert-manager will automatically recreate it
```
