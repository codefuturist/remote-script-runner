# PostgreSQL vs MariaDB: Migration and Coexistence Strategy

## Overview

This guide covers running both CloudNativePG (PostgreSQL) and MariaDB Operator side-by-side, along with strategies for migrating applications between them.

## Coexistence Architecture

Both operators can run simultaneously in the same cluster without conflicts:

```
Namespace: database
├── CloudNativePG Operator
│   └── postgres-single cluster
│       ├── Service: postgres-single-rw.database:5432
│       └── Databases: mealie, testapp, etc.
│
└── MariaDB Operator
    └── mariadb-single cluster
        ├── Service: mariadb-single-primary.database:3306
        └── Databases: wordpress, nextcloud, etc.
```

### Why Run Both?

**Use PostgreSQL (CloudNativePG) for:**
- Applications requiring PostgreSQL-specific features
- Advanced data types (JSONB, Arrays, hstore)
- Full-text search capabilities
- PostGIS for geospatial data
- Complex queries and analytics
- Example apps: Mealie, Gitea, Mastodon, Authentik

**Use MariaDB for:**
- WordPress, Drupal, Joomla (LAMP stack)
- Legacy MySQL applications
- Replication-heavy workloads
- Applications requiring MyISAM or Galera
- Example apps: WordPress, Nextcloud, Matomo, phpBB

## Database Selection Decision Matrix

| Feature | PostgreSQL | MariaDB |
|---------|-----------|---------|
| **ACID Compliance** | ✅ Full | ✅ Full (InnoDB) |
| **JSON Support** | ✅ JSONB (binary) | ⚠️ JSON (text) |
| **Full-text Search** | ✅ Native | ⚠️ Limited |
| **Replication** | ⚠️ Streaming | ✅ Galera/Multi-master |
| **Window Functions** | ✅ Advanced | ✅ Basic |
| **WordPress Compatibility** | ⚠️ Via plugin | ✅ Native |
| **Geospatial (GIS)** | ✅ PostGIS | ⚠️ Spatial |
| **Connection Pooling** | ✅ PgBouncer | ✅ ProxySQL |
| **Read Replicas** | ✅ Native | ✅ Native |

## Migration Strategies

### 1. New Application Decision

**When creating a new application:**

```bash
# Decision flowchart
Is it WordPress/LAMP stack? → Use MariaDB
Does it require PostgreSQL features? → Use PostgreSQL
Is it database-agnostic? → Choose based on team expertise
```

### 2. Migrating FROM PostgreSQL TO MariaDB

**Suitable candidates:**
- WordPress (if started with PostgreSQL via plugin)
- Simple CRUD applications without PostgreSQL-specific features
- Applications with MySQL/MariaDB drivers available

**Migration steps:**

1. **Export PostgreSQL data**
```bash
kubectl exec -n database postgres-single-1 -- \
  pg_dump -U postgres -d myapp --no-owner --no-privileges > dump.sql
```

2. **Convert schema** (handle differences):
```sql
# PostgreSQL → MariaDB conversions
SERIAL → AUTO_INCREMENT
BOOLEAN → TINYINT(1)
TEXT → TEXT or LONGTEXT
BYTEA → BLOB
ARRAY → JSON or separate table
JSONB → JSON
TIMESTAMP WITH TIME ZONE → DATETIME
```

3. **Create MariaDB resources**
```bash
./templates/onboard-mariadb-app.sh myapp myapp_db
```

4. **Import data**
```bash
mysql -h mariadb-single-primary.database -u myapp_user -p myapp_db < converted_dump.sql
```

5. **Update application configuration**
```yaml
# Before (PostgreSQL)
DB_HOST: postgres-single-rw.database.svc.cluster.local
DB_PORT: "5432"

# After (MariaDB)
DB_HOST: mariadb-single-primary.database.svc.cluster.local
DB_PORT: "3306"
```

### 3. Migrating FROM MariaDB TO PostgreSQL

**Suitable candidates:**
- Applications needing JSONB or advanced PostgreSQL features
- Microservices requiring better JSON handling
- Analytics applications

**Migration tools:**
- `pgloader` - Automated migration tool
- Manual SQL conversion
- Application-level migration (read from MariaDB, write to PostgreSQL)

**pgloader example:**
```lisp
LOAD DATABASE
  FROM mysql://user:pass@mariadb-single-primary.database:3306/myapp
  INTO postgresql://postgres:pass@postgres-single-rw.database:5432/myapp
  WITH include drop, create tables, create indexes, reset sequences
  SET work_mem to '256MB', maintenance_work_mem to '512MB';
```

## Application Compatibility

### WordPress
```yaml
# Native MariaDB support (recommended)
mariaDbRef:
  name: mariadb-single

# PostgreSQL support requires plugin (not recommended)
# Use MariaDB instead
```

### Nextcloud
```yaml
# Supports both - choose based on scale
# MariaDB: < 1000 users
# PostgreSQL: > 1000 users or advanced features
```

### Gitea
```yaml
# Prefers PostgreSQL
# Better performance with PostgreSQL
clusterRef:
  name: postgres-single
```

### Mealie
```yaml
# Designed for PostgreSQL
# Uses PostgreSQL-specific features
clusterRef:
  name: postgres-single
```

## Connection String Formats

### PostgreSQL Connection
```yaml
env:
  - name: DATABASE_URL
    value: "postgresql://user:pass@postgres-single-rw.database:5432/dbname"
  
  # Or separate variables
  - name: DB_HOST
    value: "postgres-single-rw.database.svc.cluster.local"
  - name: DB_PORT
    value: "5432"
  - name: DB_NAME
    value: "myapp"
```

### MariaDB Connection
```yaml
env:
  - name: DATABASE_URL
    value: "mysql://user:pass@mariadb-single-primary.database:3306/dbname"
  
  # Or separate variables
  - name: DB_HOST
    value: "mariadb-single-primary.database.svc.cluster.local"
  - name: DB_PORT
    value: "3306"
  - name: DB_NAME
    value: "myapp"
```

## Data Type Compatibility

| PostgreSQL | MariaDB | Notes |
|-----------|---------|-------|
| `SERIAL` | `AUTO_INCREMENT` | Auto-incrementing integers |
| `BOOLEAN` | `TINYINT(1)` | 0/1 in MariaDB |
| `TEXT` | `TEXT`, `LONGTEXT` | Size limits differ |
| `VARCHAR(n)` | `VARCHAR(n)` | Compatible |
| `INTEGER` | `INT` | Compatible |
| `BIGINT` | `BIGINT` | Compatible |
| `DECIMAL` | `DECIMAL` | Compatible |
| `TIMESTAMP` | `DATETIME` | Timezone handling differs |
| `JSONB` | `JSON` | PostgreSQL is binary, MariaDB is text |
| `ARRAY` | ❌ | No native support in MariaDB |
| `UUID` | `CHAR(36)` | Store as string in MariaDB |
| `BYTEA` | `BLOB` | Binary data |
| `ENUM` | `ENUM` | Compatible but PostgreSQL more flexible |

## Performance Considerations

### Read-Heavy Workloads
- **PostgreSQL**: Use read replicas (future CloudNativePG feature)
- **MariaDB**: Use Galera cluster with multiple readers

### Write-Heavy Workloads
- **PostgreSQL**: Better write performance, less locking
- **MariaDB**: Consider InnoDB tuning, connection pooling

### Connection Pooling
- **PostgreSQL**: Deploy PgBouncer
- **MariaDB**: Deploy ProxySQL

## Backup Strategy

### PostgreSQL Backups
```yaml
# CloudNativePG handles backups natively
backup:
  barmanObjectStore:
    destinationPath: s3://backups/postgres/
    s3Credentials:
      accessKeyId:
        name: backup-creds
        key: access-key
```

### MariaDB Backups
```yaml
# MariaDB Operator backup configuration
apiVersion: k8s.mariadb.com/v1alpha1
kind: Backup
metadata:
  name: mariadb-backup
spec:
  mariaDbRef:
    name: mariadb-single
  schedule:
    cron: "0 2 * * *"
  storage:
    s3:
      bucket: backups
      prefix: mariadb/
```

## Cost and Resource Planning

### Single Cluster (Current)
```
PostgreSQL: 2Gi memory, 2 CPU
MariaDB: 2Gi memory, 2 CPU
Total: 4Gi memory, 4 CPU
```

### Considerations
- Run both if applications require specific database features
- Consolidate to one if all apps are compatible
- Consider managed databases for production (RDS, CloudSQL)

## Monitoring Both Systems

### Prometheus Metrics
```yaml
# Both operators expose metrics
- postgres-single-primary:9187 (postgres_exporter)
- mariadb-single-primary:9104 (mysqld_exporter)
```

### Grafana Dashboards
- CloudNativePG Dashboard (ID: 20417)
- MariaDB Dashboard (ID: 7362)

## Best Practices

1. **Keep operators updated**: Both projects are actively developed
2. **Use appropriate database**: Match database to application needs
3. **Consistent naming**: Use clear prefixes (postgres-*, mariadb-*)
4. **Backup both systems**: Different tools, same schedule
5. **Monitor resources**: Track usage trends to optimize
6. **Document decisions**: Record why each app uses which database
7. **Test migrations**: Always test in staging first

## Troubleshooting

### Application Can't Connect
```bash
# PostgreSQL
kubectl exec -n database postgres-single-1 -- psql -U postgres -c "SELECT * FROM pg_stat_activity;"

# MariaDB
kubectl exec -n database mariadb-single-0 -- mysql -u root -p -e "SHOW PROCESSLIST;"
```

### Wrong Database Type Used
```bash
# Check application logs for driver errors
kubectl logs -n app-namespace deployment/myapp

# Common errors:
# "driver does not support this function" → Wrong DB type
# "relation does not exist" → PostgreSQL syntax in MariaDB
# "unknown column type" → MariaDB syntax in PostgreSQL
```

## Future Considerations

### Moving to Managed Databases
When ready for production:
- **AWS**: RDS for PostgreSQL or MariaDB
- **GCP**: Cloud SQL for PostgreSQL or MySQL
- **Azure**: Azure Database for PostgreSQL or MySQL

Both operators support external database management, allowing smooth transition to managed services.
