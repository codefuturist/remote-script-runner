#!/usr/bin/env bash
set -euo pipefail

# Script to generate secure passwords and encrypt web app database secrets
# Usage: ./encrypt-web-secrets.sh

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
AGE_KEY="age1t8gm5avm9z5pquta4w2kaud7zn3c588mkk2shdpdskvp76wxh3gsxctyst"

echo "🔐 Generating secure passwords and encrypting web app secrets..."
echo

# Generate secure passwords (32 characters)
generate_password() {
    </dev/random LC_ALL=C tr -dc '[:graph:]' | head -c32
}

# Function to encrypt a file with SOPS
encrypt_file() {
    local file="$1"
    echo "  Encrypting: $file"
    sops --encrypt \
        --age "${AGE_KEY}" \
        --encrypted-regex '^(data|stringData)$' \
        --in-place "${file}"
}

# Colin's Blog
echo "📝 Colin's Blog:"
COLINS_BLOG_PASSWORD=$(generate_password)
echo "  Generated password for wp_colins_blog_user"

COLINS_BLOG_FILE="${SCRIPT_DIR}/colins-blog/colins-blog-database.yaml"
sed -i.bak "s/PLACEHOLDER_GENERATE_SECURE_PASSWORD_32_CHARS/${COLINS_BLOG_PASSWORD}/g" "${COLINS_BLOG_FILE}"
rm -f "${COLINS_BLOG_FILE}.bak"
encrypt_file "${COLINS_BLOG_FILE}"
echo "  ✅ Colin's Blog database secret encrypted"
echo

# Rey IT Solutions
echo "🏢 Rey IT Solutions:"
REY_IT_PASSWORD=$(generate_password)
echo "  Generated password for wp_rey_it_user"

REY_IT_FILE="${SCRIPT_DIR}/rey-it-solutions/rey-it-solutions-database.yaml"
sed -i.bak "s/PLACEHOLDER_GENERATE_SECURE_PASSWORD_32_CHARS/${REY_IT_PASSWORD}/g" "${REY_IT_FILE}"
rm -f "${REY_IT_FILE}.bak"
encrypt_file "${REY_IT_FILE}"
echo "  ✅ Rey IT Solutions database secret encrypted"
echo

echo "✅ All web app secrets have been encrypted with SOPS!"
echo "📦 Database CRDs will create:"
echo "   - mariadb-single-colins-blog-user secret (reflected to web namespace)"
echo "   - mariadb-single-rey-it-user secret (reflected to web namespace)"
echo "   - Databases: wp_colins_blog, wp_rey_it"
echo "   - Users: wp_colins_blog_user, wp_rey_it_user"
echo "   - Grants: Full WordPress privileges"
echo
echo "🚀 Ready to commit and deploy!"
