# Security Infrastructure Layer

This directory contains security components that protect the cluster and applications.

## Active Components

### 1. **CrowdSec**
- **Purpose**: Intrusion detection and prevention system (IDS/IPS)
- **Features**:
  - Real-time threat detection
  - Collaborative security intelligence
  - Integration with Traefik/NGINX
- **Location**: `crowdsec/`

### 2. **RBAC Policies**
- **Purpose**: Role-based access control for users and service accounts
- **Features**:
  - Cluster admin roles (minimal usage)
  - Namespace-scoped admin roles
  - View-only roles for developers
  - Flux reconciler service account
- **Location**: `rbac/`

## Optional Components

### 3. **External Secrets Operator** (Disabled)
- **Purpose**: Integrate with cloud secret managers
- **Backends**: AWS Secrets Manager, HashiCorp Vault, Azure Key Vault, GCP Secret Manager
- **Status**: Template provided, disabled by default
- **Current Alternative**: SOPS for GitOps-native secret encryption
- **Location**: `external-secrets/`
- **Enable**: Uncomment in `kustomization.yaml` and configure SecretStore resources

## Future Considerations

### Sealed Secrets
- Alternative to SOPS for secret encryption in Git
- One-way encryption using cluster-specific keys
- Requires backing up encryption keys

### OPA Gatekeeper
- Policy enforcement engine for Kubernetes
- Validates resources against policies before admission
- Use cases: Resource limits, naming conventions, security standards

### Falco
- Runtime security monitoring
- Detects abnormal behavior in containers
- Alerts on suspicious activity

## Security Best Practices

1. **Principle of Least Privilege**: Grant minimum necessary permissions
2. **Regular Audits**: Review RBAC bindings and access logs
3. **Secret Rotation**: Rotate credentials regularly
4. **Network Policies**: Restrict pod-to-pod communication (see `policies/network-policies/`)
5. **Pod Security Standards**: Enforce via namespace labels (see `policies/security-policies/`)
6. **Image Scanning**: Scan container images for vulnerabilities
7. **Admission Control**: Validate resources before deployment

## Monitoring & Alerts

Security components expose metrics and logs:
- **CrowdSec**: Decision logs, ban lists
- **RBAC**: Audit logs for access attempts
- **Admission Controllers**: Policy violations

Configure alerts in `notifications.yaml` for security events.

## References

- [CrowdSec Documentation](https://docs.crowdsec.net/)
- [Kubernetes RBAC](https://kubernetes.io/docs/reference/access-authn-authz/rbac/)
- [External Secrets Operator](https://external-secrets.io/)
- [Pod Security Standards](https://kubernetes.io/docs/concepts/security/pod-security-standards/)

