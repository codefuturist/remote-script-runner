# Database Clusters

This directory contains cluster definitions for PostgreSQL and MariaDB.

## PostgreSQL Clusters

**Location**: `postgresql/`

### postgres-single-node.yaml (Default)
- 1 instance
- 20Gi local-path storage
- Suitable for development/staging
- Resource requests: 500m CPU, 512Mi memory

### postgres-cluster-example.yaml
- Example 3-instance HA cluster
- Not deployed by default
- Use as template for production

## MariaDB Clusters

**Location**: `mariadb/`

### mariadb-single-node.yaml (Default)
- 1 replica
- 20Gi local-path storage
- Suitable for development/staging
- Resource requests: 500m CPU, 512Mi memory
- Includes metrics exporter

## Usage

Clusters are deployed via `kustomization.yaml`:

```yaml
resources:
  - clusters/postgresql/postgres-single-node.yaml
  - clusters/mariadb/mariadb-single-node.yaml
```

## Verification

```bash
# Check PostgreSQL cluster
kubectl get cluster -n database
kubectl get pods -n database -l cnpg.io/cluster=postgres-single

# Check MariaDB cluster
kubectl get mariadb -n database
kubectl get pods -n database -l app.kubernetes.io/instance=mariadb-single

# Check services
kubectl get svc -n database
```

## Switching to HA

For high availability configurations, see:
- `../ha-optional/mariadb-cluster-ha.yaml.optional`
- `../docs/HA-GUIDE.md`
