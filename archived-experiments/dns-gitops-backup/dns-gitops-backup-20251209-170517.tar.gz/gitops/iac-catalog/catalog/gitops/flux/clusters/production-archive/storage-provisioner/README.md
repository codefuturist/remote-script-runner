# Storage Provisioners

This directory contains storage provisioner configurations for the production cluster.

## Deployed Provisioners

### 1. NFS Client Provisioner
- **Storage Class**: `nfs-client`
- **Access Mode**: ReadWriteMany
- **Use Case**: Shared storage across multiple pods
- **Server**: nfs-client-provisioner-target-0.pandia.io

### 2. Local Path Provisioner
- **Storage Class**: `local-path`
- **Access Mode**: ReadWriteOnce
- **Use Case**: Fast local storage for single-node workloads
- **Storage Path**: `/opt/local-path-provisioner`

## Deployment

This directory is deployed via FluxCD Kustomization defined in `storage-provisioners.yaml` at the cluster level.

```bash
# Check deployment status
flux get kustomizations -n flux-system storage-provisioners

# Check HelmReleases
flux get helmreleases -n flux-system | grep provisioner

# Verify storage classes
kubectl get storageclass
```

## Configuration

### Local Path Provisioner

See `local-path-provisioner-examples.yaml` for various configuration examples including:
- Multiple paths per node
- Node-specific configurations
- Shared filesystem support
- Multiple storage classes
- Production settings with HA
- Security hardening

To customize, edit `local-path-provisioner.yaml` and commit changes.

### NFS Client Provisioner

Edit `nfs-client-provisioner.yaml` to modify NFS server settings, mount options, or storage class configuration.

## Storage Class Selection

Choose the appropriate storage class based on your workload:

| Storage Class | Access Mode | Performance | Use Case |
|--------------|-------------|-------------|----------|
| `local-path` | RWO | High | Databases, local caches |
| `nfs-client` | RWX | Medium | Shared files, multi-pod access |

## Usage Example

```yaml
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: my-storage
spec:
  accessModes:
    - ReadWriteOnce
  storageClassName: local-path  # or nfs-client
  resources:
    requests:
      storage: 10Gi
```

## Troubleshooting

### Local Path Provisioner
```bash
# Check provisioner logs
kubectl logs -n local-path-storage -l app=local-path-provisioner

# Verify storage path on nodes
kubectl get nodes
# SSH to node and check: ls -la /opt/local-path-provisioner
```

### NFS Client Provisioner
```bash
# Check provisioner logs
kubectl logs -n nfs-client-provisioner -l app=nfs-subdir-external-provisioner

# Test NFS mount
kubectl run -it --rm nfs-test --image=busybox --restart=Never -- mount -t nfs -o vers=4.2 nfs-client-provisioner-target-0.pandia.io:/mnt/pool-0/kubernetes/nfs-client-provisioner /mnt
```
