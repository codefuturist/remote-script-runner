# Data Layer Services

Data tier applications provide database management, caching, and data tools.

## Active Applications

### phpMyAdmin - MySQL/MariaDB Admin
- **Description**: Web-based database administration
- **Resources**: Minimal
- **Dependencies**: MySQL/MariaDB database
- **Access**: Internal via ingress

### RedisInsight - Redis GUI
- **Description**: Redis database visualization and management
- **Resources**: Minimal
- **Dependencies**: Redis instance
- **Access**: Internal via ingress

## Suspended Applications

### test-postgres - PostgreSQL Test Instance
- **Status**: Suspended
- **Reason**: Bitnami charts migrated to OCI-only distribution
- **Resolution**: Requires OCIRepository configuration

### test-redis - Redis Test Instance
- **Status**: Suspended
- **Reason**: Bitnami charts migrated to OCI-only distribution
- **Resolution**: Requires OCIRepository configuration

## Deployment Notes

- Data layer apps provide interfaces to underlying data stores
- These are typically internal-only tools
- Ensure proper RBAC/authentication before exposing externally
- Consider network policies to restrict database access
- Monitor connection pools and query performance

