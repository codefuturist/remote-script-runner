# Web Applications

This directory contains web application deployments managed by FluxCD.

## Applications

### Colin's Blog
- **URL**: https://blog.colinrey.ch
- **Database**: MariaDB (wp_colins_blog)
- **Chart**: Bitnami WordPress
- **Namespace**: web

### Rey IT Solutions
- **URL**: https://reyitsolutions.ch
- **Database**: MariaDB (wp_rey_it)
- **Chart**: Bitnami WordPress
- **Namespace**: web

## Structure

Each application follows the FluxCD best practices:

```
app-name/
├── kustomization.yaml          # Kustomize configuration
├── app-name-database.yaml      # MariaDB database, user, grants (with SOPS-encrypted password)
└── app-name-helmrelease.yaml   # Helm chart deployment
```

## Database Setup

All web apps use the centralized **MariaDB Operator** managed database cluster (`mariadb-single`) in the `database` namespace.

**Resources created:**
- `Database`: Creates isolated database in MariaDB cluster
- `User`: Creates dedicated user with secure password
- `Grant`: Assigns WordPress privileges to user
- `Secret`: Stores credentials (SOPS-encrypted, reflected to web namespace via Reflector)

## Secret Management

**Encryption**: SOPS with Age encryption
**Key**: `age1t8gm5avm9z5pquta4w2kaud7zn3c588mkk2shdpdskvp76wxh3gsxctyst`

### Generate and Encrypt Secrets

```bash
# Run the encryption script to generate passwords and encrypt
./encrypt-web-secrets.sh
```

This script:
1. Generates secure 32-character passwords
2. Updates database YAML files
3. Encrypts secrets with SOPS
4. Creates secrets in database namespace
5. Reflector mirrors secrets to web namespace

## Deployment

Applications are automatically deployed via FluxCD when changes are committed to git.

**Dependencies:**
- MariaDB Operator (infrastructure/database)
- MariaDB single-node cluster (infrastructure/database)
- Traefik ingress (infrastructure/ingress)
- cert-manager (infrastructure/cert-manager)
- Reflector (infrastructure/utility)

**Health checks:**
- Liveness: /wp-login.php (120s initial delay)
- Readiness: /wp-login.php (30s initial delay)

## Maintenance

### View Database Status
```bash
kubectl get databases -n database | grep "colins-blog\|rey-it"
kubectl get users -n database | grep "colins-blog\|rey-it"
kubectl get grants -n database | grep "colins-blog\|rey-it"
```

### View Secrets
```bash
# In database namespace (encrypted)
kubectl get secret mariadb-single-colins-blog-user -n database
kubectl get secret mariadb-single-rey-it-user -n database

# In web namespace (reflected)
kubectl get secret mariadb-single-colins-blog-user -n web
kubectl get secret mariadb-single-rey-it-user -n web
```

### Test Database Connection
```bash
# Get password
kubectl get secret mariadb-single-colins-blog-user -n database -o jsonpath='{.data.password}' | base64 -d

# Connect to database
kubectl exec -it mariadb-single-0 -n database -- mysql -u wp_colins_blog_user -p wp_colins_blog
```

### Update WordPress Version
Edit the `tag` in the helmrelease.yaml file, or use `latest` for auto-updates.

## Features

- **Auto-scaling**: Recreate strategy (single PVC)
- **Caching**: Memcached enabled
- **SSL/TLS**: cert-manager with Let's Encrypt
- **Monitoring**: Homepage integration
- **Backups**: MariaDB operator backup (if enabled)
- **Security**: SOPS-encrypted secrets, non-root containers

## Troubleshooting

### Application won't start
1. Check HelmRelease status: `kubectl get hr -n web`
2. Check pod logs: `kubectl logs -n web -l app.kubernetes.io/name=wordpress`
3. Check database connectivity: `kubectl exec -it <pod> -n web -- wp db check`

### Database connection failed
1. Verify secret exists: `kubectl get secret -n web | grep mariadb-single`
2. Check MariaDB cluster: `kubectl get mariadb -n database`
3. Test connection from pod: `kubectl exec -it <pod> -n web -- nc -zv mariadb-single-primary.database.svc.cluster.local 3306`

### Certificate issues
1. Check cert-manager logs: `kubectl logs -n cert-manager -l app=cert-manager`
2. Check certificate status: `kubectl get certificate -n web`
3. Verify ClusterIssuer: `kubectl get clusterissuer letsencrypt-production`
