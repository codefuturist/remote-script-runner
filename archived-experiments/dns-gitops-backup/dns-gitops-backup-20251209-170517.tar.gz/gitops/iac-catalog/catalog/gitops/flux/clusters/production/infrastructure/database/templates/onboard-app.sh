#!/bin/bash
set -e

# Automated Application Database Onboarding Script
# 
# This script automates the creation of a new application database
# in the centralized PostgreSQL cluster.
#
# Usage:
#   ./onboard-app.sh <app-name> <database-name> <username> [namespaces]
#
# Example:
#   ./onboard-app.sh myapp myapp myapp_user "development,staging"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Functions
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Validate arguments
if [ $# -lt 3 ]; then
    log_error "Usage: $0 <app-name> <database-name> <username> [namespaces]"
    log_error "Example: $0 myapp myapp myapp_user \"development,staging\""
    exit 1
fi

APP_NAME="$1"
DATABASE_NAME="$2"
USERNAME="$3"
NAMESPACES="${4:-development}"

CLUSTER_NAME="postgres-single"
NAMESPACE="database"
SECRET_NAME="${CLUSTER_NAME}-${APP_NAME}-user"
DATABASE_CRD_NAME="${CLUSTER_NAME}-${APP_NAME}"

log_info "Starting onboarding process for application: $APP_NAME"
log_info "  Database: $DATABASE_NAME"
log_info "  User: $USERNAME"
log_info "  Target namespaces: $NAMESPACES"

# Generate secure password
log_info "Generating secure password..."
PASSWORD=$(</dev/random LC_ALL=C tr -dc '[:graph:]' | head -c32)

# Check if secret already exists
if kubectl get secret "$SECRET_NAME" -n "$NAMESPACE" &> /dev/null; then
    log_warn "Secret $SECRET_NAME already exists in namespace $NAMESPACE"
    read -p "Do you want to update it? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        log_info "Skipping secret creation"
    else
        log_info "Updating secret..."
        kubectl delete secret "$SECRET_NAME" -n "$NAMESPACE"
    fi
fi

# Create secret if it doesn't exist or was deleted
if ! kubectl get secret "$SECRET_NAME" -n "$NAMESPACE" &> /dev/null; then
    log_info "Creating secret: $SECRET_NAME"
    cat <<EOF | kubectl apply -f -
apiVersion: v1
kind: Secret
metadata:
  name: $SECRET_NAME
  namespace: $NAMESPACE
  annotations:
    reflector.v1.k8s.emberstack.com/reflection-allowed: "true"
    reflector.v1.k8s.emberstack.com/reflection-auto-enabled: "true"
    reflector.v1.k8s.emberstack.com/reflection-auto-namespaces: "$NAMESPACES"
type: kubernetes.io/basic-auth
stringData:
  username: $USERNAME
  password: $PASSWORD
EOF
    log_info "✓ Secret created successfully"
else
    log_info "Secret already exists, retrieving password..."
    PASSWORD=$(kubectl get secret "$SECRET_NAME" -n "$NAMESPACE" -o jsonpath='{.data.password}' | base64 -d)
fi

# Save credentials to file (optional)
CREDS_FILE="./credentials-${APP_NAME}.txt"
cat > "$CREDS_FILE" <<EOF
Application: $APP_NAME
Database: $DATABASE_NAME
Username: $USERNAME
Password: $PASSWORD
Connection String: postgresql://$USERNAME:<password>@${CLUSTER_NAME}-rw.${NAMESPACE}.svc.cluster.local:5432/$DATABASE_NAME

IMPORTANT: Store this file securely and delete it after saving credentials to your password manager.
EOF
log_warn "Credentials saved to: $CREDS_FILE (DELETE AFTER USE)"

# Check if role exists in cluster
log_info "Checking if role exists in cluster manifest..."
if kubectl get cluster "$CLUSTER_NAME" -n "$NAMESPACE" -o yaml | grep -q "name: $USERNAME"; then
    log_info "✓ Role $USERNAME already exists in cluster manifest"
else
    log_warn "Role $USERNAME not found in cluster manifest"
    log_warn "You need to add this role to $CLUSTER_NAME cluster manifest:"
    echo ""
    cat <<EOF
  managed:
    roles:
      - name: $USERNAME
        ensure: present
        login: true
        connectionLimit: 50
        passwordSecret:
          name: $SECRET_NAME
        inRoles:
          - app
EOF
    echo ""
    read -p "Press Enter after adding the role to the cluster manifest..."
fi

# Create Database CRD
log_info "Creating Database CRD: $DATABASE_CRD_NAME"
cat <<EOF | kubectl apply -f -
apiVersion: postgresql.cnpg.io/v1
kind: Database
metadata:
  name: $DATABASE_CRD_NAME
  namespace: $NAMESPACE
spec:
  cluster:
    name: $CLUSTER_NAME
  name: $DATABASE_NAME
  owner: $USERNAME
  databaseReclaimPolicy: retain
  extensions:
    - name: pgcrypto
      ensure: present
EOF

# Wait for database to be ready
log_info "Waiting for database to be ready..."
if kubectl wait --for=condition=Ready database/"$DATABASE_CRD_NAME" -n "$NAMESPACE" --timeout=120s 2>/dev/null; then
    log_info "✓ Database created successfully"
else
    log_warn "Database creation is taking longer than expected"
    log_warn "Check status with: kubectl describe database $DATABASE_CRD_NAME -n $NAMESPACE"
fi

# Verify database
log_info "Verifying database status..."
kubectl get database "$DATABASE_CRD_NAME" -n "$NAMESPACE"

# Print connection information
echo ""
log_info "=== Database Onboarding Complete ==="
echo ""
echo "Database Name: $DATABASE_NAME"
echo "Owner: $USERNAME"
echo "Kubernetes Secret: $SECRET_NAME (namespace: $NAMESPACE)"
echo "Replicated to namespaces: $NAMESPACES"
echo ""
echo "Connection String:"
echo "  postgresql://$USERNAME:<password>@${CLUSTER_NAME}-rw.${NAMESPACE}.svc.cluster.local:5432/$DATABASE_NAME"
echo ""
echo "Environment Variables (for deployment):"
echo "  DATABASE_URL: postgresql://\$(DB_USER):\$(DB_PASSWORD)@${CLUSTER_NAME}-rw.${NAMESPACE}.svc.cluster.local:5432/$DATABASE_NAME"
echo "  DB_USER: (from secret $SECRET_NAME, key: username)"
echo "  DB_PASSWORD: (from secret $SECRET_NAME, key: password)"
echo ""
log_warn "Credentials file: $CREDS_FILE (DELETE AFTER STORING SECURELY)"
echo ""
log_info "Next steps:"
echo "  1. Verify database: kubectl get database $DATABASE_CRD_NAME -n $NAMESPACE"
echo "  2. Check logs: kubectl logs -n $NAMESPACE postgres-single-1 -c postgres --tail=50"
echo "  3. Test connection: kubectl port-forward -n $NAMESPACE svc/${CLUSTER_NAME}-rw 5432:5432"
echo "  4. Update application deployment with connection details"
echo ""
