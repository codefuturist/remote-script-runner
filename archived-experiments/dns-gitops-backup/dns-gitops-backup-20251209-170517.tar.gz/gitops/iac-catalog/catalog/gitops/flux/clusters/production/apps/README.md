# Production Applications - WordPress and TestApp

This directory contains FluxCD-managed applications for the production cluster.

## Applications

### WordPress (`wordpress/`)
- **Deployment**: 2 replicas for high availability
- **Storage**: 20Gi persistent volume
- **Database**: Connects to MariaDB in database namespace
- **Domain**: wordpress.pandia.io (production certificate)
- **Resources**: 200m-1000m CPU, 512Mi-1Gi memory

### TestApp (`testapp/`)
- **Purpose**: Database connectivity test application
- **Database**: Connects to PostgreSQL cluster
- **Namespace**: test-apps
- **Resources**: 50m-100m CPU, 64Mi-128Mi memory

## Secrets Management

### WordPress Database Secret

The WordPress database credentials are stored in `wordpress/wordpress-secret-template.yaml` as a template.

**Before deploying to production, you MUST:**

1. Update the secret with production values:
   ```bash
   cd catalog/gitops/flux/clusters/production/apps/wordpress
   
   # Edit the template with actual production credentials
   vim wordpress-secret-template.yaml
   ```

2. Encrypt the secret with SOPS:
   ```bash
   # Encrypt in-place (the file will be replaced with encrypted version)
   sops -e -i wordpress-secret-template.yaml
   
   # Or create a new encrypted file
   sops -e wordpress-secret-template.yaml > wordpress-secret.yaml
   ```

3. Rename to the final secret file:
   ```bash
   mv wordpress-secret-template.yaml wordpress-secret.yaml
   ```

4. Update the kustomization to use the encrypted secret:
   ```bash
   # Edit wordpress/kustomization.yaml
   # Add:
   # resources:
   #   - wordpress-deployment.yaml
   #   - wordpress-secret.yaml
   ```

### TestApp Secret

TestApp uses the PostgreSQL user secret created by CloudNativePG operator:
- Secret name: `postgres-single-testapp-user`
- Managed by: CloudNativePG operator
- No manual secret creation needed

## Deployment

These applications are deployed automatically by FluxCD when:
1. Changes are pushed to the git repository
2. The `apps` Kustomization in flux-system reconciles (every 10 minutes)

To deploy manually:
```bash
# Apply the apps Kustomization
kubectl apply -f ../apps-kustomization.yaml --context k3s-prod

# Force reconciliation
flux reconcile kustomization apps --context k3s-prod
```

## Prerequisites

Before deploying these applications, ensure:

1. **Namespaces exist**: `web`, `test-apps`
2. **Database backends are ready**:
   - MariaDB cluster in `database` namespace
   - PostgreSQL cluster in `database` namespace with testapp user
3. **Ingress controller is running**: Traefik
4. **Cert-manager is configured**: For TLS certificates
5. **Storage class available**: `local-path` or equivalent

## Verification

After deployment, verify the applications:

```bash
# Check deployments
kubectl get deployments -n web --context k3s-prod
kubectl get deployments -n test-apps --context k3s-prod

# Check pods
kubectl get pods -n web --context k3s-prod
kubectl get pods -n test-apps --context k3s-prod

# Check ingress
kubectl get ingress -n web --context k3s-prod

# Check logs
kubectl logs -n web -l app=wordpress --context k3s-prod
kubectl logs -n test-apps -l app=testapp --context k3s-prod
```

## Access

- **WordPress**: https://wordpress.pandia.io
- **TestApp**: Internal only (no ingress)

## Differences from Staging

| Component | Staging | Production |
|-----------|---------|------------|
| WordPress replicas | 1 | 2 |
| WordPress storage | 10Gi | 20Gi |
| WordPress CPU limit | 500m | 1000m |
| WordPress memory limit | 512Mi | 1Gi |
| Domain | wordpress.staging.example.com | wordpress.pandia.io |
| TLS Issuer | letsencrypt-staging | letsencrypt-production |
| Ingress Class | nginx | traefik |

## Migration from Staging

These manifests were migrated from manually applied resources in the staging cluster (k3s-develop) to ensure GitOps reproducibility in production.

Original staging resources were created via `kubectl apply` and have been converted to proper FluxCD-managed Kustomizations.
