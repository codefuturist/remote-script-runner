# Centralized MariaDB Database Management

## Architecture Overview

**Single MariaDB Cluster → Multiple Application Databases → Dedicated Users**

This guide demonstrates how to manage a centralized MariaDB instance with per-application isolation using MariaDB Operator's declarative database management.

## Key Features

✅ **Single MariaDB Instance** (`mariadb-single`)  
✅ **Multiple Isolated Databases** (one per application)  
✅ **Dedicated Application Users** (each owns their database)  
✅ **Declarative Management** (via Database, User, Grant CRDs)  
✅ **Automated Lifecycle** (create, update, delete)  
✅ **GitOps-Ready** (FluxCD reconciliation)

## Architecture Diagram

```
┌─────────────────────────────────────────────────────┐
│  MariaDB Cluster: mariadb-single                   │
│  ├─ Instance: mariadb-single-0 (11.4)              │
│  ├─ Storage: 20Gi (local-path)                     │
│  └─ Services:                                       │
│     ├─ mariadb-single-primary (read-write)         │
│     ├─ mariadb-single-secondary (read-only)        │
│     └─ mariadb-single (load-balanced)              │
└─────────────────────────────────────────────────────┘
                         │
        ┌────────────────┼────────────────┐
        │                │                │
        ▼                ▼                ▼
┌──────────────┐  ┌──────────────┐  ┌──────────────┐
│  App1 DB     │  │  App2 DB     │  │  App3 DB     │
│  Owner: app1 │  │  Owner: app2 │  │  Owner: app3 │
│  Database:   │  │  Database:   │  │  Database:   │
│  wordpress   │  │  nextcloud   │  │  gitea       │
└──────────────┘  └──────────────┘  └──────────────┘
```

## Best Practices

### 1. Database Isolation
- **One database per application**: Provides clear boundaries
- **Dedicated owner user**: Each app owns its database
- **Schema management**: Applications control their schemas
- **No root access**: Apps use regular MariaDB users

### 2. Naming Conventions
- **Database names**: Descriptive (e.g., `wordpress`, `nextcloud`, `gitea`)
- **User names**: Match database or use suffix (e.g., `wordpress_user`, `nextcloud_owner`)
- **Kubernetes resources**: Include cluster prefix (e.g., `mariadb-single-wordpress`)

### 3. Secret Management
- **Per-application secrets**: Each app gets dedicated credentials
- **Secret naming**: `mariadb-single-<database>-user` (e.g., `mariadb-single-wordpress-user`)
- **Auto-generated passwords**: Use MariaDB Operator's secret generation
- **Rotation**: Update secrets via User CRD

### 4. Connection Management
- **Use primary service**: For read-write workloads (`mariadb-single-primary`)
- **Use secondary service**: For read replicas (HA mode: `mariadb-single-secondary`)
- **Connection pooling**: Consider ProxySQL for high-connection apps
- **Service discovery**: Use Kubernetes DNS (`mariadb-single-primary.database.svc.cluster.local`)

### 5. Grant Management
- **Principle of least privilege**: Grant only necessary permissions
- **Host restrictions**: Use `%` for cluster-internal or specific IPs
- **Separate grants per privilege level**: Read-only vs read-write
- **Grant options**: Use `grantOption: true` sparingly

## Implementation Guide

### Step 1: Create Application User Secret

Each application needs credentials stored in a Kubernetes Secret:

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: mariadb-single-wordpress-user
  namespace: database
type: Opaque
stringData:
  username: wordpress_user
  password: <GENERATE_SECURE_PASSWORD>  # Use: openssl rand -base64 32
```

**Best Practice**: Use external secret management (e.g., Sealed Secrets, External Secrets Operator, SOPS)

### Step 2: Create Database CRD

```yaml
apiVersion: k8s.mariadb.com/v1alpha1
kind: Database
metadata:
  name: mariadb-single-wordpress  # Kubernetes resource name
  namespace: database
spec:
  mariaDbRef:
    name: mariadb-single  # Target MariaDB cluster
  
  # Database name in MariaDB
  name: wordpress
  
  # Character set configuration
  characterSet: utf8mb4
  collate: utf8mb4_unicode_ci
  
  # Cleanup policy
  cleanupPolicy: Skip  # or 'Delete' for auto-cleanup on CR deletion
  
  # Retry configuration
  retryInterval: 5s
```

**Key Differences from PostgreSQL**:
- `mariaDbRef` instead of `cluster.name`
- Character set and collation configuration
- No owner field (assigned via Grant CRD)
- `cleanupPolicy` instead of `databaseReclaimPolicy`

### Step 3: Create User CRD

```yaml
apiVersion: k8s.mariadb.com/v1alpha1
kind: User
metadata:
  name: mariadb-single-wordpress-user  # Kubernetes resource name
  namespace: database
spec:
  mariaDbRef:
    name: mariadb-single  # Target MariaDB cluster
  
  # User credentials
  name: wordpress_user  # MariaDB username
  passwordSecretKeyRef:
    name: mariadb-single-wordpress-user
    key: password
  
  # Connection limits
  maxUserConnections: 20
  
  # Host restriction
  host: "%"  # Allow from anywhere in cluster (use specific IPs for security)
  
  # Cleanup policy
  cleanupPolicy: Skip  # or 'Delete'
  
  # Retry configuration
  retryInterval: 5s
```

**Key Features**:
- Separate User CRD (unlike PostgreSQL's managed roles)
- Host-based access control
- Per-user connection limits
- Independent lifecycle from database

### Step 4: Create Grant CRD

```yaml
apiVersion: k8s.mariadb.com/v1alpha1
kind: Grant
metadata:
  name: mariadb-single-wordpress-grant  # Kubernetes resource name
  namespace: database
spec:
  mariaDbRef:
    name: mariadb-single  # Target MariaDB cluster
  
  # Grant target
  username: wordpress_user
  database: wordpress
  table: "*"  # All tables
  
  # Privileges
  privileges:
    - "SELECT"
    - "INSERT"
    - "UPDATE"
    - "DELETE"
    - "CREATE"
    - "DROP"
    - "INDEX"
    - "ALTER"
    - "CREATE TEMPORARY TABLES"
    - "LOCK TABLES"
    - "EXECUTE"
    - "CREATE VIEW"
    - "SHOW VIEW"
    - "CREATE ROUTINE"
    - "ALTER ROUTINE"
    - "TRIGGER"
  
  # Grant option (allows user to grant privileges to others)
  grantOption: false
  
  # Host restriction (must match User CRD)
  host: "%"
  
  # Cleanup policy
  cleanupPolicy: Skip
  
  # Retry configuration
  retryInterval: 5s
```

**Common Privilege Sets**:

```yaml
# Read-Only Access
privileges:
  - "SELECT"
  - "SHOW VIEW"

# Application Access (recommended)
privileges:
  - "SELECT"
  - "INSERT"
  - "UPDATE"
  - "DELETE"
  - "CREATE"
  - "DROP"
  - "INDEX"
  - "ALTER"
  - "CREATE TEMPORARY TABLES"
  - "LOCK TABLES"
  - "EXECUTE"
  - "CREATE VIEW"
  - "SHOW VIEW"
  - "CREATE ROUTINE"
  - "ALTER ROUTINE"
  - "TRIGGER"

# Full Access (use with caution)
privileges:
  - "ALL PRIVILEGES"
```

## Complete Application Example

### WordPress Deployment with Centralized MariaDB

#### 1. Create Secret for Credentials

```yaml
---
apiVersion: v1
kind: Secret
metadata:
  name: mariadb-single-wordpress-user
  namespace: database
type: Opaque
stringData:
  username: wordpress_user
  password: "wp_secure_password_here"  # Generate with: openssl rand -base64 32
```

#### 2. Create Database

```yaml
---
apiVersion: k8s.mariadb.com/v1alpha1
kind: Database
metadata:
  name: mariadb-single-wordpress
  namespace: database
  labels:
    app: wordpress
    database.pandia.io/cluster: mariadb-single
spec:
  mariaDbRef:
    name: mariadb-single
  name: wordpress
  characterSet: utf8mb4
  collate: utf8mb4_unicode_ci
  cleanupPolicy: Skip
```

#### 3. Create User

```yaml
---
apiVersion: k8s.mariadb.com/v1alpha1
kind: User
metadata:
  name: mariadb-single-wordpress-user
  namespace: database
  labels:
    app: wordpress
    database.pandia.io/cluster: mariadb-single
spec:
  mariaDbRef:
    name: mariadb-single
  name: wordpress_user
  passwordSecretKeyRef:
    name: mariadb-single-wordpress-user
    key: password
  maxUserConnections: 20
  host: "%"
  cleanupPolicy: Skip
```

#### 4. Create Grants

```yaml
---
apiVersion: k8s.mariadb.com/v1alpha1
kind: Grant
metadata:
  name: mariadb-single-wordpress-grant
  namespace: database
  labels:
    app: wordpress
    database.pandia.io/cluster: mariadb-single
spec:
  mariaDbRef:
    name: mariadb-single
  username: wordpress_user
  database: wordpress
  table: "*"
  privileges:
    - "ALL PRIVILEGES"
  grantOption: false
  host: "%"
  cleanupPolicy: Skip
```

#### 5. Deploy WordPress Application

```yaml
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: wordpress
  namespace: wordpress
spec:
  replicas: 1
  selector:
    matchLabels:
      app: wordpress
  template:
    metadata:
      labels:
        app: wordpress
    spec:
      containers:
        - name: wordpress
          image: wordpress:6.4-apache
          env:
            - name: WORDPRESS_DB_HOST
              value: mariadb-single-primary.database.svc.cluster.local:3306
            - name: WORDPRESS_DB_NAME
              value: wordpress
            - name: WORDPRESS_DB_USER
              valueFrom:
                secretKeyRef:
                  name: mariadb-single-wordpress-user
                  key: username
            - name: WORDPRESS_DB_PASSWORD
              valueFrom:
                secretKeyRef:
                  name: mariadb-single-wordpress-user
                  key: password
          ports:
            - containerPort: 80
          resources:
            requests:
              memory: 256Mi
              cpu: 100m
            limits:
              memory: 512Mi
              cpu: 500m
```

## Service Discovery Patterns

### Connection Strings

```bash
# Primary (Read-Write)
mariadb-single-primary.database.svc.cluster.local:3306

# Secondary (Read-Only, HA mode only)
mariadb-single-secondary.database.svc.cluster.local:3306

# Load Balanced (HA mode)
mariadb-single.database.svc.cluster.local:3306
```

### Application Environment Variables

```yaml
env:
  # Option 1: Separate components
  - name: DB_HOST
    value: mariadb-single-primary.database.svc.cluster.local
  - name: DB_PORT
    value: "3306"
  - name: DB_NAME
    value: wordpress
  - name: DB_USER
    valueFrom:
      secretKeyRef:
        name: mariadb-single-wordpress-user
        key: username
  - name: DB_PASSWORD
    valueFrom:
      secretKeyRef:
        name: mariadb-single-wordpress-user
        key: password

  # Option 2: Connection string (DSN)
  - name: DATABASE_URL
    value: "mysql://$(DB_USER):$(DB_PASSWORD)@mariadb-single-primary.database.svc.cluster.local:3306/wordpress"
```

## Operational Procedures

### Verify Database Creation

```bash
# Check Database CRD status
kubectl get database -n database

# Verify database exists in MariaDB
kubectl exec -n database mariadb-single-0 -- \
  mariadb -u root -p$(kubectl get secret -n database mariadb-single-root -o jsonpath='{.data.password}' | base64 -d) \
  -e "SHOW DATABASES LIKE 'wordpress';"
```

### Verify User Creation

```bash
# Check User CRD status
kubectl get user -n database

# Verify user exists in MariaDB
kubectl exec -n database mariadb-single-0 -- \
  mariadb -u root -p$(kubectl get secret -n database mariadb-single-root -o jsonpath='{.data.password}' | base64 -d) \
  -e "SELECT user, host FROM mysql.user WHERE user='wordpress_user';"
```

### Verify Grants

```bash
# Check Grant CRD status
kubectl get grant -n database

# Verify grants in MariaDB
kubectl exec -n database mariadb-single-0 -- \
  mariadb -u root -p$(kubectl get secret -n database mariadb-single-root -o jsonpath='{.data.password}' | base64 -d) \
  -e "SHOW GRANTS FOR 'wordpress_user'@'%';"
```

### Test Connection

```bash
# Test from within cluster
kubectl run -it --rm mariadb-client --image=mariadb:11.4 --restart=Never -- \
  mariadb -h mariadb-single-primary.database.svc.cluster.local \
  -u wordpress_user -p wordpress
```

## Troubleshooting

### Database Not Created

```bash
# Check Database CRD events
kubectl describe database mariadb-single-wordpress -n database

# Check operator logs
kubectl logs -n mariadb-system -l app.kubernetes.io/name=mariadb-operator

# Verify cluster is ready
kubectl get mariadb mariadb-single -n database
```

### User Cannot Connect

```bash
# Verify secret exists
kubectl get secret mariadb-single-wordpress-user -n database

# Check User CRD status
kubectl describe user mariadb-single-wordpress-user -n database

# Check grants
kubectl exec -n database mariadb-single-0 -- \
  mariadb -u root -p... -e "SHOW GRANTS FOR 'wordpress_user'@'%';"

# Verify host restriction
kubectl exec -n database mariadb-single-0 -- \
  mariadb -u root -p... -e "SELECT user, host FROM mysql.user WHERE user='wordpress_user';"
```

### Permission Denied

```bash
# Check Grant CRD status
kubectl describe grant mariadb-single-wordpress-grant -n database

# Verify privileges
kubectl exec -n database mariadb-single-0 -- \
  mariadb -u root -p... -e "SHOW GRANTS FOR 'wordpress_user'@'%';"

# Flush privileges (if needed)
kubectl exec -n database mariadb-single-0 -- \
  mariadb -u root -p... -e "FLUSH PRIVILEGES;"
```

## Migration from PostgreSQL

### Key Differences

| Feature | PostgreSQL (CloudNativePG) | MariaDB Operator |
|---------|---------------------------|------------------|
| **Operator CRDs** | Cluster, Database | MariaDB, Database, User, Grant |
| **User Management** | Managed roles in cluster spec | Separate User CRD |
| **Permissions** | Automatic via database owner | Explicit Grant CRD required |
| **Database Owner** | Specified in Database CRD | Implicit via Grant with ALL PRIVILEGES |
| **Connection Service** | `<cluster>-rw` | `<cluster>-primary` |
| **Port** | 5432 | 3306 |

### Application Changes Required

```yaml
# PostgreSQL
env:
  - name: DB_ENGINE
    value: postgres
  - name: POSTGRES_HOST
    value: postgres-single-rw.database.svc.cluster.local
  - name: POSTGRES_PORT
    value: "5432"
  - name: POSTGRES_DB
    value: wordpress

# MariaDB
env:
  - name: DB_ENGINE
    value: mysql  # or mariadb
  - name: MYSQL_HOST
    value: mariadb-single-primary.database.svc.cluster.local
  - name: MYSQL_PORT
    value: "3306"
  - name: MYSQL_DATABASE
    value: wordpress
```

## Security Considerations

### 1. Secret Management
- Store passwords in external secret managers
- Use Sealed Secrets or External Secrets Operator
- Rotate credentials regularly

### 2. Network Security
- Use NetworkPolicies to restrict database access
- Limit host patterns in User CRDs
- Consider service mesh for mTLS

### 3. Backup and Recovery
- Enable automated backups via Backup CRD
- Store backups in S3-compatible storage
- Test restore procedures regularly

### 4. Audit Logging
- Enable MariaDB audit plugin
- Ship logs to centralized logging
- Monitor for suspicious queries

## Next Steps

1. **Deploy the operator**: Apply `mariadb-operator.yaml`
2. **Create the cluster**: Apply `mariadb-single-node.yaml`
3. **Onboard first app**: Use templates in `/templates` directory
4. **Set up monitoring**: Configure Prometheus and Grafana
5. **Enable backups**: Configure Backup CRD with S3 storage
6. **Test HA**: Migrate to Galera cluster for production

## References

- [MariaDB Operator Documentation](https://github.com/mariadb-operator/mariadb-operator)
- [MariaDB Configuration Guide](https://mariadb.com/kb/en/server-system-variables/)
- [Kubernetes Database Best Practices](https://kubernetes.io/docs/concepts/workloads/controllers/statefulset/)
