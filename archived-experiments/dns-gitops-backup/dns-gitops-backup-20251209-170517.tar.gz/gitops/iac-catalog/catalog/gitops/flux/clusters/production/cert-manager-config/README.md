# Cert-Manager Configuration - Staging Cluster

This directory contains Let's Encrypt certificate configuration for the staging cluster.

## Overview

The staging cluster uses **Let's Encrypt STAGING** certificates by default. This allows for:

- ✅ Testing cert-manager integration without hitting production rate limits
- ✅ Validating DNS challenges and ACME flow
- ✅ High rate limits (30,000 per week per IP)
- ❌ Certificates are not trusted by browsers (for testing only)

## Files

- `cert-manager-extras.yaml` - ClusterIssuers and Certificate resources
- `STAGING_TO_PRODUCTION_MIGRATION.md` - Guide for migrating to production certificates
- `kustomization.yaml` - Kustomize configuration

## Configuration

### ClusterIssuers

Two ClusterIssuers are configured:

1. **letsencrypt-staging** (active) - For testing
   - Server: `https://acme-staging-v02.api.letsencrypt.org/directory`
   - Rate limit: 30,000 certificates per week per IP

2. **letsencrypt-production** (available) - For production use
   - Server: `https://acme-v02.api.letsencrypt.org/directory`
   - Rate limit: 50 certificates per week per domain

### Certificates

All certificates currently use the `letsencrypt-staging` issuer:

| Domain | Certificate Name | Secret Name |
|--------|-----------------|-------------|
| *.colinrey.ch | colinrey-ch-staging | colinrey.ch-tls-staging |
| *.colinrey.com | colinrey-com-staging | colinrey.com-tls-staging |
| *.pandia.io | pandia-io-staging | pandia.io-tls-staging |
| *.reyitsolutions.ch | reyitsolutions-ch-staging | reyitsolutions.ch-tls-staging |
| *.reyitsolutions.com | reyitsolutions-com-staging | reyitsolutions.com-tls-staging |

### DNS Challenge

All certificates use Cloudflare DNS-01 challenge for validation:
- Cloudflare API token stored in secret: `cloudflare-token-secret`
- Token must have permissions: `Zone:DNS:Edit` and `Zone:Zone:Read`

### Certificate Features

- **Algorithm**: ECDSA with P-384 curve
- **Encoding**: PKCS8
- **Renewal**: 30 days before expiration (720h)
- **Rotation**: Always rotate private keys on renewal
- **Reflection**: Certificates are automatically reflected to namespaces:
  - `cert-manager`
  - `flux-system`
  - `ingress`
  - `monitoring`
  - `staging-apps`

## Quick Start

### Verify Certificate Status

```bash
# Check all certificates
kubectl get certificates -n cert-manager

# Check specific certificate
kubectl describe certificate colinrey-ch-staging -n cert-manager

# Check certificate secrets
kubectl get secrets -n cert-manager | grep tls
```

### Monitor Certificate Issuance

```bash
# Watch certificate status
watch kubectl get certificates -n cert-manager

# Check certificate requests
kubectl get certificaterequests -n cert-manager

# Follow cert-manager logs
kubectl logs -n cert-manager deployment/cert-manager -f
```

### Test Certificate with Ingress

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: test-app
  namespace: staging-apps
  annotations:
    cert-manager.io/cluster-issuer: letsencrypt-staging
spec:
  ingressClassName: traefik
  tls:
  - hosts:
    - test.colinrey.ch
    secretName: colinrey.ch-tls-staging
  rules:
  - host: test.colinrey.ch
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: test-service
            port:
              number: 80
```

## Migration to Production

When ready to use production certificates, follow the guide in `STAGING_TO_PRODUCTION_MIGRATION.md`.

### Quick Migration Steps

1. Verify staging certificates work correctly
2. Update issuerRef in certificates from `letsencrypt-staging` to `letsencrypt-production`
3. Update secret names from `*-tls-staging` to `*-tls-production`
4. Update all ingress resources to use new secret names
5. Commit changes and let Flux reconcile

## Troubleshooting

### Certificate Stuck in "Pending"

```bash
# Check certificate request
kubectl get certificaterequest -n cert-manager

# Check events
kubectl describe certificate <cert-name> -n cert-manager

# Check cert-manager logs
kubectl logs -n cert-manager deployment/cert-manager
```

### DNS Challenge Fails

```bash
# Verify Cloudflare token exists
kubectl get secret cloudflare-token-secret -n cert-manager

# Check DNS records
dig TXT _acme-challenge.colinrey.ch

# Verify token permissions in Cloudflare dashboard
```

### Rate Limit Issues

If you hit rate limits:
- **Staging**: Very unlikely (30,000/week limit)
- **Production**: Switch back to staging, wait 7 days, test more thoroughly

## References

- [cert-manager Documentation](https://cert-manager.io/docs/)
- [Let's Encrypt Rate Limits](https://letsencrypt.org/docs/rate-limits/)
- [Cloudflare API Token Setup](https://developers.cloudflare.com/fundamentals/api/get-started/create-token/)
- [Migration Guide](./STAGING_TO_PRODUCTION_MIGRATION.md)
