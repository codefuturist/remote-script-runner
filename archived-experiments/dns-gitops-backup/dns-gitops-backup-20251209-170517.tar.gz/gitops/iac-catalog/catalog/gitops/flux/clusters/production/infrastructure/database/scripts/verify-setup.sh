#!/bin/bash
# Verification Script for Centralized PostgreSQL Setup

set -e

echo "=========================================="
echo "PostgreSQL Centralized Database Test"
echo "=========================================="
echo ""

echo "1. Checking Database CRD Status..."
kubectl get database postgres-single-testapp -n database -o jsonpath='{.metadata.name}: Applied={.status.applied}, Message={.status.message}' 2>/dev/null || echo "Database CRD not found or not ready"
echo ""
echo ""

echo "2. Checking PostgreSQL Pod..."
kubectl get pods -n database -l cnpg.io/cluster=postgres-single
echo ""

echo "3. Checking Database Services..."
kubectl get svc -n database | grep postgres-single
echo ""

echo "4. Verifying testapp database in PostgreSQL..."
kubectl exec -n database postgres-single-1 -c postgres -- psql -U postgres -t -c "SELECT datname, datdba::regrole as owner FROM pg_database WHERE datname='testapp';" 2>/dev/null || echo "Could not query database"
echo ""

echo "5. Checking Test Application Pod..."
kubectl get pods -n test-apps -l app=testapp
echo ""

echo "6. Test Application Logs (last 10 lines)..."
kubectl logs -n test-apps -l app=testapp --tail=10 2>/dev/null || echo "No logs available"
echo ""

echo "7. Testing Connection from Application Pod..."
kubectl exec -n test-apps -l app=testapp -- sh -c 'PGPASSWORD=$DB_PASSWORD psql -h $DB_HOST -U $DB_USER -d $DB_NAME -c "SELECT current_database(), current_user, version();" 2>&1 | head -5' 2>/dev/null || echo "Connection test failed"
echo ""

echo "=========================================="
echo "Verification Complete"
echo "=========================================="
