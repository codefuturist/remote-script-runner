# Staging Kubernetes Cluster - FluxCD GitOps
This directory contains the FluxCD configuration for the **staging** Kubernetes cluster. The structure follows modern GitOps best practices with granular infrastructure deployment, tier-based application organization, and comprehensive governance policies.
## 📁 Directory Structure
```
staging/
├── flux-system/                 # FluxCD controllers and orchestration
│   ├── gotk-components.yaml    # Flux toolkit components
│   ├── gotk-sync.yaml          # Git repository sync configuration
│   └── kustomization.yaml      # Root orchestrator
├── infrastructure/              # Platform infrastructure (11 layers)
│   ├── sources/                # Helm, Git, OCI repositories (Layer 1)
│   ├── namespaces/             # Infrastructure namespaces (Layer 2)
│   ├── configs/                # Cluster-wide configurations (Layer 2)
│   ├── network/                # Ingress, DNS, cert-manager, MetalLB (Layer 3)
│   ├── security/               # RBAC, external-secrets (Layer 3)
│   ├── storage/                # Storage classes, OpenEBS (Layer 3)
│   ├── utility/                # Reflector, helpers (Layer 3)
│   ├── monitoring/             # Prometheus, Grafana (Layer 4)
│   ├── logging/                # Loki, Alloy (Layer 4)
│   ├── database/               # Database operators (Layer 4)
│   └── backup/                 # Backup configurations (Layer 4)
├── apps/                        # Application deployments (tier-based)
│   ├── namespaces/             # App namespace definitions
│   ├── backend/                # API services, business logic
│   ├── frontend/               # User-facing applications
│   ├── data/                   # Database tools
│   ├── jobs/                   # Batch jobs and scheduled tasks
│   ├── base/                   # Common configurations
│   ├── ci-cd/                  # CI/CD tools (Gitea, etc.)
│   ├── development/            # Development-specific apps
│   └── experimental/           # Experimental features
├── policies/                    # Governance and policy enforcement
│   ├── security-policies/      # Pod security standards, RBAC policies
│   ├── resource-quotas/        # Namespace resource limits
│   └── network-policies/       # Network segmentation rules
├── tenants/                     # Multi-tenancy configuration
│   ├── team-platform/          # Platform team resources
│   ├── team-dev/               # Development team resources
│   └── team-operations/        # Operations team resources
├── patches/                     # Staging-specific patches
│   ├── resource-limits.yaml    # Lower resource limits for staging
│   ├── affinity-rules.yaml     # Node affinity rules
│   └── increase-replicas.yaml  # Replica overrides
├── notifications.yaml           # Alert routing and notifications
├── kustomization.yaml          # Root kustomization
├── README.md                   # This file
└── MIGRATION_GUIDE.md          # Migration documentation
```
## 🚀 Deployment Architecture
### Infrastructure Layers (Dependency Chain)
The infrastructure is deployed in 4 layers with explicit dependencies:
**Layer 1: Foundation**
- `infrastructure-sources`: Helm/Git/OCI repositories
**Layer 2: Configuration**
- `infrastructure-namespaces`: Infrastructure namespaces
- `infrastructure-configs`: Cluster-wide configs
**Layer 3: Core Services** (parallel deployment after Layer 2)
- `infrastructure-network`: Ingress, DNS, cert-manager, MetalLB
- `infrastructure-security`: RBAC, external-secrets
- `infrastructure-storage`: Storage classes
- `infrastructure-utility`: Reflector, helpers
**Layer 4: Observability & Data** (parallel deployment after Layer 3)
- `infrastructure-monitoring`: Prometheus, Grafana
- `infrastructure-logging`: Loki, Alloy
- `infrastructure-database`: Database operators
- `infrastructure-backup`: Backup configurations
**Layer 5: Governance** (after Layer 4)
- `policies`: Security policies, resource quotas, network policies
- `tenants`: Multi-tenant namespace configurations
**Layer 6: Applications** (after Layer 5)
- `apps`: Application deployments organized by tier
### Deployment Flow
```mermaid
graph TD
    A[sources] --> B[namespaces]
    A --> C[configs]
    B --> D[network]
    B --> E[security]
    B --> F[storage]
    B --> G[utility]
    D --> H[monitoring]
    E --> H
    F --> H
    D --> I[logging]
    D --> J[database]
    D --> K[backup]
    H --> L[policies]
    I --> L
    J --> L
    K --> L
    L --> M[tenants]
    M --> N[apps]
```
## 🎯 Staging-Specific Configuration
Staging cluster differs from production:
### Resource Allocation
- **Lower CPU/memory limits**: ~50% of production resources
- **Fewer replicas**: 1-2 replicas vs production's 3-5
- **Smaller storage**: Reduced PVC sizes for cost savings
### Certificates
- **Let's Encrypt Staging**: Uses staging ACME server for testing
- **Self-signed certificates**: For internal testing
### Monitoring
- **Shorter retention**: 7 days vs production's 30 days
- **Less frequent scraping**: 30s vs production's 15s
### Autoscaling
- **Disabled or minimal**: Fixed replica counts for predictability
- **Lower thresholds**: More aggressive scale-down
## 🛠️ Operations
### Bootstrap Staging Cluster
```bash
# Export SOPS age key
export SOPS_AGE_KEY_FILE=age.agekey
# Bootstrap FluxCD on staging cluster
flux bootstrap github \
  --owner=your-org \
  --repository=iac-catalog \
  --branch=main \
  --path=catalog/gitops/flux/clusters/staging \
  --personal=false \
  --components-extra=image-reflector-controller,image-automation-controller
# Verify bootstrap
flux check
flux get sources git
flux get kustomizations
```
### Monitor Deployment
```bash
# Watch all Kustomizations
watch flux get kustomizations
# Check specific layer
flux get kustomization infrastructure-network
flux logs --kind=Kustomization --name=infrastructure-network
# Check HelmReleases
flux get helmreleases -A
# Watch reconciliation in real-time
flux events --for Kustomization/infrastructure-network --watch
```
### Validate Configuration
```bash
# Validate before commit
kustomize build catalog/gitops/flux/clusters/staging
# Check for errors
flux check --pre
# Dry run reconciliation
flux diff kustomization infrastructure-network \
  --path catalog/gitops/flux/clusters/staging/infrastructure/network
```
### Force Reconciliation
```bash
# Force reconcile infrastructure
flux reconcile kustomization infrastructure-network --with-source
# Force reconcile specific HelmRelease
flux reconcile helmrelease traefik-internal -n ingress
# Reconcile all
flux reconcile source git flux-system
flux reconcile kustomization flux-system
```
### Suspend/Resume
```bash
# Suspend for maintenance
flux suspend kustomization apps
# Resume after maintenance
flux resume kustomization apps
```
## 🔐 Secret Management
Staging uses SOPS for secret encryption with age encryption:
```bash
# Encrypt a secret
sops --encrypt --age $(cat age.agekey | grep public | cut -d' ' -f4) \
  secret.yaml > secret.enc.yaml
# Decrypt a secret
sops --decrypt secret.enc.yaml
# Edit encrypted secret
sops secret.enc.yaml
```
### Required Secrets
Create these secrets in the staging cluster:
```bash
# SOPS age key (for FluxCD to decrypt secrets)
kubectl create secret generic sops-age \
  --from-file=age.agekey=./age.agekey \
  --namespace=flux-system
# Mattermost webhook (for notifications)
kubectl create secret generic mattermost-webhook-url \
  --from-literal=address=https://mattermost.pandia.io/hooks/YOUR_HOOK_ID \
  --namespace=flux-system
```
## 📊 Monitoring & Alerts
### Mattermost Notifications
Staging alerts are routed to Mattermost:
- **staging-alerts**: General staging notifications
- **staging-critical**: Critical infrastructure failures
### Alert Providers
- **mattermost-notifications**: General staging alerts
- **mattermost-critical**: Critical failures
### Alert Routing
| Event Type | Severity | Provider |
|------------|----------|----------|
| Infrastructure failures | error | mattermost-critical |
| App deployment status | info | mattermost-notifications |
| App failures | error | mattermost-critical |
| Git sync issues | error | mattermost-critical |
| Policy violations | error | mattermost-notifications |
## 🐛 Troubleshooting
### Common Issues
#### HelmRelease Stuck
```bash
# Check HelmRelease status
kubectl describe helmrelease <name> -n <namespace>
# Check Helm release status
helm list -n <namespace>
# Force upgrade
flux suspend helmrelease <name> -n <namespace>
flux resume helmrelease <name> -n <namespace>
```
#### Kustomization Failed
```bash
# Check Kustomization status
flux get kustomization <name>
# View events
flux events --for Kustomization/<name>
# Check kustomize build
kustomize build <path>
```
#### SOPS Decryption Failed
```bash
# Verify SOPS secret exists
kubectl get secret sops-age -n flux-system
# Check if secret has correct key
kubectl get secret sops-age -n flux-system -o jsonpath='{.data.age\.agekey}' | base64 -d
# Recreate if needed
kubectl delete secret sops-age -n flux-system
kubectl create secret generic sops-age \
  --from-file=age.agekey=./age.agekey \
  --namespace=flux-system
```
## 📚 Related Documentation
- [Infrastructure Network Layer](infrastructure/network/README.md)
- [Infrastructure Security Layer](infrastructure/security/README.md)
- [Application Backend Tier](apps/backend/README.md)
- [Application Frontend Tier](apps/frontend/README.md)
- [Application Data Tier](apps/data/README.md)
- [Policies Documentation](policies/README.md)
- [Tenants Documentation](tenants/README.md)
- [Production Cluster](../production/README.md)
- [FluxCD Documentation](https://fluxcd.io/flux/)
## 🎓 Best Practices
1. **Test in Staging First**: Always deploy to staging before production
2. **Use Semantic Versioning**: Pin chart versions, use semver ranges carefully
3. **Monitor Reconciliation**: Watch for drift and failed reconciliations
4. **Backup Secrets**: Ensure SOPS keys and sealed-secrets keys are backed up
5. **Document Changes**: Update README files when adding new components
6. **Use Notifications**: Configure Mattermost alerts for awareness
7. **Regular Updates**: Keep FluxCD and components updated
8. **Cost Optimization**: Use lower resources in staging to save costs
## 🔄 Sync Status
Check cluster sync status:
```bash
# Overall status
flux get all
# Detailed status
flux get kustomizations
flux get helmreleases -A
flux get sources all
# Export status for reporting
flux export kustomization --all > kustomizations-backup.yaml
```
## 🆘 Support
For issues or questions:
1. Check this README and related documentation
2. Review FluxCD logs: `flux logs --all-namespaces`
3. Check Kubernetes events: `kubectl get events -A --sort-by='.lastTimestamp'`
4. Review Mattermost notifications for alerts
5. Consult [FluxCD documentation](https://fluxcd.io/flux/)
---
**Last Updated**: 2025-12-09  
**FluxCD Version**: v2.x  
**Kubernetes Version**: v1.28+
