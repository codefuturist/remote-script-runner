# Homarr - Customizable Dashboard

This directory contains the Flux HelmRelease configuration for Homarr in the staging environment.

## Overview

Homarr is a sleek, modern dashboard that puts all of your apps and services at your fingertips.

## Configuration

- **Namespace**: `dashboard`
- **Chart Repository**: https://homarr-labs.github.io/charts/
- **Ingress**: Enabled with Traefik ingress class
- **Authentication**: Credentials-based

## Storage

- Database: 1Gi persistent volume for SQLite database

## Resources

- 50m CPU / 128Mi memory (requests)
- 200m CPU / 256Mi memory (limits)

## Features

- Customizable widgets
- Application integration
- Modern UI
- Self-hosted

## Deployment

This application is deployed via FluxCD from the main cluster kustomization.
