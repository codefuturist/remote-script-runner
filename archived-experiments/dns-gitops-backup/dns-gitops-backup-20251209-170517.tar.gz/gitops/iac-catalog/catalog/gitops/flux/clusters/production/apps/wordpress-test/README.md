# WordPress Test - Testing Application

This directory contains the WordPress test deployment for the staging environment.

## Overview

Lightweight WordPress instance for testing features and configurations.

## Configuration

- **Namespace**: `wordpress-test`
- **Image**: `wordpress:6.4-apache`
- **Database**: MariaDB (centralized in `database` namespace)
- **Storage**: 5Gi persistent volume (smaller than production)
- **Ingress**: Enabled with Traefik and Let's Encrypt staging certificates

## Dependencies

- MariaDB Single instance (database namespace)
- Database: `wordpress_test`
- Database User: `wordpress_test_user`
- cert-manager for TLS certificates

## Resources

- **Requests**: 50m CPU, 128Mi memory
- **Limits**: 200m CPU, 256Mi memory

(Lower than production for testing purposes)

## Database Configuration

The test database is created via MariaDB operator resources in:
`infrastructure/database/applications/wordpress-databases.yaml`

## Secrets

- `wordpress-secret.yaml` - Database password (SOPS encrypted)
- `wordpress-deployment.yaml` - Contains database credentials secret

## Deployment

This application is deployed via FluxCD from the main cluster kustomization.

## Access

- **Host**: `wordpress-test.staging.local`
- **Protocol**: HTTPS (Let's Encrypt staging)
- **Port**: 443

## Notes

- Separate database and namespace from production WordPress
- Lower resource limits for testing
- Uses same storage class as production
- Useful for testing plugins, themes, and configurations before production deployment
