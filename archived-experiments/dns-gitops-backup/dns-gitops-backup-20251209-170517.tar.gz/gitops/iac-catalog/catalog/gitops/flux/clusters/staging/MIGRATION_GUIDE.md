# Staging Cluster Migration Guide

This document outlines the migration of applications from the archived home cluster to the FluxCD staging cluster.

## Migration Status

### ✅ Completed

#### Infrastructure Layer
- CloudNativePG Operator (PostgreSQL)
- MariaDB Operator
- Traefik Ingress (public/internal)
- cert-manager with Let's Encrypt
- Prometheus & Loki monitoring
- MetalLB / kube-vip

#### Application Layer

**Web Applications (`apps/production/web/`)**
- ✅ Colin's Blog - WordPress with MariaDB
- ✅ Rey IT Solutions - WordPress with MariaDB

**CI/CD (`apps/ci-cd/`)**
- ✅ Gitea - Git service with PostgreSQL

**Monitoring (`apps/production/`)**
- ✅ Uptime Kuma - Uptime monitoring (SQLite)
- ✅ Mattermost - Team collaboration with PostgreSQL
- ✅ Prometheus Stack (existing)
- ✅ Loki Stack (existing)
- ✅ Gatus (existing)

### 📋 Pending (Not Yet Implemented)

**Productivity Apps**
- ⏳ Odoo - ERP/CRM system
- ⏳ Open WebUI - AI chat interface

**Utility Services**
- ⏳ Mailrise - Email notification gateway
- ⏳ Reflector - Secret/ConfigMap replication
- ⏳ Shlink - URL shortener

**CI/CD (Additional)**
- ⏳ Harbor - Container registry

**Database Tools (Optional)**
- ⏳ PHPMyAdmin - MariaDB management
- ⏳ PgAdmin - PostgreSQL management
- ⏳ Redis Insight - Redis management

### ❌ Explicitly Skipped

**Redundant Services** (following standardization)
- Authelia (keeping Authentik only)
- Keycloak (keeping Authentik only)
- Nginx Ingress (standardizing on Traefik)
- Caddy Ingress (standardizing on Traefik)
- Graylog (redundant with Loki)

**Entertainment Apps** (deferred)
- Overseerr
- Radarr
- Tautulli

**Storage Provisioners** (as requested)
- Rook Ceph
- Longhorn
- OpenEBS

## Directory Structure

```
staging/
├── infrastructure/
│   ├── sources/
│   │   └── helm-repositories.yaml     # Centralized Helm repos
│   ├── namespaces/
│   ├── secrets/
│   ├── cert-manager/
│   ├── ingress/                       # Traefik
│   ├── metallb/
│   ├── monitoring/                    # Prometheus, Loki, Gatus
│   └── database/                      # CloudNativePG, MariaDB operators
│
├── apps/
│   ├── production/
│   │   ├── web/
│   │   │   ├── colins-blog/
│   │   │   │   ├── kustomization.yaml
│   │   │   │   ├── colins-blog-database.yaml      # MariaDB CRDs
│   │   │   │   └── colins-blog-helmrelease.yaml
│   │   │   ├── rey-it-solutions/
│   │   │   │   ├── kustomization.yaml
│   │   │   │   ├── rey-it-solutions-database.yaml
│   │   │   │   └── rey-it-solutions-helmrelease.yaml
│   │   │   ├── encrypt-web-secrets.sh
│   │   │   └── README.md
│   │   ├── mattermost/
│   │   │   ├── kustomization.yaml
│   │   │   ├── mattermost-database.yaml          # PostgreSQL CRDs
│   │   │   └── mattermost-helmrelease.yaml
│   │   ├── uptime-kuma/
│   │   │   ├── kustomization.yaml
│   │   │   └── uptime-kuma-helmrelease.yaml
│   │   └── kustomization.yaml
│   │
│   ├── ci-cd/
│   │   ├── gitea/
│   │   │   ├── kustomization.yaml
│   │   │   ├── gitea-database.yaml               # PostgreSQL CRDs
│   │   │   └── gitea-helmrelease.yaml
│   │   ├── kustomization.yaml
│   │   └── README.md
│   │
│   └── kustomization.yaml
│
└── flux-system/
    ├── gotk-components.yaml
    ├── gotk-sync.yaml
    ├── namespaces-kustomization.yaml
    ├── infrastructure-kustomization.yaml
    ├── apps-kustomization.yaml
    └── kustomization.yaml
```

## Key Design Decisions

### 1. Database Strategy
- **PostgreSQL**: CloudNativePG operator with CRD-based database/user management
- **MariaDB**: MariaDB operator with CRD-based database/user/grant management
- **Centralized Clusters**: Single `postgres-single` and `mariadb-single` clusters in `database` namespace
- **Application Isolation**: Each app gets dedicated database and user with minimal privileges

### 2. Secret Management
- **Tool**: SOPS with Age encryption
- **Key**: `age1t8gm5avm9z5pquta4w2kaud7zn3c588mkk2shdpdskvp76wxh3gsxctyst`
- **Pattern**: Secrets created in `database` namespace, reflected to app namespaces via Reflector
- **Encryption**: Only `data` and `stringData` fields encrypted
- **Storage**: Database credentials co-located with database CRDs

### 3. Application Pattern
Each application follows this structure:
```yaml
app-name/
├── kustomization.yaml          # Resource orchestration
├── app-name-database.yaml      # Database CRDs + SOPS-encrypted secret
└── app-name-helmrelease.yaml   # Helm chart deployment
```

### 4. Namespace Strategy
- `database`: Operators, clusters, database CRDs, user secrets
- `web`: Web applications
- `ci-cd`: CI/CD tools
- `monitoring`: Monitoring and alerting tools
- `flux-system`: FluxCD components and orchestration

### 5. Dependency Management
FluxCD Kustomization dependencies:
```
flux-system
    ↓
infrastructure (operators, ingress, cert-manager)
    ↓
apps (all applications)
```

## Database Configuration Patterns

### PostgreSQL (CloudNativePG)
```yaml
# Database
apiVersion: postgresql.cnpg.io/v1
kind: Database
metadata:
  name: postgres-single-appname
  namespace: database
spec:
  cluster:
    name: postgres-single
  name: appname
  owner: appname_user
  databaseReclaimPolicy: retain

# Secret (SOPS-encrypted)
apiVersion: v1
kind: Secret
metadata:
  name: postgres-single-appname-user
  namespace: database
  annotations:
    reflector.v1.k8s.emberstack.com/reflection-allowed: "true"
    reflector.v1.k8s.emberstack.com/reflection-auto-enabled: "true"
    reflector.v1.k8s.emberstack.com/reflection-auto-namespaces: "target-namespace"
type: Opaque
stringData:
  username: appname_user
  password: "<SOPS-encrypted>"
```

### MariaDB (MariaDB Operator)
```yaml
# Database, User, Grant
apiVersion: k8s.mariadb.com/v1alpha1
kind: Database
metadata:
  name: mariadb-single-appname
  namespace: database
spec:
  mariaDbRef:
    name: mariadb-single
  characterSet: utf8mb4
  collate: utf8mb4_unicode_ci
  name: appname

---
apiVersion: k8s.mariadb.com/v1alpha1
kind: User
metadata:
  name: mariadb-single-appname-user
  namespace: database
spec:
  mariaDbRef:
    name: mariadb-single
  name: appname_user
  passwordSecretKeyRef:
    name: mariadb-single-appname-user
    key: password

---
apiVersion: k8s.mariadb.com/v1alpha1
kind: Grant
metadata:
  name: mariadb-single-appname-grant
  namespace: database
spec:
  mariaDbRef:
    name: mariadb-single
  privileges: ["SELECT", "INSERT", "UPDATE", "DELETE", ...]
  database: appname
  username: appname_user
```

## Helm Repositories

All Helm repositories are centralized in `infrastructure/sources/helm-repositories.yaml`:

- bitnami: General applications (WordPress, etc.)
- jetstack: cert-manager
- traefik: Ingress controller
- prometheus-community: Monitoring stack
- grafana: Observability tools
- stakater: Universal application chart
- gabe565: Uptime Kuma and tools
- pandia: Mealie
- cloudnative-pg: PostgreSQL operator
- gitea: Git service
- harbor: Container registry
- bjw-s: App template
- mattermost: Team collaboration

## Encryption Workflow

### Automated (Recommended)
```bash
cd catalog/gitops/flux/clusters/staging/
chmod +x encrypt-all-secrets.sh
./encrypt-all-secrets.sh
```

### Manual
```bash
# Generate password
PASSWORD=$(openssl rand -base64 32 | tr -d "=+/" | cut -c1-32)

# Replace placeholder
sed -i "s/PLACEHOLDER_GENERATE_SECURE_PASSWORD_32_CHARS/${PASSWORD}/g" app-database.yaml

# Encrypt with SOPS
sops --encrypt \
    --age age1t8gm5avm9z5pquta4w2kaud7zn3c588mkk2shdpdskvp76wxh3gsxctyst \
    --encrypted-regex '^(data|stringData)$' \
    --in-place app-database.yaml
```

## Deployment Process

### 1. Encrypt Secrets
```bash
cd catalog/gitops/flux/clusters/staging/
./encrypt-all-secrets.sh
```

### 2. Verify Files
```bash
# Check encryption
grep -r "sops:" apps/

# Validate YAML
find apps/ -name "*.yaml" -exec yamllint {} \;
```

### 3. Commit & Push
```bash
git add catalog/gitops/flux/clusters/staging/
git commit -m "feat: migrate web, ci-cd, and monitoring apps to staging cluster"
git push origin develop
```

### 4. Monitor Deployment
```bash
# Watch FluxCD reconciliation
flux get kustomizations --watch

# Check HelmReleases
kubectl get hr -A

# Check application pods
kubectl get pods -n web
kubectl get pods -n ci-cd
kubectl get pods -n monitoring

# Check databases
kubectl get databases -n database
kubectl get users -n database
kubectl get grants -n database
```

## Troubleshooting

### Secrets Not Reflected
```bash
# Check Reflector deployment
kubectl get deployment -n kube-system reflector

# Check secret in source namespace
kubectl get secret -n database

# Check secret in target namespace
kubectl get secret -n web
```

### Database Connection Failed
```bash
# Check database cluster status
kubectl get cluster -n database
kubectl get mariadb -n database

# Check database logs
kubectl logs -n database postgres-single-1
kubectl logs -n database mariadb-single-0

# Test connection
kubectl exec -it <app-pod> -n <namespace> -- nc -zv <db-host> <port>
```

### HelmRelease Failed
```bash
# Check HelmRelease status
kubectl describe hr <name> -n <namespace>

# Check Helm release
helm list -n <namespace>

# Check pod events
kubectl get events -n <namespace> --sort-by='.lastTimestamp'
```

## Next Steps

1. **Test Deployments**: Verify all applications start correctly
2. **Configure Domains**: Update placeholder domains (*.staging.local) with real domains
3. **Set Up Monitoring**: Configure Prometheus alerts and Grafana dashboards
4. **Backup Strategy**: Implement automated database backups
5. **Add Remaining Apps**: Deploy productivity and utility applications as needed
6. **Production Migration**: Replicate structure to production cluster

## Resources

- **Web Apps**: `apps/production/web/README.md`
- **CI/CD**: `apps/ci-cd/README.md`
- **Database Guide**: `infrastructure/database/README.md`
- **SOPS Configuration**: `.sops.yaml` at repository root
- **FluxCD Docs**: https://fluxcd.io/docs/
