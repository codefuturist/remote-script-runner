# Secrets Management - Staging Cluster

This directory contains all encrypted secrets for the staging cluster, centralized for better organization and security management.

## Overview

All secrets are encrypted using **SOPS** (Secrets OPerationS) with **Age** encryption. The staging cluster uses centralized secret management following FluxCD best practices.

## Directory Structure

```
secrets/
├── kustomization.yaml              # Root secrets kustomization
├── shared/                         # Shared secrets (multi-component)
│   ├── kustomization.yaml
│   ├── monitoring-prometheus-admin-secret.yaml
│   └── monitoring-smtp-credentials-secret.yaml
├── external/                       # External service API tokens
│   ├── kustomization.yaml
│   └── cert-manager-cloudflare-api-secret.yaml
└── certificates/                   # TLS certificates and CA bundles
    └── kustomization.yaml
```

## Secret Categories

### Shared (`shared/`)
Secrets used by multiple components or shared across namespaces:
- Admin credentials
- Database passwords
- SMTP credentials
- Shared API keys

### External (`external/`)
Third-party service API tokens and credentials:
- Cloud provider tokens (AWS, GCP, Azure)
- DNS provider API keys (Cloudflare, Route53)
- SaaS service credentials
- External authentication tokens

### Certificates (`certificates/`)
TLS certificates and certificate-related secrets:
- Custom CA certificates
- Wildcard TLS certificates
- Mutual TLS certificates
- Client certificates

## Naming Convention

All secrets follow this naming pattern:

```
<namespace>-<component>-<purpose>-secret.yaml
```

**Examples:**
- `monitoring-prometheus-admin-secret.yaml` - Prometheus admin credentials in monitoring namespace
- `cert-manager-cloudflare-api-secret.yaml` - Cloudflare API token for cert-manager
- `ingress-traefik-tls-secret.yaml` - TLS certificate for Traefik ingress
- `database-postgres-credentials-secret.yaml` - PostgreSQL credentials

**Components:**
- **namespace**: Kubernetes namespace where secret is used
- **component**: Service/application name (prometheus, cloudflare, traefik)
- **purpose**: What the secret is for (admin, api, tls, credentials)
- **secret**: Always ends with `-secret.yaml`

## SOPS Encryption

### Prerequisites

Install required tools:

```bash
# macOS
brew install sops age

# Linux
# Download from releases:
# - https://github.com/mozilla/sops/releases
# - https://github.com/FiloSottile/age/releases
```

### Encryption Configuration

The repository uses `.sops.yaml` at the root with these rules:

```yaml
creation_rules:
  - path_regex: .*/flux/.*secret.*\.ya?ml$
    encrypted_regex: ^(data|stringData)$
    age: age1t8gm5avm9z5pquta4w2kaud7zn3c588mkk2shdpdskvp76wxh3gsxctyst
```

**Key Details:**
- **Public Key**: `age1t8gm5avm9z5pquta4w2kaud7zn3c588mkk2shdpdskvp76wxh3gsxctyst`
- **Encrypted Fields**: Only `data` and `stringData` in Secrets
- **Private Key**: Stored as `sops-age` secret in `flux-system` namespace (cluster only)

### Creating a New Secret

#### 1. Create Secret Manifest

```bash
# Create unencrypted secret file
cat > secrets/shared/myapp-database-credentials-secret.yaml <<EOF
apiVersion: v1
kind: Secret
metadata:
  name: myapp-database-credentials
  namespace: myapp
type: Opaque
stringData:
  username: myapp_user
  password: super_secret_password_here
  database: myapp_production
  host: postgres.database.svc.cluster.local
EOF
```

#### 2. Encrypt with SOPS

```bash
# Encrypt in place
sops --encrypt --in-place secrets/shared/myapp-database-credentials-secret.yaml

# Verify encryption (should see ENC[AES256_GCM,...])
cat secrets/shared/myapp-database-credentials-secret.yaml
```

#### 3. Add to Kustomization

Add the secret to the appropriate category's `kustomization.yaml`:

```yaml
# secrets/shared/kustomization.yaml
resources:
  - monitoring-prometheus-admin-secret.yaml
  - myapp-database-credentials-secret.yaml  # Add this line
```

#### 4. Commit and Push

```bash
git add secrets/
git commit -m "feat(secrets): add myapp database credentials"
git push origin develop
```

Flux will automatically decrypt the secret in the cluster using the age private key.

### Viewing/Editing Encrypted Secrets

#### View Decrypted Content

```bash
# View without modifying
sops --decrypt secrets/shared/myapp-database-credentials-secret.yaml

# Extract specific value
sops --decrypt --extract '["stringData"]["password"]' secrets/shared/myapp-database-credentials-secret.yaml
```

#### Edit Encrypted Secret

```bash
# Edit with SOPS (decrypts in editor, encrypts on save)
sops secrets/shared/myapp-database-credentials-secret.yaml

# SOPS will:
# 1. Decrypt the file
# 2. Open in your $EDITOR
# 3. Re-encrypt when you save and exit
```

### Re-encrypting Secrets

If you need to re-encrypt (e.g., after key rotation):

```bash
# Re-encrypt single file
sops updatekeys secrets/shared/myapp-database-credentials-secret.yaml

# Re-encrypt all secrets
find secrets/ -name "*-secret.yaml" -exec sops updatekeys {} \;
```

## Secret Rotation

### Rotation Schedule

| Secret Type | Rotation Frequency | Priority |
|-------------|-------------------|----------|
| API Tokens (External) | Quarterly | High |
| Admin Passwords | Quarterly | High |
| Database Credentials | Bi-annually | Medium |
| TLS Certificates | Annually (or 90 days for LE) | High |
| Service Accounts | Annually | Medium |

### Rotation Procedure

#### 1. Create New Secret Version

```bash
# Edit and update the values
sops secrets/shared/myapp-database-credentials-secret.yaml

# Add rotation metadata
# Add labels to track rotation date
```

#### 2. Update Applications

Ensure applications can handle credential updates:
- Use secret references (not hardcoded)
- Implement graceful restarts
- Test with new credentials first

#### 3. Deploy and Verify

```bash
# Commit rotated secret
git add secrets/
git commit -m "sec(secrets): rotate myapp database credentials"
git push origin develop

# Monitor Flux reconciliation
flux get kustomizations
flux reconcile kustomization infrastructure --with-source

# Verify in cluster
kubectl get secret myapp-database-credentials -n myapp -o yaml
```

#### 4. Document Rotation

Add rotation metadata to secret:

```yaml
metadata:
  name: myapp-database-credentials
  namespace: myapp
  labels:
    secrets.fluxcd.io/rotated: "2025-11-18"
    secrets.fluxcd.io/expires: "2026-05-18"
  annotations:
    secrets.fluxcd.io/rotation-note: "Quarterly rotation - Q4 2025"
```

## Security Best Practices

### ✅ Do

- **Always encrypt before commit**: Never commit plaintext secrets
- **Use descriptive names**: Follow naming convention strictly
- **Add metadata**: Include labels for rotation tracking
- **Verify encryption**: Check files contain `ENC[AES256_GCM,...]` before committing
- **Back up age key**: Keep private key secure and backed up
- **Rotate regularly**: Follow rotation schedule
- **Use minimal permissions**: Only grant access to needed secrets
- **Document secret purpose**: Add comments explaining what each secret is for

### ❌ Don't

- **Never commit plaintext**: Even temporarily
- **Don't share private keys**: Age private key stays in cluster only
- **Don't reuse secrets**: Use unique credentials per environment
- **Don't skip rotation**: Expired credentials are security risks
- **Don't use weak passwords**: Use strong, generated passwords
- **Don't store keys in Git**: `.agekey` files must be gitignored
- **Don't bypass SOPS**: Always use SOPS for secret management

## Troubleshooting

### Secret Not Decrypting in Cluster

**Problem**: Flux can't decrypt secrets

**Solutions**:

```bash
# 1. Check SOPS secret exists
kubectl get secret sops-age -n flux-system

# 2. Verify secret contains age key
kubectl get secret sops-age -n flux-system -o jsonpath='{.data.age\.agekey}' | base64 -d

# 3. Check Flux logs
flux logs --kind=Kustomization --name=infrastructure

# 4. Verify kustomization has decryption config
kubectl get kustomization infrastructure -n flux-system -o yaml | grep -A 5 decryption
```

### Can't Decrypt Locally

**Problem**: `sops --decrypt` fails with "no key could decrypt"

**Solutions**:

```bash
# 1. Ensure you have the age private key
export SOPS_AGE_KEY_FILE=~/.config/sops/age/keys.txt

# 2. Verify key file contains correct age key
grep "AGE-SECRET-KEY" $SOPS_AGE_KEY_FILE

# 3. Check .sops.yaml matches your key
grep "age:" .sops.yaml
```

### Wrong Key After Rotation

**Problem**: Secrets encrypted with old age key

**Solutions**:

```bash
# Re-encrypt with new key
sops updatekeys secrets/shared/myapp-secret.yaml

# Or batch update
find secrets/ -name "*-secret.yaml" -exec sops updatekeys {} \;
```

### Secret Not Applied

**Problem**: Secret exists in Git but not in cluster

**Solutions**:

```bash
# 1. Check if secret is in kustomization
cat secrets/<category>/kustomization.yaml

# 2. Force Flux reconciliation
flux reconcile kustomization infrastructure --with-source

# 3. Check for errors
kubectl get kustomization infrastructure -n flux-system -o yaml
```

## Integration with Components

### Referencing Secrets from Components

Components reference centralized secrets using relative paths:

```yaml
# Example: cert-manager/kustomization.yaml
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization
resources:
  - cert-manager.yaml
  - cert-manager-extras.yaml
  - ../secrets/external/cert-manager-cloudflare-api-secret.yaml
```

### Component-Specific Secrets

While most secrets are centralized, some components may need inline secrets:

1. **Temporary secrets**: Test credentials, development-only
2. **Generated secrets**: Created by Helm charts
3. **External sources**: Secrets pulled from external secret operators

## Validation Commands

### Before Committing

```bash
# 1. Verify all secrets are encrypted
grep -r "password.*:" secrets/ --include="*-secret.yaml" | grep -v "ENC\["
# Should return nothing

# 2. Check SOPS metadata exists
for file in secrets/**/*-secret.yaml; do
  if ! grep -q "sops:" "$file"; then
    echo "Missing SOPS metadata: $file"
  fi
done

# 3. Validate kustomizations build
kustomize build secrets/

# 4. Test Flux build
flux build kustomization infrastructure --path ./infrastructure
```

### After Deployment

```bash
# 1. Check secret exists
kubectl get secret <secret-name> -n <namespace>

# 2. Verify secret has correct keys
kubectl get secret <secret-name> -n <namespace> -o jsonpath='{.data}' | jq

# 3. Check application is using secret
kubectl describe pod <pod-name> -n <namespace> | grep -A 5 "Mounts:"
```

## Quick Reference

### Common Commands

```bash
# Encrypt new secret
sops --encrypt --in-place secrets/shared/new-secret.yaml

# View encrypted secret
sops --decrypt secrets/shared/secret.yaml

# Edit encrypted secret
sops secrets/shared/secret.yaml

# Re-encrypt all secrets
find secrets/ -name "*-secret.yaml" -exec sops updatekeys {} \;

# Validate SOPS is working
sops --version

# Check age public key
grep "age:" .sops.yaml
```

### Emergency Procedures

**Lost Age Private Key:**
1. Generate new age key pair
2. Update cluster secret: `kubectl create secret generic sops-age -n flux-system --from-file=age.agekey=new.agekey --dry-run=client -o yaml | kubectl apply -f -`
3. Update `.sops.yaml` with new public key
4. Re-encrypt all secrets: `find secrets/ -name "*-secret.yaml" -exec sops updatekeys {} \;`
5. Commit and push changes

**Compromised Secret:**
1. Immediately rotate the compromised credentials in the actual service
2. Update the secret file with new credentials
3. Re-encrypt: `sops --encrypt --in-place secrets/<category>/<secret-name>.yaml`
4. Commit and push immediately
5. Force Flux reconciliation: `flux reconcile kustomization infrastructure --with-source`
6. Verify new secret is deployed: `kubectl get secret <name> -n <namespace> -o yaml`
7. Document incident and update rotation schedule

## Additional Resources

- [SOPS Documentation](https://github.com/mozilla/sops)
- [Age Encryption](https://github.com/FiloSottile/age)
- [FluxCD SOPS Guide](https://fluxcd.io/flux/guides/mozilla-sops/)
- [Kubernetes Secrets](https://kubernetes.io/docs/concepts/configuration/secret/)
- Project Security Policy: `../../../../../SECURITY.md`

---

**Last Updated**: November 18, 2025  
**Maintainer**: Platform Team  
**Security Contact**: security@example.com
