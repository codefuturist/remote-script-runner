# Secrets Management for Staging Cluster

This directory contains SOPS-encrypted secrets for the staging FluxCD cluster.

## Prerequisites

- **SOPS**: `brew install sops`
- **Age key**: Located at `/Users/colin/Developer/Projects/personal/iac-catalog/age.agekey`
- The `.sops.yaml` configuration is already set up in the repository root

## Created Secrets

### 1. Authentik Secret (`authentik/authentik-secret.yaml`)

Contains credentials for Authentik identity provider:

- `redis-password`: Password for Authentik's Redis instance
- `postgresql-password`: Password for Authentik's PostgreSQL database
- `authentik-secret-key`: Secret key for cookie signing and cryptographic operations
- `smtp-password`: (Optional) SMTP password for email notifications

### 2. Homarr Secret (`homarr/homarr-secret.yaml`)

Contains database encryption key for Homarr:

- `db-encryption-key`: Encryption key for Homarr's database

## Encrypting Secrets

### Option 1: Using the Helper Script

```bash
cd /Users/colin/Developer/Projects/personal/iac-catalog
chmod +x scripts/encrypt-staging-secrets.sh
./scripts/encrypt-staging-secrets.sh
```

### Option 2: Manual Encryption

```bash
export SOPS_AGE_KEY_FILE=/Users/colin/Developer/Projects/personal/iac-catalog/age.agekey

# Encrypt authentik secret
sops --encrypt --in-place catalog/gitops/flux/clusters/staging/apps/production/authentik/authentik-secret.yaml

# Encrypt homarr secret
sops --encrypt --in-place catalog/gitops/flux/clusters/staging/apps/production/homarr/homarr-secret.yaml
```

## Editing Encrypted Secrets

SOPS allows you to edit encrypted files directly:

```bash
export SOPS_AGE_KEY_FILE=/Users/colin/Developer/Projects/personal/iac-catalog/age.agekey

# Edit authentik secret
sops catalog/gitops/flux/clusters/staging/apps/production/authentik/authentik-secret.yaml

# Edit homarr secret
sops catalog/gitops/flux/clusters/staging/apps/production/homarr/homarr-secret.yaml
```

The file will be decrypted in your editor, and automatically re-encrypted when you save and close it.

## Generating Secure Values

Replace the `CHANGE_ME_*` placeholder values with actual secrets:

```bash
# Generate a strong password (32 characters)
openssl rand -base64 32

# Generate a longer secret key (60 characters, for authentik-secret-key)
openssl rand -base64 60

# Generate hex string (alternative)
openssl rand -hex 32
```

## Required Changes Before Deployment

1. **Encrypt the secrets** (if not already encrypted):
   ```bash
   ./scripts/encrypt-staging-secrets.sh
   ```

2. **Edit and update placeholder values**:
   ```bash
   sops catalog/gitops/flux/clusters/staging/apps/production/authentik/authentik-secret.yaml
   ```
   - Replace `CHANGE_ME_REDIS_PASSWORD` with a strong password
   - Replace `CHANGE_ME_POSTGRESQL_PASSWORD` with a strong password
   - Replace `CHANGE_ME_AUTHENTIK_SECRET_KEY` with output from `openssl rand -base64 60`

   ```bash
   sops catalog/gitops/flux/clusters/staging/apps/production/homarr/homarr-secret.yaml
   ```
   - Replace `CHANGE_ME_HOMARR_DB_ENCRYPTION_KEY` with output from `openssl rand -base64 60`

3. **Verify encryption**:
   ```bash
   # Check that files are encrypted (should show encrypted data)
   cat catalog/gitops/flux/clusters/staging/apps/production/authentik/authentik-secret.yaml
   cat catalog/gitops/flux/clusters/staging/apps/production/homarr/homarr-secret.yaml
   ```

## FluxCD Integration

FluxCD will automatically decrypt these secrets during deployment using the age key stored in the cluster.

The secrets are referenced in the HelmRelease configurations:

- **Authentik**: Uses `authentik` secret for database and Redis passwords
- **Homarr**: Uses `homarr-db` secret for database encryption

## Security Notes

- ✅ Secrets are encrypted with age key `age1t8gm5avm9z5pquta4w2kaud7zn3c588mkk2shdpdskvp76wxh3gsxctyst`
- ✅ Only encrypted data sections (`data` and `stringData`) are encrypted
- ✅ Safe to commit encrypted secrets to Git
- ⚠️  Keep `age.agekey` file secure and never commit it to Git
- ⚠️  Ensure the same age key is configured in the FluxCD cluster for decryption

## Troubleshooting

### "no key could be found to encrypt"

Make sure `SOPS_AGE_KEY_FILE` environment variable is set:
```bash
export SOPS_AGE_KEY_FILE=/Users/colin/Developer/Projects/personal/iac-catalog/age.agekey
```

### "failed to decrypt"

Verify you're using the correct age key that matches the public key in `.sops.yaml`.

### FluxCD can't decrypt secrets

Ensure the age secret is created in the `flux-system` namespace:
```bash
cat age.agekey | kubectl create secret generic sops-age \
  --namespace=flux-system \
  --from-file=age.agekey=/dev/stdin
```
