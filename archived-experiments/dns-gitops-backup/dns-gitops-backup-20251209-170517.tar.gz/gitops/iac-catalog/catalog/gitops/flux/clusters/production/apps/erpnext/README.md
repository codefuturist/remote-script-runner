# ERPNext Deployment

Open source ERP system built on the Frappe Framework.

## Components

- **Nginx**: Frontend web server
- **Gunicorn**: Python application server
- **SocketIO**: Real-time updates
- **Workers**: Background job processors (default, short, long queues)
- **Scheduler**: Cron-like task scheduler
- **Redis**: Cache and queue storage (in-cluster)
- **MariaDB**: Database (external, via MariaDB operator)

## Post-Installation Steps

### 1. Create Initial Site

After the helm release is deployed, create your first ERPNext site:

```bash
# Generate the create-site job manifest
helm template erpnext -n erpnext frappe/erpnext \
  -f <(kubectl get hr erpnext -n erpnext -o jsonpath='{.spec.values}' | yq -P) \
  -s templates/job-create-site.yaml \
  --set jobs.createSite.enabled=true \
  --set jobs.createSite.siteName="erp.production.local" \
  --set jobs.createSite.adminPassword="YourSecurePassword" \
  --set jobs.createSite.installApps[0]=erpnext \
  > /tmp/create-site-job.yaml

# Apply the job
kubectl apply -f /tmp/create-site-job.yaml
```

Or manually via bench:

```bash
kubectl exec -it -n erpnext deploy/erpnext-gunicorn -- \
  bench new-site erp.production.local \
    --mariadb-root-password "$(kubectl get secret -n database mariadb-single-root -o jsonpath='{.data.password}' | base64 -d)" \
    --admin-password "YourSecurePassword" \
    --install-app erpnext
```

### 2. Configure DNS/Ingress

Ensure `erp.production.local` resolves to your cluster ingress IP.

### 3. First Login

1. Navigate to `http://erp.production.local`
2. Login with username `Administrator` and the admin password set during site creation

## Resource Summary

| Component    | CPU Request | Memory Request | CPU Limit | Memory Limit |
|-------------|-------------|----------------|-----------|--------------|
| Nginx       | 25m         | 64Mi           | 500m      | 256Mi        |
| Gunicorn    | 50m         | 256Mi          | 1000m     | 1Gi          |
| Worker-D    | 25m         | 128Mi          | 500m      | 512Mi        |
| Worker-S    | 10m         | 64Mi           | 300m      | 256Mi        |
| Worker-L    | 10m         | 128Mi          | 500m      | 512Mi        |
| Scheduler   | 10m         | 64Mi           | 200m      | 256Mi        |
| SocketIO    | 10m         | 32Mi           | 200m      | 128Mi        |
| Redis Cache | 10m         | 32Mi           | 200m      | 128Mi        |
| Redis Queue | 10m         | 32Mi           | 200m      | 128Mi        |
| **Total**   | **160m**    | **800Mi**      | **3600m** | **3.18Gi**   |

## Scaling

For production with higher load:

1. Enable HPA for nginx, gunicorn, and workers
2. Switch to ReadWriteMany storage (NFS) for multi-pod deployments
3. Consider external managed Redis for high availability
4. Increase worker replica counts based on queue depth

## Backup

Enable the backup job for production:

```yaml
jobs:
  backup:
    enabled: true
    siteName: "erp.production.local"
    withFiles: true
    push:
      enabled: true
      bucket: "erpnext-backups"
      # Configure S3-compatible storage
```

## Troubleshooting

Check logs:
```bash
kubectl logs -n erpnext -l app.kubernetes.io/name=erpnext-gunicorn
kubectl logs -n erpnext -l app.kubernetes.io/name=erpnext-worker-d
```

Bench console:
```bash
kubectl exec -it -n erpnext deploy/erpnext-gunicorn -- bench console
```
