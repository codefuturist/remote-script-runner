# Network Layer - Staging Cluster
This directory consolidates all network-related infrastructure components for the staging Kubernetes cluster.
## Components
### Ingress Controllers
- **Traefik Internal**: Internal traffic routing
- **Traefik Public**: Public-facing traffic
- Configured with staging-appropriate resource limits
- Lower replica counts than production
### Certificate Management
- **cert-manager**: Automated TLS certificate management
- Let's Encrypt staging environment for testing
- Automatic certificate renewal
### Load Balancing
- **MetalLB**: Bare-metal load balancer
- IP address allocation for services
- BGP or Layer 2 mode configuration
### Middlewares
- **Traefik Middlewares**: Request/response transformations
- Rate limiting
- Header modifications
- Authentication
## Staging-Specific Configuration
Staging network layer differs from production:
- **Lower resource limits**: Reduced CPU/memory allocations
- **Fewer replicas**: Single replica for non-critical components
- **Staging certificates**: Let's Encrypt staging for testing
- **Relaxed rate limits**: Higher limits for development testing
## Directory Structure
```
network/
├── kustomization.yaml          # This layer's orchestration
├── README.md                   # This file
└── (references to sibling directories)
    ├── ../ingress/             # Ingress controllers
    ├── ../cert-manager/        # Certificate management
    ├── ../metallb/             # Load balancer
    └── ../traefik-middlewares/ # Middleware configs
```
## Dependencies
The network layer depends on:
1. **Infrastructure Sources**: Helm repositories must be available
2. **Infrastructure Namespaces**: Target namespaces must exist
3. **Infrastructure Configs**: Cluster-wide configs must be applied
## Health Checks
Monitor network layer health:
```bash
# Check ingress controllers
kubectl get pods -n ingress
# Check cert-manager
kubectl get pods -n cert-manager
kubectl get certificates -A
# Check MetalLB
kubectl get pods -n metallb-system
kubectl get ipaddresspools -n metallb-system
```
## Troubleshooting
### Certificate Issues
```bash
# Check certificate requests
kubectl get certificaterequests -A
kubectl describe certificaterequest <name> -n <namespace>
# Check cert-manager logs
kubectl logs -n cert-manager deploy/cert-manager
```
### Ingress Issues
```bash
# Check Traefik status
kubectl get ingressroute -A
kubectl logs -n ingress deploy/traefik-internal
```
### Load Balancer Issues
```bash
# Check MetalLB status
kubectl get ipaddresspool -n metallb-system
kubectl logs -n metallb-system -l app=metallb
```
## Related Documentation
- [Staging Infrastructure Overview](../README.md)
- [Production Network Layer](../../production/infrastructure/network/README.md)
- [Traefik Documentation](https://doc.traefik.io/traefik/)
- [cert-manager Documentation](https://cert-manager.io/docs/)
- [MetalLB Documentation](https://metallb.universe.tf/)
