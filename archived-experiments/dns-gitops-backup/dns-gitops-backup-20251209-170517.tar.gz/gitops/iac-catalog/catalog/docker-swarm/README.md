# CrowdSec + Traefik Docker Swarm Stack

Secure reverse proxy with CrowdSec threat protection for Docker Swarm.

## Architecture

```
Internet (80/443) → Traefik → CrowdSec Bouncer → Your Services
                      ↓              ↓
                   Access Logs → CrowdSec LAPI (threat detection)
```

## Features

- **Traefik v3.6** - Modern reverse proxy with HTTP/3 support
- **CrowdSec** - Collaborative security engine with real-time threat protection
- **Default Protection** - All HTTPS traffic protected by CrowdSec
- **Automatic HTTPS** - Let's Encrypt integration
- **High Availability** - Multiple bouncer replicas

## Prerequisites

- Docker Swarm initialized
- Ports 80 and 443 available
- Domain names pointing to the swarm

## Quick Start

### 1. Generate CrowdSec API Key

First, deploy just CrowdSec to generate the bouncer API key:

```bash
# Navigate to the directory
cd ~/docker-compose/crowdsec-traefik/

# Deploy CrowdSec only
docker stack deploy -c <(docker-compose config crowdsec) crowdsec-init

# Wait for CrowdSec to start (30 seconds)
sleep 30

# Generate bouncer API key
BOUNCER_KEY=$(docker exec $(docker ps -q -f name=crowdsec) cscli bouncers add traefik-bouncer -o raw)
echo "Generated bouncer key: $BOUNCER_KEY"

# Save to .env file
echo "CROWDSEC_BOUNCER_KEY=$BOUNCER_KEY" > .env

# Remove init stack
docker stack rm crowdsec-init
```

### 2. Deploy Full Stack

```bash
# Deploy the complete stack
docker stack deploy -c crowdsec-traefik-stack.yml security

# Check status
docker service ls | grep security
docker service logs -f security_traefik
```

### 3. Verify Setup

```bash
# Check CrowdSec status
docker exec $(docker ps -q -f name=crowdsec_crowdsec) cscli metrics

# Check bouncers
docker exec $(docker ps -q -f name=crowdsec_crowdsec) cscli bouncers list

# Test the whoami service
curl -k https://whoami.pandia.io
```

## Configuration

### Environment Variables

Create a `.env` file:

```bash
# CrowdSec bouncer API key (generated in step 1)
CROWDSEC_BOUNCER_KEY=your-generated-key-here
```

### Custom Domains

Edit `crowdsec-traefik-stack.yml` and change:
- `traefik.pandia.io` → your Traefik dashboard domain
- `whoami.pandia.io` → your test service domain
- `admin@pandia.io` → your email for Let's Encrypt

### Disable CrowdSec on Specific Routes

For services that should bypass CrowdSec (like health checks):

```yaml
services:
  myservice:
    deploy:
      labels:
        - traefik.enable=true
        - traefik.http.routers.myservice.rule=Host(`myservice.example.com`)
        - traefik.http.routers.myservice.entrypoints=web
        # Use web entrypoint (HTTP) to bypass websecure middleware
```

Or override the middleware:

```yaml
        - traefik.http.routers.myservice.middlewares=security-headers@file
        # This skips CrowdSec but keeps other security headers
```

## Management

### CrowdSec Commands

```bash
# Get a shell in CrowdSec container
CROWDSEC_CONTAINER=$(docker ps -q -f name=crowdsec_crowdsec)

# View active decisions (bans)
docker exec $CROWDSEC_CONTAINER cscli decisions list

# View alerts
docker exec $CROWDSEC_CONTAINER cscli alerts list

# Unban an IP
docker exec $CROWDSEC_CONTAINER cscli decisions delete --ip 1.2.3.4

# Whitelist an IP permanently
docker exec $CROWDSEC_CONTAINER cscli decisions add \
  --ip 192.168.1.0/24 \
  --type whitelist \
  --duration 8760h

# View installed scenarios
docker exec $CROWDSEC_CONTAINER cscli scenarios list

# View hub status
docker exec $CROWDSEC_CONTAINER cscli hub list
```

### Traefik Dashboard

Access at: `https://traefik.pandia.io`

Default credentials (CHANGE THESE):
- Username: `admin`
- Password: `admin`

To generate a new password hash:

```bash
echo $(htpasswd -nb admin your-password-here) | sed -e 's/\$/\$\$/g'
```

Update the hash in `crowdsec-traefik-stack.yml` line 49.

## Monitoring

### Metrics

Traefik exposes Prometheus metrics at:
- `http://<traefik-ip>:8080/metrics`

### Logs

```bash
# Traefik access logs
docker service logs -f security_traefik

# CrowdSec logs
docker service logs -f security_crowdsec

# Bouncer logs
docker service logs -f security_bouncer-traefik
```

## Scaling

```bash
# Scale bouncer replicas
docker service scale security_bouncer-traefik=4

# Check service status
docker service ps security_bouncer-traefik
```

## Troubleshooting

### Bouncer Not Connecting

```bash
# Check bouncer logs
docker service logs security_bouncer-traefik

# Verify API key
docker exec $(docker ps -q -f name=crowdsec_crowdsec) \
  cscli bouncers list
```

### Traefik Not Starting

```bash
# Check Traefik logs
docker service logs security_traefik

# Verify configuration
docker config inspect security_traefik_dynamic_config
```

### All Traffic Blocked

```bash
# Check CrowdSec decisions
docker exec $(docker ps -q -f name=crowdsec_crowdsec) \
  cscli decisions list

# Check if your IP is banned
docker exec $(docker ps -q -f name=crowdsec_crowdsec) \
  cscli decisions list --ip YOUR_IP
```

## Updating

```bash
# Update images
docker service update --image traefik:v3.6 security_traefik
docker service update --image crowdsecurity/crowdsec:latest security_crowdsec
docker service update --image fbonalair/traefik-crowdsec-bouncer:latest security_bouncer-traefik
```

## Ports

The stack uses the following ports on the host:

| Port | Protocol | Service | Description |
|------|----------|---------|-------------|
| 80 | TCP | Traefik | HTTP (redirects to HTTPS) |
| 443 | TCP | Traefik | HTTPS |
| 443 | UDP | Traefik | HTTP/3 (QUIC) |

## Security Considerations

1. **Change default credentials** for Traefik dashboard
2. **Restrict dashboard access** by IP if possible
3. **Monitor CrowdSec alerts** regularly
4. **Keep images updated** for security patches
5. **Use strong Let's Encrypt** production certificates

## Files

- `crowdsec-traefik-stack.yml` - Main stack definition
- `traefik/dynamic-config.yml` - Traefik dynamic configuration
- `crowdsec/acquis.yaml` - CrowdSec log acquisition config
- `.env` - Environment variables (create this)

## References

- [Traefik Documentation](https://doc.traefik.io/traefik/)
- [CrowdSec Documentation](https://docs.crowdsec.net/)
- [Docker Swarm Mode](https://docs.docker.com/engine/swarm/)
