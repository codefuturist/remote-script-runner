#!/usr/bin/env bash
set -euo pipefail

# Quick deployment script for CrowdSec stack
# Reads .env and deploys with proper environment variables

if [ ! -f .env ]; then
    echo "Error: .env file not found"
    exit 1
fi

# Source environment
source .env

# Export for docker stack deploy with correct variable name
export CROWDSEC_BOUNCER_API_KEY="$CROWDSEC_BOUNCER_KEY"

# Deploy
echo "Deploying CrowdSec stack..."
docker stack deploy -c crowdsec-only-stack.yml crowdsec

echo "Done! Check status with: docker service ls --filter name=crowdsec"
