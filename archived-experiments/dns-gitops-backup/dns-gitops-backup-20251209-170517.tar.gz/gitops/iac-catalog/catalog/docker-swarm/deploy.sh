#!/usr/bin/env bash
set -euo pipefail

# CrowdSec + Traefik Docker Swarm Deployment Script
# Usage: ./deploy.sh [init|deploy|remove|status]

STACK_NAME="crowdsec"
COMPOSE_FILE="crowdsec-only-stack.yml"
ENV_FILE=".env"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if Docker Swarm is initialized
check_swarm() {
    if ! docker info | grep -q "Swarm: active"; then
        log_error "Docker Swarm is not initialized"
        log_info "Run: docker swarm init"
        exit 1
    fi
    log_info "Docker Swarm is active"
}

# Initialize - Generate bouncer API key
init() {
    log_info "Initializing CrowdSec API key..."
    
    # Start temporary CrowdSec container
    log_info "Starting temporary CrowdSec container..."
    docker run -d --name crowdsec-temp \
        -v crowdsec-config:/etc/crowdsec \
        -v crowdsec-data:/var/lib/crowdsec/data \
        crowdsecurity/crowdsec:latest
    
    # Wait for CrowdSec to be ready
    log_info "Waiting for CrowdSec to initialize (45 seconds)..."
    sleep 45
    
    # Generate bouncer key
    log_info "Generating bouncer API key..."
    BOUNCER_KEY=$(docker exec crowdsec-temp cscli bouncers add traefik-bouncer -o raw 2>/dev/null || true)
    
    if [ -z "$BOUNCER_KEY" ]; then
        log_error "Failed to generate bouncer key"
        docker stop crowdsec-temp 2>/dev/null || true
        docker rm crowdsec-temp 2>/dev/null || true
        exit 1
    fi
    
    # Save to .env file
    echo "CROWDSEC_BOUNCER_KEY=$BOUNCER_KEY" > $ENV_FILE
    log_info "Bouncer key saved to $ENV_FILE"
    log_info "Key: $BOUNCER_KEY"
    
    # Remove temporary container (keep volumes for reuse)
    log_info "Removing temporary container..."
    docker stop crowdsec-temp
    docker rm crowdsec-temp
    
    log_info "Initialization complete! Run './deploy.sh deploy' to deploy the full stack"
}

# Deploy the full stack
deploy() {
    log_info "Deploying CrowdSec + Traefik stack..."
    
    # Check if .env exists
    if [ ! -f "$ENV_FILE" ]; then
        log_error "$ENV_FILE not found. Run './deploy.sh init' first"
        exit 1
    fi
    
    # Source .env
    set -a
    source $ENV_FILE
    set +a
    
    # Validate bouncer key
    if [ -z "${CROWDSEC_BOUNCER_KEY:-}" ]; then
        log_error "CROWDSEC_BOUNCER_KEY not set in $ENV_FILE"
        exit 1
    fi
    
    # Deploy stack
    docker stack deploy -c $COMPOSE_FILE $STACK_NAME
    
    log_info "Stack deployed successfully"
    log_info "Waiting for services to start..."
    sleep 10
    
    status
}

# Show stack status
status() {
    log_info "Service status:"
    docker service ls --filter "label=com.docker.stack.namespace=$STACK_NAME"
    
    echo ""
    log_info "Stack tasks:"
    docker stack ps $STACK_NAME --no-trunc
}

# Remove the stack
remove() {
    log_warn "Removing $STACK_NAME stack..."
    docker stack rm $STACK_NAME
    log_info "Stack removed"
}

# Logs
logs() {
    SERVICE=${1:-traefik}
    log_info "Showing logs for ${STACK_NAME}_${SERVICE}..."
    docker service logs -f "${STACK_NAME}_${SERVICE}"
}

# Main
main() {
    check_swarm
    
    case "${1:-help}" in
        init)
            init
            ;;
        deploy)
            deploy
            ;;
        remove|rm)
            remove
            ;;
        status)
            status
            ;;
        logs)
            logs "${2:-traefik}"
            ;;
        *)
            echo "Usage: $0 {init|deploy|remove|status|logs [service]}"
            echo ""
            echo "Commands:"
            echo "  init    - Generate CrowdSec bouncer API key"
            echo "  deploy  - Deploy the full stack"
            echo "  remove  - Remove the stack"
            echo "  status  - Show stack status"
            echo "  logs    - Show logs for a service (default: traefik)"
            exit 1
            ;;
    esac
}

main "$@"
