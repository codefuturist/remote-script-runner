# CrowdSec Docker Swarm - Current Status

## Deployment Status

### ✅ Working Components
- **CrowdSec LAPI**: Running (1/1 replica)
  - Successfully deployed with hub operations disabled
  - Environment: `NO_HUB_UPGRADE=true`, `NO_CAPI_REGISTER=true`
  - This avoids DNS issues in Docker Swarm DNS resolver

### ❌ Issues
- **CrowdSec Bouncer**: Not running (0/1 replicas)
  - Container fails healthcheck
  - Exit code 2: unhealthy container
  - Environment variables may not be properly passed in Swarm mode

## Root Causes

### 1. DNS Resolution Issues
Docker Swarm's internal DNS resolver (127.0.0.11:53) fails to resolve external domains like `version.crowdsec.net` and `api.crowdsec.net`. This causes CrowdSec's hub update operations to fail.

**Solution**: Disabled hub operations with environment variables:
- `NO_HUB_UPGRADE=true`
- `NO_CAPI_REGISTER=true`

### 2. Environment Variable Propagation
Docker Swarm doesn't automatically load `.env` files. Environment variables must be explicitly exported before running `docker stack deploy`.

**Workaround**: Created `deploy-crowdsec.sh` script that:
1. Sources the `.env` file
2. Exports `CROWDSEC_BOUNCER_API_KEY`
3. Runs `docker stack deploy`

### 3. Bouncer Health Check Failures
The bouncer container starts but fails its healthcheck, causing Docker Swarm to repeatedly restart it.

**Possible causes**:
- Cannot reach CrowdSec LAPI on `crowdsec:8080`
- Network connectivity issues between `traefik` and `crowdsec-internal` networks
- API key not properly registered in CrowdSec

## Recommended Solutions

### Option 1: Use Docker Compose Instead of Swarm (Recommended)
Docker Compose has better support for environment files and simpler networking. Convert the stack to use `docker-compose.yml` and run with `docker-compose up -d`.

### Option 2: Use Docker Secrets
Store the API key in a Docker secret instead of environment variables:

```bash
# Create secret
echo "0Sj/y1Qm20Tmnxv2Vfs3ZA13avGSZZb+kfzICVEowkQ" | docker secret create crowdsec_bouncer_key -

# Update compose file to use secrets instead of environment variables
```

### Option 3: Manual Container Deployment
Deploy CrowdSec and bouncer as regular Docker containers (not in Swarm mode) for easier debugging and configuration.

### Option 4: Firewall-Level Protection
If CrowdSec bouncer integration proves problematic, implement basic security at the firewall level:

```bash
# Install fail2ban on the host
sudo apt-get install fail2ban

# Configure fail2ban with Traefik logs
# This provides similar brute-force protection without the bouncer complexity
```

## Current Network Architecture

```
┌─────────────────────┐
│   traefik_traefik   │  (existing, ports 80/443)
│  (separate stack)   │
└──────────┬──────────┘
           │
           │ traefik network (overlay, external)
           │
┌──────────┴──────────────────────────────┐
│                                          │
│  ┌──────────────────┐  ┌──────────────┐ │
│  │ crowdsec_bouncer │  │crowdsec_whoami│ │
│  │   (middleware)   │  │ (test service) │ │
│  └─────────┬────────┘  └────────────────┘ │
│            │                               │
│            │ crowdsec-internal (overlay)   │
│            │                               │
│  ┌─────────┴────────┐                     │
│  │ crowdsec_crowdsec│                     │
│  │      (LAPI)      │                     │
│  └──────────────────┘                     │
│                                            │
│         crowdsec stack                     │
└────────────────────────────────────────────┘
```

## Files Created

- `crowdsec-only-stack.yml`: Compose file for CrowdSec integration with existing Traefik
- `crowdsec-traefik-stack.yml`: Full stack with Traefik + CrowdSec (standalone)
- `deploy.sh`: Full deployment script with init/deploy/status/logs commands
- `deploy-crowdsec.sh`: Quick deployment script (currently used)
- `crowdsec/acquis.yaml`: Log acquisition config for Docker logs
- `traefik/dynamic-config.yml`: Traefik middleware configurations
- `README.md`: Comprehensive deployment guide

## Next Steps for Production

1. **Debug bouncer connectivity**:
   ```bash
   # Test if bouncer can reach LAPI
   docker run --rm --network crowdsec-internal curlimages/curl curl -v http://crowdsec:8080/health
   ```

2. **Verify API key registration**:
   ```bash
   docker exec $(docker ps -q -f name=crowdsec_crowdsec) cscli bouncers list
   ```

3. **Check bouncer logs in detail**:
   ```bash
   docker service logs crowdsec_bouncer --raw --follow
   ```

4. **Alternative**: Deploy on Kubernetes where it's proven to work, or use the existing production cluster setup which is already protecting public ingresses.

## Comparison: Kubernetes vs Docker Swarm

| Feature | Kubernetes (Production) | Docker Swarm (pi-nvme) |
|---------|-------------------------|------------------------|
| CrowdSec LAPI | ✅ Running | ✅ Running |
| Bouncer | ✅ Running (2 replicas) | ❌ Failed (healthcheck) |
| Traefik Integration | ✅ Active on websecure | ❌ Not configured |
| Default Protection | ✅ Enabled | ❌ Not available |
| DNS Issues | ✅ Resolved | ⚠️ Workaround applied |
| Resource Requests | ✅ Optimized (5-10m CPU) | N/A |

## Conclusion

The Kubernetes deployment in the production cluster (`k3s-prod`) is fully operational and protecting all public HTTPS ingresses. The Docker Swarm deployment on `pi-nvme` has CrowdSec LAPI running but the bouncer integration needs additional troubleshooting or an alternative approach.

For immediate security on the pi-nvme host, consider:
1. Using the existing Traefik rate limiting middleware
2. Implementing fail2ban at the host level
3. Configuring firewall rules for basic protection
4. Migrating services to the production Kubernetes cluster where CrowdSec is active
