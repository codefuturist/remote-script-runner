# Catalog - Template Library

## Purpose

This directory contains **reusable, versioned templates** for all infrastructure and applications. Templates serve as the foundation for deployments across all environments.

## Structure

```text
catalog/
├── cloud/                        # Cloud provider templates
│   ├── aws/
│   ├── azure/
│   └── gcp/
├── containers/                   # Container-based deployments
│   ├── docker/
│   ├── docker-swarm/
│   └── kubernetes/
├── gitops/                       # GitOps tool configurations
│   ├── argocd/
│   ├── fleet/
│   └── flux/
├── governance/                   # Policies, runbooks, standards
│   ├── policies/
│   ├── runbooks/
│   └── standards/
├── hybrid/                       # Hybrid cloud patterns
│   ├── connectivity/
│   ├── edge-cloud/
│   └── multi-cloud/
├── on-premises/                  # On-premises infrastructure
│   ├── bare-metal/
│   ├── edge/
│   ├── openstack/
│   └── vmware/
├── self-hosted/                  # Self-hosted services
│   ├── cicd/                     # CI/CD platforms
│   ├── databases/                # Database servers
│   ├── enterprise/               # Enterprise applications (ERP, etc.)
│   ├── monitoring/               # Monitoring stacks
│   ├── networking/               # Network services
│   └── registries/               # Container registries
└── templates/                    # Architectural patterns
    ├── application-patterns/     # Application architectures
    ├── data-patterns/            # Data management patterns
    └── infrastructure-patterns/  # Infrastructure patterns
```

## Template Categories Explained

### `cloud/` - Cloud Provider Templates

Templates specific to cloud providers:

- **aws/** - AWS-specific resources (EC2, RDS, S3, etc.)
- **azure/** - Azure resources (VMs, Storage, SQL, etc.)
- **gcp/** - Google Cloud Platform resources

**Use when**: Deploying to public cloud infrastructure.

### `containers/` - Container-Based Deployments

Container orchestration and deployment templates:

- **docker/** - Docker and Docker Compose stacks
- **docker-swarm/** - Docker Swarm configurations
- **kubernetes/** - Kubernetes manifests, Helm charts, operators

**Use when**: Deploying containerized applications.

### `gitops/` - GitOps Tools

GitOps tool configurations and patterns:

- **argocd/** - ArgoCD applications and projects
- **fleet/** - Rancher Fleet configurations
- **flux/** - FluxCD configurations

**Use when**: Setting up or configuring GitOps tooling.

### `governance/` - Policies, Runbooks, Standards

Governance and compliance templates:

- **policies/** - OPA policies, admission controllers
- **runbooks/** - Operational runbooks
- **standards/** - Configuration standards

**Use when**: Implementing governance controls.

### `hybrid/` - Hybrid Cloud Patterns

Hybrid and multi-cloud templates:

- **connectivity/** - VPN, interconnects
- **edge-cloud/** - Edge computing patterns
- **multi-cloud/** - Multi-cloud architectures

**Use when**: Building hybrid or multi-cloud solutions.

### `on-premises/` - On-Premises Infrastructure

On-premises infrastructure templates:

- **bare-metal/** - Bare metal provisioning
- **edge/** - Edge computing deployments
- **openstack/** - OpenStack resources
- **vmware/** - VMware resources

**Use when**: Deploying to on-premises infrastructure.

### `self-hosted/` - Self-Hosted Services

Self-hosted application templates:

- **cicd/** - GitLab, Jenkins, Drone, etc.
- **databases/** - PostgreSQL, MySQL, MongoDB, Redis, etc.
- **enterprise/** - ERPNext and other enterprise business applications
- **monitoring/** - Prometheus, Grafana, Loki, etc.
- **networking/** - Traefik, HAProxy, etc.
- **registries/** - Docker Registry, Harbor, etc.

**Use when**: Running services in your own infrastructure.

### `templates/` - Architectural Patterns

Technology-agnostic architectural patterns:

- **application-patterns/** - 12-factor apps, microservices, etc.
- **data-patterns/** - Replication, backup, ETL, etc.
- **infrastructure-patterns/** - HA, DR, scaling, etc.

**Use when**: Implementing standard architectural patterns.

## Template Structure

Each template should follow this structure:

```text
template-name/
├── README.md                     # Template documentation
├── template.yml                  # Template metadata
├── [deployment-files]            # docker-compose.yml, k8s manifests, etc.
└── examples/                     # Usage examples (optional)
```

### Template Metadata (template.yml)

Every template should have a metadata file:

```yaml
name: postgresql
version: 1.0.0
category: self-hosted/databases
description: PostgreSQL database server with backup support
tags:
  - database
  - postgresql
  - sql
variables:
  - name: db_name
    required: true
    description: Database name
  - name: db_password
    required: true
    description: Database password
  - name: backup_enabled
    required: false
    default: true
    description: Enable automated backups
```

## Using Templates

Templates are consumed by the CLI tool:

```bash
./scripts/cli/configure.sh \
  --template catalog/self-hosted/databases/postgresql \
  --instance my-db-01 \
  --environment production \
  --target db-server-01 \
  --param db_name=myapp \
  --param db_password=secure123
```

This creates a configured instance in `deployments/production/my-db-01/`.

## Creating New Templates

### 1. Choose the Right Category

- **Technology-specific?** → Use `cloud/`, `containers/`, or `self-hosted/`
- **Cross-cutting pattern?** → Use `templates/`
- **Governance?** → Use `governance/`
- **Hybrid/multi-cloud?** → Use `hybrid/`

### 2. Create Template Structure

```bash
mkdir -p catalog/self-hosted/databases/postgresql
cd catalog/self-hosted/databases/postgresql
```

### 3. Add Required Files

```bash
touch README.md template.yml docker-compose.yml
```

### 4. Document Thoroughly

Your README.md should include:

- Purpose and description
- Prerequisites
- Variables/parameters
- Usage examples
- Troubleshooting tips

### 5. Test Extensively

```bash
# Test template configuration
./scripts/cli/configure.sh \
  --template catalog/self-hosted/databases/postgresql \
  --instance test-db \
  --environment development \
  --target dev-server-01 \
  --param db_name=test

# Test deployment
./scripts/automation/deploy.sh --instance test-db --environment development
```

### 6. Submit for Review

See [CONTRIBUTING.md](../CONTRIBUTING.md) for the contribution process.

## Template Best Practices

### 1. Keep Templates Generic

Use variables for customization:

```yaml
# ❌ Bad - Hardcoded values
services:
  db:
    image: postgres:14
    environment:
      POSTGRES_DB: myapp

# ✅ Good - Parameterized
services:
  db:
    image: postgres:${POSTGRES_VERSION}
    environment:
      POSTGRES_DB: ${DB_NAME}
```

### 2. Document All Variables

List all variables in template.yml and README.md with:

- Name
- Description
- Required/optional
- Default value (if any)
- Example values

### 3. Include Examples

Provide working examples in README.md:

```bash
# Example: Basic deployment
./scripts/cli/configure.sh \
  --template catalog/self-hosted/databases/postgresql \
  --instance prod-db \
  --environment production \
  --target db-server-01 \
  --param db_name=production_db

# Example: With custom settings
./scripts/cli/configure.sh \
  --template catalog/self-hosted/databases/postgresql \
  --instance prod-db-replica \
  --environment production \
  --target db-server-02 \
  --param db_name=production_db \
  --param backup_enabled=false \
  --param max_connections=200
```

### 4. Follow Naming Conventions

- **Directories**: lowercase with hyphens (`my-template-name`)
- **Files**: lowercase with hyphens (`docker-compose.yml`, `template.yml`)
- **Variables**: UPPERCASE with underscores (`DB_NAME`, `POSTGRES_VERSION`)

### 5. Version Your Templates

Use semantic versioning in template.yml:

- **Major** (1.0.0 → 2.0.0): Breaking changes
- **Minor** (1.0.0 → 1.1.0): New features, backwards compatible
- **Patch** (1.0.0 → 1.0.1): Bug fixes

### 6. Test in All Environments

Test templates in:

- Development (quick iteration)
- Staging (production-like testing)
- Production (controlled rollout)

### 7. Include Health Checks

Add health checks where appropriate:

```yaml
services:
  app:
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8080/health"]
      interval: 30s
      timeout: 10s
      retries: 3
```

### 8. Document Dependencies

Clearly list:

- Infrastructure requirements (CPU, memory, disk)
- Network requirements (ports, connectivity)
- External dependencies (databases, APIs, etc.)
- Prerequisites (software, tools, access)

## Finding Templates

### By Technology

```bash
# Docker Compose templates
ls catalog/containers/docker/
ls catalog/self-hosted/

# Kubernetes templates
ls catalog/containers/kubernetes/

# Cloud templates
ls catalog/cloud/aws/
ls catalog/cloud/azure/
ls catalog/cloud/gcp/
```

### By Use Case

```bash
# Databases
find catalog -type d -name "*database*"

# Monitoring
find catalog -type d -name "*monitoring*"

# CI/CD
find catalog -type d -name "*cicd*"
```

### Search Tool (if available)

```bash
# Search by name or description
./tools/search-templates.sh "postgresql"

# List all templates
./tools/list-templates.sh
```

## Template Lifecycle

1. **Development** - Create and test template locally
2. **Review** - Submit PR, get feedback
3. **Merge** - Template available in catalog
4. **Usage** - Teams use template for deployments
5. **Maintenance** - Bug fixes, updates, new versions
6. **Deprecation** - Mark old versions as deprecated
7. **Retirement** - Remove after migration period

## Migration Between Template Versions

When updating templates, use migration scripts:

```bash
./scripts/migrations/template-migration/migrate.sh \
  --template postgresql \
  --from-version 1.0.0 \
  --to-version 2.0.0 \
  --environment production
```

## Troubleshooting

### Template Not Found

```bash
# Verify template exists
ls -la catalog/self-hosted/databases/postgresql/

# Check template.yml is present
cat catalog/self-hosted/databases/postgresql/template.yml
```

### Configuration Fails

```bash
# Validate template
./tools/validators/validate-template.sh \
  catalog/self-hosted/databases/postgresql

# Check required variables
cat catalog/self-hosted/databases/postgresql/template.yml | grep -A 10 variables
```

### Deployment Issues

Check the deployment guide in the template's README.md.

## Related Documentation

- [STRUCTURE.md](../STRUCTURE.md) - Overall repository structure
- [deployments/README.md](../deployments/README.md) - How to deploy templates
- [examples/](../examples/) - Complete examples
- [CONTRIBUTING.md](../CONTRIBUTING.md) - Contribution guidelines

## Quick Links

- **Browse Cloud Templates**: [cloud/](./cloud/)
- **Browse Container Templates**: [containers/](./containers/)
- **Browse Self-Hosted Services**: [self-hosted/](./self-hosted/)
- **Browse Patterns**: [templates/](./templates/)
- **Complete Examples**: [../examples/](../examples/)
