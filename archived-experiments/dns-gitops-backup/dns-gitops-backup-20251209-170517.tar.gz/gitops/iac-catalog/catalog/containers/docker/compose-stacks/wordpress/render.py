#!/usr/bin/env python3
"""
IaC Catalog Template Renderer

Generic Jinja2 template renderer for iac-catalog templates.
Supports multi-environment configuration with layered overrides.

Usage:
    python render.py                           # Render with base config
    python render.py --env dev                 # Render for dev environment
    python render.py --env production          # Render for production
    python render.py --output custom.yml       # Custom output file
    python render.py --values custom-values.yml # Additional values

Examples:
    # Development deployment
    python render.py --env dev --output dev-compose.yml
    
    # Production with custom values
    python render.py --env production --values values/prod-secrets.yml
    
    # Check rendering without writing
    python render.py --env staging --dry-run
"""

import os
import sys
import yaml
import argparse
from pathlib import Path
from jinja2 import Environment, FileSystemLoader, StrictUndefined
from typing import Dict, List, Optional

__version__ = "1.0.0"


class TemplateRenderer:
    """Renders Jinja2 templates with multi-environment configuration."""
    
    def __init__(self, template_dir: Path, repo_root: Optional[Path] = None):
        """
        Initialize the template renderer.
        
        Args:
            template_dir: Directory containing the template
            repo_root: Root of the repository (auto-detected if not provided)
        """
        self.template_dir = template_dir.resolve()
        self.repo_root = repo_root or self._find_repo_root()
        self.templates_path = self.template_dir / 'templates'
        self.environments_path = self.template_dir / 'environments'
        self.values_path = self.template_dir / 'values'
        
        # Setup Jinja2 environment with all search paths
        search_paths = self._get_search_paths()
        self.jinja_env = Environment(
            loader=FileSystemLoader(search_paths),
            trim_blocks=True,
            lstrip_blocks=True,
            undefined=StrictUndefined
        )
    
    def _find_repo_root(self) -> Path:
        """Find the repository root by looking for catalog/ directory."""
        current = self.template_dir
        while current != current.parent:
            if (current / 'catalog').exists():
                return current
            current = current.parent
        return self.template_dir
    
    def _get_search_paths(self) -> List[str]:
        """Get all Jinja2 template search paths."""
        paths = [
            str(self.templates_path),
            str(self.template_dir),
            str(self.repo_root),
        ]
        
        # Add template subdirectories
        if self.templates_path.exists():
            for subdir in ['macros', 'partials', 'kubernetes', 'terraform']:
                path = self.templates_path / subdir
                if path.exists():
                    paths.append(str(path))
        
        # Add library paths
        libraries_path = self.repo_root / 'catalog' / '_libraries'
        if libraries_path.exists():
            paths.append(str(libraries_path))
            for subdir in libraries_path.rglob('*'):
                if subdir.is_dir():
                    paths.append(str(subdir))
        
        return paths
    
    def load_config(self, environment: Optional[str] = None, 
                    additional_values: Optional[List[str]] = None) -> Dict:
        """
        Load configuration with layering: base -> environment -> additional values.
        
        Args:
            environment: Environment name (dev, staging, production)
            additional_values: Additional YAML files to merge
            
        Returns:
            Merged configuration dictionary
        """
        config = {}
        
        # Load base configuration
        base_config = self.environments_path / 'base.yml'
        if base_config.exists():
            with open(base_config) as f:
                config.update(yaml.safe_load(f) or {})
        
        # Load environment-specific configuration
        if environment:
            env_config = self.environments_path / f'{environment}.yml'
            if env_config.exists():
                with open(env_config) as f:
                    config.update(yaml.safe_load(f) or {})
            else:
                print(f"Warning: Environment config not found: {env_config}", 
                      file=sys.stderr)
        
        # Load additional values files
        if additional_values:
            for values_file in additional_values:
                values_path = Path(values_file)
                if not values_path.is_absolute():
                    values_path = self.template_dir / values_path
                
                if values_path.exists():
                    with open(values_path) as f:
                        config.update(yaml.safe_load(f) or {})
                else:
                    print(f"Warning: Values file not found: {values_path}", 
                          file=sys.stderr)
        
        return config
    
    def render(self, template_name: str = 'docker-compose.j2', 
               config: Optional[Dict] = None) -> str:
        """
        Render a template with the provided configuration.
        
        Args:
            template_name: Name of the template file
            config: Configuration dictionary
            
        Returns:
            Rendered template content
        """
        if config is None:
            config = {}
        
        try:
            template = self.jinja_env.get_template(template_name)
            return template.render(**config)
        except Exception as e:
            print(f"Error rendering template: {e}", file=sys.stderr)
            raise
    
    def render_to_file(self, output_path: Path, template_name: str = 'docker-compose.j2',
                       config: Optional[Dict] = None):
        """
        Render a template and write to file.
        
        Args:
            output_path: Output file path
            template_name: Name of the template file
            config: Configuration dictionary
        """
        content = self.render(template_name, config)
        
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, 'w') as f:
            f.write(content)
        
        print(f"✅ Rendered template to: {output_path}")


def main():
    """Main entry point for the template renderer."""
    parser = argparse.ArgumentParser(
        description='Render IaC Catalog Jinja2 templates',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__
    )
    
    parser.add_argument(
        '--env', '-e',
        help='Environment to render (dev, staging, production)',
        default=None
    )
    
    parser.add_argument(
        '--output', '-o',
        help='Output file path (default: docker-compose.yml)',
        default='docker-compose.yml'
    )
    
    parser.add_argument(
        '--template', '-t',
        help='Template file name (default: docker-compose.j2)',
        default='docker-compose.j2'
    )
    
    parser.add_argument(
        '--values', '-v',
        help='Additional values files to merge',
        action='append',
        default=[]
    )
    
    parser.add_argument(
        '--template-dir',
        help='Template directory (default: current directory)',
        default='.'
    )
    
    parser.add_argument(
        '--dry-run',
        help='Print rendered template without writing to file',
        action='store_true'
    )
    
    parser.add_argument(
        '--version',
        action='version',
        version=f'%(prog)s {__version__}'
    )
    
    args = parser.parse_args()
    
    # Initialize renderer
    template_dir = Path(args.template_dir)
    if not template_dir.exists():
        print(f"Error: Template directory not found: {template_dir}", 
              file=sys.stderr)
        sys.exit(1)
    
    renderer = TemplateRenderer(template_dir)
    
    # Load configuration
    print(f"📋 Loading configuration...")
    if args.env:
        print(f"   Environment: {args.env}")
    
    config = renderer.load_config(
        environment=args.env,
        additional_values=args.values if args.values else None
    )
    
    print(f"   Loaded {len(config)} configuration values")
    
    # Render template
    print(f"🔧 Rendering template: {args.template}")
    
    try:
        if args.dry_run:
            content = renderer.render(args.template, config)
            print("\n" + "="*60)
            print("RENDERED OUTPUT (DRY RUN)")
            print("="*60 + "\n")
            print(content)
        else:
            output_path = Path(args.output)
            renderer.render_to_file(output_path, args.template, config)
            print(f"\n🎉 Template rendered successfully!")
            print(f"   Output: {output_path.resolve()}")
    
    except Exception as e:
        print(f"\n❌ Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
