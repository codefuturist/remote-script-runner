# Full Stack Application

Complete full-stack application with frontend, backend, database, and cache.

## Components

- **Frontend**: Static web server (Nginx)
- **Backend**: Application API server
- **Database**: PostgreSQL
- **Cache**: Redis

## Quick Start

```bash
cp .env.example .env
vim .env  # Update configuration
docker-compose up -d
```

## Access

- Frontend: http://localhost
- Backend API: http://localhost:3001
