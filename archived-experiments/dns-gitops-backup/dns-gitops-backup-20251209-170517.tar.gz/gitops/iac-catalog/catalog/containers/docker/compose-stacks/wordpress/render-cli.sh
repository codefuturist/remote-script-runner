#!/usr/bin/env bash
#
# Simple wrapper script to render templates using jinja2 CLI
# Usage: ./render-cli.sh <environment>
#
# Example: ./render-cli.sh dev
#

set -euo pipefail

# Get absolute paths
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TEMPLATE_DIR="${SCRIPT_DIR}/templates"
ENV_DIR="${SCRIPT_DIR}/environments"
CATALOG_ROOT="$(cd "${SCRIPT_DIR}/../../../.." && pwd)"

# Hardcoded paths for debugging
TEMPLATE_FILE="${TEMPLATE_DIR}/docker-compose.j2"
OUTPUT_FILE="${SCRIPT_DIR}/docker-compose.yml"

echo "🔍 Debug Info:"
echo "   SCRIPT_DIR: ${SCRIPT_DIR}"
echo "   TEMPLATE_DIR: ${TEMPLATE_DIR}"
echo "   ENV_DIR: ${ENV_DIR}"
echo "   CATALOG_ROOT: ${CATALOG_ROOT}"
echo ""

# Check if environment is provided
if [[ $# -eq 0 ]]; then
    echo "Usage: $0 <environment>"
    echo ""
    echo "Available environments:"
    if [[ -d "${ENV_DIR}" ]]; then
        ls -1 "${ENV_DIR}"/*.yml 2>/dev/null | xargs -n1 basename | sed 's/.yml//' || echo "  No environment files found"
    else
        echo "  Environment directory not found: ${ENV_DIR}"
    fi
    exit 1
fi

ENV="$1"
ENV_FILE="${ENV_DIR}/${ENV}.yml"

# Check if environment file exists
if [[ ! -f "${ENV_FILE}" ]]; then
    echo "❌ Environment file not found: ${ENV_FILE}"
    echo ""
    echo "Available environments:"
    if [[ -d "${ENV_DIR}" ]]; then
        ls -1 "${ENV_DIR}"/*.yml 2>/dev/null | xargs -n1 basename | sed 's/.yml//' || echo "  No environment files found"
    else
        echo "  Environment directory not found: ${ENV_DIR}"
    fi
    exit 1
fi

# Check if template file exists
if [[ ! -f "${TEMPLATE_FILE}" ]]; then
    echo "❌ Template file not found: ${TEMPLATE_FILE}"
    exit 1
fi

# Check if jinja2 CLI is installed
JINJA2_CMD=""
if command -v jinja2 &> /dev/null; then
    JINJA2_CMD="jinja2"
elif [[ -f "${CATALOG_ROOT}/.venv/bin/jinja2" ]]; then
    JINJA2_CMD="${CATALOG_ROOT}/.venv/bin/jinja2"
    echo "ℹ️  Using venv jinja2: ${JINJA2_CMD}"
else
    echo "❌ jinja2 CLI not found. Install it with:"
    echo "   pip install 'jinja2-cli[yaml]'"
    echo "   OR"
    echo "   pipx install 'jinja2-cli[yaml]'"
    exit 1
fi

echo "🔧 Rendering template for environment: ${ENV}"
echo "   Template: ${TEMPLATE_FILE}"
echo "   Config: ${ENV_FILE}"
echo "   Output: ${OUTPUT_FILE}"
echo "   Jinja2: ${JINJA2_CMD}"
echo ""

# Render the template using jinja2 CLI
# Format: jinja2 [options] <input template> <input data>
# Use --format=yaml to parse the environment file
# Use --outfile to specify output file
echo "📝 Running: jinja2 --format=yaml --outfile=${OUTPUT_FILE} ${TEMPLATE_FILE} ${ENV_FILE}"
if "${JINJA2_CMD}" --format=yaml --outfile="${OUTPUT_FILE}" "${TEMPLATE_FILE}" "${ENV_FILE}" 2>&1; then
    echo ""
    echo "✅ Successfully rendered docker-compose.yml"
    echo "   Output: ${OUTPUT_FILE}"
    echo ""
    echo "To deploy:"
    echo "   cd ${SCRIPT_DIR}"
    echo "   docker compose up -d"
    exit 0
else
    RENDER_EXIT_CODE=$?
    echo ""
    echo "❌ Failed to render template (exit code: ${RENDER_EXIT_CODE})"
    echo ""
    if [[ -f "${OUTPUT_FILE}" ]] && [[ -s "${OUTPUT_FILE}" ]]; then
        echo "Error output from file:"
        cat "${OUTPUT_FILE}"
        echo ""
    fi
    echo "Debugging tips:"
    echo "   1. Check template syntax: ${TEMPLATE_FILE}"
    echo "   2. Verify environment values: ${ENV_FILE}"
    echo "   3. Check macro imports: ${CATALOG_ROOT}/_libraries/base/macros/common.j2"
    echo "   4. Verify jinja2-cli is installed with YAML support:"
    echo "      pip install 'jinja2-cli[yaml]'"
    exit 1
fi
