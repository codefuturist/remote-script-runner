#!/usr/bin/env bash
set -x  # Debug mode
set -e  # Exit on error

echo "=== Test Script Start ==="

# Hardcoded absolute paths
WORDPRESS_DIR="/Users/colin/Developer/Projects/personal/iac-catalog/catalog/containers/docker/compose-stacks/wordpress"
RENDER_SCRIPT="${WORDPRESS_DIR}/render.py"
OUTPUT_FILE="${WORDPRESS_DIR}/docker-compose-test.yml"

echo "Render Script: ${RENDER_SCRIPT}"
echo "Output: ${OUTPUT_FILE}"

# Check files exist
ls -la "${RENDER_SCRIPT}"

# Use the render.py script which properly handles library imports
echo "=== Attempting render ==="
cd "${WORDPRESS_DIR}" && python3 render.py --env dev --output "${OUTPUT_FILE}" 2>&1 || {
    RENDER_EXIT=$?
    echo "=== Render failed with exit code ${RENDER_EXIT} ==="
    exit 1
}

echo "=== Render succeeded ==="
ls -lh "${OUTPUT_FILE}"
head -20 "${OUTPUT_FILE}"
