# WordPress Docker Compose Stack

Production-ready WordPress deployment with MySQL database using Jinja2 templates for multi-environment support.

## Features

- 🎨 **Jinja2 Template System** - Flexible configuration with environment-specific overrides
- 🐳 **WordPress Latest** - Configurable version with automatic updates
- 🗄️ **MySQL 8.0** - Persistent database with health checks
- 📦 **Persistent Storage** - Named volumes for WordPress content and database
- 🔒 **Security** - Configurable security options and user permissions
- 🌐 **Network Isolation** - Dedicated Docker network
- 🔄 **Health Checks** - Automatic health monitoring for both services
- 📊 **Logging** - Configurable log management
- 🏷️ **Labels** - Standardized service labels
- ⚙️ **Multi-Environment** - Dev, staging, production configurations
- 🔧 **Traefik Support** - Optional reverse proxy with SSL

## Quick Start

### Prerequisites

**Option 1: Using jinja2 CLI (Simple)**
```bash
# Install jinja2-cli with YAML support
pipx install 'jinja2-cli[yaml]'
```

**Option 2: Using Python render.py (Advanced)**
```bash
# Install Python dependencies
pip install -r requirements.txt
```

### Method 1: Using render-cli.sh (Simplest - Recommended)

```bash
# Render for development and deploy
./render-cli.sh dev
docker compose up -d

# Or staging
./render-cli.sh staging
docker compose up -d

# Or production
./render-cli.sh production
docker compose up -d
```

### Method 2: Using render.py (Advanced Features)

```bash
# Render for development
python render.py --env dev

# Render with additional values
python render.py --env production --values custom-values.yml

# Dry run (preview without writing)
python render.py --env dev --dry-run

# Start services
docker compose up -d
```

### Method 3: Direct jinja2 CLI (Manual)

```bash
# From templates directory (uses relative path imports - no symlink needed!)
cd templates
jinja2 docker-compose.j2 ../environments/dev.yml --format=yaml > ../docker-compose.yml
cd ..
docker compose up -d
```

### Method 4: Direct Docker Compose (Legacy - Not Recommended)

```bash
# Copy environment file
cp .env.example .env

# Edit environment variables
vim .env

# Start services
docker compose up -d
```

## Template Rendering

### Comparison of Rendering Methods

| Method | Complexity | Features | Best For |
|--------|-----------|----------|----------|
| **render-cli.sh** | ⭐ Simple | Basic rendering | Quick deployments, CI/CD |
| **render.py** | ⭐⭐ Medium | Advanced features, layering | Complex configs, multi-env |
| **jinja2 CLI** | ⭐⭐⭐ Manual | Full control | Custom workflows, scripting |

**render-cli.sh** (Recommended for most users):
- ✅ Simple one-command operation
- ✅ Automatic symlink management
- ✅ No Python dependencies beyond pipx
- ✅ Perfect for CI/CD pipelines

**render.py** (Advanced users):
- ✅ Configuration layering (base → env → custom)
- ✅ Dry-run mode for validation
- ✅ Custom output paths
- ✅ Programmatic access to template system

### Render for Different Environments

**Using render-cli.sh (Simple):**
```bash
# Development
./render-cli.sh dev

# Staging
./render-cli.sh staging

# Production
./render-cli.sh production
```

**Using render.py (Advanced):**
```bash
# Development (port 8080, relaxed health checks)
python render.py --env dev --output docker-compose.dev.yml

# Staging (production-like, limited resources)
python render.py --env staging --output docker-compose.staging.yml

# Production (full resources, Traefik, SSL)
python render.py --env production --output docker-compose.prod.yml
```

### Custom Configuration

```bash
# Use additional values file
python render.py --env production --values custom-values.yml

# Dry run (preview without writing)
python render.py --env dev --dry-run
```

## Configuration

### Environment Files

Configuration is layered from multiple sources:

1. **`environments/base.yml`** - Default values for all environments
2. **`environments/<env>.yml`** - Environment-specific overrides (dev, staging, production)
3. **`values/*.yml`** - Optional additional values

### Key Configuration Parameters

| Parameter | Description | Default |
|-----------|-------------|---------|
| `wordpress_version` | WordPress Docker image version | `latest` |
| `wordpress_port` | Exposed port for WordPress | `80` |
| `mysql_version` | MySQL Docker image version | `8.0` |
| `db_name` | Database name | `wordpress` |
| `db_user` | Database user | `wordpress` |
| `db_password` | Database password | (required) |
| `db_root_password` | MySQL root password | (required) |
| `enable_traefik` | Enable Traefik integration | `false` |
| `ssl_enabled` | Enable SSL/TLS | `false` |
| `deployment_mode` | Deployment mode | `standalone` |

### Environment-Specific Settings

#### Development (`--env dev`)
- Port 8080 (avoiding conflicts)
- Relaxed health checks
- Development credentials (insecure, local only)
- Standalone mode

#### Staging (`--env staging`)
- Port 80
- Production versions
- 2 replicas
- Traefik with SSL
- Limited resources

#### Production (`--env production`)
- Port 80
- Specific versions (WordPress 6.6, MySQL 8.0)
- 3 replicas
- Traefik with SSL
- Full resources
- Swarm mode
- Strict health checks

### Backup

```bash
# Backup database
docker-compose exec db mysqldump -u root -p${DB_ROOT_PASSWORD} ${DB_NAME} > backup.sql

# Backup WordPress files
docker-compose exec wordpress tar czf /tmp/wordpress-backup.tar.gz /var/www/html
docker cp $(docker-compose ps -q wordpress):/tmp/wordpress-backup.tar.gz ./wordpress-backup.tar.gz
```

### Restore

```bash
# Restore database
cat backup.sql | docker-compose exec -T db mysql -u root -p${DB_ROOT_PASSWORD} ${DB_NAME}

# Restore WordPress files
docker cp wordpress-backup.tar.gz $(docker-compose ps -q wordpress):/tmp/
docker-compose exec wordpress tar xzf /tmp/wordpress-backup.tar.gz -C /
```

## Volumes

- `wordpress_data` - WordPress files and uploads
- `db_data` - MySQL database files

## Networks

- `wordpress_network` - Internal bridge network for WordPress and database communication

## Security Notes

⚠️ **Important:**
- Change all default passwords in `.env`
- Use strong passwords for production
- Consider using Docker secrets for sensitive data
- Implement SSL/TLS with a reverse proxy (Traefik, Nginx)
- Regular backups are recommended

## Monitoring

Check service health:

```bash
docker-compose ps
docker-compose logs wordpress
docker-compose logs db
```

## Troubleshooting

### Database connection errors
- Verify database credentials in `.env`
- Check if database container is running: `docker-compose ps db`
- View database logs: `docker-compose logs db`

### Permission issues
- Ensure volumes are properly mounted
- Check file permissions in containers

### Port conflicts
- Change `WORDPRESS_PORT` in `.env` if port 80 is in use
- Restart services: `docker-compose down && docker-compose up -d`

## Template Metadata

- **Type**: Docker Compose Stack
- **Version**: 1.0.0
- **Components**: WordPress + MySQL
- **Tested**: Docker 24.x, Docker Compose 2.x
