# Monitoring Stack

Complete monitoring stack with Prometheus, Grafana, Loki, and Promtail.

## Components

- **Prometheus**: Metrics collection and storage
- **Grafana**: Metrics visualization and dashboards
- **Loki**: Log aggregation system
- **Promtail**: Log collection agent

## Quick Start

```bash
cp .env.example .env
vim .env  # Update passwords
docker-compose up -d
```

## Access

- Prometheus: http://localhost:9090
- Grafana: http://localhost:3000 (admin/changeme_secure_password)
- Loki: http://localhost:3100

## Configuration Required

Before first run, create configuration files:

```bash
mkdir -p prometheus grafana/provisioning loki promtail
```

See README for detailed configuration examples.
