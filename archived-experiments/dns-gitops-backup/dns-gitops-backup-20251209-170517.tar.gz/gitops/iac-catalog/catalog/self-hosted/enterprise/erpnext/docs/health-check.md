# ERPNext Health Check Documentation

This document contains comprehensive health check endpoints and configurations for ERPNext services based on the production deployment running on `colin@pi-nvme-1`.

## Current Running Versions

### Production Environment (erpnext-enhanced stack)

- **ERPNext Version**: `frappe/erpnext:v15.71.1` ✅ **HEALTHY**
- **MariaDB Version**: `mariadb:10.6` ✅ **HEALTHY**
- **Redis Version**: `redis:7-alpine` ✅ **HEALTHY**
- **Deployment**: Docker Swarm with 9 services
- **Status**: All services running healthy for 36+ hours

### Development Environment (erpnext-v2)

- **ERPNext Version**: `frappe/erpnext:v15.74.0` ⚠️ **RESTARTING**
- **Status**: Frontend and WebSocket services are restarting (unstable)

## Health Check Endpoints

### 1. Backend Service Health Check

**Container**: `erpnext-enhanced_backend`

```yaml
healthcheck:
  test:
    [
      "CMD-SHELL",
      'curl -sf -H "Host: frontend" http://localhost:8000/api/method/ping || exit 1',
    ]
  interval: 30s
  timeout: 10s
  start_period: 90s
  retries: 5
```

**Endpoint Details**:

- **URL**: `http://localhost:8000/api/method/ping`
- **Method**: GET
- **Headers**: `Host: frontend`
- **Expected Response**: `{"message":"pong"}`
- **Status**: ✅ Working

### 2. Frontend Service Health Check

**Container**: `erpnext-enhanced_frontend`

```yaml
healthcheck:
  test:
    ["CMD-SHELL", "curl -sf http://localhost:8080/api/method/ping || exit 1"]
  interval: 30s
  timeout: 10s
  start_period: 60s
  retries: 3
```

**Endpoint Details**:

- **URL**: `http://localhost:8080/api/method/ping`
- **Method**: GET
- **Expected Response**: `{"message":"pong"}`
- **Public Access**: `http://pi-nvme-1:8080/api/method/ping`
- **Status**: ✅ Working

### 3. WebSocket Service Health Check

**Container**: `erpnext-enhanced_websocket`

```yaml
healthcheck:
  test: ["CMD-SHELL", "kill -0 1 || exit 1"]
  interval: 30s
  timeout: 10s
  start_period: 30s
  retries: 3
```

**Endpoint Details**:

- **Check Type**: Process health (checks if main process is running)
- **Method**: Signal test (`kill -0` sends signal 0 to check if process exists)
- **Status**: ✅ Working

### 4. MariaDB Service Health Check

**Container**: `erpnext-enhanced_mariadb`

```yaml
healthcheck:
  test:
    [
      "CMD-SHELL",
      'mysqladmin ping -h localhost -u root -p"$MYSQL_ROOT_PASSWORD" --silent',
    ]
  interval: 10s
  timeout: 5s
  start_period: 30s
  retries: 5
```

**Endpoint Details**:

- **Check Type**: Database connectivity
- **Command**: `mysqladmin ping`
- **Authentication**: Uses root user with password from environment
- **Status**: ✅ Working

### 5. Redis Cache Service Health Check

**Container**: `erpnext-enhanced_redis-cache`

```yaml
healthcheck:
  test: ["CMD", "redis-cli", "ping"]
  interval: 10s
  timeout: 5s
  start_period: 10s
  retries: 3
```

**Endpoint Details**:

- **Check Type**: Redis connectivity
- **Command**: `redis-cli ping`
- **Expected Response**: `PONG`
- **Status**: ✅ Working

### 6. Redis Queue Service Health Check

**Container**: `erpnext-enhanced_redis-queue`

```yaml
healthcheck:
  test: ["CMD", "redis-cli", "ping"]
  interval: 10s
  timeout: 5s
  start_period: 10s
  retries: 3
```

**Endpoint Details**:

- **Check Type**: Redis connectivity
- **Command**: `redis-cli ping`
- **Expected Response**: `PONG`
- **Status**: ✅ Working

### 7. Queue Worker Services Health Check

**Containers**: `erpnext-enhanced_queue-long`, `erpnext-enhanced_queue-short`

```yaml
healthcheck:
  test: ["CMD-SHELL", "kill -0 1 || exit 1"]
  interval: 30s
  timeout: 10s
  start_period: 30s
  retries: 3
```

**Endpoint Details**:

- **Check Type**: Process health
- **Method**: Signal test to verify worker processes are running
- **Status**: ✅ Working

### 8. Scheduler Service Health Check

**Container**: `erpnext-enhanced_scheduler`

```yaml
healthcheck:
  test: ["CMD-SHELL", "kill -0 1 || exit 1"]
  interval: 30s
  timeout: 10s
  start_period: 30s
  retries: 3
```

**Endpoint Details**:

- **Check Type**: Process health
- **Method**: Signal test to verify scheduler process is running
- **Status**: ✅ Working

## Additional Health Endpoints

### Application Health Endpoints

1. **Ping Endpoint**

   - **URL**: `/api/method/ping`
   - **Response**: `{"message":"pong"}`
   - **Status**: ✅ Working

2. **Root Application**

   - **URL**: `/`
   - **Response**: Login page with Frappe framework
   - **Status**: ✅ Working (serves complete login interface)

3. **System Info** (Potential endpoints - need authentication)
   - `/api/method/frappe.utils.bench.system_info`
   - `/api/method/frappe.app`
   - `/api/method/version`

## External Health Check Scripts

### Simple Health Check Script

```bash
#!/bin/bash
# Health check script for ERPNext

# Check frontend
echo "Checking Frontend..."
if curl -sf http://localhost:8080/api/method/ping > /dev/null; then
    echo "✅ Frontend: HEALTHY"
else
    echo "❌ Frontend: UNHEALTHY"
fi

# Check backend (internal)
echo "Checking Backend..."
if docker exec $(docker ps -qf "name=erpnext-enhanced_frontend") curl -sf -H "Host: frontend" http://backend:8000/api/method/ping > /dev/null; then
    echo "✅ Backend: HEALTHY"
else
    echo "❌ Backend: UNHEALTHY"
fi

# Check database
echo "Checking Database..."
if docker exec $(docker ps -qf "name=erpnext-enhanced_mariadb") mysqladmin ping -h localhost -u root -p"$MYSQL_ROOT_PASSWORD" --silent > /dev/null; then
    echo "✅ Database: HEALTHY"
else
    echo "❌ Database: UNHEALTHY"
fi

# Check Redis Cache
echo "Checking Redis Cache..."
if docker exec $(docker ps -qf "name=erpnext-enhanced_redis-cache") redis-cli ping > /dev/null; then
    echo "✅ Redis Cache: HEALTHY"
else
    echo "❌ Redis Cache: UNHEALTHY"
fi

# Check Redis Queue
echo "Checking Redis Queue..."
if docker exec $(docker ps -qf "name=erpnext-enhanced_redis-queue") redis-cli ping > /dev/null; then
    echo "✅ Redis Queue: HEALTHY"
else
    echo "❌ Redis Queue: UNHEALTHY"
fi
```

## Monitoring Configuration

### Prometheus Monitoring

Add these targets to your Prometheus configuration:

```yaml
- job_name: "erpnext-frontend"
  static_configs:
    - targets: ["pi-nvme-1:8080"]
  metrics_path: "/api/method/ping"
  scrape_interval: 30s

- job_name: "erpnext-docker-services"
  static_configs:
    - targets: ["pi-nvme-1:2375"] # Docker daemon metrics
  scrape_interval: 30s
```

### Alerting Rules

```yaml
groups:
  - name: erpnext.rules
    rules:
      - alert: ERPNextDown
        expr: up{job="erpnext-frontend"} == 0
        for: 1m
        labels:
          severity: critical
        annotations:
          summary: "ERPNext frontend is down"
          description: "ERPNext frontend has been down for more than 1 minute."

      - alert: ERPNextHealthCheckFailing
        expr: probe_success{job="erpnext-frontend"} == 0
        for: 2m
        labels:
          severity: warning
        annotations:
          summary: "ERPNext health check failing"
          description: "ERPNext health check has been failing for more than 2 minutes."
```

## Health Check Summary

| Service     | Container                    | Health Check Type       | Status     | Interval |
| ----------- | ---------------------------- | ----------------------- | ---------- | -------- |
| Frontend    | erpnext-enhanced_frontend    | HTTP `/api/method/ping` | ✅ HEALTHY | 30s      |
| Backend     | erpnext-enhanced_backend     | HTTP `/api/method/ping` | ✅ HEALTHY | 30s      |
| WebSocket   | erpnext-enhanced_websocket   | Process Check           | ✅ HEALTHY | 30s      |
| MariaDB     | erpnext-enhanced_mariadb     | mysqladmin ping         | ✅ HEALTHY | 10s      |
| Redis Cache | erpnext-enhanced_redis-cache | redis-cli ping          | ✅ HEALTHY | 10s      |
| Redis Queue | erpnext-enhanced_redis-queue | redis-cli ping          | ✅ HEALTHY | 10s      |
| Queue Long  | erpnext-enhanced_queue-long  | Process Check           | ✅ HEALTHY | 30s      |
| Queue Short | erpnext-enhanced_queue-short | Process Check           | ✅ HEALTHY | 30s      |
| Scheduler   | erpnext-enhanced_scheduler   | Process Check           | ✅ HEALTHY | 30s      |

**Overall Status**: ✅ **ALL SERVICES HEALTHY**

**Last Updated**: August 26, 2025  
**Source**: Production deployment on `colin@pi-nvme-1`  
**Docker Stack**: `erpnext-enhanced` (9 services)
