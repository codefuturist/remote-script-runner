# Enterprise Applications

This directory contains templates for enterprise-grade business applications and ERP systems.

## Available Templates

### ERPNext

**Location**: `erpnext/`
**Category**: Enterprise Resource Planning (ERP)
**Description**: Open-source ERP solution built on Frappe Framework with comprehensive business management capabilities.

**Features**:

- Multi-environment support (dev, staging, production)
- Multiple deployment targets (Docker Compose, Kubernetes, Terraform)
- Scalable architecture with worker queues
- Security configurations (RBAC, secrets management)
- Observability integration (metrics, logging, tracing)
- Cloud provider support (AWS, Azure, GCP)
- Health checks and monitoring
- Resource management and policies

**Use Cases**:

- Business operations management
- Accounting and finance
- Inventory and supply chain
- CRM and sales
- HRMS and payroll
- Manufacturing
- Project management

**Resource Requirements**:

- CPU: High
- Memory: High
- Storage: High

**Quick Start**:

```bash
# Development
make -C catalog/self-hosted/enterprise/erpnext render-dev
make -C catalog/self-hosted/enterprise/erpnext deploy-dev

# Production
make -C catalog/self-hosted/enterprise/erpnext render-production
make -C catalog/self-hosted/enterprise/erpnext deploy-production
```

**Documentation**: See `erpnext/README.md` for detailed information.

## Adding New Enterprise Applications

When adding new enterprise applications to this category:

1. Create a new directory: `catalog/self-hosted/enterprise/<app-name>/`
2. Include required files:
   - `README.md` - Application documentation
   - `manifest.yml` - Application metadata
   - `.app-config.yml` - Template configuration
   - `.meta.yml` - Categorization and metadata
   - `Makefile` - Build and deployment targets
3. Add template files in `templates/` directory
4. Add configuration values in `values/` directory
5. Add environment-specific configs in `environments/` directory
6. Update this README with the new application

## Common Patterns

Enterprise applications in this category typically include:

- **Multi-tenancy support**: Ability to serve multiple organizations
- **RBAC**: Role-based access control
- **Audit logging**: Comprehensive activity tracking
- **Backup/restore**: Data protection mechanisms
- **High availability**: Redundancy and failover
- **Scalability**: Horizontal and vertical scaling
- **Integration**: APIs and webhooks for third-party systems
- **Compliance**: Security and regulatory compliance features

## Support

For issues or questions about enterprise applications:

1. Check the application's README
2. Review the application's documentation
3. Check the main catalog documentation
4. Open an issue in the repository
