# ERPNext Template

Enterprise Resource Planning (ERP) solution built on Frappe Framework with comprehensive template support.

## Overview

This template provides a complete ERPNext deployment with support for multiple deployment targets including Docker Compose, Kubernetes, and Terraform.

## Features

- **Multi-Environment Support**: Dev, staging, production configurations
- **Scalable Architecture**: Horizontal scaling with worker queues
- **Security**: RBAC, secrets management, compliance policies
- **Observability**: Metrics, logging, tracing integration
- **Cloud Ready**: AWS, Azure, GCP deployment support

## Quick Start

```bash
# Initialize new deployment
tmplctl init my-erp --template erpnext

# Render for development
tmplctl render erpnext --env dev --format docker

# Deploy to production
tmplctl deploy erpnext --env production --target k8s
```

## Configuration

See `values/` directory for environment-specific configurations.

## Testing

```bash
# Run unit tests
tmplctl test erpnext --type unit

# Run integration tests
tmplctl test erpnext --type integration
```

## Using Healthcheck.sh

The healthcheck.sh script is part of the Docker Official Images of MariaDB Server. This script provides health monitoring capabilities for MariaDB containers in the ERPNext deployment.

The script is part of the repository of the Docker Official Image of MariaDB Server and can be used to ensure your MariaDB instance is healthy and responding correctly.

**Source**: [MariaDB Documentation - Using Healthcheck.sh](https://mariadb.com/docs/server/server-management/install-and-upgrade-mariadb/installing-mariadb/binary-packages/automated-mariadb-deployment-and-administration/docker-and-mariadb/using-healthcheck-sh)

### Implementation

The healthcheck is automatically configured in the Docker Compose template for MariaDB services and provides:

- Connection health monitoring
- Database availability checks
- Automatic container restart on health failures
- Integration with Docker's health status reporting

## Documentation

- [Deployment Guide](docs/deployment.md)
- [Configuration Reference](docs/configuration.md)
- [API Documentation](docs/api.md)

---
