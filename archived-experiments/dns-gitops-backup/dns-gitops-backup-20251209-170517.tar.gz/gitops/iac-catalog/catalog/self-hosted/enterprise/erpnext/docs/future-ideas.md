# ERPNext Deployment Scripts Summary

## Core Deployment Scripts

### `deployment_manager.py`

**State-aware deployment orchestrator** - Manages ERPNext deployments with versioning, rollback capability, and encrypted secrets storage. Handles deployment lifecycle, file organization, and provides transactional deployment safety with lock mechanisms.

### `render.py`

**Template rendering engine** - Processes Jinja2 templates with environment-specific configurations. Provides CLI for rendering Docker Compose files, comparing environments, and validating generated YAML outputs.

## Backend Storage Systems

### `backends/hybrid_backend.py`

**Multi-backend state storage** - Combines Git (version control), S3 (file storage), Consul (real-time state), and PostgreSQL (metadata/search) for comprehensive deployment state management across distributed systems.

## API & Orchestration

### `deployment_controller/api/main.py`

**RESTful deployment API** - FastAPI service providing HTTP endpoints for deployment management, real-time status tracking via WebSockets, background task processing with Celery, and authentication.

### `deployment_workflows/erpnext_workflow.yaml`

**Deployment workflow specification** - YAML-defined multi-stage deployment pipeline with blue-green strategy, automated rollback conditions, health checks, and notification integrations for production ERPNext deployments.

## Lifecycle Scripts

### `pre-deploy.sh`

**Pre-deployment validator** - Kubernetes cluster connectivity checks, namespace creation, secret management, resource quota validation, and backup preparation before deployment execution.

### `post-deploy.sh`

**Post-deployment verifier** - Waits for deployment readiness, runs database migrations, creates initial sites, performs health checks, and provides access information after successful deployment.

### `sync_deployment_state.sh`

**State synchronization daemon** - Maintains consistency between local deployment state and central management API, handles pending deployments, performs drift detection, and manages distributed state reconciliation.

## Monitoring & Observability

### `monitoring/drift_detector.py`

**Configuration drift monitor** - Continuously monitors for differences between expected and actual deployment states, provides Prometheus metrics, and triggers automatic reconciliation when drift is detected.

---

_These scripts form a comprehensive deployment orchestration system for ERPNext, providing enterprise-grade deployment management, state tracking, and operational monitoring capabilities._

# Future Ideas and Advanced Architecture

## Project Structure

```
erpnext-deployment/
├── templates/
│   ├── docker-compose.j2         # Main template
│   ├── macros/
│   │   ├── services.j2          # Service definition macros
│   │   ├── security.j2          # Security-related macros
│   │   ├── observability.j2     # Monitoring & logging macros
│   │   ├── resources.j2         # Resource management macros
│   │   └── networking.j2        # Network configuration macros
│   └── partials/
│       ├── volumes.j2           # Volume definitions
│       ├── networks.j2          # Network definitions
│       └── configs.j2           # Config definitions
├── environments/
│   ├── dev.yaml                 # Development variables
│   ├── staging.yaml             # Staging variables
│   └── production.yaml          # Production variables
├── configs/
│   ├── traefik/
│   ├── prometheus/
│   └── otel/
├── secrets/
│   └── .gitkeep
└── render.py                    # Template rendering script
```

## Main Template: `templates/docker-compose.j2`

```jinja2
{#- Main Docker Compose Template with full feature implementation -#}
{%- import 'macros/services.j2' as services -%}
{%- import 'macros/security.j2' as security -%}
{%- import 'macros/observability.j2' as observability -%}
{%- import 'macros/resources.j2' as resources -%}
{%- import 'macros/networking.j2' as networking -%}

version: "{{ compose_version | default('3.8') }}"

{#- Docker Swarm specific configurations -#}
{%- if deployment_mode == 'swarm' %}
x-deploy-policy: &default-deploy
  replicas: {{ default_replicas | default(1) }}
{%- endif %}

services:
  {#- Traefik Reverse Proxy Service -#}
  {%- endif %}

{#- Volume Definitions -#}
{% include 'partials/volumes.j2' %}

{#- Network Definitions -#}
{% include 'partials/networks.j2' %}

{#- Config Definitions -#}
{%- if deployment_mode == 'swarm' %}
{% include 'partials/configs.j2' %}
{%- endif %}

{#- Secrets Definitions -#}
{%- if secret_strategy == 'docker' and deployment_mode == 'swarm' %}
secrets:
  {%- for secret_name in docker_secrets | default([]) %}
  {%- endfor %}
{%- endif %}
```

## Macro Files

### `templates/macros/services.j2`

```jinja2
{#- Service Definition Macros -#}

{#- Base service configuration -#}
{%- macro base_service(service_name, image, environment='dev', deployment_mode='compose') -%}
image: {{ image }}
{%- if image_pull_policy %}
pull_policy: {{ image_pull_policy }}
{%- endif %}
{%- if deployment_mode == 'swarm' %}
hostname: {{ service_name }}-{{.Task.Slot}}
{%- endif %}
{%- if container_name and deployment_mode == 'compose' %}
container_name: {{ container_name_prefix | default('') }}{{ service_name }}
{%- endif %}
{%- if extra_hosts %}
extra_hosts:
  {%- for host in extra_hosts %}
  {%- endfor %}
{%- endif %}
{%- endmacro -%}

{#- Traefik service configuration -#}
{%- macro traefik_service(environment, ssl_enabled=false, acme_email='admin@example.com', deployment_mode='compose') -%}
traefik:
  image: traefik:{{ traefik_version | default('v2.10') }}
{%- endmacro -%}

{#- Traefik labels for services -#}
{%- macro traefik_labels(service_name, rule, port, ssl_enabled=false) -%}
- "traefik.enable=true"
- "traefik.http.routers.{{ service_name }}.rule={{ rule }}"
- "traefik.http.routers.{{ service_name }}.entrypoints=web"
- "traefik.http.services.{{ service_name }}.loadbalancer.server.port={{ port }}"
{%- if ssl_enabled %}
- "traefik.http.routers.{{ service_name }}-secure.rule={{ rule }}"
- "traefik.http.routers.{{ service_name }}-secure.entrypoints=websecure"
- "traefik.http.routers.{{ service_name }}-secure.tls=true"
- "traefik.http.routers.{{ service_name }}-secure.tls.certresolver=letsencrypt"
- "traefik.http.middlewares.{{ service_name }}-redirect.redirectscheme.scheme=https"
- "traefik.http.routers.{{ service_name }}.middlewares={{ service_name }}-redirect"
{%- endif %}
{%- endmacro -%}

{#- Database service configuration -#}
{%- macro database_service(db_type='mariadb', db_version='10.6', environment='dev', deployment_mode='compose') -%}
{%- if db_type == 'mariadb' %}
image: mariadb:{{ db_version }}
{%- elif db_type == 'postgres' %}
image: postgres:{{ db_version }}
{%- elif db_type == 'mongodb' %}
image: mongo:{{ db_version }}
{%- endif %}
{%- endmacro -%}

{#- Worker service configuration -#}
{%- macro worker_service(worker_name, image, queues, environment='dev', deployment_mode='compose') -%}
{{ base_service(worker_name, image, environment, deployment_mode) }}
command:
  - bench
  - {{ queues | join(',') }}
{%- endmacro -%}

{#- Redis service configuration -#}
{%- macro redis_service(service_name, redis_version='6.2-alpine', persistence=false, environment='dev', deployment_mode='compose') -%}
image: redis:{{ redis_version }}
{%- if persistence %}
command: redis-server --appendonly yes
{%- endif %}
{%- endmacro -%}

{#- OpenTelemetry Collector service -#}
{%- macro otel_collector_service(environment='dev', deployment_mode='compose', otel_config_path='./configs/otel/collector-config.yaml') -%}
image: otel/opentelemetry-collector-contrib:{{ otel_version | default('0.88.0') }}
command: ["--config=/etc/otel-collector-config.yaml"]
volumes:
  - {{ otel_config_path }}:/etc/otel-collector-config.yaml:ro
ports:
  - "4317:4317"   # OTLP gRPC receiver
  - "8888:8888"   # Prometheus metrics
networks:
  - frappe_network
deploy:
  replicas: 1
{%- endmacro -%}

{#- Prometheus service -#}
{%- macro prometheus_service(environment='dev', deployment_mode='compose', prometheus_config_path='./configs/prometheus/prometheus.yml') -%}
image: prom/prometheus:{{ prometheus_version | default('v2.47.0') }}
command:
  - '--config.file=/etc/prometheus/prometheus.yml'
  - '--web.enable-lifecycle'
volumes:
  - {{ prometheus_config_path }}:/etc/prometheus/prometheus.yml:ro
  - prometheus-data:/prometheus
ports:
  - "9090:9090"
networks:
  - frappe_network
deploy:
  replicas: 1
{%- endmacro -%}
```

### `templates/macros/security.j2`

```jinja2
{#- Security Configuration Macros -#}

{#- Service security context -#}
{%- macro service_security(run_as_user='1000', run_as_group='1000', read_only_root=false, no_new_privileges=true) -%}
{%- if run_as_user or run_as_group or read_only_root or no_new_privileges %}
security_opt:
  {%- if no_new_privileges %}
  - seccomp:unconfined
{%- if run_as_user %}
user: "{{ run_as_user }}:{{ run_as_group }}"
{%- endif %}
{%- if read_only_root %}
read_only: true
tmpfs:
  - /tmp
  - /var/cache
{%- endif %}
{%- endif %}
{%- endmacro -%}

{#- Secret management strategies -#}
{%- macro secret_management(strategy='env', secrets={}) -%}
{%- if strategy == 'env' %}
  {#- Environment variable based secrets -#}
  {%- for key, value in secrets.items() %}
{{ key }}: "${{{ key }}}"
  {%- endfor %}
{%- elif strategy == 'file' %}
  {#- File-based secrets -#}
  {%- for key, path in secrets.items() %}
{{ key }}_FILE: {{ path }}
  {%- endfor %}
{%- elif strategy == 'docker' %}
  {#- Docker secrets (Swarm mode only) -#}
  {%- for key in secrets %}
{{ key }}: /run/secrets/{{ key | lower }}
  {%- endfor %}
{%- endif %}
{%- endmacro -%}

{#- Docker secrets configuration -#}
{%- macro docker_secrets(secrets) -%}
secrets:
  {%- for secret in secrets %}
  {%- endfor %}
{%- endmacro -%}

{#- SSL/TLS configuration -#}
{%- macro ssl_config(cert_path='/certs', enable_ssl=false) -%}
{%- if enable_ssl %}
SSL_CERT_PATH: {{ cert_path }}/cert.pem
SSL_KEY_PATH: {{ cert_path }}/key.pem
SSL_CA_PATH: {{ cert_path }}/ca.pem
SSL_VERIFY_MODE: {{ ssl_verify_mode | default('VERIFY_PEER') }}
SSL_PROTOCOLS: {{ ssl_protocols | default('TLSv1.2 TLSv1.3') }}
SSL_CIPHERS: {{ ssl_ciphers | default('HIGH:!aNULL:!MD5') }}
{%- endif %}
{%- endmacro -%}

{#- Capability management -#}
{%- macro capabilities(add=[], drop=[]) -%}
{%- if add or drop %}
cap_add:
  {%- for cap in add %}
  {%- endfor %}
cap_drop:
  {%- for cap in drop | default(['ALL']) %}
  {%- endfor %}
{%- endif %}
{%- endmacro -%}
```

### `templates/macros/observability.j2`

```jinja2
{#- Observability Configuration Macros -#}

{#- Service monitoring configuration -#}
{%- macro service_monitoring(enable_metrics=true, enable_tracing=true, enable_logging=true, service_name='', log_driver='json-file', datadog_enabled=false) -%}
{%- if enable_logging %}
logging:
  driver: {{ log_driver }}
{%- endif %}
{%- endmacro -%}

{#- Health check configuration -#}
{%- macro health_check(test, interval='30s', timeout='10s', retries=3, start_period='30s') -%}
healthcheck:
  test: {{ test | tojson }}
  {%- endif %}
{%- endmacro -%}

{#- Metrics endpoint labels -#}
{%- macro metrics_labels(port='9090', path='/metrics') -%}
prometheus.io/scrape: "true"
prometheus.io/port: "{{ port }}"
prometheus.io/path: "{{ path }}"
prometheus.io/scheme: "{{ metrics_scheme | default('http') }}"
{%- endmacro -%}

{#- OpenTelemetry environment variables -#}
{%- macro otel_env_vars(service_name, enabled=true) -%}
{%- if enabled %}
OTEL_EXPORTER_OTLP_ENDPOINT: {{ otel_endpoint | default('http://otel-collector:4317') }}
OTEL_SERVICE_NAME: {{ service_name }}
OTEL_RESOURCE_ATTRIBUTES: "service.name={{ service_name }},service.version={{ service_version | default('1.0.0') }},deployment.environment={{ environment }}"
OTEL_TRACES_EXPORTER: {{ otel_traces_exporter | default('otlp') }}
OTEL_METRICS_EXPORTER: {{ otel_metrics_exporter | default('otlp') }}
OTEL_LOGS_EXPORTER: {{ otel_logs_exporter | default('otlp') }}
OTEL_EXPORTER_OTLP_PROTOCOL: {{ otel_protocol | default('grpc') }}
OTEL_PROPAGATORS: {{ otel_propagators | default('tracecontext,baggage') }}
OTEL_TRACE_SAMPLING_RATE: {{ otel_sampling_rate | default('1.0' if environment == 'dev' else '0.1') }}
{%- endif %}
{%- endmacro -%}

{#- Datadog APM configuration -#}
{%- macro datadog_apm(service_name, enabled=false) -%}
{%- if enabled %}
DD_AGENT_HOST: {{ dd_agent_host | default('datadog-agent') }}
DD_TRACE_AGENT_PORT: {{ dd_trace_port | default('8126') }}
DD_SERVICE: {{ service_name }}
DD_ENV: {{ environment }}
DD_VERSION: {{ service_version | default('1.0.0') }}
DD_LOGS_INJECTION: {{ dd_logs_injection | default('true') }}
DD_RUNTIME_METRICS_ENABLED: {{ dd_runtime_metrics | default('true') }}
DD_PROFILING_ENABLED: {{ dd_profiling | default('true' if environment == 'production' else 'false') }}
{%- endif %}
{%- endmacro -%}
```

### `templates/macros/resources.j2`

```jinja2
{#- Resource Management Macros -#}

{#- Service resource limits and reservations -#}
{%- macro service_resources(cpu_limit='1', memory_limit='512M', cpu_reservation='0.25', memory_reservation='128M', pids_limit=None, enable_gpu=false) -%}
{%- if deployment_mode == 'swarm' %}
resources:
  limits:
{%- elif deployment_mode == 'compose' %}
deploy:
  resources:
{%- endif %}
{%- endmacro -%}

{#- Ulimits configuration -#}
{%- macro ulimits(nofile_soft=65536, nofile_hard=65536, nproc_soft=32768, nproc_hard=32768, memlock_soft=-1, memlock_hard=-1) -%}
ulimits:
  nofile:
{%- endmacro -%}

{#- Sysctls configuration -#}
{%- macro sysctls(settings={}) -%}
{%- if settings %}
sysctls:
  {%- for key, value in settings.items() %}
  {%- endfor %}
{%- endif %}
{%- endmacro -%}

{#- Storage driver options -#}
{%- macro storage_driver_opts(driver='local', opts={}) -%}
driver_opts:
  {%- if driver == 'local' %}
  {%- endif %}
{%- endmacro -%}
```

### `templates/macros/networking.j2`

```jinja2
{#- Networking Configuration Macros -#}

{#- Service networks configuration -#}
{%- macro service_networks(networks=[], aliases=[]) -%}
{%- for network in networks %}
- name: {{ network }}
  {%- if aliases %}
  {%- endif %}
{%- endfor %}
{%- endmacro -%}

{#- Network driver configuration -#}
{%- macro network_config(name, driver='bridge', external=false, attachable=true, internal=false) -%}
{{ name }}:
  {%- if external %}
  {%- endif %}
{%- endmacro -%}

{#- DNS configuration -#}
{%- macro dns_config(dns_servers=[], dns_search=[], dns_options=[]) -%}
{%- if dns_servers %}
dns:
  {%- for server in dns_servers %}
  {%- endfor %}
{%- endif %}
{%- if dns_search %}
dns_search:
  {%- for domain in dns_search %}
  {%- endfor %}
{%- endif %}
{%- if dns_options %}
dns_opt:
  {%- for option in dns_options %}
  {%- endfor %}
{%- endif %}
{%- endmacro -%}
```

## Partial Templates

### `templates/partials/volumes.j2`

```jinja2
{#- Volume Definitions -#}
volumes:
  {%- if not use_external_db | default(false) %}
  {%- endif %}
```

### `templates/partials/networks.j2`

```jinja2
{#- Network Definitions -#}
networks:
  frappe_network:
  {%- endfor %}
```

### `templates/partials/configs.j2`

```jinja2
{#- Config Definitions for Swarm Mode -#}
configs:
  {%- if enable_metrics | default(false) %}
  {%- endfor %}
```

## Environment Configuration Files

### `environments/dev.yaml`

```yaml
# Development Environment Configuration
environment: dev
deployment_mode: compose
compose_version: "3.8"

# Images
erpnext_image: frappe/erpnext:v15.76.0
redis_version: 6.2-alpine
db_version: "10.6"
db_type: mariadb

# Database
use_external_db: false
db_host: db
db_port: 3306
db_root_password: admin
db_root_username: root

# Site Configuration
site_name: frontend
admin_password: admin
enable_site_creation: true
install_apps: []

# Networking
enable_traefik: false
ssl_enabled: false
domain: erpnext.local
http_port: 8080
https_port: 8443

# Security
secret_strategy: env
run_as_user: "1000"
run_as_group: "1000"
no_new_privileges: true
read_only_root_fs: false

# Observability
enable_metrics: false
enable_tracing: false
enable_logging: true
log_driver: json-file
log_max_size: "10m"
log_max_files: "3"
datadog_enabled: false

# Resources (minimal for dev)
backend_cpu_limit: "2"
backend_memory_limit: "2G"
backend_cpu_reservation: "0.5"
backend_memory_reservation: "512M"
backend_pids_limit: 100

db_cpu_limit: "1"
db_memory_limit: "1G"
```

## Scalable Repository Architecture for Multi-Application Template Management

I'll design a comprehensive, enterprise-grade repository architecture that can manage templates for hundreds of applications while maintaining consistency, security, and developer productivity.

### Repository Structure

```
template-platform/
├── .github/
│   ├── workflows/
│   │   ├── ci-templates.yml
│   │   ├── ci-security.yml
│   │   ├── cd-release.yml
│   │   ├── documentation.yml
│   │   └── marketplace-publish.yml
│   ├── CODEOWNERS
│   ├── pull_request_template.md
│   └── ISSUE_TEMPLATE/
│       ├── new-application.md
│       ├── bug-report.md
│       └── feature-request.md
│
├── applications/                    # Application-specific templates
│   ├── databases/
│   │   ├── postgresql/
│   │   ├── mysql/
│   │   ├── mongodb/
│   │   └── redis/
│   ├── web-frameworks/
│   │   ├── django/
│   │   ├── rails/
│   │   ├── express/
│   │   └── fastapi/
│   ├── microservices/
│   │   ├── spring-boot/
│   │   ├── golang-micro/
│   │   └── dotnet-core/
│   ├── data-processing/
│   │   ├── airflow/
│   │   ├── spark/
│   │   └── kafka/
│   └── enterprise/
│       ├── erpnext/
│       ├── odoo/
│       ├── gitlab/
│       └── jenkins/
│
├── core/                            # Core template engine
│   ├── engine/
│   │   ├── __init__.py
│   │   ├── renderer.py
│   │   ├── validator.py
│   │   ├── composer.py
│   │   └── registry.py
│   ├── models/
│   │   ├── application.py
│   │   ├── template.py
│   │   ├── environment.py
│   │   └── deployment.py
│   └── plugins/
│       ├── secrets/
│       ├── networking/
│       └── monitoring/
│
├── libraries/                       # Shared template libraries
│   ├── base/
│   │   ├── macros/
│   │   ├── partials/
│   │   └── layouts/
│   ├── security/
│   │   ├── rbac/
│   │   ├── secrets/
│   │   └── compliance/
│   ├── observability/
│   │   ├── logging/
│   │   ├── metrics/
│   │   └── tracing/
│   ├── networking/
│   │   ├── ingress/
│   │   ├── service-mesh/
│   │   └── load-balancing/
│   └── cloud-providers/
│       ├── aws/
│       ├── azure/
│       ├── gcp/
│       └── kubernetes/
│
├── marketplace/                     # Template marketplace
│   ├── registry/
│   │   ├── index.json
│   │   └── applications/
│   ├── api/
│   │   ├── server.py
│   │   ├── routes/
│   │   └── models/
│   └── web/
│       ├── index.html
│       ├── search.js
│       └── assets/
│
├── cli/                            # CLI tool
│   ├── tmplctl/
│   │   ├── __main__.py
│   │   ├── commands/
│   │   ├── config/
│   │   └── utils/
│   ├── setup.py
│   └── requirements.txt
│
├── tests/                        # Testing framework
│   ├── unit/
│   ├── integration/
│   ├── e2e/
│   ├── fixtures/
│   └── helpers/
│
├── tools/                          # Development tools
│   ├── linters/
│   ├── generators/
│   ├── validators/
│   └── migrators/
│
├── docs/                           # Documentation
│   ├── getting-started/
│   ├── user-guide/
│   ├── developer-guide/
│   ├── api-reference/
│   └── best-practices/
│
├── examples/                       # Example deployments
│   ├── single-app/
│   ├── microservices/
│   ├── multi-cloud/
│   └── hybrid-cloud/
│
├── schemas/                        # JSON/YAML schemas
│   ├── application.schema.json
│   ├── template.schema.json
│   ├── environment.schema.json
│   └── manifest.schema.json
│
└── scripts/                        # Automation scripts
    ├── bootstrap.sh
    └── migrate.py
```

### Application Template Structure

Each application follows a standardized structure:

```
applications/{category}/{app-name}/
├── manifest.yaml                   # Application metadata
├── README.md                       # Application-specific docs
├── LICENSE                         # License information
├── versions/                       # Version management
│   ├── v1.0.0/
│   │   ├── templates/
│   │   ├── values/
│   │   └── changelog.md
│   └── latest -> v1.0.0
├── templates/                      # Current version templates
│   ├── docker-compose.j2
│   ├── kubernetes/
│   │   ├── deployment.j2
│   │   ├── service.j2
│   │   ├── configmap.j2
│   │   └── helm/
│   ├── terraform/
│   │   ├── main.tf.j2
│   │   ├── variables.tf.j2
│   │   └── outputs.tf.j2
│   └── ansible/
│       ├── playbook.yml.j2
│       └── roles/
├── values/                         # Default configurations
│   ├── base.yaml
│   ├── environments/
│   │   ├── dev.yaml
│   │   ├── staging.yaml
│   │   └── production.yaml
│   └── clouds/
│       ├── aws.yaml
│       ├── azure.yaml
│       └── gcp.yaml
├── tests/                          # Application tests
│   ├── unit/
│   ├── integration/
│   └── smoke/
├── scripts/                        # Helper scripts
│   ├── pre-deploy.sh
│   ├── post-deploy.sh
│   └── health-check.sh
├── policies/                       # Security/compliance policies
│   ├── security.yaml
│   ├── resource-limits.yaml
│   └── compliance.yaml
└── .app-config.yaml               # Application configuration
```

### Core Components

#### 1. Application Manifest (manifest.yaml)

```yaml
apiVersion: template.io/v1
kind: Application
metadata:
  name: erpnext
  description: |
    ERPNext is an open-source enterprise resource planning (ERP) software that helps manage 
    business operations including accounting, inventory, sales, and more.
  version: v15.76.0
  category: enterprise
  tags:
    - erp
    - business
    - accounting
    - inventory
  maintainers:
    - name: ERPNext Team
      email: developers@erpnext.com
  documentation: https://docs.erpnext.com
  repository: https://github.com/frappe/erpnext
  license: MIT
spec:
  platforms:
    - docker-compose
    - kubernetes
    - helm
    - terraform
  requirements:
    min_cpu: "1"
    min_memory: "2Gi"
    min_storage: "10Gi"
  dependencies:
    - name: mariadb
      version: ">=10.6"
      optional: false
    - name: redis
      version: ">=6.0"
      optional: false
    - name: nginx
      version: ">=1.20"
      optional: true
  security:
    run_as_non_root: true
    read_only_root_filesystem: false
    allow_privilege_escalation: false
```

#### 2. Template Engine (core/engine/)

```python
# core/engine/renderer.py
"""
Advanced Template Rendering Engine with Multi-Format Support
"""

import os
import json
import yaml
from typing import Dict, Any, Optional, List
from pathlib import Path
from abc import ABC, abstractmethod
import jinja2
from jinja2 import Environment, FileSystemLoader, select_autoescape
import jsonschema
from ruamel.yaml import YAML
import hcl2
import chevron

class TemplateRenderer(ABC):
    """Abstract base class for template renderers"""

    @abstractmethod
    def render(self, template_path: Path, context: Dict[str, Any]) -> str:
        """Render template with given context"""
        pass

    @abstractmethod
    def validate_syntax(self, template_path: Path) -> List[str]:
        """Validate template syntax"""
        pass

class Jinja2Renderer(TemplateRenderer):
    """Jinja2 template renderer with advanced features"""

    def __init__(self, template_dirs: List[Path], extensions: List[str] = None):
        self.template_dirs = template_dirs
        self.env = Environment(
            loader=FileSystemLoader([str(d) for d in template_dirs]),
            autoescape=select_autoescape(['html', 'xml']),
            extensions=extensions or [],
            trim_blocks=True,
            lstrip_blocks=True,
            undefined=jinja2.StrictUndefined
        )

        # Custom filters
        self.env.filters.update({
            'to_yaml': self._to_yaml,
            'to_json': self._to_json,
            'b64encode': self._b64encode,
            'b64decode': self._b64decode,
            'hash_sha256': self._hash_sha256,
            'indent': self._indent,
            'regex_replace': self._regex_replace
        })

        # Custom tests
        self.env.tests.update({
            'version_compare': self._version_compare,
            'ip_address': self._is_ip_address,
            'url': self._is_url
        })

    def render(self, template_path: Path, context: Dict[str, Any]) -> str:
        """Render Jinja2 template"""
        try:
            template = self.env.get_template(str(template_path.relative_to(self.template_dirs[0])))
            return template.render(**context)
        except jinja2.TemplateError as e:
            raise TemplateRenderError(f"Template rendering failed: {e}")

    def validate_syntax(self, template_path: Path) -> List[str]:
        """Validate Jinja2 template syntax"""
        errors = []
        try:
            self.env.get_template(str(template_path.relative_to(self.template_dirs[0])))
        except jinja2.TemplateSyntaxError as e:
            errors.append(f"Syntax error at line {e.lineno}: {e.message}")
        except jinja2.TemplateNotFound as e:
            errors.append(f"Template not found: {e.name}")
        return errors

    @staticmethod
    def _to_yaml(value):
        """Convert value to YAML string"""
        yaml = YAML()
        yaml.default_flow_style = False
        stream = StringIO()
        yaml.dump(value, stream)
        return stream.getvalue()

    @staticmethod
    def _to_json(value, indent=2):
        """Convert value to JSON string"""
        return json.dumps(value, indent=indent, ensure_ascii=False)

    @staticmethod
    def _b64encode(value):
        """Base64 encode string"""
        import base64
        return base64.b64encode(value.encode()).decode()

    @staticmethod
    def _b64decode(value):
        """Base64 decode string"""
        import base64
        return base64.b64decode(value).decode()

    @staticmethod
    def _hash_sha256(value):
        """Generate SHA256 hash"""
        import hashlib
        return hashlib.sha256(value.encode()).hexdigest()

    @staticmethod
    def _indent(text, width=2, first=False):
        """Indent text"""
        lines = text.splitlines()
        if not first:
            first_line = lines.pop(0) if lines else ''
        else:
            first_line = ''

        indented_lines = [' ' * width + line for line in lines]
        if first_line:
            indented_lines.insert(0, first_line)

        return '\n'.join(indented_lines)

    @staticmethod
    def _regex_replace(value, pattern, replacement):
        """Regex replace in string"""
        import re
        return re.sub(pattern, replacement, value)

    @staticmethod
    def _version_compare(version1, version2, operator):
        """Compare versions"""
        from packaging.version import Version
        v1, v2 = Version(version1), Version(version2)
        if operator == 'gt':
            return v1 > v2
        elif operator == 'gte':
            return v1 >= v2
        elif operator == 'lt':
            return v1 < v2
        elif operator == 'lte':
            return v1 <= v2
        elif operator == 'eq':
            return v1 == v2
        elif operator == 'ne':
            return v1 != v2
        return False

    @staticmethod
    def _is_ip_address(value):
        """Check if value is valid IP address"""
        import ipaddress
        try:
            ipaddress.ip_address(value)
            return True
        except ValueError:
            return False

    @staticmethod
    def _is_url(value):
        """Check if value is valid URL"""
        from urllib.parse import urlparse
        parsed = urlparse(value)
        return parsed.scheme and parsed.netloc

class HelmRenderer(TemplateRenderer):
    """Helm template renderer"""

    def render(self, template_path: Path, context: Dict[str, Any]) -> str:
        """Render Helm template using helm template command"""
        # Implementation would call helm CLI
        pass

class TerraformRenderer(TemplateRenderer):
    """Terraform template renderer"""

    def render(self, template_path: Path, context: Dict[str, Any]) -> str:
        """Render Terraform template"""
        # Implementation for .tf.j2 files
        pass

class TemplateComposer:
    """Compose multiple templates into a single deployment"""

    def __init__(self, renderer: TemplateRenderer):
        self.renderer = renderer

    def compose(self,
                application: str,
                environment: str,
                platform: str,
                context: Dict[str, Any]) -> Dict[str, str]:
        """Compose templates for deployment"""

        # Load application manifest
        manifest = self._load_manifest(application)

        # Merge context with defaults
        merged_context = self._merge_context(manifest, environment, context)

        # Render templates
        rendered = {}
        template_dir = Path(f"applications/{manifest['category']}/{application}/templates/{platform}")

        for template_file in template_dir.glob("**/*.j2"):
            rendered_content = self.renderer.render(template_file, merged_context)
            output_file = str(template_file.relative_to(template_dir)).replace('.j2', '')
            rendered[output_file] = rendered_content

        return rendered
```

#### 3. CLI Tool (cli/tmplctl/)

```python
# cli/tmplctl/__main__.py
"""
Template Platform CLI - Main Entry Point
"""

import click
import sys
from pathlib import Path
from typing import Optional
from .commands import (
    init, render, validate, deploy, test,
    publish, search, install, upgrade
)
from .config import Config
from .utils import setup_logging, check_updates

@click.group()
@click.version_option(version='2.0.0')
@click.option('--config', '-c', type=Path, help='Config file path')
@click.option('--verbose', '-v', count=True, help='Increase verbosity')
@click.option('--quiet', '-q', is_flag=True, help='Suppress output')
@click.pass_context
def cli(ctx, config: Optional[Path], verbose: int, quiet: bool):
    """Template Platform CLI - Manage and deploy application templates"""

    # Setup context
    ctx.ensure_object(dict)
    ctx.obj['config'] = Config.load(config)
    ctx.obj['verbose'] = verbose
    ctx.obj['quiet'] = quiet

    # Setup logging
    setup_logging(verbose, quiet)

    # Check for updates (in background)
    if not quiet:
        check_updates()

@cli.command()
@click.argument('name')
@click.option('--template', '-t', help='Base template to use')
@click.option('--version', '-v', help='Template version')
@click.option('--output', '-o', type=Path, help='Output directory')
@click.option('--interactive', '-i', is_flag=True, help='Interactive mode')
@click.pass_context
def init(ctx, name: str, template: str, version: str,
         output: Path, interactive: bool):
    """Initialize new application from template"""

    from .commands.init import InitCommand

    cmd = InitCommand(ctx.obj['config'])
    cmd.execute(
        name=name,
        template=template,
        version=version,
        output=output,
        interactive=interactive
    )

@cli.command()
@click.argument('application')
@click.option('--env', '-e', required=True, help='Environment to render')
@click.option('--format', '-f', type=click.Choice(['docker', 'k8s', 'helm', 'terraform']))
@click.option('--values', '-v', multiple=True, help='Additional values files')
@click.option('--set', '-s', multiple=True, help='Set values (key=value)')
@click.option('--output', '-o', type=Path, help='Output file/directory')
@click.option('--dry-run', is_flag=True, help='Show what would be rendered')
@click.pass_context
def render(ctx, application: str, env: str, format: str,
          values: tuple, set: tuple, output: Path, dry_run: bool):
    """Render templates for deployment"""

    from .commands.render import RenderCommand

    cmd = RenderCommand(ctx.obj['config'])
    cmd.execute(
        application=application,
        environment=env,
        format=format,
        values=values,
        set_values=set,
        output=output,
        dry_run=dry_run
    )
```

#### 4. Marketplace API (marketplace/api/)

```python
# marketplace/api/server.py
"""
Template Marketplace API Server
"""

from fastapi import FastAPI, HTTPException, Query, Depends, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime
import asyncio
from pathlib import Path

app = FastAPI(
    title="Template Marketplace API",
    description="API for managing and discovering application templates",
    version="2.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

security = HTTPBearer()

# Models
class Application(BaseModel):
    """Application model"""
    id: str
    name: str
    description: str
    version: str
    category: str
    tags: List[str]
    maintainer: str
    downloads: int = 0
    rating: float = 0.0
    created_at: datetime
    updated_at: datetime

class SearchRequest(BaseModel):
    """Search request model"""
    query: Optional[str] = None
    category: Optional[str] = None
    tags: List[str] = []
    limit: int = Field(default=20, le=100)
    offset: int = Field(default=0, ge=0)

class DeploymentRequest(BaseModel):
    """Deployment request model"""
    application: str
    version: str
    environment: str
    platform: str
    values: Dict[str, Any] = {}
    dry_run: bool = False

# API Endpoints
@app.get("/")
async def root():
    """API root endpoint"""
    return {
        "name": "Template Marketplace API",
        "version": "2.0.0",
        "status": "active"
    }

@app.post("/api/v1/search", response_model=List[Application])
async def search_applications(request: SearchRequest):
    """Search for applications in marketplace"""

    # Implementation would query database/registry
    results = []  # Placeholder

    return results

@app.get("/api/v1/applications/{app_id}")
async def get_application(app_id: str):
    """Get application details"""

    # Implementation would fetch from registry
    app = {}  # Placeholder

    if not app:
        raise HTTPException(status_code=404, detail="Application not found")

    return app

@app.post("/api/v1/applications/{app_id}/deploy")
async def deploy_application(
    app_id: str,
    request: DeploymentRequest,
    credentials: HTTPAuthorizationCredentials = Depends(security)
):
    """Deploy application"""

    # Implementation would trigger deployment
    deployment_id = f"deploy-{app_id}-{int(datetime.now().timestamp())}"

    return {
        "deployment_id": deployment_id,
        "status": "initiated",
        "application": app_id
    }

@app.get("/api/v1/deployments/{deployment_id}")
async def get_deployment_status(deployment_id: str):
    """Get deployment status"""

    # Implementation would query deployment status
    return {
        "deployment_id": deployment_id,
        "status": "running",
        "progress": 75
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
```

## Advanced Implementation Details

### State-Aware Deployment Manager

```python
# deployment_manager.py implementation details
elif backend_type == "hybrid":
    return HybridBackend(self.config["backend"])
else:
    return LocalBackend(self.state_dir)

def deploy(self, compose_content: str, env_vars: Dict[str, str],
           configs: Dict[str, str], secrets: Dict[str, str],
           metadata: Dict[str, Any]) -> Dict[str, Any]:
    """Deploy new configuration with state management"""
    with self._acquire_lock():
        deployment_id = self._generate_deployment_id(metadata)
        version_dir = self.versions_dir / deployment_id
        version_dir.mkdir(parents=True)

        # Save deployment files
        self._save_deployment(version_dir, compose_content, env_vars, configs, secrets, metadata)

        # Validate deployment
        if not self._validate_deployment(version_dir):
            raise ValueError("Deployment validation failed")

        # Apply deployment
        self._apply_deployment(version_dir)

        # Update state
        state = self._update_state(deployment_id, metadata)

        # Push to backend
        if self.backend:
            self.backend.push(state, version_dir)

        return state

def _acquire_lock(self):
    """Acquire deployment lock"""
    return DeploymentLock(self.lock_file)

def _generate_deployment_id(self, metadata: Dict[str, Any]) -> str:
    """Generate unique deployment ID"""
    return f"v{version}-{timestamp}"

def _save_deployment(self, version_dir: Path, compose_content: str,
                    env_vars: Dict[str, str], configs: Dict[str, str],
                    secrets: Dict[str, str], metadata: Dict[str, Any]):
    """Save deployment files"""
    # Save Docker Compose file
    (version_dir / "docker-compose.yml").write_text(compose_content)

    # Save environment variables
    env_content = "\n".join(f"{k}={v}" for k, v in env_vars.items())
    (version_dir / ".env").write_text(env_content)

    # Save configurations
    configs_dir = version_dir / "configs"
    configs_dir.mkdir(exist_ok=True)
    for path, content in configs.items():
        config_file = configs_dir / path
        config_file.parent.mkdir(parents=True, exist_ok=True)
        config_file.write_text(content)

    # Save encrypted secrets
    if self.config["encryption"]["enabled"]:
        self._save_encrypted_secrets(version_dir, secrets)
    else:
        secrets_dir = version_dir / "secrets"
        secrets_dir.mkdir(exist_ok=True)
        for name, value in secrets.items():
            (secrets_dir / f"{name}.txt").write_text(value)

    # Save metadata
    metadata["deployment_timestamp"] = datetime.utcnow().isoformat()
    metadata["server_id"] = self.config["server_id"]
    metadata["environment"] = self.config["environment"]

    with open(version_dir / "metadata.json", 'w') as f:
        json.dump(metadata, f, indent=2)

    # Generate checksums
    self._generate_checksums(version_dir)

def _save_encrypted_secrets(self, version_dir: Path, secrets: Dict[str, str]):
    """Save secrets with encryption"""
    key = self._get_encryption_key()
    f = Fernet(key)

    secrets_dir = version_dir / "secrets"
    secrets_dir.mkdir(exist_ok=True)

    vault_file = secrets_dir / "vault.enc"
    encrypted_data = f.encrypt(json.dumps(secrets).encode())
    vault_file.write_bytes(encrypted_data)
    vault_file.chmod(0o600)

def _get_encryption_key(self) -> bytes:
    """Get or generate encryption key"""
    key_file = self.state_dir / ".encryption_key"
    if key_file.exists():
        return key_file.read_bytes()
    else:
        key = Fernet.generate_key()
        key_file.write_bytes(key)
        key_file.chmod(0o600)
        return key

def _generate_checksums(self, version_dir: Path):
    """Generate checksums for all files"""
    checksums = {}
    for file_path in version_dir.rglob("*"):
        if file_path.is_file() and file_path.name != "checksums.json":
            with open(file_path, 'rb') as f:
                content = f.read()
                checksums[str(file_path.relative_to(version_dir))] = hashlib.sha256(content).hexdigest()

    with open(version_dir / "checksums.json", 'w') as f:
        json.dump(checksums, f, indent=2)

def _validate_deployment(self, version_dir: Path) -> bool:
    """Validate deployment before applying"""
    # Verify checksums
    checksums_file = version_dir / "checksums.json"
    if not checksums_file.exists():
        return False

    # Validate Docker Compose syntax
    compose_file = version_dir / "docker-compose.yml"
    if compose_file.exists():
        result = subprocess.run([
            "docker-compose", "-f", str(compose_file), "config", "--quiet"
        ], capture_output=True)
        if result.returncode != 0:
            return False

    return True

def _apply_deployment(self, version_dir: Path):
    """Apply deployment to current"""
    # Create symlink to current
    if self.current_dir.exists():
        self.current_dir.unlink()
    self.current_dir.symlink_to(version_dir)

    # Decrypt secrets for runtime
    self._decrypt_secrets_in_place(version_dir)

    # Apply with docker-compose
    os.chdir(self.current_dir)
    self._run_docker_compose("up", "-d")

def _decrypt_secrets_in_place(self, deployment_dir: Path):
    """Decrypt secrets for runtime use"""
    vault_file = deployment_dir / "secrets" / "vault.enc"
    if vault_file.exists():
        key = self._get_encryption_key()
        f = Fernet(key)

        encrypted_data = vault_file.read_bytes()
        secrets = json.loads(f.decrypt(encrypted_data).decode())

        # Write individual secret files
        for name, value in secrets.items():
            secret_file = deployment_dir / "secrets" / f"{name}.txt"
            secret_file.write_text(value)
            secret_file.chmod(0o600)

        # Remove encrypted vault
        vault_file.unlink()

def _run_docker_compose(self, *args):
    """Run docker-compose command"""
    cmd = ["docker-compose", "-f", "docker-compose.yml"] + list(args)
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        raise subprocess.CalledProcessError(result.returncode, cmd, result.stderr)
    return result.stdout

def rollback(self, deployment_id: Optional[str] = None) -> Dict[str, Any]:
    """Rollback to previous deployment"""
    if deployment_id:
        target_dir = self.versions_dir / deployment_id
        if not target_dir.exists():
            raise ValueError(f"Deployment {deployment_id} not found")
    else:
        # Find previous deployment
        state = self.get_state()
        deployments = sorted(state.get("deployments", []),
                           key=lambda x: x["timestamp"], reverse=True)
        if len(deployments) < 2:
            raise ValueError("No previous deployment found")
        deployment_id = deployments[1]["id"]
        target_dir = self.versions_dir / deployment_id

    # Apply rollback
    self._apply_deployment(target_dir)

    # Update state
    metadata = {"rollback": True, "rollback_from": self.get_state()["current_deployment"]}
    return self._update_state(deployment_id, metadata)

def get_state(self) -> Dict[str, Any]:
    """Get current deployment state"""
    if self.state_file.exists():
        with open(self.state_file) as f:
            return json.load(f)
    return {}

def _update_state(self, deployment_id: str, metadata: Dict[str, Any]) -> Dict[str, Any]:
    """Update state manifest"""
    state = self.get_state()

    deployment_record = {
        "id": deployment_id,
        "timestamp": datetime.utcnow().isoformat(),
        "metadata": metadata
    }

    state["current_deployment"] = deployment_id
    state["last_update"] = datetime.utcnow().isoformat()
    state.setdefault("deployments", []).append(deployment_record)

    # Keep only last 10 deployment records
    state["deployments"] = state["deployments"][-10:]

    with open(self.state_file, 'w') as f:
        json.dump(state, f, indent=2)

    return state
```

### Hybrid Backend Storage Strategy

```python
# backends/hybrid_backend.py
"""
Hybrid storage backend combining multiple storage strategies
"""

class HybridBackend:
    """
    Hybrid backend that uses:
    - Git for version control and audit trail
    - S3/Object storage for large files and backups
    - Consul/etcd for real-time state coordination
    - PostgreSQL for metadata and search
    """

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.git = GitBackend(config.get("git", {}))
        self.s3 = S3Backend(config.get("s3", {}))
        self.consul = ConsulBackend(config.get("consul", {}))
        self.db = PostgreSQLBackend(config.get("postgresql", {}))

    def push(self, state: Dict[str, Any], deployment_dir: Path) -> Dict[str, Any]:
        """Push state to all backends"""
        results = {}

        # 1. Store metadata in PostgreSQL for fast queries
        results["db"] = self.db.store_metadata(state)

        # 2. Push configuration files to Git for version control
        results["git"] = self.git.commit_deployment(
            deployment_dir,
            message=f"Deploy {state['current_deployment']}"
        )

        # 3. Upload large files and backups to S3
        results["s3"] = self.s3.upload_deployment(deployment_dir)

        # 4. Update real-time state in Consul
        results["consul"] = self.consul.update_state(state)

        return results

    def pull(self, deployment_id: str) -> Path:
        """Pull deployment from backends"""
        # Get metadata from database
        metadata = self.db.get_metadata(deployment_id)

        # Determine best source based on metadata
        if metadata.get("storage", {}).get("primary") == "s3":
            return self.s3.download_deployment(deployment_id)
        else:
            return self.git.checkout_deployment(deployment_id)

    def sync(self) -> Dict[str, Any]:
        """Synchronize state across all backends"""
        # Get authoritative state from Consul
        consul_state = self.consul.get_state()

        # Verify against database
        db_state = self.db.get_latest_state()

        if consul_state != db_state:
            # Reconcile differences
            self.consul.update_state(db_state)

        return consul_state

    def search(self, criteria: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Search deployments using database"""
        return self.db.search_deployments(criteria)

class GitBackend:
    """Git-based state storage"""

    def __init__(self, config: Dict[str, Any]):
        self.repo_url = config["repo"]
        self.branch = config.get("branch", "main")
        self.path = config.get("path", "states")
        self.local_path = Path("/var/cache/deployment-state/git")
        self.repo = self._init_repo()

    def _init_repo(self) -> git.Repo:
        """Initialize or clone repository"""
        if self.local_path.exists():
            repo = git.Repo(self.local_path)
            repo.remotes.origin.pull()
        else:
            repo = git.Repo.clone_from(self.repo_url, self.local_path, branch=self.branch)
        return repo

    def commit_deployment(self, deployment_dir: Path, message: str) -> str:
        """Commit deployment to Git"""
        # Copy files to repo
        target_path = self.local_path / self.path / deployment_dir.name
        if target_path.exists():
            shutil.rmtree(target_path)
        shutil.copytree(deployment_dir, target_path)

        # Add and commit
        self.repo.index.add([str(target_path)])
        commit = self.repo.index.commit(message)

        # Push to remote
        self.repo.remotes.origin.push()

        return commit.hexsha

class S3Backend:
    """S3/Object storage backend"""

    def __init__(self, config: Dict[str, Any]):
        self.bucket = config["bucket"]
        self.prefix = config.get("prefix", "deployments")
        self.client = boto3.client('s3',
                                 aws_access_key_id=config["access_key"],
                                 aws_secret_access_key=config["secret_key"],
                                 region_name=config.get("region", "us-east-1"))

    def upload_deployment(self, deployment_dir: Path) -> Dict[str, Any]:
        """Upload deployment to S3"""
        archive_path = f"/tmp/{deployment_dir.name}.tar.gz"

        # Create compressed archive
        with tarfile.open(archive_path, "w:gz") as tar:
            tar.add(deployment_dir, arcname=deployment_dir.name)

        # Upload to S3
        key = f"{self.prefix}/{deployment_dir.name}.tar.gz"
        self.client.upload_file(archive_path, self.bucket, key)

        # Cleanup
        os.unlink(archive_path)

        return {
            "bucket": self.bucket,
            "key": key,
            "url": f"s3://{self.bucket}/{key}"
        }

    def download_deployment(self, deployment_id: str) -> Path:
        """Download deployment from S3"""
        key = f"{self.prefix}/{deployment_id}.tar.gz"
        archive_path = f"/tmp/{deployment_id}.tar.gz"

        # Download from S3
        self.client.download_file(self.bucket, key, archive_path)

        # Extract archive
        extract_path = Path(f"/tmp/{deployment_id}")
        with tarfile.open(archive_path, "r:gz") as tar:
            tar.extractall(extract_path)

        # Cleanup archive
        os.unlink(archive_path)

        local_path = extract_path / deployment_id
        return local_path

class ConsulBackend:
    """Consul KV store backend for real-time state"""

    def __init__(self, config: Dict[str, Any]):
        self.consul = Consul(
            host=config.get("host", "localhost"),
            port=config.get("port", 8500),
            token=config.get("token")
        )
        self.prefix = config.get("prefix", "deployment-states")

    def update_state(self, state: Dict[str, Any]) -> bool:
        """Update state in Consul"""
        key = f"{self.prefix}/current"
        value = json.dumps(state)
        return self.consul.kv.put(key, value)

    def get_state(self) -> Dict[str, Any]:
        """Get current state from Consul"""
        key = f"{self.prefix}/current"
        index, data = self.consul.kv.get(key)
        if data:
            return json.loads(data['Value'].decode())
        return {}

    def watch_state(self, callback):
        """Watch for state changes"""
        key = f"{self.prefix}/current"
        index = None

        while True:
            index, data = self.consul.kv.get(key, index=index)
            if data:
                state = json.loads(data['Value'].decode())
                callback(state)

class PostgreSQLBackend:
    """PostgreSQL backend for metadata and search"""

    def __init__(self, config: Dict[str, Any]):
        self.conn_params = {
            "host": config.get("host", "localhost"),
            "port": config.get("port", 5432),
            "database": config.get("database", "deployments"),
            "user": config.get("user", "postgres"),
            "password": config.get("password")
        }
        self._init_schema()

    def _init_schema(self):
        """Initialize database schema"""
        schema_sql = """
        CREATE TABLE IF NOT EXISTS deployments (
            id VARCHAR(255) PRIMARY KEY,
            server_id VARCHAR(255) NOT NULL,
            environment VARCHAR(50) NOT NULL,
            application VARCHAR(255) NOT NULL,
            version VARCHAR(50) NOT NULL,
            status VARCHAR(50) NOT NULL DEFAULT 'active',
            metadata JSONB NOT NULL,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        );

        CREATE INDEX IF NOT EXISTS idx_deployments_server_env
        ON deployments(server_id, environment);

        CREATE INDEX IF NOT EXISTS idx_deployments_application
        ON deployments(application);

        CREATE INDEX IF NOT EXISTS idx_deployments_metadata
        ON deployments USING GIN(metadata);
        """

        with psycopg2.connect(**self.conn_params) as conn:
            with conn.cursor() as cur:
                cur.execute(schema_sql)

    def store_metadata(self, state: Dict[str, Any]) -> int:
        """Store deployment metadata"""
        sql = """
        INSERT INTO deployments (id, server_id, environment, application, version, metadata)
        VALUES (%(id)s, %(server_id)s, %(environment)s, %(application)s, %(version)s, %(metadata)s)
        ON CONFLICT (id) DO UPDATE SET
            metadata = EXCLUDED.metadata,
            updated_at = NOW()
        RETURNING id;
        """

        with psycopg2.connect(**self.conn_params) as conn:
            with conn.cursor() as cur:
                cur.execute(sql, {
                    "id": state["current_deployment"],
                    "server_id": state.get("server_id"),
                    "environment": state.get("environment"),
                    "application": state.get("application"),
                    "version": state.get("version"),
                    "metadata": json.dumps(state)
                })
                return cur.fetchone()[0]

    def search_deployments(self, criteria: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Search deployments with criteria"""
        where_clauses = []
        params = {}

        if "server_id" in criteria:
            where_clauses.append("server_id = %(server_id)s")
            params["server_id"] = criteria["server_id"]

        if "environment" in criteria:
            where_clauses.append("environment = %(environment)s")
            params["environment"] = criteria["environment"]

        if "application" in criteria:
            where_clauses.append("application = %(application)s")
            params["application"] = criteria["application"]

        where_sql = " AND ".join(where_clauses) if where_clauses else "1=1"

        sql = f"""
        SELECT id, server_id, environment, application, version,
               status, metadata, created_at, updated_at
        FROM deployments
        WHERE {where_sql}
        ORDER BY created_at DESC
        LIMIT %(limit)s OFFSET %(offset)s;
        """

        params.update({
            "limit": criteria.get("limit", 50),
            "offset": criteria.get("offset", 0)
        })

        with psycopg2.connect(**self.conn_params) as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(sql, params)
                return [dict(row) for row in cur.fetchall()]
```

### Best Practices Implementation

#### Directory Structure for Multi-Server ERPNext

```bash
# Organization for multi-server ERPNext deployment
/opt/erpnext-deployments/
├── environments/
│   ├── production/
│   │   ├── servers/
│   │   │   ├── erp-prod-01/
│   │   │   │   ├── current -> ../../../versions/v15.76.0-20240115/
│   │   │   │   ├── data/
│   │   │   │   │   ├── sites/
│   │   │   │   │   ├── files/
│   │   │   │   │   └── backups/
│   │   │   │   └── state.json
│   │   │   ├── erp-prod-02/
│   │   │   └── erp-prod-03/
│   │   ├── load-balancer/
│   │   │   └── haproxy.cfg
│   │   └── shared/
│   │       ├── database/
│   │       └── redis/
│   ├── staging/
│   └── development/
│
├── versions/                       # Shared version repository
│   ├── v15.76.0-20240115/
│   ├── v15.75.0-20240101/
│   └── v15.74.0-20231215/
│
├── templates/                      # Template library
│   ├── erpnext/
│   │   ├── docker-compose.j2
│   │   ├── configs/
│   │   └── values/
│   └── shared/
│       └── macros/
│
└── orchestration/
    ├── ansible/                   # Ansible playbooks
    └── scripts/                   # Utility scripts
```

#### State Synchronization Script

```bash
#!/bin/bash
# sync_deployment_state.sh - Synchronize deployment state across servers

set -euo pipefail

# Configuration
STATE_DIR="/opt/deployment-state"
CENTRAL_API="https://deploy-api.example.com"
SERVER_ID=$(hostname)
ENVIRONMENT=${ENVIRONMENT:-production}

# Functions
log() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] $*" | tee -a "${STATE_DIR}/logs/sync.log"
}

sync_to_central() {
    local state_file="${STATE_DIR}/.state/manifest.json"

    if [[ ! -f "$state_file" ]]; then
        log "ERROR: State file not found"
        return 1
    fi

    # Upload state to central API
    curl -X POST "${CENTRAL_API}/api/v1/servers/${SERVER_ID}/state" \
         -H "Content-Type: application/json" \
         -H "Authorization: Bearer ${API_TOKEN}" \
         -d @"${state_file}" \
         --silent --show-error | jq .
}

pull_from_central() {
    local deployment_id=$1

    # Download deployment from central
    curl -X GET "${CENTRAL_API}/api/v1/deployments/${deployment_id}/package" \
         -H "Authorization: Bearer ${API_TOKEN}" \
         --output "${STATE_DIR}/pending/${deployment_id}.tar.gz" \
         --silent --show-error

    # Extract to pending
    tar -xzf "${STATE_DIR}/pending/${deployment_id}.tar.gz" \
        -C "${STATE_DIR}/pending/"
}

verify_state() {
    # Verify checksums
    cd "${STATE_DIR}/current"
    sha256sum -c checksums.sha256 > /dev/null 2>&1 || {
        log "WARNING: Checksum verification failed"
        return 1
    }

    # Verify Docker services
    docker-compose ps --services | while read -r service; do
        if ! docker-compose ps "$service" | grep -q "Up"; then
            log "WARNING: Service $service is not running"
            return 1
        fi
    done

    return 0
}

# Main execution
main() {
    log "Starting state synchronization for ${SERVER_ID}"

    # Acquire lock
    exec 200>"${STATE_DIR}/.state/sync.lock"
    flock -n 200 || {
        log "ERROR: Another sync is already running"
        exit 1
    }

    # Sync current state to central
    if sync_to_central; then
        log "State synchronized to central"
    else
        log "Failed to sync state"
        exit 1
    fi

    # Check for pending deployments
    PENDING=$(curl -s "${CENTRAL_API}/api/v1/servers/${SERVER_ID}/pending" \
                   -H "Authorization: Bearer ${API_TOKEN}" | jq -r '.deployment_id // empty')

    if [[ -n "$PENDING" ]]; then
        log "Found pending deployment: ${PENDING}"
        pull_from_central "$PENDING"

        # Trigger deployment service
        systemctl start "deploy@${PENDING}.service"
    fi

    # Verify current state
    if verify_state; then
        log "State verification successful"
    else
        log "State verification failed, triggering reconciliation"
        systemctl start deployment-reconcile.service
    fi

    log "Synchronization complete"
}

# Run if not sourced
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi
```

## Summary

This comprehensive storage strategy provides:

### **State Management**

- 🗂️ **Multi-layer storage**: Local, Git, S3, Database, and KV store
- 🔄 **Version control**: Complete history with rollback capability
- 🔐 **Encryption**: Secure secret management with multiple key sources
- 📊 **Metadata tracking**: Rich metadata for search and analytics

### **Organizational Benefits**

- 🏢 **Multi-server support**: Centralized management for server fleets
- 🌍 **Environment separation**: Clear isolation between dev/staging/prod
- 📦 **Application grouping**: Logical organization by application type
- 🔍 **Audit trail**: Complete deployment history and compliance

### **Operational Excellence**

- 🚀 **Automated workflows**: Orchestrated deployment pipelines
- 🔄 **Drift detection**: Automatic configuration drift monitoring
- 🛡️ **Rollback capability**: Quick recovery from failed deployments
- 📈 **Performance monitoring**: Metrics and alerting integration

### **Enterprise Features**

- 🔐 **Compliance ready**: Audit logs and approval workflows
- 🌐 **Multi-cloud support**: Works with AWS, Azure, GCP
- 🔧 **Extensible**: Plugin architecture for custom backends
- 📊 **Analytics**: Deployment metrics and trends

This architecture scales from single-server deployments to large enterprise fleets, providing robust state management for template-generated configurations while maintaining security, auditability, and operational efficiency.

```

```
