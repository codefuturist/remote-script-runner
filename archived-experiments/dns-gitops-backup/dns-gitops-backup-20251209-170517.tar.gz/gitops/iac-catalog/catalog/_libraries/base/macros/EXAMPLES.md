# Macro Usage Examples

Comprehensive examples for all macros in `common.j2`.

## Health Checks

### Basic HTTP Health Check

```jinja
{{ healthcheck(
    test=['CMD-SHELL', 'curl -sf http://localhost:8080/health || exit 1'],
    interval='30s',
    timeout='10s',
    retries=5,
    start_period='40s'
) | indent(4) }}
```

Output:
```yaml
healthcheck:
  test: ['CMD-SHELL', 'curl -sf http://localhost:8080/health || exit 1']
  start_period: 40s
  interval: 30s
  timeout: 10s
  retries: 5
```

### Database Health Check

```jinja
{{ healthcheck(
    test=['CMD-SHELL', 'mysqladmin ping -h localhost --silent'],
    interval='10s'
) | indent(4) }}
```

### Redis Health Check

```jinja
{{ healthcheck(
    test=['CMD', 'redis-cli', 'ping']
) | indent(4) }}
```

## Deployment Configuration

### Basic Deployment

```jinja
{{ deploy_config(replicas=2) | indent(4) }}
```

### With Resource Limits

```jinja
{{ deploy_config(
    replicas=3,
    resources={
        'limits': {
            'cpus': '2.0',
            'memory': '2G'
        },
        'reservations': {
            'cpus': '1.0',
            'memory': '1G'
        }
    }
) | indent(4) }}
```

### With Placement Constraints

```jinja
{{ deploy_config(
    replicas=2,
    placement={
        'constraints': [
            'node.role == worker',
            'node.labels.environment == production'
        ]
    }
) | indent(4) }}
```

### Complete Deployment Configuration

```jinja
{{ deploy_config(
    replicas=3,
    resources={
        'limits': {'cpus': '1.0', 'memory': '512M'},
        'reservations': {'cpus': '0.5', 'memory': '256M'}
    },
    restart_policy_config={
        'condition': 'on-failure',
        'max_attempts': 3,
        'delay': '5s'
    },
    placement={
        'constraints': ['node.role == worker']
    },
    update_config={
        'parallelism': 1,
        'delay': '10s',
        'failure_action': 'rollback'
    }
) | indent(4) }}
```

## Logging

### Basic Logging

```jinja
{{ logging_config() | indent(4) }}
```

### With Service Name

```jinja
{{ logging_config(
    service_name='web',
    max_size='20m',
    max_file='5'
) | indent(4) }}
```

## Labels

### Service Labels

```jinja
{{ service_labels(
    app_name='myapp',
    service_name='web',
    version='1.0.0',
    environment='production',
    additional_labels={
        'com.example.team': 'platform',
        'com.example.project': 'core'
    }
) | indent(4) }}
```

### Traefik Labels

#### Simple HTTP

```jinja
{{ traefik_labels({
    'service_name': 'web',
    'rule': 'Host(`example.com`)',
    'port': 8080
}) | indent(4) }}
```

#### With SSL

```jinja
{{ traefik_labels({
    'service_name': 'api',
    'rule': 'Host(`api.example.com`)',
    'port': 8000,
    'ssl_enabled': true
}) | indent(4) }}
```

#### Custom Entrypoints

```jinja
{{ traefik_labels({
    'service_name': 'backend',
    'rule': 'Host(`backend.example.com`) && PathPrefix(`/api`)',
    'port': 3000,
    'ssl_enabled': true,
    'entrypoints': 'websecure',
    'additional_labels': {
        'traefik.http.routers.backend.middlewares': 'auth@docker'
    }
}) | indent(4) }}
```

### Watchtower Labels

```jinja
{{ watchtower_labels(
    enable=true,
    additional_labels={
        'com.centurylinklabs.watchtower.monitor-only': 'true'
    }
) | indent(4) }}
```

## Security

### Security Options

```jinja
{{ security_opts(
    no_new_privileges=true,
    additional_opts=['apparmor=docker-default']
) | indent(4) }}
```

### Capabilities

```jinja
{{ capabilities(
    add=['NET_ADMIN', 'SYS_TIME'],
    drop=['ALL']
) | indent(4) }}
```

### User Configuration

```jinja
{{ user_config(user_id=1000, group_id=1000) | indent(4) }}
```

## Dependencies

### Simple Dependencies (List)

```jinja
{{ depends_on_config(['db', 'redis', 'cache']) | indent(4) }}
```

Output:
```yaml
depends_on:
  - db
  - redis
  - cache
```

### With Health Conditions

```jinja
{{ depends_on_config([
    {'name': 'db', 'condition': 'service_healthy'},
    {'name': 'redis', 'condition': 'service_started'},
    {'name': 'cache', 'condition': 'service_healthy'}
]) | indent(4) }}
```

Output:
```yaml
depends_on:
  db:
    condition: service_healthy
  redis:
    condition: service_started
  cache:
    condition: service_healthy
```

### As Dictionary

```jinja
{{ depends_on_config({
    'db': 'service_healthy',
    'redis': 'service_started'
}) | indent(4) }}
```

## Volumes

### Service Volumes

```jinja
{{ service_volumes([
    './data:/app/data:ro',
    'logs:/app/logs',
    '/tmp:/tmp:rw'
]) | indent(4) }}
```

### Named Volumes (Compose-Level)

```jinja
{{ named_volumes({
    'db-data': {
        'driver': 'local',
        'labels': {
            'com.example.backup': 'true',
            'com.example.description': 'Database data'
        }
    },
    'app-logs': {
        'driver': 'local'
    }
}) }}
```

### Tmpfs Mounts

```jinja
{{ tmpfs_mounts(['/tmp', '/run']) | indent(4) }}
```

## Networks

### Service Networks

```jinja
{{ service_networks(['frontend', 'backend', 'database']) | indent(4) }}
```

### Compose Networks

```jinja
{{ compose_networks({
    'frontend': {
        'driver': 'bridge'
    },
    'backend': {
        'driver': 'overlay',
        'attachable': true,
        'internal': false
    },
    'database': {
        'driver': 'overlay',
        'internal': true,
        'ipam': {
            'config': [
                {
                    'subnet': '10.0.1.0/24',
                    'gateway': '10.0.1.1'
                }
            ]
        }
    },
    'external_net': {
        'external': true
    }
}) }}
```

## Environment Variables

### Environment Variables

```jinja
{{ env_vars({
    'NODE_ENV': 'production',
    'PORT': '8080',
    'DEBUG': 'false',
    'DATABASE_URL': 'postgres://db:5432/myapp'
}) | indent(4) }}
```

### Environment File

```jinja
{{ env_file('.env') | indent(4) }}
```

Or multiple files:

```jinja
{{ env_file(['.env', '.env.production']) | indent(4) }}
```

## Ports

```jinja
{{ ports_mapping([
    '80:8080',
    '443:8443',
    '127.0.0.1:3306:3306'
]) | indent(4) }}
```

## Secrets

### Service Secrets

```jinja
{{ service_secrets([
    'db_password',
    'api_key',
    {
        'source': 'jwt_secret',
        'target': '/run/secrets/jwt',
        'uid': '1000',
        'gid': '1000',
        'mode': '0400'
    }
]) | indent(4) }}
```

### Compose Secrets

```jinja
{{ compose_secrets({
    'db_password': {
        'file': './secrets/db_password.txt'
    },
    'api_key': {
        'file': './secrets/api_key.txt'
    },
    'external_secret': {
        'external': true
    }
}) }}
```

## Complete Service Example

```jinja
{% from 'catalog/_libraries/base/macros/common.j2' import 
   healthcheck,
   deploy_config,
   logging_config,
   service_labels,
   service_networks,
   service_volumes,
   env_vars,
   ports_mapping,
   depends_on_config %}

services:
  web:
    image: nginx:alpine
    {{ ports_mapping(['80:80', '443:443']) | indent(4) }}
    {{ service_volumes([
        './nginx.conf:/etc/nginx/nginx.conf:ro',
        'static:/usr/share/nginx/html'
    ]) | indent(4) }}
    {{ env_vars({
        'NGINX_HOST': 'example.com',
        'NGINX_PORT': '80'
    }) | indent(4) }}
    {{ healthcheck(['CMD', 'nginx', '-t']) | indent(4) }}
    {{ logging_config(service_name='web', max_size='20m') | indent(4) }}
    {{ service_labels(
        app_name='myapp',
        service_name='web',
        version='1.0.0'
    ) | indent(4) }}
    {{ service_networks(['frontend']) | indent(4) }}
    {{ depends_on_config(['app']) | indent(4) }}
    {{ deploy_config(
        replicas=2,
        resources={
            'limits': {'cpus': '0.5', 'memory': '256M'}
        }
    ) | indent(4) }}
```

## Advanced Patterns

### Multi-Service Template

```jinja
{% from 'catalog/_libraries/base/macros/common.j2' import 
   healthcheck, deploy_config, depends_on_config %}

version: "3.8"

services:
  db:
    image: postgres:14
    {{ healthcheck(['CMD-SHELL', 'pg_isready -U postgres']) | indent(4) }}
    {{ deploy_config(replicas=1) | indent(4) }}

  redis:
    image: redis:alpine
    {{ healthcheck(['CMD', 'redis-cli', 'ping']) | indent(4) }}

  app:
    image: myapp:latest
    {{ depends_on_config([
        {'name': 'db', 'condition': 'service_healthy'},
        {'name': 'redis', 'condition': 'service_healthy'}
    ]) | indent(4) }}
    {{ healthcheck(['CMD', 'curl', '-f', 'http://localhost:8000/health']) | indent(4) }}
    {{ deploy_config(
        replicas=3,
        resources={
            'limits': {'cpus': '1.0', 'memory': '1G'}
        }
    ) | indent(4) }}
```

## Tips

1. **Always use `| indent(X)`** to ensure proper YAML formatting
2. **Test your templates** with `render.py` before deployment
3. **Use defaults** - Most parameters have sensible defaults
4. **Combine macros** - Mix and match for complete configurations
5. **Check output** - Always verify the rendered YAML is valid
