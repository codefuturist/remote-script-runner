# Docker Compose Macro Library

This directory contains reusable Jinja2 macros for Docker Compose templates in the iac-catalog system.

## Overview

The macro library provides standardized, reusable patterns for common Docker Compose configurations. All templates in the catalog can import and use these macros to ensure consistency and reduce duplication.

## Directory Structure

```
_libraries/
├── base/
│   └── macros/
│       ├── common.j2          # Core Docker Compose macros
│       ├── README.md           # This file
│       └── EXAMPLES.md         # Usage examples
├── cloud-providers/            # Cloud-specific macros (AWS, Azure, GCP)
├── networking/                 # Networking patterns
├── observability/              # Monitoring, logging, tracing
└── security/                   # Security patterns
```

## Available Macros (common.j2)

### Deployment & Restart Policies

- **`restart_policy_content()`** - Restart policy configuration
- **`deploy_config()`** - Complete deployment with resource limits, placement, updates

### Health Checks

- **`healthcheck()`** - Standard health check configuration

### Logging

- **`logging_config()`** - Logging driver and options

### Labels & Metadata

- **`service_labels()`** - Standard service labels
- **`traefik_labels()`** - Traefik reverse proxy labels
- **`watchtower_labels()`** - Auto-update labels

### Security

- **`security_opts()`** - Security options
- **`capabilities()`** - Container capabilities (cap_add/cap_drop)
- **`user_config()`** - User/group configuration

### Dependencies

- **`depends_on_config()`** - Service dependencies with conditions

### Volumes

- **`service_volumes()`** - Volume mappings for services
- **`named_volumes()`** - Named volume definitions (compose-level)
- **`tmpfs_mounts()`** - Temporary filesystem mounts

### Networks

- **`service_networks()`** - Network assignments for services
- **`compose_networks()`** - Network definitions (compose-level)

### Environment

- **`env_vars()`** - Environment variables
- **`env_file()`** - Environment file references

### Ports

- **`ports_mapping()`** - Port mappings

### Secrets

- **`service_secrets()`** - Secrets for services
- **`compose_secrets()`** - Secret definitions (compose-level)

## Quick Start

### 1. Import Macros in Template

```jinja
{# Import from library #}
{% from 'catalog/_libraries/base/macros/common.j2' import 
   healthcheck,
   deploy_config,
   logging_config,
   service_networks %}
```

### 2. Use Macros with Proper Indentation

```jinja
services:
  web:
    image: nginx:alpine
    {{ healthcheck(['CMD', 'nginx', '-t']) | indent(4) }}
    {{ logging_config(service_name='web') | indent(4) }}
    {{ service_networks(['frontend', 'backend']) | indent(4) }}
```

### 3. Pass Configuration Parameters

```jinja
{{ deploy_config(
    replicas=3,
    resources={
        'limits': {'cpus': '1.0', 'memory': '512M'},
        'reservations': {'cpus': '0.5', 'memory': '256M'}
    },
    restart_policy_config={
        'condition': 'on-failure',
        'max_attempts': 3
    }
) | indent(4) }}
```

## Indentation Standard

**All macros use 2-space indentation** to match Docker Compose conventions.

When using macros in templates, always use the `| indent(X)` filter:
- `| indent(4)` for service-level properties
- `| indent(6)` for nested properties
- `| indent(2)` for top-level properties

## Usage Examples

See [EXAMPLES.md](EXAMPLES.md) for comprehensive examples of each macro.

## Creating Custom Macros

### Application-Specific Macros

For application-specific patterns, create macros in your template directory:

```
catalog/containers/docker/compose-stacks/myapp/
└── templates/
    └── macros/
        └── myapp_macros.j2
```

Then import both:

```jinja
{% from 'catalog/_libraries/base/macros/common.j2' import healthcheck %}
{% from 'macros/myapp_macros.j2' import myapp_service %}
```

### Best Practices

1. **Use library macros first** - Check if a pattern exists before creating custom macros
2. **Keep macros simple** - Each macro should do one thing well
3. **Document parameters** - Include comments explaining parameters
4. **Test thoroughly** - Test macros with different parameter combinations
5. **Follow conventions** - Use 2-space indentation, consistent naming

## Contributing

When adding new macros:

1. Add to appropriate file (`common.j2` for generic patterns)
2. Document in this README
3. Add examples to `EXAMPLES.md`
4. Test with multiple templates
5. Follow existing naming conventions

## See Also

- [Template System Documentation](../../../../docs/guides/template-system.md)
- [Macro Examples](EXAMPLES.md)
- [Template Best Practices](../../../../docs/guides/template-best-practices.md)
