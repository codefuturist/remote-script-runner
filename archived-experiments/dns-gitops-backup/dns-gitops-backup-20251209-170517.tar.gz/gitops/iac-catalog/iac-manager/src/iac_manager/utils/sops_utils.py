"""SOPS encryption utilities for FluxCD secret management."""

import re
import subprocess
from pathlib import Path
from typing import Optional, Tuple

import ruamel.yaml
from rich.console import Console

console = Console()


class SOPSError(Exception):
    """SOPS operation failed."""
    pass


def is_sops_available() -> bool:
    """Check if SOPS is installed and available."""
    try:
        result = subprocess.run(
            ["sops", "--version"],
            capture_output=True,
            text=True,
            timeout=5
        )
        return result.returncode == 0
    except (subprocess.SubprocessError, FileNotFoundError):
        return False


def is_encrypted(file_path: Path) -> bool:
    """Check if a file is already SOPS encrypted.
    
    Args:
        file_path: Path to the YAML file
        
    Returns:
        True if file contains SOPS metadata
    """
    if not file_path.exists():
        return False
    
    try:
        content = file_path.read_text()
        # Check for SOPS metadata markers
        return "sops:" in content and ("mac:" in content or "lastmodified:" in content)
    except Exception:
        return False


def is_fluxcd_path(file_path: Path) -> bool:
    """Check if a file is in a FluxCD-managed directory.
    
    Args:
        file_path: Path to check
        
    Returns:
        True if path matches FluxCD pattern (catalog/gitops/flux/**)
    """
    path_str = str(file_path.absolute())
    return "catalog/gitops/flux" in path_str


def get_sops_config(repo_root: Optional[Path] = None) -> Optional[Path]:
    """Find the .sops.yaml configuration file.
    
    Args:
        repo_root: Repository root directory (auto-detect if None)
        
    Returns:
        Path to .sops.yaml or None if not found
    """
    if repo_root is None:
        # Try to find repo root by looking for .sops.yaml or .git
        current = Path.cwd()
        while current != current.parent:
            if (current / ".sops.yaml").exists():
                return current / ".sops.yaml"
            if (current / ".git").exists() and (current / ".sops.yaml").exists():
                return current / ".sops.yaml"
            current = current.parent
        return None
    
    sops_config = repo_root / ".sops.yaml"
    return sops_config if sops_config.exists() else None


def encrypt_file(file_path: Path, in_place: bool = True) -> Tuple[bool, str]:
    """Encrypt a file with SOPS.
    
    Args:
        file_path: Path to the file to encrypt
        in_place: Whether to encrypt in-place (default: True)
        
    Returns:
        Tuple of (success, message)
        
    Raises:
        SOPSError: If SOPS operation fails
    """
    if not is_sops_available():
        return False, "SOPS is not installed. Install with: brew install sops"
    
    if not file_path.exists():
        return False, f"File not found: {file_path}"
    
    if is_encrypted(file_path):
        return False, f"File is already encrypted: {file_path}"
    
    # Check if .sops.yaml exists
    sops_config = get_sops_config()
    if not sops_config:
        return False, "No .sops.yaml configuration found in repository"
    
    try:
        cmd = ["sops", "--encrypt"]
        if in_place:
            cmd.append("--in-place")
        cmd.append(str(file_path))
        
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=30
        )
        
        if result.returncode == 0:
            return True, f"Successfully encrypted: {file_path.name}"
        else:
            error_msg = result.stderr or result.stdout
            return False, f"SOPS encryption failed: {error_msg}"
            
    except subprocess.TimeoutExpired:
        return False, "SOPS encryption timed out"
    except Exception as e:
        return False, f"Encryption error: {str(e)}"


def decrypt_file(file_path: Path, output_path: Optional[Path] = None) -> Tuple[bool, str]:
    """Decrypt a SOPS-encrypted file.
    
    Args:
        file_path: Path to the encrypted file
        output_path: Output path (if None, print to stdout)
        
    Returns:
        Tuple of (success, message or decrypted content)
    """
    if not is_sops_available():
        return False, "SOPS is not installed"
    
    if not file_path.exists():
        return False, f"File not found: {file_path}"
    
    if not is_encrypted(file_path):
        return False, f"File is not encrypted: {file_path}"
    
    try:
        cmd = ["sops", "--decrypt"]
        if output_path:
            cmd.extend(["--output", str(output_path)])
        cmd.append(str(file_path))
        
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=30
        )
        
        if result.returncode == 0:
            if output_path:
                return True, f"Successfully decrypted to: {output_path}"
            else:
                return True, result.stdout
        else:
            error_msg = result.stderr or result.stdout
            return False, f"SOPS decryption failed: {error_msg}"
            
    except subprocess.TimeoutExpired:
        return False, "SOPS decryption timed out"
    except Exception as e:
        return False, f"Decryption error: {str(e)}"


def should_encrypt_field(field_path: str) -> bool:
    """Check if a YAML field should be encrypted based on SOPS rules.
    
    Args:
        field_path: Dot-notation path (e.g., "data", "stringData")
        
    Returns:
        True if field matches encrypted_regex pattern
    """
    # Standard SOPS pattern: ^(data|stringData)$
    return field_path in ("data", "stringData")


def create_encrypted_secret_template(
    name: str,
    namespace: str,
    data: dict[str, str],
    labels: Optional[dict[str, str]] = None
) -> str:
    """Create a Kubernetes Secret YAML template.
    
    Args:
        name: Secret name
        namespace: Namespace
        data: Dictionary of key-value pairs for stringData
        labels: Optional labels
        
    Returns:
        YAML string (not encrypted - call encrypt_file separately)
    """
    yaml = ruamel.yaml.YAML()
    yaml.default_flow_style = False
    yaml.preserve_quotes = True
    yaml.width = 4096
    
    secret = {
        "apiVersion": "v1",
        "kind": "Secret",
        "metadata": {
            "name": name,
            "namespace": namespace
        },
        "type": "Opaque",
        "stringData": data
    }
    
    if labels:
        secret["metadata"]["labels"] = labels
    
    # Convert to YAML string
    from io import StringIO
    stream = StringIO()
    yaml.dump(secret, stream)
    return stream.getvalue()


def validate_sops_config(repo_root: Path) -> Tuple[bool, list[str]]:
    """Validate SOPS configuration.
    
    Args:
        repo_root: Repository root directory
        
    Returns:
        Tuple of (is_valid, list of issues)
    """
    issues = []
    
    sops_config = repo_root / ".sops.yaml"
    if not sops_config.exists():
        issues.append("Missing .sops.yaml configuration file")
        return False, issues
    
    try:
        yaml = ruamel.yaml.YAML()
        with open(sops_config) as f:
            config = yaml.load(f)
        
        if "creation_rules" not in config:
            issues.append("Missing 'creation_rules' in .sops.yaml")
        else:
            rules = config["creation_rules"]
            if not isinstance(rules, list) or len(rules) == 0:
                issues.append("'creation_rules' is empty or invalid")
            else:
                # Check for FluxCD rule
                has_flux_rule = any(
                    "path_regex" in rule and "flux" in rule.get("path_regex", "")
                    for rule in rules
                )
                if not has_flux_rule:
                    issues.append("No rule found for FluxCD paths (catalog/gitops/flux)")
                
                # Check for age keys
                for i, rule in enumerate(rules):
                    if "age" not in rule:
                        issues.append(f"Rule {i} missing 'age' key configuration")
        
        return len(issues) == 0, issues
        
    except Exception as e:
        issues.append(f"Failed to parse .sops.yaml: {str(e)}")
        return False, issues


def get_encryption_info(file_path: Path) -> dict[str, any]:
    """Get encryption information about a file.
    
    Args:
        file_path: Path to check
        
    Returns:
        Dictionary with encryption details
    """
    info = {
        "path": str(file_path),
        "exists": file_path.exists(),
        "is_encrypted": False,
        "is_fluxcd_path": is_fluxcd_path(file_path),
        "sops_available": is_sops_available(),
        "sops_config_found": get_sops_config() is not None,
        "should_encrypt": False
    }
    
    if info["exists"]:
        info["is_encrypted"] = is_encrypted(file_path)
        info["should_encrypt"] = (
            info["is_fluxcd_path"] and
            "secret" in file_path.name.lower() and
            not info["is_encrypted"]
        )
    
    return info
