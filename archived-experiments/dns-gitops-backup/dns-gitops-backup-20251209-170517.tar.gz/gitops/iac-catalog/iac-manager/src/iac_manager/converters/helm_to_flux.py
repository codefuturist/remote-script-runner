"""Converter for transforming Helm charts to FluxCD HelmRelease manifests."""

from pathlib import Path
from typing import Any, Dict, Optional

from ruamel.yaml import YAML


class HelmToFluxConverter:
    """Convert Helm charts and commands to FluxCD HelmRelease manifests."""

    def __init__(self):
        """Initialize the converter."""
        self.yaml = YAML()
        self.yaml.preserve_quotes = True
        self.yaml.default_flow_style = False
        self.yaml.width = 4096

    def convert(
        self,
        chart: str,
        release_name: str,
        namespace: str,
        repo_url: Optional[str] = None,
        version: Optional[str] = None,
        values: Optional[Dict[str, Any]] = None,
        values_file: Optional[Path] = None,
        oci: bool = False,
    ) -> Dict[str, Any]:
        """Convert Helm chart specification to FluxCD HelmRelease manifest.

        Args:
            chart: Chart name (e.g., 'bitnami/postgresql' or 'postgresql')
            release_name: Helm release name
            namespace: Kubernetes namespace
            repo_url: Helm repository URL (optional if chart includes repo)
            version: Chart version (optional)
            values: Values dictionary to embed
            values_file: Path to values file to read
            oci: Whether chart is from OCI registry

        Returns:
            Dictionary containing HelmRelease manifest

        Raises:
            ValueError: If required parameters are missing
        """
        # Parse chart reference
        repo_name, chart_name = self._parse_chart_reference(chart, oci)

        # Build HelmRelease manifest
        helm_release = {
            "apiVersion": "helm.toolkit.fluxcd.io/v2",
            "kind": "HelmRelease",
            "metadata": {
                "name": release_name,
                "namespace": namespace,
            },
            "spec": {
                "interval": "30m",
                "timeout": "15m",
                "maxHistory": 3,
                "chart": {
                    "spec": {
                        "chart": chart_name,
                        "sourceRef": {
                            "kind": "HelmRepository" if not oci else "OCIRepository",
                            "name": repo_name,
                            "namespace": "flux-system",
                        },
                        "interval": "5m",
                    }
                },
                "install": {
                    "remediation": {
                        "retries": 3,
                    }
                },
                "upgrade": {
                    "remediation": {
                        "retries": 3,
                    }
                },
            },
        }

        # Add version if specified
        if version:
            helm_release["spec"]["chart"]["spec"]["version"] = version

        # Add values
        if values_file and values_file.exists():
            with open(values_file) as f:
                values_data = self.yaml.load(f)
                helm_release["spec"]["values"] = values_data
        elif values:
            helm_release["spec"]["values"] = values

        return helm_release

    def generate_helm_repository(
        self,
        name: str,
        url: str,
        namespace: str = "flux-system",
        interval: str = "1h",
        oci: bool = False,
    ) -> Dict[str, Any]:
        """Generate HelmRepository or OCIRepository manifest.

        Args:
            name: Repository name
            url: Repository URL
            namespace: Kubernetes namespace (default: flux-system)
            interval: Sync interval (default: 1h)
            oci: Whether this is an OCI repository

        Returns:
            Dictionary containing repository manifest
        """
        if oci:
            return {
                "apiVersion": "source.toolkit.fluxcd.io/v1beta2",
                "kind": "OCIRepository",
                "metadata": {
                    "name": name,
                    "namespace": namespace,
                },
                "spec": {
                    "url": url,
                    "interval": interval,
                },
            }
        else:
            return {
                "apiVersion": "source.toolkit.fluxcd.io/v1beta2",
                "kind": "HelmRepository",
                "metadata": {
                    "name": name,
                    "namespace": namespace,
                },
                "spec": {
                    "url": url,
                    "interval": interval,
                },
            }

    def convert_from_command(
        self,
        command: str,
    ) -> tuple[Dict[str, Any], Optional[Dict[str, Any]]]:
        """Parse helm install/upgrade command and convert to HelmRelease.

        Args:
            command: Helm CLI command string

        Returns:
            Tuple of (HelmRelease manifest, HelmRepository manifest or None)

        Raises:
            ValueError: If command cannot be parsed
        """
        # Parse helm command
        parts = command.split()
        
        if "install" not in parts and "upgrade" not in parts:
            raise ValueError("Command must be 'helm install' or 'helm upgrade'")

        # Extract parameters
        release_name = None
        chart = None
        namespace = "default"
        version = None
        repo_url = None
        values_files = []

        i = 0
        while i < len(parts):
            part = parts[i]
            
            if part in ["install", "upgrade"]:
                # Next two args should be release-name and chart
                if i + 2 < len(parts):
                    release_name = parts[i + 1]
                    chart = parts[i + 2]
                    i += 2
            elif part in ["-n", "--namespace"]:
                if i + 1 < len(parts):
                    namespace = parts[i + 1]
                    i += 1
            elif part == "--version":
                if i + 1 < len(parts):
                    version = parts[i + 1]
                    i += 1
            elif part in ["-f", "--values"]:
                if i + 1 < len(parts):
                    values_files.append(parts[i + 1])
                    i += 1
            elif part == "--repo":
                if i + 1 < len(parts):
                    repo_url = parts[i + 1]
                    i += 1
            
            i += 1

        if not release_name or not chart:
            raise ValueError("Could not extract release name and chart from command")

        # Load values from files
        values = {}
        for vf in values_files:
            vf_path = Path(vf)
            if vf_path.exists():
                with open(vf_path) as f:
                    file_values = self.yaml.load(f)
                    if file_values:
                        values.update(file_values)

        # Generate manifests
        helm_release = self.convert(
            chart=chart,
            release_name=release_name,
            namespace=namespace,
            repo_url=repo_url,
            version=version,
            values=values if values else None,
        )

        # Generate HelmRepository if repo_url provided
        helm_repo = None
        if repo_url:
            repo_name, _ = self._parse_chart_reference(chart, False)
            helm_repo = self.generate_helm_repository(
                name=repo_name,
                url=repo_url,
            )

        return helm_release, helm_repo

    def _parse_chart_reference(self, chart: str, oci: bool) -> tuple[str, str]:
        """Parse chart reference into repository and chart names.

        Args:
            chart: Chart reference (e.g., 'bitnami/postgresql' or 'postgresql')
            oci: Whether this is an OCI reference

        Returns:
            Tuple of (repo_name, chart_name)
        """
        if oci:
            # For OCI, use last part of URL as repo name
            parts = chart.rstrip('/').split('/')
            repo_name = parts[-2] if len(parts) > 1 else "oci-repo"
            chart_name = parts[-1]
            return repo_name, chart_name

        if "/" in chart:
            # Format: repo/chart
            parts = chart.split("/", 1)
            return parts[0], parts[1]
        else:
            # Chart name only
            return "helm-repo", chart

    def save_manifests(
        self,
        output_dir: Path,
        helm_release: Dict[str, Any],
        helm_repository: Optional[Dict[str, Any]] = None,
        filename_prefix: Optional[str] = None,
    ) -> list[Path]:
        """Save generated manifests to files.

        Args:
            output_dir: Directory to save manifests
            helm_release: HelmRelease manifest
            helm_repository: Optional HelmRepository manifest
            filename_prefix: Optional prefix for filenames

        Returns:
            List of created file paths
        """
        output_dir.mkdir(parents=True, exist_ok=True)
        created_files = []

        prefix = f"{filename_prefix}-" if filename_prefix else ""

        # Save HelmRelease
        release_file = output_dir / f"{prefix}helmrelease.yaml"
        with open(release_file, "w") as f:
            self.yaml.dump(helm_release, f)
        created_files.append(release_file)

        # Save HelmRepository if provided
        if helm_repository:
            repo_kind = helm_repository["kind"].lower()
            repo_file = output_dir / f"{prefix}{repo_kind}.yaml"
            with open(repo_file, "w") as f:
                self.yaml.dump(helm_repository, f)
            created_files.append(repo_file)

        return created_files
