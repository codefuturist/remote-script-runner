"""FastAPI application factory and main entry point."""

import logging
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from iac_manager.web.config import get_settings
from iac_manager.web.database import close_db, init_db

logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """Application lifespan handler for startup/shutdown events."""
    # Startup
    logger.info("Starting IaC Manager Web API...")
    await init_db()
    logger.info("Database initialized")

    yield

    # Shutdown
    logger.info("Shutting down IaC Manager Web API...")
    await close_db()
    logger.info("Database connections closed")


def create_app() -> FastAPI:
    """Create and configure the FastAPI application.

    Returns:
        Configured FastAPI application instance
    """
    settings = get_settings()

    # Configure logging
    logging.basicConfig(
        level=getattr(logging, settings.log_level),
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    app = FastAPI(
        title="IaC Manager API",
        description="Modern Infrastructure as Code management API",
        version="0.1.0",
        docs_url="/api/docs",
        redoc_url="/api/redoc",
        openapi_url="/api/openapi.json",
        lifespan=lifespan,
    )

    # Configure CORS
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=settings.cors_allow_credentials,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Register API routes
    from iac_manager.web.routes import register_routes

    register_routes(app)

    # Serve static frontend files if enabled
    if settings.serve_frontend and settings.static_dir:
        static_path = Path(settings.static_dir)
        if static_path.exists():
            app.mount("/", StaticFiles(directory=static_path, html=True), name="frontend")
            logger.info(f"Serving frontend from {static_path}")

    return app


def run_server() -> None:
    """Run the development server using uvicorn."""
    import uvicorn

    settings = get_settings()

    uvicorn.run(
        "iac_manager.web.main:create_app",
        factory=True,
        host=settings.host,
        port=settings.port,
        reload=settings.reload,
        workers=settings.workers if not settings.reload else 1,
        log_level=settings.log_level.lower(),
    )


# Create app instance for uvicorn direct execution
app = create_app()

if __name__ == "__main__":
    run_server()
