"""Dashboard routes - overview and statistics."""

from typing import Annotated

from fastapi import APIRouter, Depends

from iac_manager.web.auth.dependencies import ActiveUser
from iac_manager.web.schemas.common import BaseSchema
from iac_manager.web.services import ServiceProvider, get_services

router = APIRouter()


class EnvironmentStats(BaseSchema):
    """Statistics for an environment."""

    name: str
    deployment_count: int
    last_updated: str | None = None


class DashboardStats(BaseSchema):
    """Dashboard statistics."""

    total_deployments: int
    total_templates: int
    total_hosts: int
    environments: list[EnvironmentStats]
    git_branch: str | None = None
    git_is_clean: bool = True
    recent_deployments: list[dict]


@router.get("", response_model=DashboardStats)
async def get_dashboard_stats(
    current_user: ActiveUser,
    services: Annotated[ServiceProvider, Depends(get_services)],
) -> DashboardStats:
    """Get dashboard statistics and overview."""
    # Get deployments
    deployments = await services.deployments.list_deployments()

    # Count by environment
    env_counts: dict[str, int] = {}
    for deployment in deployments:
        env_name = deployment.environment.value
        env_counts[env_name] = env_counts.get(env_name, 0) + 1

    environments = [
        EnvironmentStats(name=name, deployment_count=count)
        for name, count in sorted(env_counts.items())
    ]

    # Get templates
    templates = await services.templates.list_templates()

    # Get hosts
    hosts = await services.inventory.list_hosts()

    # Get git status
    git_status = await services.gitops.get_status()

    # Recent deployments (last 5)
    recent = sorted(
        deployments,
        key=lambda d: d.manifest.updated_at,
        reverse=True,
    )[:5]

    return DashboardStats(
        total_deployments=len(deployments),
        total_templates=len(templates),
        total_hosts=len(hosts),
        environments=environments,
        git_branch=git_status.get("branch"),
        git_is_clean=len(git_status.get("modified", [])) == 0,
        recent_deployments=[
            {
                "instance_id": d.instance_id,
                "environment": d.environment.value,
                "template": d.template,
                "updated_at": d.manifest.updated_at.isoformat(),
            }
            for d in recent
        ],
    )
