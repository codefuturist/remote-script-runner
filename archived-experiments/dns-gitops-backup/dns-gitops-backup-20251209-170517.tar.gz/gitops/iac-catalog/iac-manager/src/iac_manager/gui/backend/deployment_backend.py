"""Deployment backend for QML."""

from typing import Optional

from PyQt6.QtCore import QObject, pyqtProperty, pyqtSignal, pyqtSlot

from iac_manager.config import Config
from iac_manager.services import DeploymentService
from iac_manager.gui.backend.models import DeploymentListModel


class DeploymentBackend(QObject):
    """Backend bridge for deployment operations in QML."""

    # Signals
    deploymentsLoaded = pyqtSignal()
    statusChanged = pyqtSignal(str)
    errorOccurred = pyqtSignal(str)

    def __init__(self, config: Config, deployment_service: DeploymentService, parent=None):
        """Initialize deployment backend.

        Args:
            config: Configuration object
            deployment_service: Deployment service instance
            parent: Parent QObject
        """
        super().__init__(parent)
        self._config = config
        self._deployment_service = deployment_service
        self._model = DeploymentListModel(self)
        self._status = "Ready"
        self._selected_environment = "all"

    @pyqtProperty(QObject, constant=True)
    def model(self) -> DeploymentListModel:
        """Get deployments model for QML."""
        return self._model

    @pyqtProperty(str, notify=statusChanged)
    def status(self) -> str:
        """Get current status message."""
        return self._status

    @status.setter
    def status(self, value: str):
        """Set status message."""
        if self._status != value:
            self._status = value
            self.statusChanged.emit(value)

    @pyqtSlot()
    @pyqtSlot(str)
    def refresh(self, environment: Optional[str] = None):
        """Refresh deployments list.

        Args:
            environment: Optional environment filter
        """
        try:
            self.status = "Loading deployments..."

            # Use environment filter if provided
            env = environment if environment and environment != "all" else None

            # Load deployments
            deployments = self._deployment_service.list_deployments(environment=env)

            # Update model
            self._model.setDeployments(deployments)

            # Update status
            count = len(deployments)
            env_text = f" in {environment}" if environment and environment != "all" else ""
            self.status = f"Found {count} deployment{'s' if count != 1 else ''}{env_text}"

            self.deploymentsLoaded.emit()

        except Exception as e:
            self.status = f"Error: {str(e)}"
            self.errorOccurred.emit(str(e))

    @pyqtSlot(int, result=str)
    def getDeploymentDetails(self, index: int) -> str:
        """Get deployment details as formatted string.

        Args:
            index: Deployment index

        Returns:
            Formatted details string
        """
        deployment = self._model.getDeployment(index)
        if not deployment:
            return ""

        details = f"""<h3>{deployment.instance_id}</h3>
<p><b>Environment:</b> {deployment.environment.value}</p>
<p><b>Template:</b> {deployment.template}</p>
<p><b>Version:</b> {deployment.template_version or 'latest'}</p>
<p><b>Path:</b> {deployment.deployment_path}</p>

<h4>Configuration:</h4>
<ul>
<li>Environment file: {'✅ Yes' if deployment.has_env_file else '❌ No'}</li>
<li>Docker Compose: {'✅ Yes' if deployment.has_docker_compose else '❌ No'}</li>
<li>Kubernetes: {'✅ Yes' if deployment.has_kubernetes_manifests else '❌ No'}</li>
</ul>

<h4>Manifest Details:</h4>
<ul>
<li><b>Name:</b> {deployment.manifest.name}</li>
<li><b>Description:</b> {deployment.manifest.description or 'N/A'}</li>
</ul>"""

        return details

    @pyqtSlot(int)
    def deployDeployment(self, index: int):
        """Deploy selected deployment.

        Args:
            index: Deployment index
        """
        deployment = self._model.getDeployment(index)
        if deployment:
            try:
                self.status = f"Deploying {deployment.instance_id}..."
                
                # Perform deployment using apply_deployment
                self._deployment_service.apply_deployment(
                    instance=deployment.instance_id,
                    environment=deployment.environment.value
                )
                
                self.status = f"✅ Deployed {deployment.instance_id}"
                self.deploymentsLoaded.emit()
                    
            except Exception as e:
                self.status = f"❌ Error deploying {deployment.instance_id}"
                self.errorOccurred.emit(f"Deployment error: {str(e)}")

    @pyqtSlot(int)
    def deleteDeployment(self, index: int):
        """Delete selected deployment.

        Args:
            index: Deployment index
        """
        deployment = self._model.getDeployment(index)
        if deployment:
            try:
                self.status = f"Deleting {deployment.instance_id}..."
                
                # Delete deployment
                self._deployment_service.delete_deployment(
                    instance=deployment.instance_id,
                    environment=deployment.environment.value
                )
                
                self.status = f"✅ Deleted {deployment.instance_id}"
                self.refresh(self._selected_environment)
                    
            except Exception as e:
                self.status = f"❌ Error deleting {deployment.instance_id}"
                self.errorOccurred.emit(f"Deletion error: {str(e)}")

    @pyqtSlot()
    def openDeploymentWizard(self):
        """Open deployment wizard with Docker configuration.
        
        This opens the full wizard that includes Docker configuration options
        for ingress, secrets, networking, and database choices.
        """
        from iac_manager.services import TemplateService
        from iac_manager.gui.windows.deploy_wizard import DeployWizard
        
        try:
            # Create template service if not available
            template_service = TemplateService(self._config)
            
            wizard = DeployWizard(
                self._config,
                template_service,
                self._deployment_service
            )
            
            # The wizard includes:
            # - Template selection
            # - Basic configuration
            # - Docker configuration (deployment mode, ingress, secrets, network, database)
            # - Live preview with editing
            # - Final review
            
            if wizard.exec():
                self.status = "✅ Deployment wizard completed"
                self.refresh()
            else:
                self.status = "Deployment wizard cancelled"
                
        except Exception as e:
            self.status = f"❌ Error opening wizard"
            self.errorOccurred.emit(f"Wizard error: {str(e)}")
