"""Service provider for dependency injection.

Wraps existing services with async adapters for use in FastAPI routes.
"""

import asyncio
from functools import lru_cache
from pathlib import Path
from typing import Any

from iac_manager.config import Config, load_config
from iac_manager.services import (
    DeploymentService,
    GitOpsService,
    InventoryService,
    SecretsService,
    TemplateService,
)


class AsyncServiceAdapter:
    """Wraps synchronous service methods for async execution."""

    def __init__(self, service: Any):
        self._service = service

    def __getattr__(self, name: str):
        """Wrap service method calls in asyncio.to_thread."""
        attr = getattr(self._service, name)
        if callable(attr):

            async def async_wrapper(*args, **kwargs):
                return await asyncio.to_thread(attr, *args, **kwargs)

            return async_wrapper
        return attr


class ServiceProvider:
    """Provides access to business logic services."""

    _instance: "ServiceProvider | None" = None
    _config: Config | None = None

    def __init__(self, config: Config):
        self._config = config
        self._deployment_service: DeploymentService | None = None
        self._template_service: TemplateService | None = None
        self._gitops_service: GitOpsService | None = None
        self._inventory_service: InventoryService | None = None
        self._secrets_service: SecretsService | None = None

    @classmethod
    def get_instance(cls, repo_root: Path | None = None) -> "ServiceProvider":
        """Get or create the service provider singleton.

        Args:
            repo_root: Optional repository root path. If not provided,
                      uses current working directory.

        Returns:
            ServiceProvider instance
        """
        if cls._instance is None:
            config = load_config(repo_root)
            cls._instance = cls(config)
        return cls._instance

    @classmethod
    def reset(cls) -> None:
        """Reset the singleton instance (useful for testing)."""
        cls._instance = None

    @property
    def config(self) -> Config:
        """Get the configuration object."""
        assert self._config is not None
        return self._config

    @property
    def deployments(self) -> AsyncServiceAdapter:
        """Get the deployment service (async-wrapped)."""
        if self._deployment_service is None:
            self._deployment_service = DeploymentService(self._config)
        return AsyncServiceAdapter(self._deployment_service)

    @property
    def templates(self) -> AsyncServiceAdapter:
        """Get the template service (async-wrapped)."""
        if self._template_service is None:
            self._template_service = TemplateService(self._config)
        return AsyncServiceAdapter(self._template_service)

    @property
    def gitops(self) -> AsyncServiceAdapter:
        """Get the GitOps service (async-wrapped)."""
        if self._gitops_service is None:
            self._gitops_service = GitOpsService(self._config)
        return AsyncServiceAdapter(self._gitops_service)

    @property
    def inventory(self) -> AsyncServiceAdapter:
        """Get the inventory service (async-wrapped)."""
        if self._inventory_service is None:
            self._inventory_service = InventoryService(self._config)
        return AsyncServiceAdapter(self._inventory_service)

    @property
    def secrets(self) -> AsyncServiceAdapter:
        """Get the secrets service (async-wrapped)."""
        if self._secrets_service is None:
            self._secrets_service = SecretsService(self._config)
        return AsyncServiceAdapter(self._secrets_service)


def get_services() -> ServiceProvider:
    """Dependency injection helper for FastAPI routes.

    Returns:
        ServiceProvider instance
    """
    return ServiceProvider.get_instance()
