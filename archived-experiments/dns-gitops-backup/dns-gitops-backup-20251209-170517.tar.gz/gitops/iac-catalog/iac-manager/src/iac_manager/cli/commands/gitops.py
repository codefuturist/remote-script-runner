"""GitOps integration commands."""

from pathlib import Path
from typing import Optional

import click
from git import Repo
from rich.console import Console
from rich.panel import Panel

from iac_manager.cli.config import Config
from iac_manager.cli.utils import confirm_action


@click.group()
def gitops() -> None:
    """🔄 GitOps integration.

    Manage Git operations for GitOps workflows.
    """
    pass


@gitops.command()
@click.option(
    "--message",
    "-m",
    help="Commit message (will prompt if not provided)",
)
@click.option(
    "--push",
    is_flag=True,
    help="Push changes after commit",
)
@click.pass_context
def commit(
    ctx: click.Context,
    message: Optional[str],
    push: bool,
) -> None:
    """Commit deployment changes to Git.

    Examples:

        # Commit with automatic message
        iac gitops commit

        # Commit with custom message
        iac gitops commit -m "feat: add wordpress deployment"

        # Commit and push
        iac gitops commit --push
    """
    config: Config = ctx.obj["config"]
    console: Console = ctx.obj["console"]

    try:
        repo = Repo(config.repo_root)
    except Exception as e:
        console.print(f"[red]Error: Not a git repository: {e}[/red]")
        ctx.exit(1)

    # Check if there are changes
    if not repo.is_dirty(untracked_files=True):
        console.print("[yellow]No changes to commit.[/yellow]")
        return

    # Show status
    console.print("[bold]Git Status:[/bold]\n")
    changed_files = [item.a_path for item in repo.index.diff(None)]
    untracked_files = repo.untracked_files

    if changed_files:
        console.print("[yellow]Modified files:[/yellow]")
        for f in changed_files[:10]:
            console.print(f"  • {f}")
        if len(changed_files) > 10:
            console.print(f"  ... and {len(changed_files) - 10} more")

    if untracked_files:
        console.print("\n[green]New files:[/green]")
        for f in untracked_files[:10]:
            console.print(f"  • {f}")
        if len(untracked_files) > 10:
            console.print(f"  ... and {len(untracked_files) - 10} more")

    # Prompt for commit message if not provided
    if not message:
        console.print()
        message = click.prompt("Commit message", type=str)

    # Confirm
    console.print()
    if not confirm_action("Commit these changes?", default=True):
        console.print("[yellow]Cancelled.[/yellow]")
        ctx.exit(0)

    # Add all changes
    repo.index.add("*")

    # Commit
    repo.index.commit(message)
    console.print(f"\n[green]✓[/green] Changes committed: {message}")

    # Push if requested
    if push or config.git_auto_push:
        if confirm_action("Push changes to remote?", default=True):
            try:
                origin = repo.remote("origin")
                origin.push()
                console.print("[green]✓[/green] Changes pushed to remote")
            except Exception as e:
                console.print(f"[red]Error pushing to remote: {e}[/red]")


@gitops.command()
@click.pass_context
def status(ctx: click.Context) -> None:
    """Show Git repository status.

    Examples:

        iac gitops status
    """
    config: Config = ctx.obj["config"]
    console: Console = ctx.obj["console"]

    try:
        repo = Repo(config.repo_root)
    except Exception as e:
        console.print(f"[red]Error: Not a git repository: {e}[/red]")
        ctx.exit(1)

    # Get current branch
    current_branch = repo.active_branch.name

    # Check if dirty
    is_dirty = repo.is_dirty(untracked_files=True)

    # Get commit info
    last_commit = repo.head.commit
    commit_message = last_commit.message.strip()
    commit_author = last_commit.author.name
    commit_date = last_commit.committed_datetime.strftime("%Y-%m-%d %H:%M:%S")

    # Print status
    status_color = "yellow" if is_dirty else "green"
    status_text = "Changes present" if is_dirty else "Clean"

    console.print(
        Panel.fit(
            f"[bold]Branch:[/bold] {current_branch}\n"
            f"[bold]Status:[/bold] [{status_color}]{status_text}[/{status_color}]\n\n"
            f"[bold]Last Commit:[/bold]\n"
            f"  Message: {commit_message}\n"
            f"  Author: {commit_author}\n"
            f"  Date: {commit_date}",
            title="Git Status",
            border_style="blue",
        )
    )

    # Show pending changes if any
    if is_dirty:
        console.print("\n[yellow]Pending changes:[/yellow]")
        changed = [item.a_path for item in repo.index.diff(None)]
        untracked = repo.untracked_files

        if changed:
            console.print("  Modified:")
            for f in changed[:5]:
                console.print(f"    • {f}")
            if len(changed) > 5:
                console.print(f"    ... and {len(changed) - 5} more")

        if untracked:
            console.print("  Untracked:")
            for f in untracked[:5]:
                console.print(f"    • {f}")
            if len(untracked) > 5:
                console.print(f"    ... and {len(untracked) - 5} more")


@gitops.command()
@click.pass_context
def sync(ctx: click.Context) -> None:
    """Sync with remote repository.

    Examples:

        iac gitops sync
    """
    config: Config = ctx.obj["config"]
    console: Console = ctx.obj["console"]

    try:
        repo = Repo(config.repo_root)
    except Exception as e:
        console.print(f"[red]Error: Not a git repository: {e}[/red]")
        ctx.exit(1)

    console.print("[bold]Syncing with remote...[/bold]\n")

    try:
        # Fetch
        console.print("Fetching from remote...")
        origin = repo.remote("origin")
        fetch_info = origin.fetch()

        # Pull
        console.print("Pulling changes...")
        pull_info = origin.pull()

        console.print(f"\n[green]✓[/green] Synchronized with remote")

        # Show summary
        if pull_info:
            for info in pull_info:
                if info.flags & info.HEAD_UPTODATE:
                    console.print("  Already up to date")
                else:
                    console.print(f"  Updated: {info.ref}")

    except Exception as e:
        console.print(f"[red]Error syncing with remote: {e}[/red]")
        ctx.exit(1)
