"""Windows package."""

from iac_manager.gui.windows.main_window import MainWindow

__all__ = ["MainWindow"]
