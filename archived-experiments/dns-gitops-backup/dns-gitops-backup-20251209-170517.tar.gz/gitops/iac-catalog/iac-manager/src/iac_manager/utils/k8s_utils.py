"""Kubernetes utilities for interacting with clusters via kubectl."""

import json
import subprocess
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from ruamel.yaml import YAML


def is_kubectl_available() -> bool:
    """Check if kubectl is installed and available.
    
    Returns:
        True if kubectl is available
    """
    try:
        result = subprocess.run(
            ["kubectl", "version", "--client", "--output=json"],
            capture_output=True,
            text=True,
            timeout=5
        )
        return result.returncode == 0
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return False


def check_cluster_access() -> Tuple[bool, Optional[str]]:
    """Check if kubectl can access a cluster.
    
    Returns:
        Tuple of (success, cluster_name or error_message)
    """
    try:
        result = subprocess.run(
            ["kubectl", "cluster-info"],
            capture_output=True,
            text=True,
            timeout=10
        )
        
        if result.returncode == 0:
            # Get current context
            context_result = subprocess.run(
                ["kubectl", "config", "current-context"],
                capture_output=True,
                text=True,
                timeout=5
            )
            
            if context_result.returncode == 0:
                cluster_name = context_result.stdout.strip()
                return True, cluster_name
            
            return True, "unknown"
        
        return False, result.stderr.strip() or "Cannot access cluster"
    
    except subprocess.TimeoutExpired:
        return False, "Timeout connecting to cluster"
    except FileNotFoundError:
        return False, "kubectl not found"
    except Exception as e:
        return False, str(e)


def get_secret(name: str, namespace: str = "default") -> Tuple[bool, Optional[Dict], Optional[str]]:
    """Fetch a secret from the Kubernetes cluster.
    
    Args:
        name: Secret name
        namespace: Kubernetes namespace
        
    Returns:
        Tuple of (success, secret_data, error_message)
    """
    try:
        result = subprocess.run(
            ["kubectl", "get", "secret", name, "-n", namespace, "-o", "json"],
            capture_output=True,
            text=True,
            timeout=10
        )
        
        if result.returncode != 0:
            error_msg = result.stderr.strip()
            if "NotFound" in error_msg:
                return False, None, f"Secret '{name}' not found in namespace '{namespace}'"
            return False, None, error_msg or "Failed to fetch secret"
        
        secret_data = json.loads(result.stdout)
        return True, secret_data, None
    
    except subprocess.TimeoutExpired:
        return False, None, "Timeout fetching secret"
    except json.JSONDecodeError as e:
        return False, None, f"Invalid JSON response: {e}"
    except Exception as e:
        return False, None, f"Error fetching secret: {e}"


def list_secrets(namespace: str = "default", label_selector: Optional[str] = None) -> Tuple[bool, List[str], Optional[str]]:
    """List secrets in a namespace.
    
    Args:
        namespace: Kubernetes namespace
        label_selector: Optional label selector (e.g., "app=myapp")
        
    Returns:
        Tuple of (success, list_of_secret_names, error_message)
    """
    try:
        cmd = ["kubectl", "get", "secrets", "-n", namespace, "-o", "json"]
        
        if label_selector:
            cmd.extend(["-l", label_selector])
        
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=10
        )
        
        if result.returncode != 0:
            return False, [], result.stderr.strip() or "Failed to list secrets"
        
        data = json.loads(result.stdout)
        secret_names = [item["metadata"]["name"] for item in data.get("items", [])]
        
        return True, secret_names, None
    
    except subprocess.TimeoutExpired:
        return False, [], "Timeout listing secrets"
    except json.JSONDecodeError as e:
        return False, [], f"Invalid JSON response: {e}"
    except Exception as e:
        return False, [], f"Error listing secrets: {e}"


def list_namespaces() -> Tuple[bool, List[str], Optional[str]]:
    """List all namespaces in the cluster.
    
    Returns:
        Tuple of (success, list_of_namespaces, error_message)
    """
    try:
        result = subprocess.run(
            ["kubectl", "get", "namespaces", "-o", "json"],
            capture_output=True,
            text=True,
            timeout=10
        )
        
        if result.returncode != 0:
            return False, [], result.stderr.strip() or "Failed to list namespaces"
        
        data = json.loads(result.stdout)
        namespace_names = [item["metadata"]["name"] for item in data.get("items", [])]
        
        return True, namespace_names, None
    
    except subprocess.TimeoutExpired:
        return False, [], "Timeout listing namespaces"
    except json.JSONDecodeError as e:
        return False, [], f"Invalid JSON response: {e}"
    except Exception as e:
        return False, [], f"Error listing namespaces: {e}"


def clean_secret_metadata(secret_data: Dict) -> Dict:
    """Clean cluster-specific metadata from a secret.
    
    Removes fields that shouldn't be in Git:
    - uid, resourceVersion, creationTimestamp
    - managedFields, selfLink
    - Status information
    
    Args:
        secret_data: Raw secret data from cluster
        
    Returns:
        Cleaned secret data suitable for Git
    """
    cleaned = {
        "apiVersion": secret_data.get("apiVersion", "v1"),
        "kind": secret_data.get("kind", "Secret"),
        "metadata": {},
        "type": secret_data.get("type", "Opaque")
    }
    
    # Clean metadata
    metadata = secret_data.get("metadata", {})
    cleaned["metadata"]["name"] = metadata.get("name")
    cleaned["metadata"]["namespace"] = metadata.get("namespace")
    
    # Preserve specific annotations/labels if present
    if "labels" in metadata and metadata["labels"]:
        # Filter out system labels
        labels = {
            k: v for k, v in metadata["labels"].items()
            if not k.startswith("kubectl.kubernetes.io/")
        }
        if labels:
            cleaned["metadata"]["labels"] = labels
    
    if "annotations" in metadata and metadata["annotations"]:
        # Filter out system annotations
        annotations = {
            k: v for k, v in metadata["annotations"].items()
            if not k.startswith("kubectl.kubernetes.io/")
        }
        if annotations:
            cleaned["metadata"]["annotations"] = annotations
    
    # Include data/stringData
    if "data" in secret_data:
        cleaned["data"] = secret_data["data"]
    
    if "stringData" in secret_data:
        cleaned["stringData"] = secret_data["stringData"]
    
    return cleaned


def convert_to_stringdata(secret_data: Dict) -> Dict:
    """Convert base64-encoded data to stringData for easier editing.
    
    Args:
        secret_data: Secret with base64-encoded data
        
    Returns:
        Secret with decoded stringData
    """
    import base64
    
    if "data" not in secret_data or not secret_data["data"]:
        return secret_data
    
    # Convert data to stringData
    string_data = {}
    for key, value in secret_data["data"].items():
        try:
            decoded = base64.b64decode(value).decode('utf-8')
            string_data[key] = decoded
        except Exception:
            # If decoding fails, keep as data
            pass
    
    if string_data:
        # Remove data field and use stringData
        cleaned = {k: v for k, v in secret_data.items() if k != "data"}
        cleaned["stringData"] = string_data
        return cleaned
    
    return secret_data


def is_system_secret(secret_name: str) -> bool:
    """Check if a secret is a system-managed secret that shouldn't be exported.
    
    Args:
        secret_name: Name of the secret
        
    Returns:
        True if this is a system secret
    """
    system_prefixes = [
        "default-token-",
        "sh.helm.release.",
        "bootstrap-token-",
    ]
    
    system_suffixes = [
        "-token-",
        "-dockercfg-",
    ]
    
    for prefix in system_prefixes:
        if secret_name.startswith(prefix):
            return True
    
    for suffix in system_suffixes:
        if suffix in secret_name:
            return True
    
    return False


def categorize_secret(secret_data: Dict) -> str:
    """Determine the category for organizing the secret.
    
    Args:
        secret_data: Secret data
        
    Returns:
        Category name (shared, database, auth, tls, etc.)
    """
    secret_type = secret_data.get("type", "Opaque")
    name = secret_data.get("metadata", {}).get("name", "")
    labels = secret_data.get("metadata", {}).get("labels", {})
    
    # TLS certificates
    if secret_type == "kubernetes.io/tls":
        return "tls"
    
    # Docker registry credentials
    if secret_type in ["kubernetes.io/dockerconfigjson", "kubernetes.io/dockercfg"]:
        return "registry"
    
    # SSH keys
    if secret_type == "kubernetes.io/ssh-auth":
        return "ssh"
    
    # Basic auth
    if secret_type == "kubernetes.io/basic-auth":
        return "auth"
    
    # Check labels for hints
    if "database" in labels.get("app.kubernetes.io/component", ""):
        return "database"
    
    # Check name for hints
    name_lower = name.lower()
    if any(db in name_lower for db in ["postgres", "mysql", "mariadb", "mongo", "redis"]):
        return "database"
    
    if any(auth in name_lower for auth in ["auth", "oauth", "token", "api-key"]):
        return "auth"
    
    if "backup" in name_lower:
        return "backup"
    
    # Default to shared
    return "shared"
