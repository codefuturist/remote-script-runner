"""Deployment schemas."""

from datetime import datetime
from pathlib import Path
from typing import Any

from pydantic import Field

from iac_manager.models import EnvironmentType, TargetType
from iac_manager.web.schemas.common import BaseSchema, PaginatedResponse


class DeploymentCreate(BaseSchema):
    """Request to create a new deployment."""

    template: str = Field(description="Template path relative to catalog")
    instance_id: str = Field(
        min_length=1,
        max_length=63,
        pattern=r"^[a-z0-9][a-z0-9-]*[a-z0-9]$",
        description="Unique instance identifier",
    )
    environment: EnvironmentType
    description: str | None = None
    labels: dict[str, str] = Field(default_factory=dict)
    values: dict[str, Any] = Field(
        default_factory=dict,
        description="Values to merge into the deployment",
    )
    target_type: TargetType = TargetType.DOCKER_COMPOSE


class DeploymentUpdate(BaseSchema):
    """Request to update an existing deployment."""

    description: str | None = None
    labels: dict[str, str] | None = None
    values: dict[str, Any] | None = None


class ManifestResponse(BaseSchema):
    """Deployment manifest information."""

    name: str
    template: str
    template_version: str
    instance_id: str
    environment: EnvironmentType
    description: str | None = None
    labels: dict[str, str]
    created_at: datetime
    updated_at: datetime


class DeploymentResponse(BaseSchema):
    """Deployment information response."""

    instance_id: str
    environment: EnvironmentType
    template: str
    template_version: str
    deployment_path: str  # String path for JSON serialization
    manifest: ManifestResponse
    has_env_file: bool
    has_docker_compose: bool
    has_kubernetes_manifests: bool

    @classmethod
    def from_domain(cls, deployment) -> "DeploymentResponse":
        """Create response from domain model.

        Args:
            deployment: DeploymentInfo domain model

        Returns:
            API response schema
        """
        return cls(
            instance_id=deployment.instance_id,
            environment=deployment.environment,
            template=deployment.template,
            template_version=deployment.template_version,
            deployment_path=str(deployment.deployment_path),
            manifest=ManifestResponse(
                name=deployment.manifest.name,
                template=deployment.manifest.template,
                template_version=deployment.manifest.template_version,
                instance_id=deployment.manifest.instance_id,
                environment=deployment.manifest.environment,
                description=deployment.manifest.description,
                labels=deployment.manifest.labels,
                created_at=deployment.manifest.created_at,
                updated_at=deployment.manifest.updated_at,
            ),
            has_env_file=deployment.has_env_file,
            has_docker_compose=deployment.has_docker_compose,
            has_kubernetes_manifests=deployment.has_kubernetes_manifests,
        )


class DeploymentList(PaginatedResponse[DeploymentResponse]):
    """Paginated list of deployments."""

    pass


class DeploymentDeleteRequest(BaseSchema):
    """Request to delete a deployment."""

    force: bool = Field(
        default=False,
        description="Force deletion even if deployment has running resources",
    )


class DeploymentPreview(BaseSchema):
    """Preview of files that would be generated."""

    files: dict[str, str]  # filename -> content preview
    warnings: list[str]
    missing_values: list[str]
