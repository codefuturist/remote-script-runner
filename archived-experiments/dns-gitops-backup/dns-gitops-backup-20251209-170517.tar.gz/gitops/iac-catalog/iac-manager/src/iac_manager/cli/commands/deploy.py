"""Deployment management commands."""

import json
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn

from iac_manager.cli.config import Config, get_environment_with_fallback
from iac_manager.cli.models import (
    DeploymentInfo,
    EnvironmentType,
    Manifest,
    PathRequirement,
    Target,
    TargetType,
)
from iac_manager.cli.utils import (
    confirm_action,
    console,
    copy_with_jinja,
    find_template_fuzzy,
    get_available_targets,
    load_yaml,
    print_table,
    run_command,
    save_yaml,
    suggest_templates,
    validate_instance_id,
)
from iac_manager.cli.ssh_utils import (
    create_multiple_paths,
    parse_ssh_config,
    SSHConnectionError,
    SSHCommandError,
)


@click.group()
def deploy() -> None:
    """🚀 Manage deployments.

    Configure, deploy, and manage application deployments
    from templates to different environments.
    """
    pass


# Import and register wizard command
from iac_manager.cli.commands.wizard import wizard as wizard_cmd
from iac_manager.cli.commands.platform_configure import configure_with_platform

deploy.add_command(wizard_cmd, name="wizard")
deploy.add_command(configure_with_platform, name="configure-platform")


@deploy.command()
@click.option(
    "--template",
    required=True,
    help="Template path (e.g., catalog/containers/docker/compose-stacks/wordpress)",
)
@click.option(
    "--instance",
    help="Instance ID (will prompt if not provided)",
)
@click.option(
    "--environment",
    type=click.Choice(["development", "staging", "production", "dr-site"]),
    help="Target environment (will use config default if not provided)",
)
@click.option(
    "--target",
    help="Deployment target (host or group name)",
)
@click.option(
    "--param",
    multiple=True,
    help="Template parameter (KEY=VALUE, can be specified multiple times)",
)
@click.option(
    "--dry-run",
    is_flag=True,
    help="Show what would be created without creating it",
)
@click.pass_context
def configure(
    ctx: click.Context,
    template: str,
    instance: Optional[str],
    environment: Optional[str],
    target: Optional[str],
    param: Tuple[str, ...],
    dry_run: bool,
) -> None:
    """Configure a new deployment from a template.

    Examples:

        # Basic configuration
        iac deploy configure \\
            --template catalog/containers/docker/compose-stacks/wordpress \\
            --instance my-blog \\
            --environment production \\
            --target web-server-01

        # With parameters
        iac deploy configure \\
            --template catalog/containers/docker/compose-stacks/wordpress \\
            --instance my-blog \\
            --param domain=example.com \\
            --param ssl_enabled=true
    """
    config: Config = ctx.obj["config"]
    console: Console = ctx.obj["console"]

    # Validate and resolve template path (support fuzzy matching)
    template_path = config.repo_root / template
    
    if not template_path.exists():
        # Try fuzzy matching
        console.print(f"[yellow]Template not found at: {template}[/yellow]")
        console.print("[dim]Searching for similar templates...[/dim]\n")
        
        fuzzy_match = find_template_fuzzy(config, template)
        
        if fuzzy_match:
            template_path = fuzzy_match
            template = str(template_path.relative_to(config.repo_root))
            console.print(f"[green]✓ Found template:[/green] [cyan]{template}[/cyan]\n")
        else:
            # Show suggestions
            suggestions = suggest_templates(config, template, limit=5)
            
            if suggestions:
                console.print("[yellow]Did you mean one of these?[/yellow]")
                for i, suggestion in enumerate(suggestions, 1):
                    console.print(f"  {i}. [cyan]{suggestion['path']}[/cyan]")
                console.print()
            
            console.print(f"[red]Template not found: {template}[/red]")
            console.print(f"[dim]Hint: Use 'iac template list' to see available templates[/dim]")
            ctx.exit(1)

    # Get and validate instance ID early
    if not instance:
        instance = click.prompt("Instance ID", type=str)

    # Validate instance ID format upfront
    if not validate_instance_id(instance):
        console.print(
            "\n[red]Invalid instance ID format:[/red] [yellow]{}[/yellow]".format(instance)
        )
        console.print("\n[bold]Requirements:[/bold]")
        console.print("  • 3-63 characters long")
        console.print("  • Lowercase letters, numbers, and hyphens only")
        console.print("  • Must start and end with a letter or number")
        console.print("\n[bold]Examples:[/bold]")
        console.print("  [green]✓[/green] my-app")
        console.print("  [green]✓[/green] blog-prod-01")
        console.print("  [green]✓[/green] wordpress-staging")
        console.print("  [red]✗[/red] MyApp (uppercase)")
        console.print("  [red]✗[/red] my_app (underscore)")
        console.print("  [red]✗[/red] -myapp (starts with hyphen)")
        ctx.exit(1)

    # Use smart environment detection
    if not environment:
        environment = get_environment_with_fallback(config, environment)
        # Show what was inferred
        from iac_manager.cli.config import infer_environment_from_context
        inferred = infer_environment_from_context(config)
        if inferred:
            console.print(f"[dim]Using environment from git branch: {environment}[/dim]")
        else:
            console.print(f"[dim]Using default environment: {environment}[/dim]")

    # Prompt for target if not provided
    if not target:
        # Show available targets
        available_targets = get_available_targets(config, environment)
        
        if available_targets["hosts"] or available_targets["groups"]:
            console.print("\n[bold]Available targets:[/bold]")
            
            if available_targets["hosts"]:
                console.print(f"\n[cyan]Hosts:[/cyan]")
                for host in available_targets["hosts"][:10]:  # Show first 10
                    console.print(f"  • {host}")
                if len(available_targets["hosts"]) > 10:
                    console.print(f"  [dim]... and {len(available_targets['hosts']) - 10} more[/dim]")
            
            if available_targets["groups"]:
                console.print(f"\n[cyan]Groups:[/cyan]")
                for group in available_targets["groups"]:
                    console.print(f"  • {group}")
            console.print()
        
        target = click.prompt("Deployment target (host or group)")



    # Parse parameters
    parameters = {}
    for p in param:
        if "=" not in p:
            console.print(f"[red]Invalid parameter format: {p} (expected KEY=VALUE)[/red]")
            ctx.exit(1)
        key, value = p.split("=", 1)
        parameters[key] = value

    # Determine deployment path
    deployment_path = (
        config.repo_root / config.deployments_dir / environment / instance
    )

    if deployment_path.exists() and not dry_run:
        console.print(
            f"[yellow]Warning: Deployment already exists at {deployment_path}[/yellow]"
        )
        if not confirm_action("Overwrite existing deployment?", default=False):
            console.print("[yellow]Cancelled.[/yellow]")
            ctx.exit(0)

    # Show what will be created
    console.print("\n[bold]Configuration Summary:[/bold]")
    console.print(f"  Template:    {template}")
    console.print(f"  Instance:    {instance}")
    console.print(f"  Environment: {environment}")
    console.print(f"  Target:      {target}")
    console.print(f"  Path:        {deployment_path.relative_to(config.repo_root)}")

    if parameters:
        console.print("\n[bold]Parameters:[/bold]")
        for key, value in parameters.items():
            console.print(f"  {key}: {value}")

    if dry_run:
        console.print("\n[yellow]Dry run mode - no changes made.[/yellow]")
        return

    # Confirm before proceeding
    if not confirm_action("\nProceed with configuration?", default=True):
        console.print("[yellow]Cancelled.[/yellow]")
        ctx.exit(0)

    # Create deployment with progress
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task("Configuring deployment...", total=None)

        # Create deployment directory
        deployment_path.mkdir(parents=True, exist_ok=True)

        # Copy template files with Jinja2 rendering
        progress.update(task, description="Copying template files...")
        copy_with_jinja(
            template_path,
            deployment_path,
            parameters,
            exclude_patterns=["README.md", ".git*", "__pycache__"],
        )

        # Create manifest
        progress.update(task, description="Creating manifest...")
        manifest = Manifest(
            name=instance,
            template=template,
            instance_id=instance,
            environment=EnvironmentType(environment),
            created_at=datetime.now(),
            updated_at=datetime.now(),
        )
        save_yaml(manifest.dict(), deployment_path / "manifest.yml")

        # Create target configuration
        progress.update(task, description="Creating target configuration...")
        target_config = {
            "targets": [
                {
                    "type": config.default_target_type,
                    "host": target,
                    "inventory": f"inventory/{environment}/servers.yml",
                }
            ]
        }
        save_yaml(target_config, deployment_path / "target.yml")

        # Create .env template if doesn't exist
        env_file = deployment_path / ".env"
        if not env_file.exists():
            progress.update(task, description="Creating environment file...")
            env_file.write_text("# Environment variables\n# Add your secrets here\n")

        progress.update(task, description="Done!", completed=True)

    console.print(
        Panel.fit(
            f"[green]✓[/green] Deployment configured successfully!\n\n"
            f"Location: [cyan]{deployment_path.relative_to(config.repo_root)}[/cyan]\n\n"
            f"Next steps:\n"
            f"  1. Edit configuration files in {deployment_path.relative_to(config.repo_root)}\n"
            f"  2. Add secrets to .env file\n"
            f"  3. Deploy with: [bold]iac deploy apply {instance} --environment {environment}[/bold]\n"
            f"  4. Or commit to Git for GitOps: [bold]iac gitops commit[/bold]",
            title="Success",
            border_style="green",
        )
    )


@deploy.command()
@click.option(
    "--environment",
    "-e",
    type=click.Choice(["development", "staging", "production", "dr-site"]),
    help="Filter by environment",
)
@click.pass_context
def list(ctx: click.Context, environment: Optional[str]) -> None:
    """List all deployments.

    Examples:

        iac deploy list
        iac deploy list --environment production
    """
    config: Config = ctx.obj["config"]
    console: Console = ctx.obj["console"]

    deployments_dir = config.repo_root / config.deployments_dir

    if not deployments_dir.exists():
        console.print("[yellow]No deployments found.[/yellow]")
        return

    # Find all deployments
    if environment:
        env_dir = deployments_dir / environment
        if not env_dir.exists():
            console.print(f"[yellow]No deployments found in {environment} environment.[/yellow]")
            return
        deployments = _find_deployments(env_dir)
    else:
        deployments = _find_deployments(deployments_dir)

    if not deployments:
        console.print("[yellow]No deployments found.[/yellow]")
        return

    # Print table
    rows = []
    for d in deployments:
        rows.append([
            d.instance_id,
            d.environment.value,
            d.template,
            str(d.deployment_path.relative_to(config.repo_root)),
        ])

    print_table(
        "Deployments",
        ["Instance ID", "Environment", "Template", "Path"],
        rows,
        console,
    )


@deploy.command()
@click.argument("instance_id")
@click.option(
    "--environment",
    type=click.Choice(["development", "staging", "production", "dr-site"]),
    help="Environment (will search all if not specified)",
)
@click.pass_context
def status(
    ctx: click.Context,
    instance_id: str,
    environment: Optional[str],
) -> None:
    """Show deployment status.

    Examples:

        iac deploy status my-app
        iac deploy status my-app --environment production
    """
    config: Config = ctx.obj["config"]
    console: Console = ctx.obj["console"]

    # Find deployment
    deployment = _find_deployment(config, instance_id, environment)

    if not deployment:
        console.print(f"[red]Deployment not found: {instance_id}[/red]")
        ctx.exit(1)

    # Display status
    console.print(f"\n[bold]Instance:[/bold] {deployment.instance_id}")
    console.print(f"[bold]Environment:[/bold] {deployment.environment.value}")
    console.print(f"[bold]Template:[/bold] {deployment.template}")
    console.print(f"[bold]Version:[/bold] {deployment.template_version}")
    console.print(f"[bold]Path:[/bold] {deployment.deployment_path.relative_to(config.repo_root)}")

    console.print(f"\n[bold]Files:[/bold]")
    console.print(f"  • docker-compose.yml: {'✓' if deployment.has_docker_compose else '✗'}")
    console.print(f"  • .env file: {'✓' if deployment.has_env_file else '✗'}")
    console.print(f"  • kubernetes manifests: {'✓' if deployment.has_kubernetes_manifests else '✗'}")

    console.print(f"\n[bold]Targets:[/bold]")
    for target in deployment.targets:
        host_or_group = target.host if target.host else f"group:{target.group}"
        console.print(f"  • {target.type.value} → {host_or_group}")


def _find_deployments(deployments_dir: Path) -> List[DeploymentInfo]:
    """Find all deployments."""
    deployments = []

    for env_dir in deployments_dir.iterdir():
        if not env_dir.is_dir():
            continue

        for instance_dir in env_dir.iterdir():
            if not instance_dir.is_dir():
                continue

            manifest_path = instance_dir / "manifest.yml"
            if not manifest_path.exists():
                continue

            try:
                manifest_data = load_yaml(manifest_path)
                manifest = Manifest(**manifest_data)

                # Load targets
                targets = []
                target_file = instance_dir / "target.yml"
                if target_file.exists():
                    target_data = load_yaml(target_file)
                    for t in target_data.get("targets", []):
                        targets.append(Target(**t))

                deployment = DeploymentInfo(
                    instance_id=manifest.instance_id,
                    environment=manifest.environment,
                    template=manifest.template,
                    template_version=manifest.template_version,
                    deployment_path=instance_dir,
                    manifest=manifest,
                    targets=targets,
                    has_env_file=(instance_dir / ".env").exists(),
                    has_docker_compose=(instance_dir / "docker-compose.yml").exists(),
                    has_kubernetes_manifests=(instance_dir / "kubernetes").is_dir()
                    or (instance_dir / "k8s").is_dir(),
                )
                deployments.append(deployment)
            except Exception:
                continue

    return sorted(deployments, key=lambda d: (d.environment.value, d.instance_id))


def _find_deployment(
    config: Config,
    instance_id: str,
    environment: Optional[str],
) -> Optional[DeploymentInfo]:
    """Find a specific deployment."""
    deployments_dir = config.repo_root / config.deployments_dir

    # If environment specified, look there
    if environment:
        instance_dir = deployments_dir / environment / instance_id
        if instance_dir.exists():
            manifest_path = instance_dir / "manifest.yml"
            if manifest_path.exists():
                manifest_data = load_yaml(manifest_path)
                manifest = Manifest(**manifest_data)

                targets = []
                target_file = instance_dir / "target.yml"
                if target_file.exists():
                    target_data = load_yaml(target_file)
                    for t in target_data.get("targets", []):
                        targets.append(Target(**t))

                return DeploymentInfo(
                    instance_id=manifest.instance_id,
                    environment=manifest.environment,
                    template=manifest.template,
                    template_version=manifest.template_version,
                    deployment_path=instance_dir,
                    manifest=manifest,
                    targets=targets,
                    has_env_file=(instance_dir / ".env").exists(),
                    has_docker_compose=(instance_dir / "docker-compose.yml").exists(),
                    has_kubernetes_manifests=(instance_dir / "kubernetes").is_dir(),
                )

    # Search all environments
    all_deployments = _find_deployments(deployments_dir)
    for d in all_deployments:
        if d.instance_id == instance_id:
            return d

    return None


@deploy.command()
@click.argument("instance_id")
@click.option(
    "--environment",
    type=click.Choice(["development", "staging", "production", "dr-site"]),
    help="Environment (required for apply)",
)
@click.option(
    "--check-mode",
    is_flag=True,
    help="Run in check mode (dry-run, no changes made)",
)
@click.option(
    "--tags",
    help="Ansible tags to run (comma-separated)",
)
@click.option(
    "--verbose",
    "-v",
    count=True,
    help="Increase Ansible verbosity (-v, -vv, -vvv)",
)
@click.pass_context
def apply(
    ctx: click.Context,
    instance_id: str,
    environment: Optional[str],
    check_mode: bool,
    tags: Optional[str],
    verbose: int,
) -> None:
    """Deploy an application using Ansible.

    This command executes the Ansible playbook to deploy the configured
    application to the target infrastructure.

    Examples:

        # Deploy to production
        iac deploy apply my-app --environment production

        # Dry-run deployment
        iac deploy apply my-app --environment production --check-mode

        # Deploy with specific tags
        iac deploy apply my-app --environment production --tags docker-compose

        # Verbose output
        iac deploy apply my-app --environment production -vvv
    """
    config: Config = ctx.obj["config"]
    console: Console = ctx.obj["console"]

    # Find deployment
    deployment = _find_deployment(config, instance_id, environment)

    if not deployment:
        console.print(f"[red]Deployment not found: {instance_id}[/red]")
        if not environment:
            console.print("[yellow]Hint: Try specifying --environment[/yellow]")
        ctx.exit(1)

    # Validate deployment before applying
    console.print(f"\n[bold]Validating deployment:[/bold] {deployment.instance_id}")
    validation_errors = _validate_deployment(deployment, config)
    
    if validation_errors:
        console.print("\n[red]Validation failed:[/red]")
        for error in validation_errors:
            console.print(f"  ✗ {error}")
        ctx.exit(1)
    
    console.print("[green]✓ Validation passed[/green]")

    # Show deployment info
    console.print(f"\n[bold]Deployment:[/bold] {deployment.instance_id}")
    console.print(f"[bold]Environment:[/bold] {deployment.environment.value}")
    console.print(f"[bold]Template:[/bold] {deployment.template}")
    
    if deployment.targets:
        console.print(f"\n[bold]Targets:[/bold]")
        for target in deployment.targets:
            host_or_group = target.host if target.host else f"group:{target.group}"
            console.print(f"  • {target.type.value} → {host_or_group}")

    if check_mode:
        console.print("\n[yellow]Running in check mode (no changes will be made)[/yellow]")

    # Confirm before deploying
    if not check_mode:
        if not confirm_action("\nProceed with deployment?", default=True):
            console.print("[yellow]Cancelled.[/yellow]")
            ctx.exit(0)

    # Prepare remote paths if required
    has_path_requirements = any(target.required_paths for target in deployment.targets)
    if has_path_requirements and not check_mode:
        console.print("\n[bold]Preparing remote paths...[/bold]")
        if not _prepare_remote_paths(deployment, config, console):
            console.print("\n[yellow]Warning: Some paths could not be created[/yellow]")
            if not confirm_action("Continue with deployment?", default=False):
                console.print("[yellow]Cancelled.[/yellow]")
                ctx.exit(0)

    # Build Ansible command
    ansible_playbook = config.repo_root / config.ansible_dir / "playbooks" / "docker-compose-deploy.yml"
    
    if not ansible_playbook.exists():
        console.print(f"[red]Ansible playbook not found: {ansible_playbook}[/red]")
        ctx.exit(1)

    deployment_path = deployment.deployment_path.relative_to(config.repo_root)
    
    ansible_cmd = [
        "ansible-playbook",
        str(ansible_playbook),
        "-e", f"deployment_path={deployment_path}",
    ]

    # Add target host/group
    if deployment.targets:
        target = deployment.targets[0]  # Use first target
        if target.host:
            ansible_cmd.extend(["-e", f"target_host={target.host}"])
        elif target.group:
            ansible_cmd.extend(["-e", f"target_group={target.group}"])

    # Add check mode
    if check_mode:
        ansible_cmd.append("--check")

    # Add tags
    if tags:
        ansible_cmd.extend(["--tags", tags])

    # Add verbosity
    if verbose:
        ansible_cmd.append("-" + "v" * verbose)

    # Execute Ansible
    console.print(f"\n[bold]Executing Ansible playbook...[/bold]")
    console.print(f"[dim]Command: {' '.join(ansible_cmd)}[/dim]\n")

    try:
        result = run_command(
            ansible_cmd,
            cwd=config.repo_root,
            capture_output=False,
        )
        
        if result.returncode == 0:
            console.print(
                Panel.fit(
                    f"[green]✓[/green] Deployment {'checked' if check_mode else 'completed'} successfully!\n\n"
                    f"Instance: [cyan]{deployment.instance_id}[/cyan]\n"
                    f"Environment: [cyan]{deployment.environment.value}[/cyan]",
                    title="Success",
                    border_style="green",
                )
            )
        else:
            console.print(f"[red]Deployment failed with exit code {result.returncode}[/red]")
            ctx.exit(result.returncode)

    except FileNotFoundError:
        console.print("[red]Error: ansible-playbook command not found[/red]")
        console.print("[yellow]Please install Ansible: pip install ansible[/yellow]")
        ctx.exit(1)
    except Exception as e:
        console.print(f"[red]Error executing Ansible: {e}[/red]")
        ctx.exit(1)


@deploy.command()
@click.argument("instance_id")
@click.option(
    "--environment",
    type=click.Choice(["development", "staging", "production", "dr-site"]),
    help="Environment (will search all if not specified)",
)
@click.option(
    "--verify",
    is_flag=True,
    help="Verify paths exist after creation",
)
@click.pass_context
def prepare_paths(
    ctx: click.Context,
    instance_id: str,
    environment: Optional[str],
    verify: bool,
) -> None:
    """Prepare required paths on target hosts.

    This command creates all required directories on target hosts with
    proper ownership and permissions before deployment.

    Examples:

        # Prepare paths for a deployment
        iac deploy prepare-paths my-app --environment production

        # Prepare and verify paths
        iac deploy prepare-paths my-app --environment production --verify
    """
    config: Config = ctx.obj["config"]
    console: Console = ctx.obj["console"]

    # Find deployment
    deployment = _find_deployment(config, instance_id, environment)

    if not deployment:
        console.print(f"[red]Deployment not found: {instance_id}[/red]")
        if not environment:
            console.print("[yellow]Hint: Try specifying --environment[/yellow]")
        ctx.exit(1)

    # Check if deployment has path requirements
    has_path_requirements = any(target.required_paths for target in deployment.targets)

    if not has_path_requirements:
        console.print(f"[yellow]No path requirements defined for {instance_id}[/yellow]")
        console.print("[dim]Add 'required_paths' to target.yml to define paths[/dim]")
        return

    # Show what will be created
    console.print(f"\n[bold]Deployment:[/bold] {deployment.instance_id}")
    console.print(f"[bold]Environment:[/bold] {deployment.environment.value}")

    for target in deployment.targets:
        if target.required_paths:
            host_or_group = target.host if target.host else f"group:{target.group}"
            console.print(f"\n[bold]Target:[/bold] {host_or_group}")
            console.print("[bold]Required paths:[/bold]")
            for path_req in target.required_paths:
                # Show both original and resolved path
                absolute_path = path_req.get_absolute_path(deployment.instance_id)
                if path_req.path.startswith('/'):
                    console.print(f"  • {path_req.path}")
                else:
                    console.print(f"  • {path_req.path} → {absolute_path}")
                console.print(f"    Owner: {path_req.owner}:{path_req.group}")
                console.print(f"    Mode: {path_req.mode}")
                if path_req.base_path and not path_req.path.startswith('/'):
                    console.print(f"    Base: {path_req.base_path}")

    if not confirm_action("\nProceed with path creation?", default=True):
        console.print("[yellow]Cancelled.[/yellow]")
        ctx.exit(0)

    # Prepare paths
    if not _prepare_remote_paths(deployment, config, console):
        console.print("\n[red]Failed to create all required paths[/red]")
        ctx.exit(1)

    # Verify if requested
    if verify:
        from iac_manager.cli.ssh_utils import verify_path_exists

        console.print("\n[bold]Verifying paths...[/bold]")

        for target in deployment.targets:
            if not target.required_paths:
                continue

            # Get hosts
            if target.host:
                hosts_to_verify = [target.host]
            elif target.group:
                inventory_path = config.repo_root / target.inventory
                inventory_data = load_yaml(inventory_path)
                hosts_to_verify = []
                for group_name, group_data in inventory_data.get("all", {}).get("children", {}).items():
                    if group_name == target.group:
                        hosts_to_verify = list(group_data.get("hosts", {}).keys())
                        break
            else:
                continue

            # Verify each host
            for host in hosts_to_verify:
                inventory_path = config.repo_root / target.inventory
                inventory_data = load_yaml(inventory_path)
                ssh_host, ssh_user, ssh_port = parse_ssh_config(host, inventory_data)

                console.print(f"\n[bold]{host}:[/bold]")
                for path_req in target.required_paths:
                    exists = verify_path_exists(ssh_host, ssh_user, path_req.path, ssh_port)
                    if exists:
                        console.print(f"  [green]✓[/green] {path_req.path}")
                    else:
                        console.print(f"  [red]✗[/red] {path_req.path}")

    console.print(
        Panel.fit(
            f"[green]✓[/green] Path preparation completed!\n\n"
            f"Instance: [cyan]{deployment.instance_id}[/cyan]\n"
            f"Environment: [cyan]{deployment.environment.value}[/cyan]",
            title="Success",
            border_style="green",
        )
    )


@deploy.command()
@click.argument("instance_id")
@click.option(
    "--environment",
    type=click.Choice(["development", "staging", "production", "dr-site"]),
    help="Environment (required)",
)
@click.option(
    "--cleanup",
    is_flag=True,
    help="Also cleanup deployment from servers",
)
@click.option(
    "--force",
    is_flag=True,
    help="Skip confirmation prompts",
)
@click.option(
    "--keep-backup",
    is_flag=True,
    help="Keep backup of deployment before removal",
)
@click.pass_context
def remove(
    ctx: click.Context,
    instance_id: str,
    environment: Optional[str],
    cleanup: bool,
    force: bool,
    keep_backup: bool,
) -> None:
    """Remove a deployment.

    This command removes the deployment configuration from the repository.
    Optionally, it can also cleanup the deployment from target servers.

    Examples:

        # Remove deployment configuration
        iac deploy remove my-app --environment production

        # Remove and cleanup from servers
        iac deploy remove my-app --environment production --cleanup

        # Force removal without confirmation
        iac deploy remove my-app --environment production --force
    """
    config: Config = ctx.obj["config"]
    console: Console = ctx.obj["console"]

    # Environment is required
    if not environment:
        console.print("[red]Error: --environment is required[/red]")
        ctx.exit(1)

    # Find deployment
    deployment = _find_deployment(config, instance_id, environment)

    if not deployment:
        console.print(f"[red]Deployment not found: {instance_id} in {environment}[/red]")
        ctx.exit(1)

    # Show what will be removed
    console.print(f"\n[bold red]WARNING: This will remove the deployment:[/bold red]")
    console.print(f"  Instance: {deployment.instance_id}")
    console.print(f"  Environment: {deployment.environment.value}")
    console.print(f"  Path: {deployment.deployment_path.relative_to(config.repo_root)}")
    
    if cleanup:
        console.print(f"\n[bold red]Also will cleanup from servers:[/bold red]")
        for target in deployment.targets:
            host_or_group = target.host if target.host else f"group:{target.group}"
            console.print(f"  • {host_or_group}")

    # Confirm
    if not force:
        if not confirm_action("\nAre you sure you want to remove this deployment?", default=False):
            console.print("[yellow]Cancelled.[/yellow]")
            ctx.exit(0)

    # Create backup if requested
    if keep_backup:
        import shutil
        import tarfile
        from datetime import datetime
        
        backup_dir = config.repo_root / ".deployments" / "backups"
        backup_dir.mkdir(parents=True, exist_ok=True)
        
        timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        backup_file = backup_dir / f"{instance_id}-{environment}-{timestamp}.tar.gz"
        
        console.print(f"\n[bold]Creating backup...[/bold]")
        with tarfile.open(backup_file, "w:gz") as tar:
            tar.add(deployment.deployment_path, arcname=deployment.deployment_path.name)
        
        console.print(f"[green]✓ Backup created:[/green] {backup_file.relative_to(config.repo_root)}")

    # Cleanup from servers if requested
    if cleanup:
        console.print(f"\n[bold]Cleaning up from servers...[/bold]")
        
        ansible_playbook = config.repo_root / config.ansible_dir / "playbooks" / "docker-compose-remove.yml"
        
        if ansible_playbook.exists():
            deployment_path = deployment.deployment_path.relative_to(config.repo_root)
            
            ansible_cmd = [
                "ansible-playbook",
                str(ansible_playbook),
                "-e", f"deployment_path={deployment_path}",
            ]

            if deployment.targets:
                target = deployment.targets[0]
                if target.host:
                    ansible_cmd.extend(["-e", f"target_host={target.host}"])
                elif target.group:
                    ansible_cmd.extend(["-e", f"target_group={target.group}"])

            try:
                run_command(ansible_cmd, cwd=config.repo_root, capture_output=False)
                console.print("[green]✓ Server cleanup completed[/green]")
            except Exception as e:
                console.print(f"[yellow]Warning: Server cleanup failed: {e}[/yellow]")
        else:
            console.print(f"[yellow]Warning: Cleanup playbook not found, skipping server cleanup[/yellow]")

    # Remove deployment directory
    console.print(f"\n[bold]Removing deployment files...[/bold]")
    import shutil
    shutil.rmtree(deployment.deployment_path)
    console.print("[green]✓ Deployment files removed[/green]")

    # Show success message
    console.print(
        Panel.fit(
            f"[green]✓[/green] Deployment removed successfully!\n\n"
            f"Instance: [cyan]{deployment.instance_id}[/cyan]\n"
            f"Environment: [cyan]{deployment.environment.value}[/cyan]\n\n"
            f"Next steps:\n"
            f"  1. Commit the change: [bold]iac gitops commit -m 'chore: remove {instance_id}'[/bold]",
            title="Success",
            border_style="green",
        )
    )


@deploy.command()
@click.argument("instance_id")
@click.option(
    "--environment",
    type=click.Choice(["development", "staging", "production", "dr-site"]),
    help="Environment",
)
@click.option(
    "--strict",
    is_flag=True,
    help="Fail on warnings",
)
@click.pass_context
def validate(
    ctx: click.Context,
    instance_id: str,
    environment: Optional[str],
    strict: bool,
) -> None:
    """Validate deployment configuration.

    Checks deployment files, configuration, and dependencies to ensure
    everything is properly configured before deployment.

    Examples:

        # Validate deployment
        iac deploy validate my-app --environment production

        # Strict validation (fail on warnings)
        iac deploy validate my-app --environment production --strict
    """
    config: Config = ctx.obj["config"]
    console: Console = ctx.obj["console"]

    # Find deployment
    deployment = _find_deployment(config, instance_id, environment)

    if not deployment:
        console.print(f"[red]Deployment not found: {instance_id}[/red]")
        if not environment:
            console.print("[yellow]Hint: Try specifying --environment[/yellow]")
        ctx.exit(1)

    console.print(f"\n[bold]Validating deployment:[/bold] {deployment.instance_id}")
    console.print(f"[bold]Environment:[/bold] {deployment.environment.value}\n")

    # Run validation checks
    errors = []
    warnings = []

    # Check 1: manifest.yml
    console.print("Checking manifest.yml... ", end="")
    manifest_path = deployment.deployment_path / "manifest.yml"
    if manifest_path.exists():
        try:
            load_yaml(manifest_path)
            console.print("[green]✓[/green]")
        except Exception as e:
            error_msg = f"Invalid manifest.yml: {e}"
            errors.append(error_msg)
            console.print(f"[red]✗[/red] {error_msg}")
    else:
        error_msg = "manifest.yml not found"
        errors.append(error_msg)
        console.print(f"[red]✗[/red] {error_msg}")

    # Check 2: docker-compose.yml
    if deployment.has_docker_compose:
        console.print("Checking docker-compose.yml... ", end="")
        compose_path = deployment.deployment_path / "docker-compose.yml"
        try:
            load_yaml(compose_path)
            console.print("[green]✓[/green]")
        except Exception as e:
            error_msg = f"Invalid docker-compose.yml: {e}"
            errors.append(error_msg)
            console.print(f"[red]✗[/red] {error_msg}")

    # Check 3: target configuration
    console.print("Checking target configuration... ", end="")
    target_path = deployment.deployment_path / "target.yml"
    if target_path.exists():
        try:
            target_data = load_yaml(target_path)
            if "targets" not in target_data or not target_data["targets"]:
                warning_msg = "No targets defined"
                warnings.append(warning_msg)
                console.print(f"[yellow]⚠[/yellow] {warning_msg}")
            else:
                console.print("[green]✓[/green]")
        except Exception as e:
            error_msg = f"Invalid target.yml: {e}"
            errors.append(error_msg)
            console.print(f"[red]✗[/red] {error_msg}")
    else:
        error_msg = "target.yml not found"
        errors.append(error_msg)
        console.print(f"[red]✗[/red] {error_msg}")

    # Check 4: .env file
    console.print("Checking environment file... ", end="")
    if deployment.has_env_file:
        console.print("[green]✓[/green]")
    else:
        warning_msg = ".env file not found (may be required)"
        warnings.append(warning_msg)
        console.print(f"[yellow]⚠[/yellow] {warning_msg}")

    # Check 5: Inventory references
    console.print("Checking inventory references... ", end="")
    if deployment.targets:
        inventory_valid = True
        for target in deployment.targets:
            inventory_path = config.repo_root / target.inventory
            if not inventory_path.exists():
                error_msg = f"Inventory file not found: {target.inventory}"
                errors.append(error_msg)
                inventory_valid = False
        
        if inventory_valid:
            console.print("[green]✓[/green]")
        else:
            console.print("[red]✗[/red]")
    else:
        console.print("[yellow]⚠[/yellow] No targets to check")

    # Summary
    console.print()
    
    if errors:
        console.print(f"[red]✗ Validation failed with {len(errors)} error(s)[/red]")
        for error in errors:
            console.print(f"  • {error}")
        ctx.exit(1)
    elif warnings and strict:
        console.print(f"[yellow]⚠ Validation failed in strict mode with {len(warnings)} warning(s)[/yellow]")
        for warning in warnings:
            console.print(f"  • {warning}")
        ctx.exit(1)
    elif warnings:
        console.print(f"[yellow]⚠ Validation passed with {len(warnings)} warning(s)[/yellow]")
        for warning in warnings:
            console.print(f"  • {warning}")
    else:
        console.print("[green]✓ Validation passed successfully![/green]")


@deploy.command()
@click.argument("instance_id")
@click.option(
    "--environment",
    type=click.Choice(["development", "staging", "production", "dr-site"]),
    help="Environment",
)
@click.option(
    "--against-template",
    is_flag=True,
    help="Compare against original template",
)
@click.pass_context
def diff(
    ctx: click.Context,
    instance_id: str,
    environment: Optional[str],
    against_template: bool,
) -> None:
    """Show changes in deployment configuration.

    Display uncommitted changes or compare deployment to its template.

    Examples:

        # Show uncommitted changes
        iac deploy diff my-app --environment production

        # Compare to original template
        iac deploy diff my-app --environment production --against-template
    """
    config: Config = ctx.obj["config"]
    console: Console = ctx.obj["console"]

    # Find deployment
    deployment = _find_deployment(config, instance_id, environment)

    if not deployment:
        console.print(f"[red]Deployment not found: {instance_id}[/red]")
        if not environment:
            console.print("[yellow]Hint: Try specifying --environment[/yellow]")
        ctx.exit(1)

    deployment_rel_path = deployment.deployment_path.relative_to(config.repo_root)

    if against_template:
        console.print(f"\n[yellow]Note: Template comparison not yet implemented[/yellow]")
        console.print("[dim]This feature will compare the deployment against its original template[/dim]\n")
        ctx.exit(0)

    # Show git diff for the deployment
    console.print(f"\n[bold]Changes in:[/bold] {deployment_rel_path}\n")

    try:
        from git import Repo
        repo = Repo(config.repo_root)
        
        # Check if there are changes
        changed = False
        
        # Check for unstaged changes
        diffs = repo.index.diff(None, paths=str(deployment_rel_path))
        if diffs:
            console.print("[yellow]Unstaged changes:[/yellow]\n")
            for diff in diffs:
                console.print(f"[yellow]Modified:[/yellow] {diff.a_path}")
                if diff.diff:
                    from rich.syntax import Syntax
                    syntax = Syntax(diff.diff.decode('utf-8'), "diff", theme="monokai")
                    console.print(syntax)
                console.print()
            changed = True

        # Check for staged changes
        diffs = repo.index.diff("HEAD", paths=str(deployment_rel_path))
        if diffs:
            console.print("[green]Staged changes:[/green]\n")
            for diff in diffs:
                console.print(f"[green]Modified:[/green] {diff.a_path}")
                if diff.diff:
                    from rich.syntax import Syntax
                    syntax = Syntax(diff.diff.decode('utf-8'), "diff", theme="monokai")
                    console.print(syntax)
                console.print()
            changed = True

        # Check for untracked files
        untracked = [f for f in repo.untracked_files if f.startswith(str(deployment_rel_path))]
        if untracked:
            console.print("[cyan]Untracked files:[/cyan]\n")
            for file in untracked:
                console.print(f"  [cyan]New:[/cyan] {file}")
            changed = True

        if not changed:
            console.print("[green]No changes detected[/green]")

    except Exception as e:
        console.print(f"[red]Error getting diff: {e}[/red]")
        ctx.exit(1)


def _validate_deployment(deployment: DeploymentInfo, config: Config) -> List[str]:
    """Validate a deployment and return list of errors.

    Args:
        deployment: Deployment to validate
        config: Configuration

    Returns:
        List of error messages (empty if valid)
    """
    errors = []

    # Check manifest.yml
    manifest_path = deployment.deployment_path / "manifest.yml"
    if not manifest_path.exists():
        errors.append("manifest.yml not found")
    else:
        try:
            load_yaml(manifest_path)
        except Exception as e:
            errors.append(f"Invalid manifest.yml: {e}")

    # Check docker-compose.yml if it should exist
    if deployment.has_docker_compose:
        compose_path = deployment.deployment_path / "docker-compose.yml"
        try:
            load_yaml(compose_path)
        except Exception as e:
            errors.append(f"Invalid docker-compose.yml: {e}")

    # Check target configuration
    target_path = deployment.deployment_path / "target.yml"
    if not target_path.exists():
        errors.append("target.yml not found")
    else:
        try:
            target_data = load_yaml(target_path)
            if "targets" not in target_data or not target_data["targets"]:
                errors.append("No targets defined in target.yml")
        except Exception as e:
            errors.append(f"Invalid target.yml: {e}")

    # Check inventory references
    for target in deployment.targets:
        inventory_path = config.repo_root / target.inventory
        if not inventory_path.exists():
            errors.append(f"Inventory file not found: {target.inventory}")

    return errors


def _prepare_remote_paths(
    deployment: DeploymentInfo,
    config: Config,
    console: Console,
) -> bool:
    """Prepare required paths on target hosts.

    Args:
        deployment: Deployment information
        config: Configuration
        console: Rich console for output

    Returns:
        True if all paths created successfully, False otherwise
    """
    all_successful = True

    for target in deployment.targets:
        # Skip if no paths required
        if not target.required_paths:
            continue

        # Determine which host to use
        if target.host:
            hosts_to_process = [target.host]
        elif target.group:
            # Load inventory to get hosts in group
            inventory_path = config.repo_root / target.inventory
            try:
                inventory_data = load_yaml(inventory_path)
                # Find group hosts
                hosts_to_process = []
                for group_name, group_data in inventory_data.get("all", {}).get("children", {}).items():
                    if group_name == target.group:
                        hosts_to_process = list(group_data.get("hosts", {}).keys())
                        break

                if not hosts_to_process:
                    console.print(f"[yellow]Warning: No hosts found in group {target.group}[/yellow]")
                    continue
            except Exception as e:
                console.print(f"[red]Error loading inventory: {e}[/red]")
                all_successful = False
                continue
        else:
            console.print("[yellow]Warning: Target has no host or group specified[/yellow]")
            continue

        # Process each host
        for host in hosts_to_process:
            try:
                # Load inventory to get SSH details
                inventory_path = config.repo_root / target.inventory
                inventory_data = load_yaml(inventory_path)

                # Parse SSH configuration
                ssh_host, ssh_user, ssh_port = parse_ssh_config(host, inventory_data)

                console.print(f"\n[bold]Preparing paths on {host}:[/bold]")

                # Create paths with deployment name for relative path resolution
                results = create_multiple_paths(
                    ssh_host,
                    ssh_user,
                    target.required_paths,
                    ssh_port,
                    use_sudo=True,
                    show_progress=True,
                    deployment_name=deployment.instance_id,
                )

                # Check results
                failed_paths = [path for path, success in results.items() if not success]
                if failed_paths:
                    console.print(f"[yellow]Failed to create paths: {', '.join(failed_paths)}[/yellow]")
                    all_successful = False
                else:
                    console.print(f"[green]✓ All paths created successfully on {host}[/green]")

            except ValueError as e:
                console.print(f"[red]Configuration error: {e}[/red]")
                all_successful = False
            except SSHConnectionError as e:
                console.print(f"[red]SSH connection error: {e}[/red]")
                all_successful = False
            except Exception as e:
                console.print(f"[red]Unexpected error: {e}[/red]")
                all_successful = False

    return all_successful


@deploy.command()
@click.argument("instance_id")
@click.option(
    "--environment",
    "-e",
    help="Environment name (default: from manifest or config)",
)
@click.option(
    "--limit",
    "-l",
    type=int,
    default=10,
    help="Number of history entries to show",
)
@click.pass_context
def history(
    ctx: click.Context,
    instance_id: str,
    environment: Optional[str],
    limit: int,
):
    """Show deployment history and versions.

    Examples:

        # Show deployment history
        iac deploy history my-app

        # Show last 20 entries
        iac deploy history my-app --limit 20

        # Show history for specific environment
        iac deploy history my-app --environment production
    """
    config: Config = ctx.obj["config"]
    console: Console = ctx.obj["console"]
    
    import git
    from datetime import datetime
    from rich.table import Table
    
    try:
        # Find deployment
        deployment = _find_deployment(config, instance_id, environment)
        if not deployment:
            console.print(f"[red]Deployment not found: {instance_id}[/red]")
            if environment:
                console.print(f"[dim]Environment: {environment}[/dim]")
            raise click.Abort()
        
        # Get git history for deployment directory
        try:
            repo = git.Repo(config.repo_root)
        except git.InvalidGitRepositoryError:
            console.print("[red]Not a git repository[/red]")
            console.print("[dim]Deployment history requires git tracking[/dim]")
            raise click.Abort()
        
        deployment_rel_path = deployment.deployment_path.relative_to(config.repo_root)
        
        # Get commits that modified this deployment
        commits = list(repo.iter_commits(
            paths=str(deployment_rel_path),
            max_count=limit,
        ))
        
        if not commits:
            console.print(f"[yellow]No history found for deployment: {instance_id}[/yellow]")
            console.print("[dim]Deployment may not be committed yet[/dim]")
            return
        
        # Display history
        table = Table(title=f"Deployment History: {instance_id}")
        table.add_column("Version", style="cyan", width=8)
        table.add_column("Date", style="yellow")
        table.add_column("Author", style="green")
        table.add_column("Message", style="white")
        table.add_column("SHA", style="dim", width=10)
        
        for idx, commit in enumerate(commits, 1):
            commit_date = datetime.fromtimestamp(commit.committed_date).strftime("%Y-%m-%d %H:%M")
            author = commit.author.name
            message = commit.message.split("\n")[0][:50]  # First line, truncated
            sha = commit.hexsha[:8]
            
            table.add_row(
                f"v{len(commits) - idx + 1}",
                commit_date,
                author,
                message,
                sha,
            )
        
        console.print(table)
        console.print(f"\n[dim]Showing {len(commits)} of {len(list(repo.iter_commits(paths=str(deployment_rel_path))))} total commits[/dim]")
        console.print(f"[dim]To rollback: iac deploy rollback {instance_id} --to-version v{{N}}[/dim]")
        
    except click.Abort:
        raise
    except Exception as e:
        console.print(f"[red]Error getting history: {e}[/red]")
        raise click.Abort()


@deploy.command()
@click.argument("instance_id")
@click.option(
    "--environment",
    "-e",
    help="Environment name (default: from manifest or config)",
)
@click.option(
    "--to-version",
    "-v",
    help="Version to rollback to (e.g., v1, v2, or git SHA)",
)
@click.option(
    "--to-commit",
    "-c",
    help="Git commit SHA to rollback to",
)
@click.option(
    "--steps",
    "-s",
    type=int,
    default=1,
    help="Number of versions to rollback (default: 1)",
)
@click.option(
    "--dry-run",
    is_flag=True,
    help="Show what would be rolled back without doing it",
)
@click.option(
    "--auto-deploy",
    is_flag=True,
    help="Automatically deploy after rollback",
)
@click.pass_context
def rollback(
    ctx: click.Context,
    instance_id: str,
    environment: Optional[str],
    to_version: Optional[str],
    to_commit: Optional[str],
    steps: int,
    dry_run: bool,
    auto_deploy: bool,
):
    """Rollback deployment to a previous version.

    Rollback restores the deployment configuration to a previous git commit.
    This updates the configuration files but does NOT automatically deploy.
    Use --auto-deploy to deploy after rollback.

    Examples:

        # Rollback to previous version
        iac deploy rollback my-app

        # Rollback 3 versions back
        iac deploy rollback my-app --steps 3

        # Rollback to specific version
        iac deploy rollback my-app --to-version v5

        # Rollback to specific commit
        iac deploy rollback my-app --to-commit abc1234

        # Preview rollback
        iac deploy rollback my-app --dry-run

        # Rollback and deploy
        iac deploy rollback my-app --auto-deploy
    """
    config: Config = ctx.obj["config"]
    console: Console = ctx.obj["console"]
    
    import git
    import shutil
    from datetime import datetime
    from iac_manager.cli.utils import confirm_action
    
    try:
        # Find deployment
        deployment = _find_deployment(config, instance_id, environment)
        if not deployment:
            console.print(f"[red]Deployment not found: {instance_id}[/red]")
            raise click.Abort()
        
        # Get git repo
        try:
            repo = git.Repo(config.repo_root)
        except git.InvalidGitRepositoryError:
            console.print("[red]Not a git repository[/red]")
            console.print("[dim]Rollback requires git tracking[/dim]")
            raise click.Abort()
        
        # Check for uncommitted changes
        if repo.is_dirty(path=str(deployment.deployment_path.relative_to(config.repo_root))):
            console.print("[yellow]Warning: Deployment has uncommitted changes[/yellow]")
            if not dry_run and not confirm_action("Continue with rollback?", default=False):
                console.print("[yellow]Cancelled[/yellow]")
                return
        
        deployment_rel_path = deployment.deployment_path.relative_to(config.repo_root)
        
        # Determine target commit
        if to_commit:
            target_sha = to_commit
        elif to_version:
            # Parse version (e.g., "v5" -> 5th commit from top)
            if to_version.startswith("v"):
                try:
                    version_num = int(to_version[1:])
                    commits = list(repo.iter_commits(paths=str(deployment_rel_path)))
                    if version_num < 1 or version_num > len(commits):
                        console.print(f"[red]Invalid version: {to_version}[/red]")
                        console.print(f"[dim]Available versions: v1 to v{len(commits)}[/dim]")
                        raise click.Abort()
                    target_commit = commits[len(commits) - version_num]
                    target_sha = target_commit.hexsha
                except ValueError:
                    console.print(f"[red]Invalid version format: {to_version}[/red]")
                    console.print("[dim]Use format: v1, v2, v3, etc.[/dim]")
                    raise click.Abort()
            else:
                target_sha = to_version
        else:
            # Rollback N steps
            commits = list(repo.iter_commits(paths=str(deployment_rel_path), max_count=steps + 1))
            if len(commits) <= steps:
                console.print(f"[red]Cannot rollback {steps} steps - only {len(commits) - 1} versions available[/red]")
                raise click.Abort()
            target_commit = commits[steps]
            target_sha = target_commit.hexsha
        
        # Get target commit details
        try:
            target_commit = repo.commit(target_sha)
        except (git.BadName, ValueError):
            console.print(f"[red]Invalid commit: {target_sha}[/red]")
            raise click.Abort()
        
        # Show rollback info
        commit_date = datetime.fromtimestamp(target_commit.committed_date).strftime("%Y-%m-%d %H:%M")
        
        console.print("\n[bold]Rollback Plan:[/bold]")
        console.print(f"  Deployment: [cyan]{instance_id}[/cyan]")
        console.print(f"  Target Commit: [yellow]{target_sha[:8]}[/yellow]")
        console.print(f"  Date: [dim]{commit_date}[/dim]")
        console.print(f"  Author: [green]{target_commit.author.name}[/green]")
        console.print(f"  Message: [white]{target_commit.message.split("\n")[0]}[/white]")
        
        if dry_run:
            console.print("\n[yellow]Dry run - no changes made[/yellow]")
            return
        
        # Confirm rollback
        if not confirm_action("Proceed with rollback?", default=False):
            console.print("[yellow]Cancelled[/yellow]")
            return
        
        # Create backup
        backup_dir = deployment.deployment_path.parent / f".{instance_id}.backup.{int(datetime.now().timestamp())}"
        console.print(f"\n[dim]Creating backup: {backup_dir.name}[/dim]")
        shutil.copytree(deployment.deployment_path, backup_dir)
        
        # Perform rollback
        console.print("[dim]Rolling back files...[/dim]")
        
        # Use git checkout to restore files from target commit
        try:
            repo.git.checkout(target_sha, "--", str(deployment_rel_path))
            console.print(f"[green]✓[/green] Rolled back to {target_sha[:8]}")
            console.print(f"[dim]Backup saved: {backup_dir.name}[/dim]")
            
            # Auto-deploy if requested
            if auto_deploy:
                console.print("\n[bold]Deploying rolled-back configuration...[/bold]")
                # Call apply command
                from click.testing import CliRunner
                runner = CliRunner()
                result = runner.invoke(
                    apply,
                    [instance_id],
                    obj=config,
                    catch_exceptions=False,
                )
                if result.exit_code != 0:
                    console.print("[yellow]Deployment failed - you may need to manually deploy[/yellow]")
            else:
                console.print("\n[yellow]Configuration rolled back but NOT deployed[/yellow]")
                console.print(f"[dim]To deploy: iac deploy apply {instance_id}[/dim]")
        
        except git.GitCommandError as e:
            console.print(f"[red]Git error during rollback: {e}[/red]")
            # Restore from backup
            console.print("[yellow]Restoring from backup...[/yellow]")
            shutil.rmtree(deployment.deployment_path)
            shutil.copytree(backup_dir, deployment.deployment_path)
            shutil.rmtree(backup_dir)
            console.print("[green]✓[/green] Restored from backup")
            raise click.Abort()
        
    except click.Abort:
        raise
    except Exception as e:
        console.print(f"[red]Error during rollback: {e}[/red]")
        raise click.Abort()


@deploy.command()
@click.argument("instance_id", required=False)
@click.option(
    "--environment",
    "-e",
    help="Environment name (default: from manifest or config)",
)
@click.option(
    "--all",
    "-a",
    is_flag=True,
    help="Check health of all deployments",
)
@click.option(
    "--watch",
    "-w",
    is_flag=True,
    help="Continuously monitor health (refresh every 5s)",
)
@click.option(
    "--format",
    type=click.Choice(["table", "json"]),
    default="table",
    help="Output format",
)
@click.pass_context
def health(
    ctx: click.Context,
    instance_id: Optional[str],
    environment: Optional[str],
    all: bool,
    watch: bool,
    format: str,
):
    """Check deployment health status.

    Checks Docker container status, service availability, and basic metrics
    for deployed applications.

    Examples:

        # Check single deployment health
        iac deploy health my-app

        # Check all deployments
        iac deploy health --all

        # Check specific environment
        iac deploy health --all --environment production

        # Watch mode (continuous monitoring)
        iac deploy health my-app --watch

        # JSON output
        iac deploy health my-app --format json
    """
    config: Config = ctx.obj["config"]
    console: Console = ctx.obj["console"]
    
    import json
    import time
    from rich.table import Table
    from rich.live import Live
    
    try:
        if not all and not instance_id:
            console.print("[red]Error: Specify an instance ID or use --all[/red]")
            console.print("[dim]Usage: iac deploy health <instance_id> or iac deploy health --all[/dim]")
            raise click.Abort()
        
        # Continuous monitoring
        if watch:
            if format == "json":
                console.print("[yellow]Watch mode not supported with JSON format[/yellow]")
                raise click.Abort()
            
            with Live(console=console, refresh_per_second=0.2) as live:
                while True:
                    if all:
                        table = _create_health_table_all(config, environment)
                    else:
                        table = _create_health_table_single(config, instance_id, environment)
                    
                    live.update(table)
                    time.sleep(5)
        
        # Single check
        if all:
            health_data = _check_all_health(config, environment)
            
            if format == "json":
                console.print(json.dumps(health_data, indent=2))
            else:
                _display_health_table(health_data)
        else:
            health_data = _check_single_health(config, instance_id, environment)
            
            if format == "json":
                console.print(json.dumps(health_data, indent=2))
            else:
                _display_single_health(health_data, instance_id)
        
    except KeyboardInterrupt:
        console.print("\n[yellow]Monitoring stopped[/yellow]")
    except click.Abort:
        raise
    except Exception as e:
        console.print(f"[red]Error checking health: {e}[/red]")
        raise click.Abort()


def _check_single_health(
    config: Config,
    instance_id: str,
    environment: Optional[str],
) -> Dict:
    """Check health of a single deployment."""
    deployment = _find_deployment(config, instance_id, environment)
    
    if not deployment:
        return {
            "status": "error",
            "message": f"Deployment not found: {instance_id}",
        }
    
    # Get target host
    if not deployment.targets:
        return {
            "instance_id": instance_id,
            "status": "error",
            "message": "No targets configured",
        }
    
    target = deployment.targets[0]
    
    # Check if docker-compose deployment
    if not deployment.has_docker_compose:
        return {
            "instance_id": instance_id,
            "status": "unknown",
            "message": "Not a docker-compose deployment",
        }
    
    # Build docker-compose command
    compose_file = deployment.deployment_path / "docker-compose.yml"
    
    # Check container status via SSH
    health_data = {
        "instance_id": instance_id,
        "environment": deployment.environment,
        "deployment_path": str(deployment.deployment_path),
        "containers": [],
        "overall_status": "unknown",
    }
    
    try:
        # Try to get container status
        # This assumes docker-compose ps output format
        result = run_command(
            ["docker-compose", "-f", str(compose_file), "ps", "--format", "json"],
            capture_output=True,
        )
        
        if result["success"]:
            # Parse container information
            containers = []
            for line in result["output"].strip().split("\n"):
                if line:
                    try:
                        container = json.loads(line)
                        containers.append({
                            "name": container.get("Name", "unknown"),
                            "state": container.get("State", "unknown"),
                            "status": container.get("Status", "unknown"),
                            "health": container.get("Health", "unknown"),
                        })
                    except json.JSONDecodeError:
                        continue
            
            health_data["containers"] = containers
            
            # Determine overall status
            if not containers:
                health_data["overall_status"] = "stopped"
            elif all(c["state"] == "running" for c in containers):
                health_data["overall_status"] = "healthy"
            elif any(c["state"] == "running" for c in containers):
                health_data["overall_status"] = "degraded"
            else:
                health_data["overall_status"] = "down"
        else:
            health_data["overall_status"] = "error"
            health_data["message"] = "Failed to get container status"
    
    except Exception as e:
        health_data["overall_status"] = "error"
        health_data["message"] = str(e)
    
    return health_data


def _check_all_health(config: Config, environment: Optional[str]) -> List[Dict]:
    """Check health of all deployments."""
    deployments_dir = config.repo_root / config.deployments_dir
    
    if not deployments_dir.exists():
        return []
    
    # Find deployments
    if environment:
        env_dir = deployments_dir / environment
        if not env_dir.exists():
            return []
        deployments = _find_deployments(env_dir)
    else:
        deployments = _find_deployments(deployments_dir)
    
    # Check health for each
    health_results = []
    for deployment in deployments:
        health_data = _check_single_health(
            config,
            deployment.instance_id,
            deployment.environment,
        )
        health_results.append(health_data)
    
    return health_results


def _display_single_health(health_data: Dict, instance_id: str):
    """Display health information for a single deployment."""
    from rich.table import Table
    
    # Overall status panel
    status = health_data.get("overall_status", "unknown")
    status_color = {
        "healthy": "green",
        "degraded": "yellow",
        "down": "red",
        "stopped": "dim",
        "error": "red",
        "unknown": "dim",
    }.get(status, "white")
    
    console.print(Panel(
        f"[bold]Deployment:[/bold] {instance_id}\n"
        f"[bold]Environment:[/bold] {health_data.get('environment', 'unknown')}\n"
        f"[bold]Status:[/bold] [{status_color}]{status.upper()}[/{status_color}]",
        title="Health Check",
        border_style=status_color,
    ))
    
    # Container details
    containers = health_data.get("containers", [])
    
    if containers:
        table = Table(title="Containers")
        table.add_column("Container", style="cyan")
        table.add_column("State", style="white")
        table.add_column("Status", style="dim")
        
        for container in containers:
            state = container.get("state", "unknown")
            state_color = "green" if state == "running" else "red"
            
            table.add_row(
                container.get("name", "unknown"),
                f"[{state_color}]{state}[/{state_color}]",
                container.get("status", "unknown"),
            )
        
        console.print(table)
    elif "message" in health_data:
        console.print(f"\n[yellow]{health_data['message']}[/yellow]")
    else:
        console.print("\n[dim]No container information available[/dim]")


def _display_health_table(health_results: List[Dict]):
    """Display health information for multiple deployments."""
    from rich.table import Table
    
    if not health_results:
        console.print("[yellow]No deployments found[/yellow]")
        return
    
    table = Table(title=f"Health Status ({len(health_results)} deployments)")
    table.add_column("Instance ID", style="cyan")
    table.add_column("Environment", style="yellow")
    table.add_column("Status", style="white")
    table.add_column("Containers", justify="center")
    
    for health in health_results:
        instance_id = health.get("instance_id", "unknown")
        environment = health.get("environment", "unknown")
        status = health.get("overall_status", "unknown")
        containers = health.get("containers", [])
        
        status_color = {
            "healthy": "green",
            "degraded": "yellow",
            "down": "red",
            "stopped": "dim",
            "error": "red",
            "unknown": "dim",
        }.get(status, "white")
        
        running = sum(1 for c in containers if c.get("state") == "running")
        total = len(containers)
        
        table.add_row(
            instance_id,
            environment,
            f"[{status_color}]{status.upper()}[/{status_color}]",
            f"{running}/{total}" if containers else "0/0",
        )
    
    console.print(table)


def _create_health_table_single(
    config: Config,
    instance_id: str,
    environment: Optional[str],
) -> Panel:
    """Create a live-updating health table for a single deployment."""
    health_data = _check_single_health(config, instance_id, environment)
    
    status = health_data.get("overall_status", "unknown")
    status_color = {
        "healthy": "green",
        "degraded": "yellow",
        "down": "red",
        "stopped": "dim",
        "error": "red",
        "unknown": "dim",
    }.get(status, "white")
    
    containers = health_data.get("containers", [])
    container_info = "\n".join(
        f"  • {c.get('name', 'unknown')}: [{('green' if c.get('state') == 'running' else 'red')}]{c.get('state', 'unknown')}[/]"
        for c in containers
    ) if containers else "  [dim]No containers[/dim]"
    
    return Panel(
        f"[bold]Instance:[/bold] {instance_id}\n"
        f"[bold]Status:[/bold] [{status_color}]{status.upper()}[/{status_color}]\n\n"
        f"[bold]Containers:[/bold]\n{container_info}\n\n"
        f"[dim]Last updated: {datetime.now().strftime('%H:%M:%S')}[/dim]",
        title="🏥 Health Monitor",
        border_style=status_color,
    )


def _create_health_table_all(
    config: Config,
    environment: Optional[str],
) -> Table:
    """Create a live-updating health table for all deployments."""
    health_results = _check_all_health(config, environment)
    
    table = Table(title=f"🏥 Health Monitor ({len(health_results)} deployments)")
    table.add_column("Instance ID", style="cyan")
    table.add_column("Environment", style="yellow")
    table.add_column("Status", style="white")
    table.add_column("Containers", justify="center")
    
    for health in health_results:
        instance_id = health.get("instance_id", "unknown")
        env = health.get("environment", "unknown")
        status = health.get("overall_status", "unknown")
        containers = health.get("containers", [])
        
        status_color = {
            "healthy": "green",
            "degraded": "yellow",
            "down": "red",
            "stopped": "dim",
            "error": "red",
            "unknown": "dim",
        }.get(status, "white")
        
        running = sum(1 for c in containers if c.get("state") == "running")
        total = len(containers)
        
        table.add_row(
            instance_id,
            env,
            f"[{status_color}]{status.upper()}[/{status_color}]",
            f"{running}/{total}" if containers else "0/0",
        )
    
    table.caption = f"[dim]Last updated: {datetime.now().strftime('%H:%M:%S')}[/dim]"
    
    return table


@deploy.command()
@click.option(
    "--environment",
    "-e",
    required=True,
    help="Environment to apply all deployments in",
)
@click.option(
    "--dry-run",
    is_flag=True,
    help="Show what would be deployed without deploying",
)
@click.option(
    "--parallel",
    "-p",
    is_flag=True,
    help="Deploy in parallel (experimental)",
)
@click.option(
    "--continue-on-error",
    is_flag=True,
    help="Continue deploying even if one fails",
)
@click.pass_context
def apply_all(
    ctx: click.Context,
    environment: str,
    dry_run: bool,
    parallel: bool,
    continue_on_error: bool,
):
    """Apply all deployments in an environment.

    Examples:

        # Apply all staging deployments
        iac deploy apply-all --environment staging

        # Preview what would be deployed
        iac deploy apply-all --environment production --dry-run

        # Deploy with error handling
        iac deploy apply-all --environment staging --continue-on-error
    """
    config: Config = ctx.obj["config"]
    console: Console = ctx.obj["console"]
    
    from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn
    from rich.table import Table
    
    try:
        # Find all deployments in environment
        deployments_dir = config.repo_root / config.deployments_dir / environment
        
        if not deployments_dir.exists():
            console.print(f"[red]Environment not found: {environment}[/red]")
            raise click.Abort()
        
        deployments = _find_deployments(deployments_dir)
        
        if not deployments:
            console.print(f"[yellow]No deployments found in {environment}[/yellow]")
            return
        
        console.print(f"\n[bold]Found {len(deployments)} deployments in {environment}[/bold]\n")
        
        # Show summary table
        table = Table()
        table.add_column("Instance ID", style="cyan")
        table.add_column("Template", style="dim")
        
        for d in deployments:
            table.add_row(d.instance_id, d.template)
        
        console.print(table)
        
        if dry_run:
            console.print("\n[yellow]Dry run - no deployments will be applied[/yellow]")
            return
        
        # Confirm
        if not confirm_action(f"\nDeploy all {len(deployments)} instances?", default=False):
            console.print("[yellow]Cancelled[/yellow]")
            return
        
        # Deploy each
        results = []
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            console=console,
        ) as progress:
            task = progress.add_task(
                f"Deploying {len(deployments)} instances...",
                total=len(deployments),
            )
            
            for deployment in deployments:
                instance_id = deployment.instance_id
                progress.update(task, description=f"Deploying {instance_id}...")
                
                try:
                    # Build ansible command
                    playbook = config.repo_root / "ansible" / "playbooks" / "docker-compose-deploy.yml"
                    
                    if not playbook.exists():
                        results.append({
                            "instance": instance_id,
                            "status": "error",
                            "message": "Playbook not found",
                        })
                        if not continue_on_error:
                            break
                        continue
                    
                    # Get target
                    if not deployment.targets:
                        results.append({
                            "instance": instance_id,
                            "status": "error",
                            "message": "No targets configured",
                        })
                        if not continue_on_error:
                            break
                        continue
                    
                    target = deployment.targets[0]
                    
                    # Run ansible
                    cmd = [
                        "ansible-playbook",
                        str(playbook),
                        "-i", str(config.repo_root / target.inventory),
                        "-e", f"deployment_path={deployment.deployment_path}",
                        "-e", f"instance_id={instance_id}",
                    ]
                    
                    if target.host_patterns:
                        cmd.extend(["-l", ",".join(target.host_patterns)])
                    
                    result = run_command(cmd, capture_output=True)
                    
                    if result.returncode == 0:
                        results.append({
                            "instance": instance_id,
                            "status": "success",
                            "message": "Deployed successfully",
                        })
                    else:
                        results.append({
                            "instance": instance_id,
                            "status": "error",
                            "message": f"Deploy failed (exit {result.returncode})",
                        })
                        if not continue_on_error:
                            break
                
                except Exception as e:
                    results.append({
                        "instance": instance_id,
                        "status": "error",
                        "message": str(e),
                    })
                    if not continue_on_error:
                        break
                
                progress.update(task, advance=1)
        
        # Show results
        console.print("\n[bold]Deployment Results:[/bold]\n")
        
        results_table = Table()
        results_table.add_column("Instance ID", style="cyan")
        results_table.add_column("Status", style="white")
        results_table.add_column("Message", style="dim")
        
        success_count = 0
        error_count = 0
        
        for result in results:
            status = result["status"]
            if status == "success":
                success_count += 1
                status_display = "[green]✓ SUCCESS[/green]"
            else:
                error_count += 1
                status_display = "[red]✗ ERROR[/red]"
            
            results_table.add_row(
                result["instance"],
                status_display,
                result["message"],
            )
        
        console.print(results_table)
        console.print(f"\n[bold]Summary:[/bold] {success_count} succeeded, {error_count} failed")
        
        if error_count > 0:
            raise click.Abort()
    
    except click.Abort:
        raise
    except Exception as e:
        console.print(f"[red]Error during bulk deployment: {e}[/red]")
        raise click.Abort()


@deploy.command()
@click.option(
    "--environment",
    "-e",
    help="Validate specific environment (default: all)",
)
@click.pass_context
def validate_all(
    ctx: click.Context,
    environment: Optional[str],
):
    """Validate all deployments.

    Examples:

        # Validate all deployments
        iac deploy validate-all

        # Validate specific environment
        iac deploy validate-all --environment production
    """
    config: Config = ctx.obj["config"]
    console: Console = ctx.obj["console"]
    
    from rich.table import Table
    
    try:
        deployments_dir = config.repo_root / config.deployments_dir
        
        if not deployments_dir.exists():
            console.print(f"[red]Deployments directory not found: {deployments_dir}[/red]")
            raise click.Abort()
        
        # Find deployments
        if environment:
            env_dir = deployments_dir / environment
            if not env_dir.exists():
                console.print(f"[red]Environment not found: {environment}[/red]")
                raise click.Abort()
            deployments = _find_deployments(env_dir)
        else:
            deployments = _find_deployments(deployments_dir)
        
        if not deployments:
            console.print("[yellow]No deployments found[/yellow]")
            return
        
        console.print(f"\n[bold]Validating {len(deployments)} deployments...[/bold]\n")
        
        # Validate each
        results = []
        
        for deployment in deployments:
            errors = _validate_deployment(deployment, config)
            
            results.append({
                "instance": deployment.instance_id,
                "environment": deployment.environment,
                "valid": len(errors) == 0,
                "errors": errors,
            })
        
        # Show results
        table = Table(title="Validation Results")
        table.add_column("Instance ID", style="cyan")
        table.add_column("Environment", style="yellow")
        table.add_column("Status", style="white")
        table.add_column("Issues", style="dim")
        
        valid_count = 0
        invalid_count = 0
        
        for result in results:
            if result["valid"]:
                valid_count += 1
                status = "[green]✓ VALID[/green]"
                issues = ""
            else:
                invalid_count += 1
                status = "[red]✗ INVALID[/red]"
                issues = f"{len(result['errors'])} errors"
            
            table.add_row(
                result["instance"],
                result["environment"],
                status,
                issues,
            )
        
        console.print(table)
        console.print(f"\n[bold]Summary:[/bold] {valid_count} valid, {invalid_count} invalid")
        
        # Show detailed errors for invalid deployments
        if invalid_count > 0:
            console.print("\n[bold red]Validation Errors:[/bold red]\n")
            for result in results:
                if not result["valid"]:
                    console.print(f"[cyan]{result['instance']}[/cyan]:")
                    for error in result["errors"]:
                        console.print(f"  • [red]{error}[/red]")
                    console.print()
    
    except click.Abort:
        raise
    except Exception as e:
        console.print(f"[red]Error during validation: {e}[/red]")
        raise click.Abort()


