"""Workspace status and overview commands."""

from pathlib import Path
from typing import Dict, List, Optional

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from iac_manager.cli.config import Config, get_current_git_branch, infer_environment_from_context
from iac_manager.cli.utils import console, load_yaml


@click.group()
def status() -> None:
    """📊 Show workspace status and overview.

    Quick overview of your IaC workspace including environments,
    deployments, templates, and git status.
    """
    pass


@status.command(name="overview")
@click.pass_context
def overview(ctx: click.Context) -> None:
    """Show complete workspace overview.

    Examples:

        iac status overview
    """
    config: Config = ctx.obj["config"]
    console: Console = ctx.obj["console"]

    console.print("\n[bold]🚀 IaC Workspace Overview[/bold]\n")

    # Repository info
    console.print(f"[bold]Repository:[/bold] {config.repo_root.name}")
    console.print(f"[bold]Location:[/bold] {config.repo_root}")

    # Git info
    branch = get_current_git_branch(config.repo_root)
    if branch:
        console.print(f"[bold]Git Branch:[/bold] {branch}")
        
        inferred_env = infer_environment_from_context(config)
        if inferred_env:
            console.print(f"[bold]Inferred Environment:[/bold] [cyan]{inferred_env}[/cyan]")
        else:
            console.print(f"[bold]Default Environment:[/bold] [dim]{config.default_environment}[/dim]")
    else:
        console.print(f"[bold]Default Environment:[/bold] {config.default_environment}")

    # Environments
    console.print("\n[bold]📁 Environments:[/bold]")
    env_stats = _get_environment_stats(config)
    
    env_table = Table(show_header=True, header_style="bold cyan", box=None)
    env_table.add_column("Environment")
    env_table.add_column("Deployments", justify="right")
    env_table.add_column("Inventory", justify="center")
    
    for env_name, stats in sorted(env_stats.items()):
        has_inventory = "✓" if stats["has_inventory"] else "✗"
        env_table.add_row(
            env_name,
            str(stats["deployments"]),
            f"[green]{has_inventory}[/green]" if stats["has_inventory"] else f"[dim]{has_inventory}[/dim]"
        )
    
    console.print(env_table)

    # Templates
    console.print("\n[bold]📦 Templates:[/bold]")
    template_stats = _get_template_stats(config)
    
    console.print(f"  Total: {template_stats['total']}")
    if template_stats['by_category']:
        for category, count in sorted(template_stats['by_category'].items()):
            console.print(f"  • {category}: {count}")

    # Recent deployments
    console.print("\n[bold]🚀 Recent Deployments:[/bold]")
    recent = _get_recent_deployments(config, limit=5)
    
    if recent:
        for deployment in recent:
            console.print(f"  • [cyan]{deployment['instance']}[/cyan] ({deployment['environment']}) - [dim]{deployment['template']}[/dim]")
    else:
        console.print("  [dim]No deployments found[/dim]")

    # Quick actions
    console.print("\n[bold]💡 Quick Actions:[/bold]")
    console.print("  [dim]iac template list[/dim]          - Browse templates")
    console.print("  [dim]iac deploy list[/dim]            - View all deployments")
    console.print("  [dim]iac deploy configure[/dim]       - Create new deployment")
    console.print("  [dim]iac inventory hosts[/dim]        - Check available hosts")
    console.print()


@status.command(name="quick")
@click.pass_context
def quick(ctx: click.Context) -> None:
    """Show quick status summary.

    Examples:

        iac status quick
    """
    config: Config = ctx.obj["config"]
    console: Console = ctx.obj["console"]

    # Get stats
    env_stats = _get_environment_stats(config)
    template_stats = _get_template_stats(config)
    
    total_deployments = sum(s["deployments"] for s in env_stats.values())
    
    # Git info
    branch = get_current_git_branch(config.repo_root)
    inferred_env = infer_environment_from_context(config) if branch else None
    
    # Build status message
    status_lines = []
    status_lines.append(f"[bold]Workspace:[/bold] {config.repo_root.name}")
    
    if branch:
        env_text = f"[cyan]{inferred_env}[/cyan]" if inferred_env else f"[dim]{config.default_environment}[/dim]"
        status_lines.append(f"[bold]Branch:[/bold] {branch} → {env_text}")
    
    status_lines.append(f"[bold]Environments:[/bold] {len(env_stats)}")
    status_lines.append(f"[bold]Deployments:[/bold] {total_deployments}")
    status_lines.append(f"[bold]Templates:[/bold] {template_stats['total']}")
    
    console.print(
        Panel(
            "\n".join(status_lines),
            title="🚀 IaC Status",
            border_style="cyan",
        )
    )


def _get_environment_stats(config: Config) -> Dict[str, Dict]:
    """Get statistics for each environment.
    
    Args:
        config: Configuration object
        
    Returns:
        Dict mapping environment name to stats
    """
    stats = {}
    
    env_dir = config.repo_root / config.environments_dir
    deployments_dir = config.repo_root / config.deployments_dir
    inventory_dir = config.repo_root / config.inventory_dir
    
    if not env_dir.exists():
        return stats
    
    for env_path in env_dir.iterdir():
        if not env_path.is_dir():
            continue
        
        env_name = env_path.name
        
        # Count deployments
        deployment_count = 0
        env_deployment_dir = deployments_dir / env_name
        if env_deployment_dir.exists():
            deployment_count = len([d for d in env_deployment_dir.iterdir() if d.is_dir()])
        
        # Check inventory
        has_inventory = (inventory_dir / env_name / "servers.yml").exists()
        
        stats[env_name] = {
            "deployments": deployment_count,
            "has_inventory": has_inventory,
        }
    
    return stats


def _get_template_stats(config: Config) -> Dict:
    """Get template statistics.
    
    Args:
        config: Configuration object
        
    Returns:
        Dict with template counts
    """
    catalog_dir = config.repo_root / config.catalog_dir
    
    if not catalog_dir.exists():
        return {"total": 0, "by_category": {}}
    
    categories = {}
    total = 0
    
    for category_path in catalog_dir.iterdir():
        if not category_path.is_dir() or category_path.name.startswith("_"):
            continue
        
        # Count templates in this category (look for manifest.yml files)
        template_count = len(list(category_path.rglob("manifest.yml")))
        
        if template_count > 0:
            categories[category_path.name] = template_count
            total += template_count
    
    return {
        "total": total,
        "by_category": categories,
    }


def _get_recent_deployments(config: Config, limit: int = 5) -> List[Dict]:
    """Get recently modified deployments.
    
    Args:
        config: Configuration object
        limit: Maximum number of deployments to return
        
    Returns:
        List of deployment info dicts
    """
    deployments = []
    deployments_dir = config.repo_root / config.deployments_dir
    
    if not deployments_dir.exists():
        return deployments
    
    # Find all deployment directories
    for env_dir in deployments_dir.iterdir():
        if not env_dir.is_dir():
            continue
        
        for deployment_dir in env_dir.iterdir():
            if not deployment_dir.is_dir():
                continue
            
            manifest_path = deployment_dir / "manifest.yml"
            if not manifest_path.exists():
                continue
            
            try:
                manifest = load_yaml(manifest_path)
                deployments.append({
                    "instance": manifest.get("instance_id", deployment_dir.name),
                    "environment": env_dir.name,
                    "template": manifest.get("template", "unknown"),
                    "modified": manifest_path.stat().st_mtime,
                })
            except Exception:
                continue
    
    # Sort by modification time and return most recent
    deployments.sort(key=lambda d: d["modified"], reverse=True)
    return deployments[:limit]
