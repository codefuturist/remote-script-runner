"""Convert command for transforming between deployment formats."""

from pathlib import Path
from typing import Optional

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from iac_manager.cli.config import Config
from iac_manager.cli.converters.kompose import KomposeConverter
from iac_manager.cli.converters.post_processor import ManifestPostProcessor
from iac_manager.cli.models import ConversionConfig
from iac_manager.converters import HelmToFluxConverter, FluxToHelmConverter
from iac_manager.services.preference_service import PreferenceService

console = Console()


@click.group()
def convert() -> None:
    """🔄 Convert between deployment formats.

    Transform Docker Compose files to Kubernetes manifests, and more.
    Uses industry-standard tools like kompose with intelligent enhancements.

    Examples:

        # Convert Docker Compose to Kubernetes
        iac convert compose-to-k8s -i docker-compose.yml -o ./k8s-manifests

        # Preview conversion without writing files
        iac convert compose-to-k8s -i docker-compose.yml --dry-run

        # Convert with custom namespace and storage
        iac convert compose-to-k8s -i docker-compose.yml -o ./k8s \\
          --namespace production --storage-class gp3
    """
    pass


@convert.command("compose-to-k8s")
@click.option(
    "--input",
    "-i",
    "input_file",
    type=click.Path(exists=True, dir_okay=False, path_type=Path),
    required=True,
    help="Docker Compose file to convert",
)
@click.option(
    "--output",
    "-o",
    "output_dir",
    type=click.Path(file_okay=False, path_type=Path),
    required=True,
    help="Output directory for Kubernetes manifests",
)
@click.option(
    "--namespace",
    "-n",
    default="default",
    help="Kubernetes namespace [default: default]",
)
@click.option(
    "--storage-class",
    help="Storage class for PersistentVolumeClaims",
)
@click.option(
    "--generate-pvc/--no-generate-pvc",
    default=True,
    help="Generate PersistentVolumeClaim resources [default: true]",
)
@click.option(
    "--dry-run",
    is_flag=True,
    help="Show what would be generated without creating files",
)
@click.option(
    "--validate/--no-validate",
    default=True,
    help="Validate manifests after generation [default: true]",
)
@click.pass_context
def compose_to_k8s(
    ctx: click.Context,
    input_file: Path,
    output_dir: Path,
    namespace: str,
    storage_class: Optional[str],
    generate_pvc: bool,
    dry_run: bool,
    validate: bool,
) -> None:
    """Convert Docker Compose file to Kubernetes manifests.

    This command uses kompose to convert your Docker Compose file into
    Kubernetes manifests, with intelligent post-processing to add
    production-ready features.

    Examples:

        # Basic conversion
        iac convert compose-to-k8s \\
          -i docker-compose.yml \\
          -o ./k8s-manifests

        # Production deployment
        iac convert compose-to-k8s \\
          -i docker-compose.yml \\
          -o ./k8s-production \\
          --namespace production \\
          --storage-class gp3 \\
          --validate

        # Preview without creating files
        iac convert compose-to-k8s \\
          -i docker-compose.yml \\
          -o /tmp/preview \\
          --dry-run
    """
    config: Config = ctx.obj["config"]

    # Display header
    console.print(
        Panel.fit(
            "[bold cyan]🔄 Docker Compose → Kubernetes Conversion[/bold cyan]\n\n"
            f"Input:     {input_file}\n"
            f"Output:    {output_dir}\n"
            f"Namespace: {namespace}",
            border_style="cyan",
        )
    )

    # Initialize converter
    converter = KomposeConverter()

    # Check if kompose is installed
    if not converter.is_installed():
        converter.print_installation_instructions()
        ctx.exit(1)

    # Show version
    version = converter.get_version()
    if version:
        console.print(f"\n[dim]Using kompose version {version}[/dim]")

    # Validate compose file
    console.print("\n[bold]Step 1: Validating Docker Compose file[/bold]")
    if not converter.validate_compose_file(input_file):
        console.print("[red]✗[/red] Docker Compose file validation failed")
        ctx.exit(1)
    console.print("[green]✓[/green] Docker Compose file is valid")

    if dry_run:
        console.print("\n[yellow]Dry-run mode: No files will be created[/yellow]")
        # In dry-run, we'd normally analyze and preview
        console.print("\n[dim]Would generate Kubernetes manifests in: {output_dir}[/dim]")
        return

    # Convert
    console.print("\n[bold]Step 2: Converting to Kubernetes manifests[/bold]")
    try:
        manifests = converter.convert(
            compose_file=input_file,
            output_dir=output_dir,
            namespace=namespace,
            generate_pvc=generate_pvc,
        )

        # Post-process manifests for production readiness
        console.print("\n[bold]Step 3: Adding production enhancements[/bold]")
        conversion_config = ConversionConfig(
            namespace=namespace,
            storage_class=storage_class,
        )
        post_processor = ManifestPostProcessor(conversion_config)
        post_processor.process_all(manifests)

        # Display results
        console.print("\n[bold]✓ Conversion Complete![/bold]\n")

        table = Table(title="Generated Kubernetes Resources")
        table.add_column("Resource Type", style="cyan")
        table.add_column("Count", justify="right", style="green")
        table.add_column("Files", style="dim")

        for resource_type, files in manifests.items():
            if files:
                file_names = ", ".join([f.name for f in files])
                table.add_row(resource_type.title(), str(len(files)), file_names)

        console.print(table)

        # Show next steps
        console.print("\n[bold cyan]Next Steps:[/bold cyan]")
        console.print(f"1. Review manifests: [cyan]cd {output_dir}[/cyan]")
        console.print(f"2. Update secrets: [cyan]kubectl create secret -n {namespace} ...[/cyan]")
        if validate:
            console.print(f"3. Validate: [cyan]kubectl apply --dry-run=client -f {output_dir}[/cyan]")
        console.print(f"4. Deploy: [cyan]kubectl apply -n {namespace} -f {output_dir}[/cyan]")
        console.print(f"5. Monitor: [cyan]kubectl get pods -n {namespace} -w[/cyan]")

        # Validation step
        if validate:
            console.print("\n[bold]Step 4: Validating Kubernetes manifests[/bold]")
            console.print("[yellow]⚠[/yellow] Validation requires kubectl and cluster access")
            console.print(f"[dim]Run: kubectl apply --dry-run=client -f {output_dir}[/dim]")

    except RuntimeError as e:
        console.print(f"\n[red]✗ Conversion failed:[/red] {e}")
        ctx.exit(1)
    except Exception as e:
        console.print(f"\n[red]✗ Unexpected error:[/red] {e}")
        if ctx.obj.get("verbose", 0) > 0:
            import traceback

            console.print(f"\n[dim]{traceback.format_exc()}[/dim]")
        ctx.exit(1)


# Register convert group to main CLI
def register_convert_command(main_cli: click.Group) -> None:
    """Register convert command group with main CLI.

    Args:
        main_cli: Main Click group to register with
    """
    main_cli.add_command(convert)


@convert.command("helm-to-flux")
@click.option(
    "--chart",
    "-c",
    required=True,
    help="Chart name (e.g., 'bitnami/postgresql' or 'postgresql')",
)
@click.option(
    "--release-name",
    "-r",
    required=True,
    help="Helm release name",
)
@click.option(
    "--namespace",
    "-n",
    default="default",
    help="Kubernetes namespace [default: default]",
)
@click.option(
    "--repo",
    help="Helm repository URL",
)
@click.option(
    "--version",
    "-v",
    help="Chart version",
)
@click.option(
    "--values",
    "-f",
    "values_file",
    type=click.Path(exists=True, path_type=Path),
    help="Values file to include",
)
@click.option(
    "--output",
    "-o",
    "output_dir",
    type=click.Path(file_okay=False, path_type=Path),
    required=True,
    help="Output directory for FluxCD manifests",
)
@click.option(
    "--oci",
    is_flag=True,
    help="Chart is from OCI registry",
)
@click.option(
    "--apply-preferences/--no-apply-preferences",
    default=True,
    help="Apply preference profile after conversion",
)
@click.option(
    "--profile",
    "-p",
    default="default",
    help="Preference profile to apply [default: default]",
)
@click.option(
    "--environment",
    "-e",
    help="Environment (production/staging/development)",
)
@click.pass_context
def helm_to_flux(
    ctx: click.Context,
    chart: str,
    release_name: str,
    namespace: str,
    repo: Optional[str],
    version: Optional[str],
    values_file: Optional[Path],
    output_dir: Path,
    oci: bool,
    apply_preferences: bool,
    profile: str,
    environment: Optional[str],
) -> None:
    """Convert Helm chart to FluxCD HelmRelease manifest.

    Examples:

        # Convert bitnami/postgresql chart
        iac convert helm-to-flux \\
          --chart bitnami/postgresql \\
          --release-name my-postgres \\
          --namespace database \\
          --repo https://charts.bitnami.com/bitnami \\
          --version 13.2.0 \\
          --output ./flux-manifests

        # Convert with values file and apply preferences
        iac convert helm-to-flux \\
          -c n8n/n8n \\
          -r n8n \\
          -n automation \\
          --repo https://riatlas.github.io/chart__n8n \\
          -f custom-values.yaml \\
          -o ./flux-manifests \\
          -p default \\
          -e production

        # Convert OCI chart
        iac convert helm-to-flux \\
          -c oci://registry-1.docker.io/bitnamicharts/postgresql \\
          -r postgres \\
          -n database \\
          -o ./flux-manifests \\
          --oci
    """
    config: Config = ctx.obj["config"]

    console.print(
        Panel.fit(
            "[bold cyan]🔄 Helm → FluxCD Conversion[/bold cyan]\n\n"
            f"Chart:     {chart}\n"
            f"Release:   {release_name}\n"
            f"Namespace: {namespace}\n"
            f"Output:    {output_dir}",
            border_style="cyan",
        )
    )

    try:
        # Initialize converter
        converter = HelmToFluxConverter()

        console.print("\n[bold]Step 1: Generating FluxCD manifests[/bold]")

        # Convert to FluxCD manifest
        helm_release = converter.convert(
            chart=chart,
            release_name=release_name,
            namespace=namespace,
            repo_url=repo,
            version=version,
            values_file=values_file,
            oci=oci,
        )

        # Generate HelmRepository if repo URL provided
        helm_repo = None
        if repo:
            repo_name, _ = converter._parse_chart_reference(chart, oci)
            helm_repo = converter.generate_helm_repository(
                name=repo_name,
                url=repo,
                oci=oci,
            )

        console.print("[green]✓[/green] FluxCD manifests generated")

        # Apply preferences if requested
        if apply_preferences and environment:
            console.print(f"\n[bold]Step 2: Applying preferences (profile: {profile}, env: {environment})[/bold]")
            
            # Save temporary HelmRelease to apply preferences
            temp_file = output_dir / "temp-helmrelease.yaml"
            temp_file.parent.mkdir(parents=True, exist_ok=True)
            
            from ruamel.yaml import YAML
            yaml = YAML()
            yaml.preserve_quotes = True
            with open(temp_file, "w") as f:
                yaml.dump(helm_release, f)

            # Apply preferences
            preferences_dir = config.repo_root / "iac-manager" / "config" / "preferences"
            if preferences_dir.exists():
                service = PreferenceService(preferences_dir)
                pref_profile = service.load_profile(profile)
                result = service.apply_preferences(
                    file_path=temp_file,
                    profile=pref_profile,
                    environment=environment,
                    resource_type="HelmRelease",
                    dry_run=False,
                    create_backup=False,
                )
                
                # Reload the modified manifest
                with open(temp_file) as f:
                    helm_release = yaml.load(f)
                
                temp_file.unlink()  # Clean up temp file
                
                console.print(f"[green]✓[/green] Applied {result.rules_applied} preference rules")
            else:
                console.print("[yellow]⚠[/yellow] Preferences directory not found, skipping")

        # Save manifests
        console.print(f"\n[bold]Step 3: Saving manifests[/bold]")
        created_files = converter.save_manifests(
            output_dir=output_dir,
            helm_release=helm_release,
            helm_repository=helm_repo,
            filename_prefix=release_name,
        )

        console.print(f"[green]✓[/green] Saved {len(created_files)} manifest(s)")

        # Display results
        console.print("\n[bold]✓ Conversion Complete![/bold]\n")

        table = Table(title="Generated FluxCD Manifests")
        table.add_column("File", style="cyan")
        table.add_column("Type", style="green")

        for file_path in created_files:
            file_type = "HelmRelease" if "helmrelease" in file_path.name else "HelmRepository"
            table.add_row(file_path.name, file_type)

        console.print(table)

        # Show next steps
        console.print("\n[bold cyan]Next Steps:[/bold cyan]")
        console.print(f"1. Review manifests: [cyan]ls {output_dir}[/cyan]")
        console.print(f"2. Apply to cluster: [cyan]kubectl apply -f {output_dir}[/cyan]")
        console.print(f"3. Check status: [cyan]flux get helmreleases -n {namespace}[/cyan]")
        console.print(f"4. View logs: [cyan]flux logs -n {namespace}[/cyan]")

    except Exception as e:
        console.print(f"\n[red]✗ Conversion failed:[/red] {e}")
        if ctx.obj.get("verbose", 0) > 0:
            import traceback
            console.print(f"\n[dim]{traceback.format_exc()}[/dim]")
        ctx.exit(1)


@convert.command("flux-to-helm")
@click.option(
    "--input",
    "-i",
    "input_file",
    type=click.Path(exists=True, dir_okay=False, path_type=Path),
    required=True,
    help="HelmRelease YAML file to convert",
)
@click.option(
    "--output",
    "-o",
    "output_dir",
    type=click.Path(file_okay=False, path_type=Path),
    required=True,
    help="Output directory for helm commands and values",
)
@click.option(
    "--repository",
    "repo_file",
    type=click.Path(exists=True, path_type=Path),
    help="HelmRepository YAML file (optional)",
)
@click.option(
    "--generate-script/--no-generate-script",
    default=True,
    help="Generate executable deployment script [default: true]",
)
@click.option(
    "--command-type",
    type=click.Choice(["install", "upgrade"]),
    default="upgrade",
    help="Type of helm command to generate [default: upgrade]",
)
@click.pass_context
def flux_to_helm(
    ctx: click.Context,
    input_file: Path,
    output_dir: Path,
    repo_file: Optional[Path],
    generate_script: bool,
    command_type: str,
) -> None:
    """Convert FluxCD HelmRelease to Helm CLI commands.

    Examples:

        # Convert HelmRelease to helm command
        iac convert flux-to-helm \\
          --input postgresql-helmrelease.yaml \\
          --output ./helm-commands

        # Convert with HelmRepository and generate script
        iac convert flux-to-helm \\
          -i n8n-helmrelease.yaml \\
          -o ./helm-commands \\
          --repository n8n-helmrepository.yaml \\
          --generate-script

        # Generate helm install command (instead of upgrade)
        iac convert flux-to-helm \\
          -i app-helmrelease.yaml \\
          -o ./helm-commands \\
          --command-type install
    """
    console.print(
        Panel.fit(
            "[bold cyan]🔄 FluxCD → Helm Conversion[/bold cyan]\n\n"
            f"Input:  {input_file}\n"
            f"Output: {output_dir}",
            border_style="cyan",
        )
    )

    try:
        # Initialize converter
        converter = FluxToHelmConverter()

        console.print("\n[bold]Step 1: Converting HelmRelease to Helm command[/bold]")

        # Convert based on command type
        if command_type == "upgrade":
            helm_cmd, values_path = converter.convert_to_upgrade(
                helmrelease_file=input_file,
                extract_values=True,
                values_output=output_dir / f"{input_file.stem}-values.yaml",
            )
        else:
            helm_cmd, values_path = converter.convert(
                helmrelease_file=input_file,
                extract_values=True,
                values_output=output_dir / f"{input_file.stem}-values.yaml",
            )

        console.print("[green]✓[/green] Helm command generated")

        # Save command to file
        output_dir.mkdir(parents=True, exist_ok=True)
        cmd_file = output_dir / f"{input_file.stem}-command.sh"
        cmd_file.write_text(f"#!/bin/bash\n\n{helm_cmd}\n")
        cmd_file.chmod(0o755)

        console.print(f"[green]✓[/green] Command saved to: {cmd_file}")

        # Generate deployment script if requested
        script_path = None
        if generate_script:
            console.print("\n[bold]Step 2: Generating deployment script[/bold]")
            script_path = converter.generate_script(
                helmrelease_file=input_file,
                helmrepository_file=repo_file,
                output_file=output_dir / f"deploy-{input_file.stem}.sh",
            )
            console.print(f"[green]✓[/green] Script generated: {script_path}")

        # Display results
        console.print("\n[bold]✓ Conversion Complete![/bold]\n")

        console.print("[bold]Helm Command:[/bold]")
        console.print(f"[dim]{helm_cmd}[/dim]\n")

        table = Table(title="Generated Files")
        table.add_column("File", style="cyan")
        table.add_column("Description", style="white")

        table.add_row(cmd_file.name, "Helm command")
        if values_path:
            table.add_row(values_path.name, "Chart values")
        if script_path:
            table.add_row(script_path.name, "Deployment script")

        console.print(table)

        # Show next steps
        console.print("\n[bold cyan]Next Steps:[/bold cyan]")
        if script_path:
            console.print(f"1. Run script: [cyan]{script_path}[/cyan]")
        else:
            console.print(f"1. Run command: [cyan]{cmd_file}[/cyan]")
        console.print(f"2. Or copy-paste the helm command above")

    except Exception as e:
        console.print(f"\n[red]✗ Conversion failed:[/red] {e}")
        if ctx.obj.get("verbose", 0) > 0:
            import traceback
            console.print(f"\n[dim]{traceback.format_exc()}[/dim]")
        ctx.exit(1)

