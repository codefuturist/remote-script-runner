"""GitOps schemas."""

from datetime import datetime
from enum import Enum

from pydantic import Field

from iac_manager.web.schemas.common import BaseSchema


class FileStatus(str, Enum):
    """Git file status."""

    MODIFIED = "modified"
    ADDED = "added"
    DELETED = "deleted"
    RENAMED = "renamed"
    COPIED = "copied"
    UNTRACKED = "untracked"
    IGNORED = "ignored"


class FileChange(BaseSchema):
    """Information about a changed file."""

    path: str
    status: FileStatus
    staged: bool
    diff: str | None = None  # Optional diff content


class GitStatusResponse(BaseSchema):
    """Git repository status."""

    branch: str
    is_clean: bool
    ahead: int = 0  # Commits ahead of remote
    behind: int = 0  # Commits behind remote
    staged: list[FileChange]
    unstaged: list[FileChange]
    untracked: list[str]
    has_conflicts: bool = False


class GitCommitRequest(BaseSchema):
    """Request to commit changes."""

    message: str = Field(min_length=1, max_length=500)
    files: list[str] | None = Field(
        None,
        description="Specific files to commit. If None, commits all staged files.",
    )
    amend: bool = Field(
        default=False,
        description="Amend the previous commit",
    )


class GitCommitResponse(BaseSchema):
    """Response after committing."""

    success: bool
    commit_hash: str | None = None
    message: str


class GitPushRequest(BaseSchema):
    """Request to push changes."""

    remote: str = "origin"
    branch: str | None = Field(
        None,
        description="Branch to push. If None, pushes current branch.",
    )
    force: bool = False
    set_upstream: bool = False


class GitPushResponse(BaseSchema):
    """Response after pushing."""

    success: bool
    message: str
    commits_pushed: int = 0


class GitPullRequest(BaseSchema):
    """Request to pull changes."""

    remote: str = "origin"
    branch: str | None = None
    rebase: bool = False


class GitPullResponse(BaseSchema):
    """Response after pulling."""

    success: bool
    message: str
    commits_pulled: int = 0
    conflicts: list[str] | None = None


class GitStageRequest(BaseSchema):
    """Request to stage files."""

    files: list[str] = Field(min_length=1)


class GitUnstageRequest(BaseSchema):
    """Request to unstage files."""

    files: list[str] = Field(min_length=1)


class GitLogEntry(BaseSchema):
    """Git log entry."""

    hash: str
    short_hash: str
    author: str
    author_email: str
    date: datetime
    message: str


class GitLogResponse(BaseSchema):
    """Git log response."""

    entries: list[GitLogEntry]
    has_more: bool
