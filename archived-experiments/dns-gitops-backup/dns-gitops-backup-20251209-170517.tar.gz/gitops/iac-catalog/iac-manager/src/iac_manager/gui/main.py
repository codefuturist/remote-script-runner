"""Main entry point for IaC GUI application using QML."""

import sys
import os
from pathlib import Path

from PyQt6.QtWidgets import QApplication
from PyQt6.QtQml import QQmlApplicationEngine
from PyQt6.QtCore import QUrl

from iac_manager.config import load_config
from iac_manager.services import (
    DeploymentService,
    GitOpsService,
    TemplateService,
    InventoryService,
    SecretsService,
)
from iac_manager.gui.backend import (
    DeploymentBackend,
    GitOpsBackend,
    TemplateBackend,
    InventoryBackend,
    SecretsBackend,
)


def main() -> int:
    """Main application entry point.

    Returns:
        Exit code
    """
    # Set Qt Quick Controls style to Basic for full customization support
    # Must be set before creating QApplication
    os.environ["QT_QUICK_CONTROLS_STYLE"] = "Basic"
    
    # Use QApplication instead of QGuiApplication to support both QML and Widgets
    # This allows opening widget-based dialogs (like DeployWizard) from QML
    app = QApplication(sys.argv)
    app.setApplicationName("IaC Manager")
    app.setOrganizationName("codefuturist")
    app.setOrganizationDomain("github.com/codefuturist")

    try:
        # Load configuration
        config = load_config()

        # Create services
        deployment_service = DeploymentService(config)
        gitops_service = GitOpsService(config)
        template_service = TemplateService(config)
        inventory_service = InventoryService(config)
        secrets_service = SecretsService(config)

        # Create QML engine
        engine = QQmlApplicationEngine()

        # Add import paths for QML modules
        qml_dir = Path(__file__).parent / "qml"
        engine.addImportPath(str(qml_dir))
        
        # Create backend instances
        deployment_backend = DeploymentBackend(config, deployment_service)
        gitops_backend = GitOpsBackend(config, gitops_service)
        template_backend = TemplateBackend(config, template_service)
        inventory_backend = InventoryBackend(config, inventory_service)
        secrets_backend = SecretsBackend(config, secrets_service)

        # Expose backends to QML
        context = engine.rootContext()
        context.setContextProperty("deploymentBackend", deployment_backend)
        context.setContextProperty("gitopsBackend", gitops_backend)
        context.setContextProperty("templateBackend", template_backend)
        context.setContextProperty("inventoryBackend", inventory_backend)
        context.setContextProperty("secretsBackend", secrets_backend)

        # Load main QML file
        qml_file = qml_dir / "main.qml"
        if not qml_file.exists():
            print(f"Error: QML file not found: {qml_file}", file=sys.stderr)
            return 1
            
        engine.load(QUrl.fromLocalFile(str(qml_file)))

        # Check if QML loaded successfully
        if not engine.rootObjects():
            print("Error: Failed to load QML file - check QML syntax", file=sys.stderr)
            return 1

        # Initialize backends after QML is loaded
        deployment_backend.refresh()
        gitops_backend.refresh()
        template_backend.refresh()
        inventory_backend.refresh()
        secrets_backend.refresh()

        return app.exec()

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
