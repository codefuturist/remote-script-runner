"""API schemas - Pydantic models for request/response validation."""

from iac_manager.web.schemas.auth import (
    LoginRequest,
    RegisterRequest,
    TokenResponse,
    UserResponse,
    UserUpdate,
)
from iac_manager.web.schemas.deployments import (
    DeploymentCreate,
    DeploymentResponse,
    DeploymentList,
)
from iac_manager.web.schemas.templates import (
    TemplateResponse,
    TemplateList,
    TemplateParams,
)
from iac_manager.web.schemas.gitops import (
    GitStatusResponse,
    GitCommitRequest,
    GitPushRequest,
)
from iac_manager.web.schemas.inventory import (
    HostCreate,
    HostResponse,
    GroupCreate,
    GroupResponse,
)

__all__ = [
    # Auth
    "LoginRequest",
    "RegisterRequest",
    "TokenResponse",
    "UserResponse",
    "UserUpdate",
    # Deployments
    "DeploymentCreate",
    "DeploymentResponse",
    "DeploymentList",
    # Templates
    "TemplateResponse",
    "TemplateList",
    "TemplateParams",
    # GitOps
    "GitStatusResponse",
    "GitCommitRequest",
    "GitPushRequest",
    # Inventory
    "HostCreate",
    "HostResponse",
    "GroupCreate",
    "GroupResponse",
]
