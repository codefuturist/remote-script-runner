// LoadingSpinner.qml - Modern loading indicator
import QtQuick
import "../theme"

Item {
    id: root
    
    property int size: Theme.iconSizeLarge
    property color color: Theme.primary
    property int lineWidth: 3
    property string spinnerType: "circular" // circular, dots, pulse
    
    width: size
    height: size
    
    // Circular spinner
    Rectangle {
        id: circularSpinner
        visible: spinnerType === "circular"
        anchors.centerIn: parent
        width: root.size
        height: root.size
        radius: root.size / 2
        color: "transparent"
        border.width: root.lineWidth
        border.color: Theme.gray300
        
        Rectangle {
            anchors.top: parent.top
            anchors.horizontalCenter: parent.horizontalCenter
            width: parent.border.width
            height: parent.height / 3
            radius: width / 2
            color: root.color
        }
        
        RotationAnimation on rotation {
            from: 0
            to: 360
            duration: 1000
            loops: Animation.Infinite
            running: visible
            easing.type: Easing.Linear
        }
    }
    
    // Dots spinner
    Row {
        id: dotsSpinner
        visible: spinnerType === "dots"
        anchors.centerIn: parent
        spacing: root.size / 6
        
        Repeater {
            model: 3
            
            Rectangle {
                width: root.size / 5
                height: width
                radius: width / 2
                color: root.color
                
                SequentialAnimation on opacity {
                    loops: Animation.Infinite
                    running: dotsSpinner.visible
                    
                    PauseAnimation { duration: index * 200 }
                    NumberAnimation { to: 0.3; duration: 400 }
                    NumberAnimation { to: 1.0; duration: 400 }
                    PauseAnimation { duration: (2 - index) * 200 }
                }
                
                SequentialAnimation on scale {
                    loops: Animation.Infinite
                    running: dotsSpinner.visible
                    
                    PauseAnimation { duration: index * 200 }
                    NumberAnimation { to: 0.7; duration: 400 }
                    NumberAnimation { to: 1.0; duration: 400 }
                    PauseAnimation { duration: (2 - index) * 200 }
                }
            }
        }
    }
    
    // Pulse spinner
    Item {
        id: pulseSpinner
        visible: spinnerType === "pulse"
        anchors.centerIn: parent
        width: root.size
        height: root.size
        
        Repeater {
            model: 2
            
            Rectangle {
                anchors.centerIn: parent
                width: root.size
                height: root.size
                radius: root.size / 2
                color: "transparent"
                border.width: root.lineWidth
                border.color: root.color
                opacity: 0
                
                SequentialAnimation on opacity {
                    loops: Animation.Infinite
                    running: pulseSpinner.visible
                    
                    PauseAnimation { duration: index * 600 }
                    NumberAnimation { to: 1.0; duration: 0 }
                    NumberAnimation { to: 0; duration: 1200 }
                }
                
                SequentialAnimation on scale {
                    loops: Animation.Infinite
                    running: pulseSpinner.visible
                    
                    PauseAnimation { duration: index * 600 }
                    PropertyAnimation { to: 0; duration: 0 }
                    PropertyAnimation { to: 1.2; duration: 1200; easing.type: Easing.OutCubic }
                }
            }
        }
    }
}
