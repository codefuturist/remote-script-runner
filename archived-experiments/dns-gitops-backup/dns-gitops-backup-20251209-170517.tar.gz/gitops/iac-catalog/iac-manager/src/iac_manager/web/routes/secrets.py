"""Secrets management routes."""

import secrets as py_secrets
import string
import math
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, status

from iac_manager.web.auth.dependencies import ActiveUser
from iac_manager.web.schemas.common import MessageResponse
from iac_manager.web.schemas.secrets import (
    PasswordGenerateRequest,
    PasswordGenerateResponse,
    SecretCreate,
    SecretList,
    SecretResponse,
    SopsDecryptRequest,
    SopsDecryptResponse,
    SopsEncryptRequest,
    SopsEncryptResponse,
)
from iac_manager.web.services import ServiceProvider, get_services

router = APIRouter()


@router.get("", response_model=SecretList)
async def list_secrets(
    current_user: ActiveUser,
    services: Annotated[ServiceProvider, Depends(get_services)],
    environment: str | None = None,
) -> SecretList:
    """List all secrets (metadata only, values are not returned)."""
    secrets_list = await services.secrets.list_secrets(environment=environment)

    return SecretList(
        secrets=[
            SecretResponse(
                key=s.get("key", ""),
                secret_type=s.get("type", "generic"),
                description=s.get("description"),
                environment=s.get("environment"),
                encrypted=s.get("encrypted", True),
            )
            for s in secrets_list
        ],
        total=len(secrets_list),
    )


@router.post("", response_model=SecretResponse, status_code=status.HTTP_201_CREATED)
async def create_secret(
    data: SecretCreate,
    current_user: ActiveUser,
    services: Annotated[ServiceProvider, Depends(get_services)],
) -> SecretResponse:
    """Create or update a secret."""
    try:
        await services.secrets.set_secret(
            key=data.key,
            value=data.value,
            secret_type=data.secret_type.value,
            description=data.description,
            environment=data.environment,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )

    return SecretResponse(
        key=data.key,
        secret_type=data.secret_type,
        description=data.description,
        environment=data.environment,
        encrypted=True,
    )


@router.delete("/{secret_key}", response_model=MessageResponse)
async def delete_secret(
    secret_key: str,
    current_user: ActiveUser,
    services: Annotated[ServiceProvider, Depends(get_services)],
    environment: str | None = None,
) -> MessageResponse:
    """Delete a secret."""
    try:
        await services.secrets.delete_secret(
            key=secret_key,
            environment=environment,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )

    return MessageResponse(message=f"Secret {secret_key} deleted successfully")


@router.post("/generate-password", response_model=PasswordGenerateResponse)
async def generate_password(
    data: PasswordGenerateRequest,
    current_user: ActiveUser,
) -> PasswordGenerateResponse:
    """Generate a secure random password."""
    # Build character set
    chars = ""
    char_classes = 0

    if data.include_lowercase:
        chars += string.ascii_lowercase
        char_classes += 1
    if data.include_uppercase:
        chars += string.ascii_uppercase
        char_classes += 1
    if data.include_digits:
        chars += string.digits
        char_classes += 1
    if data.include_special:
        chars += "!@#$%^&*()-_=+[]{}|;:,.<>?"
        char_classes += 1

    # Remove ambiguous characters if requested
    if data.exclude_ambiguous:
        ambiguous = "O0l1I|"
        chars = "".join(c for c in chars if c not in ambiguous)

    if not chars:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="At least one character type must be included",
        )

    # Generate password
    password = "".join(py_secrets.choice(chars) for _ in range(data.length))

    # Calculate entropy
    entropy_bits = data.length * math.log2(len(chars))

    return PasswordGenerateResponse(
        password=password,
        entropy_bits=round(entropy_bits, 2),
    )


@router.post("/sops/encrypt", response_model=SopsEncryptResponse)
async def sops_encrypt(
    data: SopsEncryptRequest,
    current_user: ActiveUser,
    services: Annotated[ServiceProvider, Depends(get_services)],
) -> SopsEncryptResponse:
    """Encrypt content using SOPS."""
    try:
        encrypted = await services.secrets.sops_encrypt(
            content=data.content,
            format=data.format,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"SOPS encryption failed: {e}",
        )

    return SopsEncryptResponse(
        encrypted_content=encrypted,
        format=data.format,
    )


@router.post("/sops/decrypt", response_model=SopsDecryptResponse)
async def sops_decrypt(
    data: SopsDecryptRequest,
    current_user: ActiveUser,
    services: Annotated[ServiceProvider, Depends(get_services)],
) -> SopsDecryptResponse:
    """Decrypt content using SOPS."""
    try:
        decrypted, format_detected = await services.secrets.sops_decrypt(
            encrypted_content=data.encrypted_content,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"SOPS decryption failed: {e}",
        )

    return SopsDecryptResponse(
        content=decrypted,
        format=format_detected,
    )
