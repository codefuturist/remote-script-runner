// Theme.qml - Application theme and styling
pragma Singleton
import QtQuick

QtObject {
    // Theme mode
    property bool darkMode: false
    
    // ============================================================================
    // COLOR PALETTE - Modern Design System
    // ============================================================================
    
    // Primary Colors (Modern Blue)
    readonly property color primary: darkMode ? "#60A5FA" : "#3B82F6"
    readonly property color primaryLight: darkMode ? "#93C5FD" : "#60A5FA"
    readonly property color primaryDark: darkMode ? "#3B82F6" : "#2563EB"
    readonly property color primaryHover: darkMode ? "#93C5FD" : "#2563EB"
    
    // Accent Colors (Purple)
    readonly property color accent: darkMode ? "#A78BFA" : "#8B5CF6"
    readonly property color accentLight: darkMode ? "#C4B5FD" : "#A78BFA"
    readonly property color accentDark: darkMode ? "#8B5CF6" : "#7C3AED"
    
    // Semantic Colors
    readonly property color success: darkMode ? "#34D399" : "#10B981"
    readonly property color successLight: darkMode ? "#6EE7B7" : "#34D399"
    readonly property color successDark: darkMode ? "#059669" : "#047857"
    readonly property color successColorLight: darkMode ? "#D1FAE5" : "#D1FAE5"
    readonly property color successColorDark: darkMode ? "#065F46" : "#065F46"
    
    readonly property color warning: darkMode ? "#FBBF24" : "#F59E0B"
    readonly property color warningLight: darkMode ? "#FCD34D" : "#FBBF24"
    
    readonly property color error: darkMode ? "#F87171" : "#EF4444"
    readonly property color errorLight: darkMode ? "#FCA5A5" : "#F87171"
    
    readonly property color info: darkMode ? "#22D3EE" : "#06B6D4"
    readonly property color infoLight: darkMode ? "#67E8F9" : "#22D3EE"
    
    // Gray Scale (Neutral)
    readonly property color gray50: darkMode ? "#1F2937" : "#F9FAFB"
    readonly property color gray100: darkMode ? "#374151" : "#F3F4F6"
    readonly property color gray200: darkMode ? "#4B5563" : "#E5E7EB"
    readonly property color gray300: darkMode ? "#6B7280" : "#D1D5DB"
    readonly property color gray400: darkMode ? "#9CA3AF" : "#9CA3AF"
    readonly property color gray500: darkMode ? "#D1D5DB" : "#6B7280"
    readonly property color gray600: darkMode ? "#E5E7EB" : "#4B5563"
    readonly property color gray700: darkMode ? "#F3F4F6" : "#374151"
    readonly property color gray800: darkMode ? "#F9FAFB" : "#1F2937"
    readonly property color gray900: darkMode ? "#FFFFFF" : "#111827"
    
    // Semantic UI Colors
    readonly property color backgroundColor: darkMode ? "#111827" : "#F9FAFB"
    readonly property color surfaceColor: darkMode ? "#1F2937" : "#FFFFFF"
    readonly property color surfaceElevated: darkMode ? "#374151" : "#FFFFFF"
    readonly property color overlayColor: darkMode ? "#00000099" : "#00000066"
    
    readonly property color textPrimary: darkMode ? "#F9FAFB" : "#111827"
    readonly property color textSecondary: darkMode ? "#D1D5DB" : "#6B7280"
    readonly property color textTertiary: darkMode ? "#9CA3AF" : "#9CA3AF"
    readonly property color textDisabled: darkMode ? "#6B7280" : "#D1D5DB"
    
    readonly property color borderColor: darkMode ? "#374151" : "#E5E7EB"
    readonly property color borderColorLight: darkMode ? "#4B5563" : "#F3F4F6"
    readonly property color dividerColor: darkMode ? "#374151" : "#E5E7EB"
    readonly property color focusRing: darkMode ? "#60A5FA" : "#3B82F6"
    
    // Environment Colors (Enhanced)
    readonly property color productionColor: darkMode ? "#7F1D1D" : "#FEE2E2"
    readonly property color productionBadge: darkMode ? "#EF4444" : "#DC2626"
    readonly property color stagingColor: darkMode ? "#854D0E" : "#FEF3C7"
    readonly property color stagingBadge: darkMode ? "#F59E0B" : "#D97706"
    readonly property color developmentColor: darkMode ? "#065F46" : "#D1FAE5"
    readonly property color developmentBadge: darkMode ? "#10B981" : "#059669"
    readonly property color drSiteColor: darkMode ? "#3730A3" : "#E0E7FF"
    readonly property color drSiteBadge: darkMode ? "#8B5CF6" : "#7C3AED"
    
    // Legacy color mappings (for backward compatibility)
    readonly property color primaryColor: primary
    readonly property color secondaryColor: success
    readonly property color errorColor: error
    readonly property color textColor: textPrimary
    readonly property color textSecondaryColor: textSecondary
    readonly property color successColor: success
    readonly property color warningColor: warning
    readonly property color infoColor: info
    readonly property color hoverColor: darkMode ? "#374151" : "#F3F4F6"
    readonly property color disabledColor: darkMode ? "#1F2937" : "#F9FAFB"
    
    // ============================================================================
    // TYPOGRAPHY
    // ============================================================================
    
    // Font Families
    readonly property string fontFamily: "Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif"
    readonly property string fontFamilyMono: "'JetBrains Mono', 'Fira Code', 'Courier New', monospace"
    
    // Font Sizes
    readonly property int fontSizeXS: 11
    readonly property int fontSizeSmall: 12
    readonly property int fontSizeNormal: 14
    readonly property int fontSizeMedium: 16
    readonly property int fontSizeLarge: 18
    readonly property int fontSizeXL: 20
    readonly property int fontSizeXXL: 24
    readonly property int fontSizeH1: 32
    readonly property int fontSizeH2: 28
    readonly property int fontSizeH3: 24
    readonly property int fontSizeH4: 20
    readonly property int fontSizeH5: 18
    readonly property int fontSizeH6: 16
    
    // Font Weights
    readonly property int fontWeightLight: 300
    readonly property int fontWeightNormal: 400
    readonly property int fontWeightMedium: 500
    readonly property int fontWeightSemiBold: 600
    readonly property int fontWeightBold: 700
    
    // Line Heights
    readonly property real lineHeightTight: 1.25
    readonly property real lineHeightNormal: 1.5
    readonly property real lineHeightRelaxed: 1.75
    
    // Letter Spacing
    readonly property real letterSpacingTight: -0.025
    readonly property real letterSpacingNormal: 0
    readonly property real letterSpacingWide: 0.025
    
    // ============================================================================
    // SPACING SYSTEM
    // ============================================================================
    
    readonly property int spacing0: 0
    readonly property int spacing1: 4
    readonly property int spacing2: 8
    readonly property int spacing3: 12
    readonly property int spacing4: 16
    readonly property int spacing5: 20
    readonly property int spacing6: 24
    readonly property int spacing8: 32
    readonly property int spacing10: 40
    readonly property int spacing12: 48
    readonly property int spacing16: 64
    readonly property int spacing20: 80
    readonly property int spacing24: 96
    
    // Semantic spacing aliases
    readonly property int spacingXS: spacing1
    readonly property int spacingSmall: spacing2
    readonly property int spacingNormal: spacing3
    readonly property int spacingMedium: spacing4
    readonly property int spacingLarge: spacing6
    readonly property int spacingXL: spacing8
    readonly property int spacingXXL: spacing12
    
    // ============================================================================
    // SIZING SYSTEM
    // ============================================================================
    
    readonly property int buttonHeightSmall: 32
    readonly property int buttonHeight: 40
    readonly property int buttonHeightLarge: 48
    readonly property int inputHeight: 40
    readonly property int inputHeightSmall: 32
    readonly property int inputHeightLarge: 48
    
    readonly property int iconSizeXS: 16
    readonly property int iconSizeSmall: 20
    readonly property int iconSize: 24
    readonly property int iconSizeLarge: 32
    readonly property int iconSizeXL: 40
    readonly property int iconSizeXXL: 48
    
    readonly property int avatarSizeSmall: 32
    readonly property int avatarSize: 40
    readonly property int avatarSizeLarge: 48
    readonly property int avatarSizeXL: 64
    
    readonly property int headerHeight: 64
    readonly property int sidebarWidth: 240
    readonly property int sidebarWidthCollapsed: 72
    
    // ============================================================================
    // BORDER RADIUS
    // ============================================================================
    
    readonly property int radiusNone: 0
    readonly property int radiusXS: 2
    readonly property int radiusSmall: 4
    readonly property int radiusNormal: 6
    readonly property int radiusMedium: 8
    readonly property int radiusLarge: 12
    readonly property int radiusXL: 16
    readonly property int radiusXXL: 24
    readonly property int radiusFull: 9999
    
    // ============================================================================
    // SHADOWS (Elevation System)
    // ============================================================================
    
    readonly property string shadowNone: "0 0 0 0 transparent"
    readonly property string shadowXS: "0 1px 2px 0 rgba(0, 0, 0, 0.05)"
    readonly property string shadowSmall: "0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px -1px rgba(0, 0, 0, 0.1)"
    readonly property string shadowNormal: "0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -2px rgba(0, 0, 0, 0.1)"
    readonly property string shadowMedium: "0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -4px rgba(0, 0, 0, 0.1)"
    readonly property string shadowLarge: "0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1)"
    readonly property string shadowXL: "0 25px 50px -12px rgba(0, 0, 0, 0.25)"
    readonly property string shadowInner: "inset 0 2px 4px 0 rgba(0, 0, 0, 0.05)"
    
    // Dark mode shadows (lighter for visibility)
    readonly property string shadowSmallDark: "0 1px 3px 0 rgba(0, 0, 0, 0.3)"
    readonly property string shadowNormalDark: "0 4px 6px -1px rgba(0, 0, 0, 0.3)"
    readonly property string shadowMediumDark: "0 10px 15px -3px rgba(0, 0, 0, 0.4)"
    readonly property string shadowLargeDark: "0 20px 25px -5px rgba(0, 0, 0, 0.4)"
    
    // Legacy shadow mappings
    readonly property int shadowElevation: 2
    
    // ============================================================================
    // OPACITY
    // ============================================================================
    
    readonly property real opacityDisabled: 0.38
    readonly property real opacityInactive: 0.54
    readonly property real opacitySecondary: 0.74
    readonly property real opacityHover: 0.08
    readonly property real opacityPressed: 0.16
    readonly property real opacityFocus: 0.12
    
    // ============================================================================
    // ANIMATION & TRANSITIONS
    // ============================================================================
    
    readonly property int animationDurationFast: 150
    readonly property int animationDuration: 250
    readonly property int animationDurationSlow: 350
    readonly property int animationDurationXL: 500
    
    // Easing curves
    readonly property string easingStandard: "cubic-bezier(0.4, 0.0, 0.2, 1)"
    readonly property string easingDecelerate: "cubic-bezier(0.0, 0.0, 0.2, 1)"
    readonly property string easingAccelerate: "cubic-bezier(0.4, 0.0, 1, 1)"
    readonly property string easingSharp: "cubic-bezier(0.4, 0.0, 0.6, 1)"
    
    // ============================================================================
    // Z-INDEX
    // ============================================================================
    
    readonly property int zIndexDropdown: 1000
    readonly property int zIndexModal: 1300
    readonly property int zIndexPopover: 1400
    readonly property int zIndexTooltip: 1500
    readonly property int zIndexNotification: 1600
    
    // ============================================================================
    // BREAKPOINTS (for responsive design)
    // ============================================================================
    
    readonly property int breakpointSM: 640
    readonly property int breakpointMD: 768
    readonly property int breakpointLG: 1024
    readonly property int breakpointXL: 1280
    readonly property int breakpointXXL: 1536
    
    // ============================================================================
    // UTILITY FUNCTIONS
    // ============================================================================
    
    function alpha(color, opacity) {
        return Qt.rgba(color.r, color.g, color.b, opacity)
    }
    
    function lighten(color, factor) {
        return Qt.lighter(color, 1 + factor)
    }
    
    function darken(color, factor) {
        return Qt.darker(color, 1 + factor)
    }
    
    function getShadow(elevation) {
        if (darkMode) {
            switch(elevation) {
                case 0: return shadowNone
                case 1: return shadowSmallDark
                case 2: return shadowNormalDark
                case 3: return shadowMediumDark
                case 4: return shadowLargeDark
                default: return shadowNormalDark
            }
        } else {
            switch(elevation) {
                case 0: return shadowNone
                case 1: return shadowSmall
                case 2: return shadowNormal
                case 3: return shadowMedium
                case 4: return shadowLarge
                default: return shadowNormal
            }
        }
    }
    
    function getEnvironmentColor(environment) {
        switch(environment) {
            case "production": return productionColor
            case "staging": return stagingColor
            case "development": return developmentColor
            case "dr-site": return drSiteColor
            default: return gray200
        }
    }
    
    function getEnvironmentBadgeColor(environment) {
        switch(environment) {
            case "production": return productionBadge
            case "staging": return stagingBadge
            case "development": return developmentBadge
            case "dr-site": return drSiteBadge
            default: return gray500
        }
    }
}
