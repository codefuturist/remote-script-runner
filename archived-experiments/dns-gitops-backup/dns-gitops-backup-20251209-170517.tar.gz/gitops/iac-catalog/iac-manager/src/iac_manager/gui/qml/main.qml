// main.qml - Main application window with modern design
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Window
import "./views"
import "./components"
import "./theme"

ApplicationWindow {
    id: window
    visible: true
    width: 1280
    height: 800
    minimumWidth: 1024
    minimumHeight: 600
    title: "IaC Manager"
    
    // Backends are injected via context properties from Python
    
    // State management
    property bool sidebarCollapsed: false
    
    // Modern color scheme from Theme
    color: Theme.backgroundColor
    
    // Header with gradient
    header: Rectangle {
        height: Theme.headerHeight
        
        gradient: Gradient {
            GradientStop { position: 0.0; color: Theme.primary }
            GradientStop { position: 1.0; color: Theme.primaryDark }
        }
        
        // Subtle shadow using simple border
        Rectangle {
            anchors.bottom: parent.bottom
            width: parent.width
            height: 2
            opacity: 0.1
            gradient: Gradient {
                GradientStop { position: 0.0; color: "transparent" }
                GradientStop { position: 0.5; color: "black" }
                GradientStop { position: 1.0; color: "transparent" }
            }
        }
        
        RowLayout {
            anchors.fill: parent
            anchors.leftMargin: Theme.spacingLarge
            anchors.rightMargin: Theme.spacingLarge
            spacing: Theme.spacingMedium
            
            // Menu button for collapsing sidebar
            Rectangle {
                width: 40
                height: 40
                radius: Theme.radiusNormal
                color: menuMouseArea.containsMouse ? Theme.alpha("white", 0.15) : "transparent"
                
                Text {
                    anchors.centerIn: parent
                    text: "☰"
                    font.pixelSize: Theme.fontSizeLarge
                    color: "white"
                }
                
                MouseArea {
                    id: menuMouseArea
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: sidebarCollapsed = !sidebarCollapsed
                }
                
                Behavior on color {
                    ColorAnimation { duration: Theme.animationDurationFast }
                }
            }
            
            // Logo and title
            Row {
                spacing: Theme.spacing3
                
                Text {
                    text: "🚀"
                    font.pixelSize: Theme.fontSizeH4
                    anchors.verticalCenter: parent.verticalCenter
                }
                
                Label {
                    text: "IaC Manager"
                    font.pixelSize: Theme.fontSizeH4
                    font.weight: Theme.fontWeightBold
                    color: "white"
                    anchors.verticalCenter: parent.verticalCenter
                }
            }
            
            Item { Layout.fillWidth: true }
            
            // Subtitle
            Label {
                text: "Modern Infrastructure as Code Management"
                color: Theme.alpha("white", 0.9)
                font.pixelSize: Theme.fontSizeNormal
                font.weight: Theme.fontWeightMedium
            }
            
            // Settings button
            Rectangle {
                width: 36
                height: 36
                radius: Theme.radiusFull
                color: settingsMouseArea.containsMouse ? Theme.alpha("white", 0.15) : "transparent"
                
                Text {
                    anchors.centerIn: parent
                    text: "⚙"
                    font.pixelSize: Theme.iconSize
                    color: "white"
                }
                
                MouseArea {
                    id: settingsMouseArea
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                }
                
                Behavior on color {
                    ColorAnimation { duration: Theme.animationDurationFast }
                }
            }
        }
    }
    
    // Main content
    SplitView {
        anchors.fill: parent
        orientation: Qt.Horizontal
        
        // Navigation sidebar
        Rectangle {
            id: sidebar
            SplitView.preferredWidth: sidebarCollapsed ? Theme.sidebarWidthCollapsed : Theme.sidebarWidth
            SplitView.minimumWidth: sidebarCollapsed ? Theme.sidebarWidthCollapsed : 180
            SplitView.maximumWidth: sidebarCollapsed ? Theme.sidebarWidthCollapsed : 300
            color: Theme.surfaceColor
            
            Behavior on SplitView.preferredWidth {
                NumberAnimation { 
                    duration: Theme.animationDuration
                    easing.type: Easing.OutCubic
                }
            }
            
            // Divider line
            Rectangle {
                anchors.right: parent.right
                width: 1
                height: parent.height
                color: Theme.dividerColor
            }
            
            ColumnLayout {
                anchors.fill: parent
                anchors.margins: Theme.spacing3
                anchors.topMargin: Theme.spacingMedium
                spacing: Theme.spacing2
                
                Label {
                    text: sidebarCollapsed ? "" : "Navigation"
                    font.pixelSize: Theme.fontSizeSmall
                    font.weight: Theme.fontWeightSemiBold
                    color: Theme.textSecondary
                    Layout.fillWidth: true
                    Layout.leftMargin: Theme.spacing3
                    visible: !sidebarCollapsed
                }
                
                Rectangle {
                    Layout.fillWidth: true
                    height: 1
                    color: Theme.dividerColor
                    visible: !sidebarCollapsed
                }
                
                // Navigation items
                NavButton {
                    Layout.fillWidth: true
                    icon: "🏠"
                    label: "Dashboard"
                    collapsed: sidebarCollapsed
                    active: stackView.currentItem === dashboardView
                    onClicked: stackView.replace(dashboardView)
                }
                
                NavButton {
                    Layout.fillWidth: true
                    icon: "🚀"
                    label: "Deployments"
                    collapsed: sidebarCollapsed
                    active: stackView.currentItem === deploymentView
                    onClicked: stackView.replace(deploymentView)
                }
                
                NavButton {
                    Layout.fillWidth: true
                    icon: "📦"
                    label: "Templates"
                    collapsed: sidebarCollapsed
                    active: stackView.currentItem === templateView
                    onClicked: stackView.replace(templateView)
                }
                
                NavButton {
                    Layout.fillWidth: true
                    icon: "📋"
                    label: "Inventory"
                    collapsed: sidebarCollapsed
                    active: stackView.currentItem === inventoryView
                    onClicked: stackView.replace(inventoryView)
                }
                
                NavButton {
                    Layout.fillWidth: true
                    icon: "🔄"
                    label: "GitOps"
                    collapsed: sidebarCollapsed
                    active: stackView.currentItem === gitopsView
                    onClicked: stackView.replace(gitopsView)
                }
                
                NavButton {
                    Layout.fillWidth: true
                    icon: "🔐"
                    label: "Secrets"
                    collapsed: sidebarCollapsed
                    active: stackView.currentItem === secretsView
                    onClicked: stackView.replace(secretsView)
                }
                
                Item { Layout.fillHeight: true }
                
                Rectangle {
                    Layout.fillWidth: true
                    height: 1
                    color: Theme.dividerColor
                }
                
                Label {
                    Layout.fillWidth: true
                    text: sidebarCollapsed ? "v0.1" : "Version 0.1.0"
                    color: Theme.textSecondary
                    font.pixelSize: Theme.fontSizeXS
                    font.weight: Theme.fontWeightMedium
                    horizontalAlignment: sidebarCollapsed ? Text.AlignHCenter : Text.AlignLeft
                    Layout.leftMargin: sidebarCollapsed ? 0 : Theme.spacing3
                }
            }
        }
        
        // Main content area
        Rectangle {
            SplitView.fillWidth: true
            color: Theme.backgroundColor
            
            StackView {
                id: stackView
                anchors.fill: parent
                anchors.margins: Theme.spacingLarge
                
                initialItem: dashboardView
                
                // Smooth page transitions
                pushEnter: Transition {
                    ParallelAnimation {
                        NumberAnimation {
                            property: "opacity"
                            from: 0
                            to: 1
                            duration: Theme.animationDuration
                            easing.type: Easing.OutCubic
                        }
                        NumberAnimation {
                            property: "x"
                            from: 20
                            to: 0
                            duration: Theme.animationDuration
                            easing.type: Easing.OutCubic
                        }
                    }
                }
                
                pushExit: Transition {
                    NumberAnimation {
                        property: "opacity"
                        from: 1
                        to: 0
                        duration: Theme.animationDurationFast
                    }
                }
                
                replaceEnter: Transition {
                    ParallelAnimation {
                        NumberAnimation {
                            property: "opacity"
                            from: 0
                            to: 1
                            duration: Theme.animationDuration
                            easing.type: Easing.OutCubic
                        }
                        NumberAnimation {
                            property: "x"
                            from: 20
                            to: 0
                            duration: Theme.animationDuration
                            easing.type: Easing.OutCubic
                        }
                    }
                }
                
                replaceExit: Transition {
                    NumberAnimation {
                        property: "opacity"
                        from: 1
                        to: 0
                        duration: Theme.animationDurationFast
                    }
                }
            }
        }
    }
    
    // View components
    Component {
        id: dashboardView
        DashboardView {
            deploymentBackend: deploymentBackend
            gitopsBackend: gitopsBackend
        }
    }
    
    Component {
        id: deploymentView
        DeploymentListView {
            backend: deploymentBackend
        }
    }
    
    Component {
        id: templateView
        TemplateBrowserView {
        }
    }
    
    Component {
        id: inventoryView
        InventoryView {
        }
    }
    
    Component {
        id: gitopsView
        GitOpsView {
            backend: gitopsBackend
        }
    }
    
    Component {
        id: secretsView
        Label {
            text: "🔐 Secrets Management\n\nComing soon..."
            horizontalAlignment: Text.AlignHCenter
            verticalAlignment: Text.AlignVCenter
            font.pixelSize: Theme.fontSizeLarge
            color: Theme.textSecondary
        }
    }
    
    // Modern status bar
    footer: Rectangle {
        height: 28
        color: Theme.surfaceColor
        
        Rectangle {
            anchors.top: parent.top
            width: parent.width
            height: 1
            color: Theme.dividerColor
        }
        
        RowLayout {
            anchors.fill: parent
            anchors.leftMargin: Theme.spacingMedium
            anchors.rightMargin: Theme.spacingMedium
            spacing: Theme.spacingSmall
            
            StatusBadge {
                status: "success"
                badgeText: "Ready"
                size: "small"
                dot: true
            }
            
            Item { Layout.fillWidth: true }
            
            Label {
                text: "IaC Catalog Manager"
                font.pixelSize: Theme.fontSizeXS
                color: Theme.textSecondary
            }
        }
    }
    
    // Toast notification container
    Item {
        id: toastContainer
        anchors.bottom: parent.bottom
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.bottomMargin: Theme.spacing8
        width: parent.width
        height: 100
        z: Theme.zIndexNotification
        
        ToastNotification {
            id: toast
            anchors.horizontalCenter: parent.horizontalCenter
            y: parent.height - height - Theme.spacing4
        }
    }
}
