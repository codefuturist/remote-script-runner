"""Helm chart utilities for fetching default values."""

import re
import subprocess
import tempfile
from pathlib import Path
from typing import Dict, Optional, Tuple
from urllib.parse import urlparse

import requests
from ruamel.yaml import YAML


class HelmChartValuesFetcher:
    """Utility to fetch default values.yaml from Helm charts."""

    def __init__(self):
        """Initialize the Helm chart values fetcher."""
        self.yaml = YAML()
        self.yaml.preserve_quotes = True
        self.yaml.default_flow_style = False

    def fetch_chart_values(
        self,
        chart: str,
        repo: Optional[str] = None,
        version: Optional[str] = None,
        save_path: Optional[Path] = None,
    ) -> Tuple[Dict, Path]:
        """Fetch default values.yaml from a Helm chart.

        Args:
            chart: Chart name (e.g., 'bitnami/postgresql', 'postgresql')
            repo: Repository URL (optional if chart includes repo)
            version: Chart version (optional, defaults to latest)
            save_path: Where to save the values file (optional)

        Returns:
            Tuple of (values dict, path to saved file)

        Raises:
            ValueError: If chart format is invalid
            RuntimeError: If helm command fails or values not found
        """
        # Parse chart reference
        repo_name, chart_name = self._parse_chart_reference(chart, repo)

        # Add repo if provided
        if repo:
            self._add_helm_repo(repo_name, repo)

        # Pull the chart
        chart_path = self._pull_helm_chart(repo_name, chart_name, version)

        try:
            # Extract values.yaml
            values_file = self._extract_values_from_chart(chart_path)

            # Load values
            with open(values_file) as f:
                values = self.yaml.load(f)

            # Save to desired location if specified
            if save_path:
                save_path.parent.mkdir(parents=True, exist_ok=True)
                with open(save_path, "w") as f:
                    self.yaml.dump(values, f)
                final_path = save_path
            else:
                final_path = values_file

            return values, final_path

        finally:
            # Cleanup temporary chart file
            if chart_path.exists():
                chart_path.unlink()

    def _parse_chart_reference(
        self, chart: str, repo: Optional[str]
    ) -> Tuple[str, str]:
        """Parse chart reference into repo and chart names.

        Args:
            chart: Chart reference (e.g., 'bitnami/postgresql' or 'postgresql')
            repo: Optional repository URL

        Returns:
            Tuple of (repo_name, chart_name)
        """
        if "/" in chart:
            # Format: repo/chart
            parts = chart.split("/", 1)
            return parts[0], parts[1]
        elif repo:
            # Chart name only, use repo URL to generate name
            parsed = urlparse(repo)
            repo_name = parsed.path.strip("/").split("/")[-1] or "helm-repo"
            return repo_name, chart
        else:
            # Assume it's from a pre-configured repo
            return "stable", chart

    def _add_helm_repo(self, name: str, url: str) -> None:
        """Add a Helm repository.

        Args:
            name: Repository name
            url: Repository URL

        Raises:
            RuntimeError: If helm repo add fails
        """
        try:
            # Check if repo already exists
            result = subprocess.run(
                ["helm", "repo", "list", "-o", "json"],
                capture_output=True,
                text=True,
                check=False,
            )

            if result.returncode == 0:
                import json

                repos = json.loads(result.stdout) if result.stdout else []
                if any(r["name"] == name for r in repos):
                    # Repo exists, update it
                    subprocess.run(
                        ["helm", "repo", "update", name],
                        check=True,
                        capture_output=True,
                    )
                    return

            # Add new repo
            subprocess.run(
                ["helm", "repo", "add", name, url],
                check=True,
                capture_output=True,
            )
            subprocess.run(
                ["helm", "repo", "update", name], check=True, capture_output=True
            )

        except subprocess.CalledProcessError as e:
            raise RuntimeError(f"Failed to add Helm repository: {e.stderr}")
        except FileNotFoundError:
            raise RuntimeError(
                "Helm CLI not found. Please install Helm: https://helm.sh/docs/intro/install/"
            )

    def _pull_helm_chart(
        self, repo: str, chart: str, version: Optional[str]
    ) -> Path:
        """Pull a Helm chart to temporary location.

        Args:
            repo: Repository name
            chart: Chart name
            version: Chart version (optional)

        Returns:
            Path to pulled chart .tgz file

        Raises:
            RuntimeError: If helm pull fails
        """
        try:
            temp_dir = Path(tempfile.mkdtemp())
            chart_ref = f"{repo}/{chart}"

            cmd = ["helm", "pull", chart_ref, "--destination", str(temp_dir)]
            if version:
                cmd.extend(["--version", version])

            subprocess.run(cmd, check=True, capture_output=True)

            # Find the downloaded .tgz file
            tgz_files = list(temp_dir.glob("*.tgz"))
            if not tgz_files:
                raise RuntimeError(f"No chart file found after pulling {chart_ref}")

            return tgz_files[0]

        except subprocess.CalledProcessError as e:
            stderr = e.stderr.decode() if e.stderr else ""
            raise RuntimeError(f"Failed to pull Helm chart: {stderr}")
        except FileNotFoundError:
            raise RuntimeError(
                "Helm CLI not found. Please install Helm: https://helm.sh/docs/intro/install/"
            )

    def _extract_values_from_chart(self, chart_path: Path) -> Path:
        """Extract values.yaml from chart archive.

        Args:
            chart_path: Path to chart .tgz file

        Returns:
            Path to extracted values.yaml

        Raises:
            RuntimeError: If extraction fails or values.yaml not found
        """
        import tarfile

        try:
            temp_dir = Path(tempfile.mkdtemp())

            with tarfile.open(chart_path, "r:gz") as tar:
                # Find values.yaml in the archive
                values_member = None
                for member in tar.getmembers():
                    if member.name.endswith("/values.yaml"):
                        values_member = member
                        break

                if not values_member:
                    raise RuntimeError(
                        f"No values.yaml found in chart {chart_path.name}"
                    )

                # Extract values.yaml
                tar.extract(values_member, temp_dir)

            values_path = temp_dir / values_member.name
            return values_path

        except Exception as e:
            raise RuntimeError(f"Failed to extract values.yaml: {e}")

    def fetch_from_oci(
        self,
        oci_url: str,
        version: Optional[str] = None,
        save_path: Optional[Path] = None,
    ) -> Tuple[Dict, Path]:
        """Fetch values from an OCI registry.

        Args:
            oci_url: OCI URL (e.g., 'oci://registry-1.docker.io/bitnamicharts/postgresql')
            version: Chart version (optional)
            save_path: Where to save the values file (optional)

        Returns:
            Tuple of (values dict, path to saved file)

        Raises:
            RuntimeError: If OCI pull fails
        """
        try:
            temp_dir = Path(tempfile.mkdtemp())

            cmd = ["helm", "pull", oci_url, "--destination", str(temp_dir)]
            if version:
                cmd.extend(["--version", version])

            subprocess.run(cmd, check=True, capture_output=True)

            # Find the downloaded .tgz file
            tgz_files = list(temp_dir.glob("*.tgz"))
            if not tgz_files:
                raise RuntimeError(f"No chart file found after pulling {oci_url}")

            # Extract values
            values_file = self._extract_values_from_chart(tgz_files[0])

            # Load values
            with open(values_file) as f:
                values = self.yaml.load(f)

            # Save to desired location if specified
            if save_path:
                save_path.parent.mkdir(parents=True, exist_ok=True)
                with open(save_path, "w") as f:
                    self.yaml.dump(values, f)
                final_path = save_path
            else:
                final_path = values_file

            # Cleanup
            tgz_files[0].unlink()

            return values, final_path

        except subprocess.CalledProcessError as e:
            stderr = e.stderr.decode() if e.stderr else ""
            raise RuntimeError(f"Failed to pull OCI chart: {stderr}")
        except FileNotFoundError:
            raise RuntimeError(
                "Helm CLI not found. Please install Helm: https://helm.sh/docs/intro/install/"
            )

    def search_charts(self, keyword: str, repo: Optional[str] = None) -> list:
        """Search for Helm charts by keyword.

        Args:
            keyword: Search keyword
            repo: Optional repository to search in

        Returns:
            List of chart info dicts

        Raises:
            RuntimeError: If search fails
        """
        try:
            cmd = ["helm", "search", "repo", keyword]
            if repo:
                cmd[3] = f"{repo}/{keyword}"

            result = subprocess.run(cmd, capture_output=True, text=True, check=True)

            # Parse output
            lines = result.stdout.strip().split("\n")
            if len(lines) <= 1:
                return []

            # Skip header
            charts = []
            for line in lines[1:]:
                parts = line.split(None, 3)
                if len(parts) >= 3:
                    charts.append(
                        {
                            "name": parts[0],
                            "version": parts[1],
                            "app_version": parts[2],
                            "description": parts[3] if len(parts) > 3 else "",
                        }
                    )

            return charts

        except subprocess.CalledProcessError as e:
            stderr = e.stderr.decode() if e.stderr else ""
            raise RuntimeError(f"Failed to search charts: {stderr}")
        except FileNotFoundError:
            raise RuntimeError(
                "Helm CLI not found. Please install Helm: https://helm.sh/docs/intro/install/"
            )
