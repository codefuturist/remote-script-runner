"""Authentication routes."""

import secrets
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from iac_manager.web.auth.dependencies import ActiveUser, get_current_active_user
from iac_manager.web.auth.jwt import create_token_pair, verify_token
from iac_manager.web.auth.oauth import OAuthUser, get_oauth_handler
from iac_manager.web.auth.password import hash_password, verify_password
from iac_manager.web.config import get_settings
from iac_manager.web.database import RefreshToken, User, get_db
from iac_manager.web.schemas.auth import (
    LoginRequest,
    OAuthCallbackRequest,
    OAuthUrlResponse,
    PasswordChangeRequest,
    RefreshTokenRequest,
    RegisterRequest,
    TokenResponse,
    UserResponse,
    UserUpdate,
)
from iac_manager.web.schemas.common import MessageResponse

router = APIRouter()


@router.post("/register", response_model=TokenResponse, status_code=status.HTTP_201_CREATED)
async def register(
    data: RegisterRequest,
    db: Annotated[AsyncSession, Depends(get_db)],
) -> TokenResponse:
    """Register a new user account."""
    # Check if email or username already exists
    result = await db.execute(
        select(User).where((User.email == data.email) | (User.username == data.username))
    )
    existing = result.scalar_one_or_none()

    if existing:
        if existing.email == data.email:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Email already registered",
            )
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Username already taken",
        )

    # Create user
    user = User(
        email=data.email,
        username=data.username,
        hashed_password=hash_password(data.password),
        full_name=data.full_name,
    )
    db.add(user)
    await db.flush()

    # Create tokens
    token_pair, token_hash = create_token_pair(user.id)

    # Store refresh token
    refresh_token = RefreshToken(
        token_hash=token_hash,
        user_id=user.id,
        expires_at=verify_token(token_pair.refresh_token, "refresh").exp,
    )
    db.add(refresh_token)

    return TokenResponse(
        access_token=token_pair.access_token,
        refresh_token=token_pair.refresh_token,
        expires_in=token_pair.expires_in,
    )


@router.post("/login", response_model=TokenResponse)
async def login(
    data: LoginRequest,
    db: Annotated[AsyncSession, Depends(get_db)],
) -> TokenResponse:
    """Login with email and password."""
    result = await db.execute(select(User).where(User.email == data.email))
    user = result.scalar_one_or_none()

    if not user or not user.hashed_password:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password",
        )

    if not verify_password(data.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password",
        )

    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Account is disabled",
        )

    # Create tokens
    token_pair, token_hash = create_token_pair(user.id)

    # Store refresh token
    refresh_token = RefreshToken(
        token_hash=token_hash,
        user_id=user.id,
        expires_at=verify_token(token_pair.refresh_token, "refresh").exp,
    )
    db.add(refresh_token)

    return TokenResponse(
        access_token=token_pair.access_token,
        refresh_token=token_pair.refresh_token,
        expires_in=token_pair.expires_in,
    )


@router.post("/refresh", response_model=TokenResponse)
async def refresh_token(
    data: RefreshTokenRequest,
    db: Annotated[AsyncSession, Depends(get_db)],
) -> TokenResponse:
    """Refresh access token using refresh token."""
    import hashlib

    # Verify the refresh token
    payload = verify_token(data.refresh_token, "refresh")
    if not payload:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired refresh token",
        )

    # Check if token is in database and not revoked
    token_hash = hashlib.sha256(data.refresh_token.encode()).hexdigest()
    result = await db.execute(
        select(RefreshToken).where(
            RefreshToken.token_hash == token_hash,
            RefreshToken.revoked == False,
        )
    )
    stored_token = result.scalar_one_or_none()

    if not stored_token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Refresh token not found or revoked",
        )

    # Revoke old refresh token
    stored_token.revoked = True

    # Create new token pair
    token_pair, new_token_hash = create_token_pair(int(payload.sub))

    # Store new refresh token
    new_refresh_token = RefreshToken(
        token_hash=new_token_hash,
        user_id=int(payload.sub),
        expires_at=verify_token(token_pair.refresh_token, "refresh").exp,
    )
    db.add(new_refresh_token)

    return TokenResponse(
        access_token=token_pair.access_token,
        refresh_token=token_pair.refresh_token,
        expires_in=token_pair.expires_in,
    )


@router.post("/logout", response_model=MessageResponse)
async def logout(
    data: RefreshTokenRequest,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: ActiveUser,
) -> MessageResponse:
    """Logout and revoke refresh token."""
    import hashlib

    token_hash = hashlib.sha256(data.refresh_token.encode()).hexdigest()
    result = await db.execute(
        select(RefreshToken).where(
            RefreshToken.token_hash == token_hash,
            RefreshToken.user_id == current_user.id,
        )
    )
    stored_token = result.scalar_one_or_none()

    if stored_token:
        stored_token.revoked = True

    return MessageResponse(message="Successfully logged out")


@router.get("/me", response_model=UserResponse)
async def get_current_user_info(current_user: ActiveUser) -> UserResponse:
    """Get current user information."""
    return UserResponse.model_validate(current_user)


@router.patch("/me", response_model=UserResponse)
async def update_current_user(
    data: UserUpdate,
    current_user: ActiveUser,
    db: Annotated[AsyncSession, Depends(get_db)],
) -> UserResponse:
    """Update current user information."""
    if data.email and data.email != current_user.email:
        result = await db.execute(select(User).where(User.email == data.email))
        if result.scalar_one_or_none():
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Email already in use",
            )
        current_user.email = data.email

    if data.username and data.username != current_user.username:
        result = await db.execute(select(User).where(User.username == data.username))
        if result.scalar_one_or_none():
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Username already taken",
            )
        current_user.username = data.username

    if data.full_name is not None:
        current_user.full_name = data.full_name

    if data.password:
        current_user.hashed_password = hash_password(data.password)

    return UserResponse.model_validate(current_user)


@router.post("/change-password", response_model=MessageResponse)
async def change_password(
    data: PasswordChangeRequest,
    current_user: ActiveUser,
) -> MessageResponse:
    """Change current user's password."""
    if not current_user.hashed_password:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cannot change password for OAuth users",
        )

    if not verify_password(data.current_password, current_user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Current password is incorrect",
        )

    current_user.hashed_password = hash_password(data.new_password)
    return MessageResponse(message="Password changed successfully")


# OAuth routes
@router.get("/oauth/{provider}/authorize", response_model=OAuthUrlResponse)
async def oauth_authorize(
    provider: str,
    redirect_uri: str = Query(..., description="OAuth callback URI"),
) -> OAuthUrlResponse:
    """Get OAuth authorization URL."""
    try:
        handler = get_oauth_handler(provider)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

    state = secrets.token_urlsafe(32)
    url = handler.get_authorize_url(state, redirect_uri)

    return OAuthUrlResponse(url=url, state=state)


@router.post("/oauth/{provider}/callback", response_model=TokenResponse)
async def oauth_callback(
    provider: str,
    data: OAuthCallbackRequest,
    redirect_uri: str = Query(..., description="OAuth callback URI"),
    db: Annotated[AsyncSession, Depends(get_db)] = None,
) -> TokenResponse:
    """Handle OAuth callback and create/login user."""
    try:
        handler = get_oauth_handler(provider)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

    # Exchange code for token and get user info
    try:
        access_token = await handler.exchange_code(data.code, redirect_uri)
        oauth_user = await handler.get_user(access_token)
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=f"OAuth authentication failed: {e}",
        )

    # Find or create user
    result = await db.execute(
        select(User).where(
            (User.oauth_provider == provider) & (User.oauth_id == oauth_user.oauth_id)
            | (User.email == oauth_user.email)
        )
    )
    user = result.scalar_one_or_none()

    if user:
        # Update OAuth info if needed
        if not user.oauth_provider:
            user.oauth_provider = provider
            user.oauth_id = oauth_user.oauth_id
        user.avatar_url = oauth_user.avatar_url
    else:
        # Create new user
        user = User(
            email=oauth_user.email,
            username=oauth_user.username,
            full_name=oauth_user.full_name,
            oauth_provider=provider,
            oauth_id=oauth_user.oauth_id,
            avatar_url=oauth_user.avatar_url,
        )
        db.add(user)
        await db.flush()

    # Create tokens
    token_pair, token_hash = create_token_pair(user.id)

    # Store refresh token
    refresh_token = RefreshToken(
        token_hash=token_hash,
        user_id=user.id,
        expires_at=verify_token(token_pair.refresh_token, "refresh").exp,
    )
    db.add(refresh_token)

    return TokenResponse(
        access_token=token_pair.access_token,
        refresh_token=token_pair.refresh_token,
        expires_in=token_pair.expires_in,
    )


@router.get("/oauth/providers")
async def list_oauth_providers() -> dict:
    """List available OAuth providers."""
    settings = get_settings()
    return {
        "providers": [
            {"name": "github", "enabled": settings.github_enabled},
            {"name": "gitlab", "enabled": settings.gitlab_enabled},
        ]
    }
