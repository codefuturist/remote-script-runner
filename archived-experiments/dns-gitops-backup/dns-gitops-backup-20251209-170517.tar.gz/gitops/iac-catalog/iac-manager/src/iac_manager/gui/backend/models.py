"""Backend models for QML views."""

from typing import Any, List, Dict, Optional
import secrets
import string

from PyQt6.QtCore import QAbstractListModel, QModelIndex, Qt, pyqtSlot, pyqtSignal, QObject, pyqtProperty

from iac_manager.models import DeploymentInfo, InventoryHost, InventoryGroup, TemplateInfo
from .validators import ConfigValidator


class DeploymentListModel(QAbstractListModel):
    """Model for deployment list in QML."""

    # Custom roles for QML access
    InstanceIdRole = Qt.ItemDataRole.UserRole + 1
    EnvironmentRole = Qt.ItemDataRole.UserRole + 2
    TemplateRole = Qt.ItemDataRole.UserRole + 3
    VersionRole = Qt.ItemDataRole.UserRole + 4
    StatusRole = Qt.ItemDataRole.UserRole + 5
    PathRole = Qt.ItemDataRole.UserRole + 6
    HasEnvFileRole = Qt.ItemDataRole.UserRole + 7
    HasDockerRole = Qt.ItemDataRole.UserRole + 8
    HasK8sRole = Qt.ItemDataRole.UserRole + 9

    def __init__(self, parent=None):
        """Initialize model."""
        super().__init__(parent)
        self._deployments: List[DeploymentInfo] = []

    def rowCount(self, parent=QModelIndex()) -> int:
        """Return number of rows."""
        return len(self._deployments)

    def data(self, index: QModelIndex, role: int = Qt.ItemDataRole.DisplayRole) -> Any:
        """Return data for given index and role."""
        if not index.isValid() or index.row() >= len(self._deployments):
            return None

        deployment = self._deployments[index.row()]

        if role == self.InstanceIdRole:
            return deployment.instance_id
        elif role == self.EnvironmentRole:
            return deployment.environment.value
        elif role == self.TemplateRole:
            template_name = deployment.template.split("/")[-1] if "/" in deployment.template else deployment.template
            return template_name
        elif role == self.VersionRole:
            return deployment.template_version or "latest"
        elif role == self.StatusRole:
            return self._get_status(deployment)
        elif role == self.PathRole:
            return str(deployment.deployment_path)
        elif role == self.HasEnvFileRole:
            return deployment.has_env_file
        elif role == self.HasDockerRole:
            return deployment.has_docker_compose
        elif role == self.HasK8sRole:
            return deployment.has_kubernetes_manifests

        return None

    def roleNames(self):
        """Return role names for QML access."""
        return {
            self.InstanceIdRole: b"instanceId",
            self.EnvironmentRole: b"environment",
            self.TemplateRole: b"template",
            self.VersionRole: b"version",
            self.StatusRole: b"status",
            self.PathRole: b"path",
            self.HasEnvFileRole: b"hasEnvFile",
            self.HasDockerRole: b"hasDocker",
            self.HasK8sRole: b"hasK8s",
        }

    def _get_status(self, deployment: DeploymentInfo) -> str:
        """Get status string for deployment."""
        checks = []
        if deployment.has_env_file:
            checks.append("✅ Env")
        else:
            checks.append("⚠️ No Env")
        if deployment.has_docker_compose:
            checks.append("✅ Docker")
        elif deployment.has_kubernetes_manifests:
            checks.append("✅ K8s")
        else:
            checks.append("⚠️ No Runtime")
        return " | ".join(checks)

    def setDeployments(self, deployments: List[DeploymentInfo]):
        """Set deployments list."""
        self.beginResetModel()
        self._deployments = deployments
        self.endResetModel()

    def getDeployment(self, index: int) -> DeploymentInfo:
        """Get deployment at index."""
        if 0 <= index < len(self._deployments):
            return self._deployments[index]
        return None


class FileListModel(QAbstractListModel):
    """Model for file lists (modified, staged) in GitOps view."""

    FilePathRole = Qt.ItemDataRole.UserRole + 1
    FileNameRole = Qt.ItemDataRole.UserRole + 2

    def __init__(self, parent=None):
        """Initialize model."""
        super().__init__(parent)
        self._files: List[str] = []

    def rowCount(self, parent=QModelIndex()) -> int:
        """Return number of rows."""
        return len(self._files)

    def data(self, index: QModelIndex, role: int = Qt.ItemDataRole.DisplayRole) -> Any:
        """Return data for given index and role."""
        if not index.isValid() or index.row() >= len(self._files):
            return None

        file_path = self._files[index.row()]

        if role == self.FilePathRole or role == Qt.ItemDataRole.DisplayRole:
            return file_path
        elif role == self.FileNameRole:
            return file_path.split("/")[-1]

        return None

    def roleNames(self):
        """Return role names for QML access."""
        return {
            self.FilePathRole: b"filePath",
            self.FileNameRole: b"fileName",
        }

    def setFiles(self, files: List[str]):
        """Set files list."""
        self.beginResetModel()
        self._files = files
        self.endResetModel()

    def getFiles(self) -> List[str]:
        """Get all files."""
        return self._files.copy()

    def clear(self):
        """Clear all files."""
        self.beginResetModel()
        self._files = []
        self.endResetModel()


class TemplateListModel(QAbstractListModel):
    """Model for template list in QML."""

    # Custom roles for QML access
    NameRole = Qt.ItemDataRole.UserRole + 1
    CategoryRole = Qt.ItemDataRole.UserRole + 2
    DescriptionRole = Qt.ItemDataRole.UserRole + 3
    PathRole = Qt.ItemDataRole.UserRole + 4
    IconRole = Qt.ItemDataRole.UserRole + 5
    TargetTypesRole = Qt.ItemDataRole.UserRole + 6
    PopularRole = Qt.ItemDataRole.UserRole + 7

    def __init__(self, parent=None):
        """Initialize model."""
        super().__init__(parent)
        self._templates: List[TemplateInfo] = []

    def rowCount(self, parent=QModelIndex()) -> int:
        """Return number of rows."""
        return len(self._templates)

    def data(self, index: QModelIndex, role: int = Qt.ItemDataRole.DisplayRole) -> Any:
        """Return data for given index and role."""
        if not index.isValid() or index.row() >= len(self._templates):
            return None

        template = self._templates[index.row()]

        if role == self.NameRole or role == Qt.ItemDataRole.DisplayRole:
            return template.name
        elif role == self.CategoryRole:
            return template.category
        elif role == self.DescriptionRole:
            return template.description or ""
        elif role == self.PathRole:
            return str(template.path)
        elif role == self.IconRole:
            return self._get_icon(template.category, template.name)
        elif role == self.TargetTypesRole:
            return self._get_target_types(template)
        elif role == self.PopularRole:
            # Mark certain templates as popular
            popular = ["wordpress", "postgresql", "nginx", "gitlab", "nextcloud"]
            return template.name.lower() in popular

        return None

    def roleNames(self):
        """Return role names for QML access."""
        return {
            self.NameRole: b"name",
            self.CategoryRole: b"category",
            self.DescriptionRole: b"description",
            self.PathRole: b"path",
            self.IconRole: b"icon",
            self.TargetTypesRole: b"targetTypes",
            self.PopularRole: b"popular",
        }

    def _get_icon(self, category: str, name: str) -> str:
        """Get emoji icon for template."""
        # Category-based icons
        category_icons = {
            "containers": "🐳",
            "cloud": "☁️",
            "gitops": "🔄",
            "on-premises": "🏢",
            "self-hosted": "🏠",
            "governance": "📋",
        }
        
        # Specific template icons
        name_lower = name.lower()
        if "wordpress" in name_lower:
            return "🌐"
        elif "database" in name_lower or "postgres" in name_lower or "mysql" in name_lower:
            return "💾"
        elif "nginx" in name_lower or "apache" in name_lower:
            return "🚀"
        elif "gitlab" in name_lower or "github" in name_lower:
            return "🦊"
        elif "redis" in name_lower:
            return "⚡"
        elif "nextcloud" in name_lower:
            return "☁️"
        elif "monitoring" in name_lower or "prometheus" in name_lower:
            return "📊"
        elif "jenkins" in name_lower:
            return "🔧"
        
        return category_icons.get(category, "📦")

    def _get_target_types(self, template: TemplateInfo) -> str:
        """Get target types for template."""
        types = [t.value for t in template.target_types]
        return ", ".join(types) if types else "Unknown"

    def setTemplates(self, templates: List[TemplateInfo]):
        """Set templates list."""
        self.beginResetModel()
        self._templates = templates
        self.endResetModel()

    def getTemplate(self, index: int) -> Optional[TemplateInfo]:
        """Get template at index."""
        if 0 <= index < len(self._templates):
            return self._templates[index]
        return None


class InventoryHostListModel(QAbstractListModel):
    """Model for inventory host list in QML."""

    # Custom roles for QML access
    HostnameRole = Qt.ItemDataRole.UserRole + 1
    IpAddressRole = Qt.ItemDataRole.UserRole + 2
    GroupsRole = Qt.ItemDataRole.UserRole + 3
    VariablesRole = Qt.ItemDataRole.UserRole + 4
    StatusRole = Qt.ItemDataRole.UserRole + 5

    def __init__(self, parent=None):
        """Initialize model."""
        super().__init__(parent)
        self._hosts: List[InventoryHost] = []

    def rowCount(self, parent=QModelIndex()) -> int:
        """Return number of rows."""
        return len(self._hosts)

    def data(self, index: QModelIndex, role: int = Qt.ItemDataRole.DisplayRole) -> Any:
        """Return data for given index and role."""
        if not index.isValid() or index.row() >= len(self._hosts):
            return None

        host = self._hosts[index.row()]

        if role == self.HostnameRole or role == Qt.ItemDataRole.DisplayRole:
            return host.name
        elif role == self.IpAddressRole:
            return host.ansible_host or "N/A"
        elif role == self.GroupsRole:
            return ", ".join(host.groups) if host.groups else "none"
        elif role == self.VariablesRole:
            return len(host.labels)
        elif role == self.StatusRole:
            return self._check_host_status(host)

        return None

    def roleNames(self):
        """Return role names for QML access."""
        return {
            self.HostnameRole: b"hostname",
            self.IpAddressRole: b"ipAddress",
            self.GroupsRole: b"groups",
            self.VariablesRole: b"variableCount",
            self.StatusRole: b"status",
        }

    def setHosts(self, hosts: List[InventoryHost]):
        """Set hosts list."""
        self.beginResetModel()
        self._hosts = hosts
        self.endResetModel()

    def _check_host_status(self, host: InventoryHost) -> str:
        """Check host status based on configuration.
        
        Args:
            host: Inventory host to check
            
        Returns:
            Status string ('configured', 'unknown', or 'unconfigured')
        """
        # Basic validation - check if essential fields are configured
        if not host.ansible_host:
            return "unconfigured"
        
        # If host has an ansible_host and at least one group, consider it configured
        if host.groups and len(host.groups) > 0:
            return "configured"
        
        # Has ansible_host but no groups
        if host.ansible_host:
            return "configured"
        
        return "unknown"

    def getHost(self, index: int) -> Optional[InventoryHost]:
        """Get host at index."""
        if 0 <= index < len(self._hosts):
            return self._hosts[index]
        return None


class InventoryGroupListModel(QAbstractListModel):
    """Model for inventory group list in QML."""

    # Custom roles for QML access
    NameRole = Qt.ItemDataRole.UserRole + 1
    HostCountRole = Qt.ItemDataRole.UserRole + 2
    VariablesRole = Qt.ItemDataRole.UserRole + 3
    ChildrenRole = Qt.ItemDataRole.UserRole + 4

    def __init__(self, parent=None):
        """Initialize model."""
        super().__init__(parent)
        self._groups: List[InventoryGroup] = []

    def rowCount(self, parent=QModelIndex()) -> int:
        """Return number of rows."""
        return len(self._groups)

    def data(self, index: QModelIndex, role: int = Qt.ItemDataRole.DisplayRole) -> Any:
        """Return data for given index and role."""
        if not index.isValid() or index.row() >= len(self._groups):
            return None

        group = self._groups[index.row()]

        if role == self.NameRole or role == Qt.ItemDataRole.DisplayRole:
            return group.name
        elif role == self.HostCountRole:
            return len(group.hosts)
        elif role == self.VariablesRole:
            return len(group.vars)
        elif role == self.ChildrenRole:
            return ", ".join(group.children) if group.children else ""

        return None

    def roleNames(self):
        """Return role names for QML access."""
        return {
            self.NameRole: b"name",
            self.HostCountRole: b"hostCount",
            self.VariablesRole: b"variableCount",
            self.ChildrenRole: b"children",
        }

    def setGroups(self, groups: List[InventoryGroup]):
        """Set groups list."""
        self.beginResetModel()
        self._groups = groups
        self.endResetModel()

    def getGroup(self, index: int) -> Optional[InventoryGroup]:
        """Get group at index."""
        if 0 <= index < len(self._groups):
            return self._groups[index]
        return None


class SecretsListModel(QAbstractListModel):
    """Model for secrets list in QML."""

    # Custom roles for QML access
    KeyRole = Qt.ItemDataRole.UserRole + 1
    EnvironmentRole = Qt.ItemDataRole.UserRole + 2
    DescriptionRole = Qt.ItemDataRole.UserRole + 3
    CreatedRole = Qt.ItemDataRole.UserRole + 4
    ModifiedRole = Qt.ItemDataRole.UserRole + 5

    def __init__(self, parent=None):
        """Initialize model."""
        super().__init__(parent)
        self._secrets: List[Dict[str, Any]] = []

    def rowCount(self, parent=QModelIndex()) -> int:
        """Return number of rows."""
        return len(self._secrets)

    def data(self, index: QModelIndex, role: int = Qt.ItemDataRole.DisplayRole) -> Any:
        """Return data for given index and role."""
        if not index.isValid() or index.row() >= len(self._secrets):
            return None

        secret = self._secrets[index.row()]

        if role == self.KeyRole or role == Qt.ItemDataRole.DisplayRole:
            return secret.get("key", "")
        elif role == self.EnvironmentRole:
            return secret.get("environment", "global")
        elif role == self.DescriptionRole:
            return secret.get("description", "")
        elif role == self.CreatedRole:
            return secret.get("created", "")
        elif role == self.ModifiedRole:
            return secret.get("modified", "")

        return None

    def roleNames(self):
        """Return role names for QML access."""
        return {
            self.KeyRole: b"key",
            self.EnvironmentRole: b"environment",
            self.DescriptionRole: b"description",
            self.CreatedRole: b"created",
            self.ModifiedRole: b"modified",
        }

    def setSecrets(self, secrets: List[Dict[str, Any]]):
        """Set secrets list."""
        self.beginResetModel()
        self._secrets = secrets
        self.endResetModel()

    def getSecret(self, index: int) -> Optional[Dict[str, Any]]:
        """Get secret at index."""
        if 0 <= index < len(self._secrets):
            return self._secrets[index]
        return None


class DockerDeploymentConfig(QObject):
    """Docker-specific deployment configuration model."""

    # Signals
    configChanged = pyqtSignal()
    deploymentModeChanged = pyqtSignal(str)
    ingressEnabledChanged = pyqtSignal(bool)
    ingressTypeChanged = pyqtSignal(str)
    sslEnabledChanged = pyqtSignal(bool)
    secretTypeChanged = pyqtSignal(str)
    networkTypeChanged = pyqtSignal(str)
    networkExternalChanged = pyqtSignal(bool)
    networkInternalChanged = pyqtSignal(bool)
    databaseStrategyChanged = pyqtSignal(str)
    databaseTypeChanged = pyqtSignal(str)
    databaseHostChanged = pyqtSignal(str)
    databasePortChanged = pyqtSignal(int)
    databaseNameChanged = pyqtSignal(str)
    databaseUsernameChanged = pyqtSignal(str)
    databasePasswordChanged = pyqtSignal(str)
    databaseContainerNameChanged = pyqtSignal(str)
    databaseNetworkNameChanged = pyqtSignal(str)
    databaseSslEnabledChanged = pyqtSignal(bool)


    def __init__(self, parent=None):
        """Initialize Docker deployment configuration."""
        super().__init__(parent)
        self._deployment_mode = "standalone"
        self._ingress_enabled = False
        self._ingress_type = "traefik"
        self._ssl_enabled = False
        self._traefik_rule = "Host(`app.local`)"
        self._secret_type = "env"
        self._secret_provider = "local"
        self._network_type = "bridge"
        self._network_driver = "bridge"
        self._network_external = False
        self._network_internal = False
        self._database_strategy = "managed"  # none, managed, container, external
        self._database_type = "mariadb"
        self._database_version = "10.6"
        self._database_host = ""
        self._database_port = 3306
        self._database_name = "appdb"
        self._database_username = "dbuser"
        self._database_password = ""
        self._database_container_name = ""  # For 'container' strategy
        self._database_network_name = ""    # For 'container' strategy
        self._database_ssl_enabled = False  # For 'external' strategy

        # Resource limits
        self._cpu_limit = ""
        self._memory_limit = ""
        self._cpu_reservation = ""
        self._memory_reservation = ""

        # Healthcheck
        self._healthcheck_enabled = True
        self._healthcheck_interval = "30s"
        self._healthcheck_timeout = "10s"
        self._healthcheck_retries = 3
        self._healthcheck_start_period = "40s"

        # Restart policy
        self._restart_policy = "unless-stopped"

        # Port mapping
        self._expose_ports = True
        self._host_port = 8080
        self._container_port = 80

        # Volumes
        self._enable_volumes = True
        self._volume_driver = "local"

        # Scaling
        self._replicas = 1

        # Logging
        self._log_driver = "json-file"
        self._log_max_size = "10m"
        self._log_max_file = "3"

        # Environment variables (as key-value pairs)
        self._custom_env_vars: Dict[str, str] = {}

        # Labels
        self._custom_labels: Dict[str, str] = {}

    @pyqtProperty(str, notify=deploymentModeChanged)
    def deploymentMode(self) -> str:
        """Get deployment mode."""
        return self._deployment_mode

    @deploymentMode.setter
    def deploymentMode(self, value: str):
        """Set deployment mode."""
        if self._deployment_mode != value:
            self._deployment_mode = value
            self.deploymentModeChanged.emit(value)
            self.configChanged.emit()

    @pyqtProperty(bool, notify=ingressEnabledChanged)
    def ingressEnabled(self) -> bool:
        """Get ingress enabled status."""
        return self._ingress_enabled

    @ingressEnabled.setter
    def ingressEnabled(self, value: bool):
        """Set ingress enabled status."""
        if self._ingress_enabled != value:
            self._ingress_enabled = value
            self.ingressEnabledChanged.emit(value)
            self.configChanged.emit()

    @pyqtProperty(str, notify=ingressTypeChanged)
    def ingressType(self) -> str:
        """Get ingress type."""
        return self._ingress_type

    @ingressType.setter
    def ingressType(self, value: str):
        """Set ingress type."""
        if self._ingress_type != value:
            self._ingress_type = value
            self.ingressTypeChanged.emit(value)
            self.configChanged.emit()

    @pyqtProperty(bool, notify=sslEnabledChanged)
    def sslEnabled(self) -> bool:
        """Get SSL enabled status."""
        return self._ssl_enabled

    @sslEnabled.setter
    def sslEnabled(self, value: bool):
        """Set SSL enabled status."""
        if self._ssl_enabled != value:
            self._ssl_enabled = value
            self.sslEnabledChanged.emit(value)
            self.configChanged.emit()

    @pyqtProperty(str)
    def traefikRule(self) -> str:
        """Get Traefik rule."""
        return self._traefik_rule

    @traefikRule.setter
    def traefikRule(self, value: str):
        """Set Traefik rule."""
        if self._traefik_rule != value:
            self._traefik_rule = value
            self.configChanged.emit()

    @pyqtProperty(str, notify=secretTypeChanged)
    def secretType(self) -> str:
        """Get secret type."""
        return self._secret_type

    @secretType.setter
    def secretType(self, value: str):
        """Set secret type."""
        if self._secret_type != value:
            self._secret_type = value
            self.secretTypeChanged.emit(value)
            self.configChanged.emit()

    @pyqtProperty(str)
    def secretProvider(self) -> str:
        """Get secret provider."""
        return self._secret_provider

    @secretProvider.setter
    def secretProvider(self, value: str):
        """Set secret provider."""
        if self._secret_provider != value:
            self._secret_provider = value
            self.configChanged.emit()

    @pyqtProperty(str, notify=networkTypeChanged)
    def networkType(self) -> str:
        """Get network type."""
        return self._network_type

    @networkType.setter
    def networkType(self, value: str):
        """Set network type."""
        if self._network_type != value:
            self._network_type = value
            self._network_driver = value  # Sync driver with type
            self.networkTypeChanged.emit(value)
            self.configChanged.emit()

    @pyqtProperty(str)
    def networkDriver(self) -> str:
        """Get network driver."""
        return self._network_driver

    @networkDriver.setter
    def networkDriver(self, value: str):
        """Set network driver."""
        if self._network_driver != value:
            self._network_driver = value
            self.configChanged.emit()

    @pyqtProperty(bool, notify=networkExternalChanged)
    def networkExternal(self) -> bool:
        """Get network external status."""
        return self._network_external

    @networkExternal.setter
    def networkExternal(self, value: bool):
        """Set network external status."""
        if self._network_external != value:
            self._network_external = value
            self.networkExternalChanged.emit(value)
            self.configChanged.emit()

    @pyqtProperty(bool, notify=networkInternalChanged)
    def networkInternal(self) -> bool:
        """Get network internal status."""
        return self._network_internal

    @networkInternal.setter
    def networkInternal(self, value: bool):
        """Set network internal status."""
        if self._network_internal != value:
            self._network_internal = value
            self.networkInternalChanged.emit(value)
            self.configChanged.emit()

    @pyqtProperty(str, notify=databaseStrategyChanged)
    def databaseStrategy(self) -> str:
        """Get database strategy."""
        return self._database_strategy

    @databaseStrategy.setter
    def databaseStrategy(self, value: str):
        """Set database strategy."""
        if self._database_strategy != value:
            self._database_strategy = value
            self.databaseStrategyChanged.emit(value)
            self.configChanged.emit()

    @pyqtProperty(str, notify=databaseTypeChanged)
    def databaseType(self) -> str:
        """Get database type."""
        return self._database_type

    @databaseType.setter
    def databaseType(self, value: str):
        """Set database type."""
        if self._database_type != value:
            self._database_type = value
            self.databaseTypeChanged.emit(value)
            self.configChanged.emit()

    @pyqtProperty(str)
    def databaseVersion(self) -> str:
        """Get database version."""
        return self._database_version

    @databaseVersion.setter
    def databaseVersion(self, value: str):
        """Set database version."""
        if self._database_version != value:
            self._database_version = value
            self.configChanged.emit()

    @pyqtProperty(str, notify=databaseHostChanged)
    def databaseHost(self) -> str:
        """Get database host."""
        return self._database_host

    @databaseHost.setter
    def databaseHost(self, value: str):
        """Set database host."""
        if self._database_host != value:
            self._database_host = value
            self.databaseHostChanged.emit(value)
            self.configChanged.emit()

    @pyqtProperty(int, notify=databasePortChanged)
    def databasePort(self) -> int:
        """Get database port."""
        return self._database_port

    @databasePort.setter
    def databasePort(self, value: int):
        """Set database port."""
        if self._database_port != value:
            self._database_port = value
            self.databasePortChanged.emit(value)
            self.configChanged.emit()

    @pyqtProperty(str, notify=databaseNameChanged)
    def databaseName(self) -> str:
        """Get database name."""
        return self._database_name

    @databaseName.setter
    def databaseName(self, value: str):
        """Set database name."""
        if self._database_name != value:
            self._database_name = value
            self.databaseNameChanged.emit(value)
            self.configChanged.emit()

    @pyqtProperty(str, notify=databaseUsernameChanged)
    def databaseUsername(self) -> str:
        """Get database username."""
        return self._database_username

    @databaseUsername.setter
    def databaseUsername(self, value: str):
        """Set database username."""
        if self._database_username != value:
            self._database_username = value
            self.databaseUsernameChanged.emit(value)
            self.configChanged.emit()

    @pyqtProperty(str, notify=databasePasswordChanged)
    def databasePassword(self) -> str:
        """Get database password."""
        return self._database_password

    @databasePassword.setter
    def databasePassword(self, value: str):
        """Set database password."""
        if self._database_password != value:
            self._database_password = value
            self.databasePasswordChanged.emit(value)
            self.configChanged.emit()

    @pyqtProperty(str, notify=databaseContainerNameChanged)
    def databaseContainerName(self) -> str:
        """Get database container name."""
        return self._database_container_name

    @databaseContainerName.setter
    def databaseContainerName(self, value: str):
        """Set database container name."""
        if self._database_container_name != value:
            self._database_container_name = value
            self.databaseContainerNameChanged.emit(value)
            self.configChanged.emit()

    @pyqtProperty(str, notify=databaseNetworkNameChanged)
    def databaseNetworkName(self) -> str:
        """Get database network name."""
        return self._database_network_name

    @databaseNetworkName.setter
    def databaseNetworkName(self, value: str):
        """Set database network name."""
        if self._database_network_name != value:
            self._database_network_name = value
            self.databaseNetworkNameChanged.emit(value)
            self.configChanged.emit()

    @pyqtProperty(bool, notify=databaseSslEnabledChanged)
    def databaseSslEnabled(self) -> bool:
        """Get database SSL enabled."""
        return self._database_ssl_enabled

    @databaseSslEnabled.setter
    def databaseSslEnabled(self, value: bool):
        """Set database SSL enabled."""
        if self._database_ssl_enabled != value:
            self._database_ssl_enabled = value
            self.databaseSslEnabledChanged.emit(value)
            self.configChanged.emit()

    # Resource limit properties
    @pyqtProperty(str)
    def cpuLimit(self) -> str:
        """Get CPU limit."""
        return self._cpu_limit

    @cpuLimit.setter
    def cpuLimit(self, value: str):
        """Set CPU limit."""
        if self._cpu_limit != value:
            self._cpu_limit = value
            self.configChanged.emit()

    @pyqtProperty(str)
    def memoryLimit(self) -> str:
        """Get memory limit."""
        return self._memory_limit

    @memoryLimit.setter
    def memoryLimit(self, value: str):
        """Set memory limit."""
        if self._memory_limit != value:
            self._memory_limit = value
            self.configChanged.emit()

    @pyqtProperty(str)
    def cpuReservation(self) -> str:
        """Get CPU reservation."""
        return self._cpu_reservation

    @cpuReservation.setter
    def cpuReservation(self, value: str):
        """Set CPU reservation."""
        if self._cpu_reservation != value:
            self._cpu_reservation = value
            self.configChanged.emit()

    @pyqtProperty(str)
    def memoryReservation(self) -> str:
        """Get memory reservation."""
        return self._memory_reservation

    @memoryReservation.setter
    def memoryReservation(self, value: str):
        """Set memory reservation."""
        if self._memory_reservation != value:
            self._memory_reservation = value
            self.configChanged.emit()

    # Healthcheck properties
    @pyqtProperty(bool)
    def healthcheckEnabled(self) -> bool:
        """Get healthcheck enabled status."""
        return self._healthcheck_enabled

    @healthcheckEnabled.setter
    def healthcheckEnabled(self, value: bool):
        """Set healthcheck enabled status."""
        if self._healthcheck_enabled != value:
            self._healthcheck_enabled = value
            self.configChanged.emit()

    @pyqtProperty(str)
    def healthcheckInterval(self) -> str:
        """Get healthcheck interval."""
        return self._healthcheck_interval

    @healthcheckInterval.setter
    def healthcheckInterval(self, value: str):
        """Set healthcheck interval."""
        if self._healthcheck_interval != value:
            self._healthcheck_interval = value
            self.configChanged.emit()

    @pyqtProperty(int)
    def healthcheckRetries(self) -> int:
        """Get healthcheck retries."""
        return self._healthcheck_retries

    @healthcheckRetries.setter
    def healthcheckRetries(self, value: int):
        """Set healthcheck retries."""
        if self._healthcheck_retries != value:
            self._healthcheck_retries = value
            self.configChanged.emit()

    # Restart policy
    @pyqtProperty(str)
    def restartPolicy(self) -> str:
        """Get restart policy."""
        return self._restart_policy

    @restartPolicy.setter
    def restartPolicy(self, value: str):
        """Set restart policy."""
        if self._restart_policy != value:
            self._restart_policy = value
            self.configChanged.emit()

    # Port mapping
    @pyqtProperty(bool)
    def exposePorts(self) -> bool:
        """Get expose ports status."""
        return self._expose_ports

    @exposePorts.setter
    def exposePorts(self, value: bool):
        """Set expose ports status."""
        if self._expose_ports != value:
            self._expose_ports = value
            self.configChanged.emit()

    @pyqtProperty(int)
    def hostPort(self) -> int:
        """Get host port."""
        return self._host_port

    @hostPort.setter
    def hostPort(self, value: int):
        """Set host port."""
        if self._host_port != value:
            self._host_port = value
            self.configChanged.emit()

    @pyqtProperty(int)
    def containerPort(self) -> int:
        """Get container port."""
        return self._container_port

    @containerPort.setter
    def containerPort(self, value: int):
        """Set container port."""
        if self._container_port != value:
            self._container_port = value
            self.configChanged.emit()

    # Scaling
    @pyqtProperty(int)
    def replicas(self) -> int:
        """Get replicas count."""
        return self._replicas

    @replicas.setter
    def replicas(self, value: int):
        """Set replicas count."""
        if self._replicas != value:
            self._replicas = value
            self.configChanged.emit()

    # Logging
    @pyqtProperty(str)
    def logDriver(self) -> str:
        """Get log driver."""
        return self._log_driver

    @logDriver.setter
    def logDriver(self, value: str):
        """Set log driver."""
        if self._log_driver != value:
            self._log_driver = value
            self.configChanged.emit()

    @pyqtProperty(str)
    def logMaxSize(self) -> str:
        """Get log max size."""
        return self._log_max_size

    @logMaxSize.setter
    def logMaxSize(self, value: str):
        """Set log max size."""
        if self._log_max_size != value:
            self._log_max_size = value
            self.configChanged.emit()

    # Methods for custom environment variables and labels
    @pyqtSlot(str, str)
    def addEnvVar(self, key: str, value: str):
        """Add custom environment variable."""
        self._custom_env_vars[key] = value
        self.configChanged.emit()

    @pyqtSlot(str)
    def removeEnvVar(self, key: str):
        """Remove custom environment variable."""
        if key in self._custom_env_vars:
            del self._custom_env_vars[key]
            self.configChanged.emit()

    @pyqtSlot(result=str)
    def getEnvVarsJson(self) -> str:
        """Get environment variables as JSON string."""
        import json
        return json.dumps(self._custom_env_vars, indent=2)

    @pyqtSlot(str, str)
    def addLabel(self, key: str, value: str):
        """Add custom label."""
        self._custom_labels[key] = value
        self.configChanged.emit()

    @pyqtSlot(str)
    def removeLabel(self, key: str):
        """Remove custom label."""
        if key in self._custom_labels:
            del self._custom_labels[key]
            self.configChanged.emit()

    @pyqtSlot(result=str)
    def getLabelsJson(self) -> str:
        """Get labels as JSON string."""
        import json
        return json.dumps(self._custom_labels, indent=2)

    @pyqtSlot(result=str)
    def generatePassword(self, length: int = 32) -> str:
        """Generate a random secure password.

        Args:
            length: Length of password (default 32)

        Returns:
            Random password string
        """
        alphabet = string.ascii_letters + string.digits + "!@#$%^&*()-_=+"
        password = ''.join(secrets.choice(alphabet) for _ in range(length))
        return password

    def toDict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary."""
        return {
            'deployment_mode': self._deployment_mode,
            'enable_traefik': self._ingress_enabled,
            'ingress_type': self._ingress_type,
            'ssl_enabled': self._ssl_enabled,
            'traefik_rule': self._traefik_rule,
            'secret_type': self._secret_type,
            'secret_provider': self._secret_provider,
            'network_type': self._network_type,
            'network_driver': self._network_driver,
            'network_external': self._network_external,
            'network_internal': self._network_internal,
            'database_strategy': self._database_strategy,
            'database_type': self._database_type,
            'database_version': self._database_version,
            'database_host': self._database_host,
            'database_port': self._database_port,
            'database_name': self._database_name,
            'database_username': self._database_username,
            'database_password': self._database_password,
            'database_container_name': self._database_container_name,
            'database_network_name': self._database_network_name,
            'database_ssl_enabled': self._database_ssl_enabled,
            # Resource limits
            'cpu_limit': self._cpu_limit,
            'memory_limit': self._memory_limit,
            'cpu_reservation': self._cpu_reservation,
            'memory_reservation': self._memory_reservation,
            # Healthcheck
            'healthcheck_enabled': self._healthcheck_enabled,
            'healthcheck_interval': self._healthcheck_interval,
            'healthcheck_timeout': self._healthcheck_timeout,
            'healthcheck_retries': self._healthcheck_retries,
            'healthcheck_start_period': self._healthcheck_start_period,
            # Restart policy
            'restart_policy': self._restart_policy,
            # Port mapping
            'expose_ports': self._expose_ports,
            'host_port': self._host_port,
            'container_port': self._container_port,
            # Volumes
            'enable_volumes': self._enable_volumes,
            'volume_driver': self._volume_driver,
            # Scaling
            'replicas': self._replicas,
            # Logging
            'log_driver': self._log_driver,
            'log_max_size': self._log_max_size,
            'log_max_file': self._log_max_file,
            # Custom env vars and labels
            'custom_env_vars': self._custom_env_vars.copy(),
            'custom_labels': self._custom_labels.copy(),
        }

    def validate(self) -> List[str]:
        """Validate configuration and return list of errors."""
        errors = []

        # Docker Secrets only work in Swarm mode
        if self._secret_type == 'docker-secret' and self._deployment_mode != 'swarm':
            errors.append("Docker Secrets require Swarm mode")

        # Overlay networks for Swarm
        if self._network_type == 'overlay' and self._deployment_mode != 'swarm':
            errors.append("Overlay networks require Swarm mode")

        # Database validation based on strategy
        if self._database_strategy == 'managed':
            if not self._database_type:
                errors.append("Managed database requires database type")
            if not self._database_name:
                errors.append("Managed database requires database name")
        elif self._database_strategy == 'container':
            if not self._database_container_name:
                errors.append("Container strategy requires container/service name")
            if not self._database_name:
                errors.append("Container strategy requires database name")
        elif self._database_strategy == 'external':
            if not self._database_host:
                errors.append("External database requires host address")
            if not self._database_name:
                errors.append("External database requires database name")

        # Port validation
        if self._database_strategy in ['container', 'external']:
            if self._database_port < 1 or self._database_port > 65535:
                errors.append("Database port must be between 1 and 65535")

        return errors

    @pyqtSlot(str, result='QVariantMap')
    def validateField(self, field_name: str) -> Dict[str, Any]:
        """Validate a specific field and return result.
        
        Args:
            field_name: Name of the field to validate
            
        Returns:
            Dictionary with 'valid' (bool) and 'message' (str) keys
        """
        from .validators import ConfigValidator, SecretValidator
        
        result = {'valid': True, 'message': ''}
        
        if field_name == 'databaseHost':
            validation = ConfigValidator.validate_hostname(self._database_host)
            result['valid'] = validation.valid
            result['message'] = validation.message
            
        elif field_name == 'databasePort':
            validation = ConfigValidator.validate_port(self._database_port, warn_dangerous=True)
            result['valid'] = validation.valid
            result['message'] = validation.message
            
        elif field_name == 'hostPort':
            validation = ConfigValidator.validate_port(self._host_port, warn_dangerous=False)
            result['valid'] = validation.valid
            result['message'] = validation.message
            
        elif field_name == 'databaseVersion':
            validation = ConfigValidator.validate_version_tag(self._database_version)
            result['valid'] = validation.valid
            result['message'] = validation.message
            
        elif field_name == 'traefikRule':
            validation = ConfigValidator.validate_traefik_rule(self._traefik_rule)
            result['valid'] = validation.valid
            result['message'] = validation.message
            
        elif field_name == 'cpuLimit':
            validation = ConfigValidator.validate_cpu_limit(self._cpu_limit)
            result['valid'] = validation.valid
            result['message'] = validation.message
            
        elif field_name == 'memoryLimit':
            validation = ConfigValidator.validate_memory_limit(self._memory_limit)
            result['valid'] = validation.valid
            result['message'] = validation.message
            
        return result

    @pyqtSlot()
    def applySmartDefaults(self):
        """Apply smart defaults based on current deployment mode."""
        if self._deployment_mode == 'standalone':
            # Standalone mode defaults
            self.networkType = 'bridge'
            self.secretType = 'env'
            self.replicas = 1
            
        elif self._deployment_mode == 'swarm':
            # Swarm mode defaults
            self.networkType = 'overlay'
            self.secretType = 'docker-secret'
            # Keep replicas as set by user
            
    @pyqtSlot(result='QVariantMap')
    def getRecommendations(self) -> Dict[str, Any]:
        """Get recommendations for current configuration.
        
        Returns:
            Dictionary with recommendations
        """
        recommendations = {
            'secretStrategy': self._get_secret_recommendation(),
            'networkType': self._get_network_recommendation(),
            'resourceLimits': self._get_resource_recommendation(),
            'security': self._get_security_recommendations()
        }
        return recommendations

    @pyqtSlot(str, result=int)
    def getDefaultPortForDatabase(self, db_type: str) -> int:
        """Get default port for database type.
        
        Args:
            db_type: Database type (mariadb, postgresql, mysql, mongodb)
            
        Returns:
            Default port number
        """
        port_defaults = {
            'mariadb': 3306,
            'mysql': 3306,
            'postgresql': 5432,
            'mongodb': 27017,
            'redis': 6379
        }
        return port_defaults.get(db_type, 3306)

    @pyqtSlot(result=str)
    def getDatabaseConnectionPreview(self) -> str:
        """Get database connection string preview.
        
        Returns:
            Connection string preview
        """
        if self._database_strategy == 'none':
            return "No database configured"
        
        # Determine host based on strategy
        if self._database_strategy == 'managed':
            host = f"{self._database_type}-db"
        elif self._database_strategy == 'container':
            host = self._database_container_name or "container-name"
        else:  # external
            host = self._database_host or "hostname"
        
        # Build connection string based on database type
        db_name = self._database_name or "database"
        username = self._database_username or "user"
        port = self._database_port
        
        if self._database_type in ['mariadb', 'mysql']:
            return f"mysql://{username}@{host}:{port}/{db_name}"
        elif self._database_type == 'postgresql':
            return f"postgresql://{username}@{host}:{port}/{db_name}"
        elif self._database_type == 'mongodb':
            return f"mongodb://{username}@{host}:{port}/{db_name}"
        else:
            return f"{self._database_type}://{username}@{host}:{port}/{db_name}"
        
    def _get_secret_recommendation(self) -> str:
        """Get secret strategy recommendation."""
        if self._deployment_mode == 'swarm':
            return "Docker Secrets (native Swarm integration)"
        else:
            return "Environment File (.env) - Simple and secure for single host"
            
    def _get_network_recommendation(self) -> str:
        """Get network type recommendation."""
        if self._deployment_mode == 'swarm':
            return "Overlay network for multi-host communication"
        else:
            return "Bridge network for single-host isolation"
            
    def _get_resource_recommendation(self) -> str:
        """Get resource limits recommendation."""
        if not self._memory_limit and not self._cpu_limit:
            return "⚠️ Consider setting resource limits to prevent resource exhaustion"
        return "✓ Resource limits configured"
        
    def _get_security_recommendations(self) -> List[str]:
        """Get security recommendations."""
        recommendations = []
        
        # Check for exposed database ports
        if self._expose_ports and self._database_strategy == 'internal':
            if self._database_port in ConfigValidator.DANGEROUS_PORTS:
                recommendations.append(
                    f"⚠️ Database port {self._database_port} should not be exposed publicly"
                )
        
        # Check SSL
        if self._ingress_enabled and not self._ssl_enabled:
            recommendations.append("⚠️ Enable SSL/TLS for production deployments")
            
        # Check restart policy
        if self._restart_policy == 'no':
            recommendations.append("⚠️ Consider using 'unless-stopped' restart policy")
            
        return recommendations
