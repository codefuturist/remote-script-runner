"""Inventory routes."""

from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, status

from iac_manager.web.auth.dependencies import ActiveUser
from iac_manager.web.schemas.common import MessageResponse, PaginatedResponse
from iac_manager.web.schemas.inventory import (
    GroupCreate,
    GroupResponse,
    GroupUpdate,
    HostCreate,
    HostResponse,
    HostUpdate,
    InventorySummary,
)
from iac_manager.web.services import ServiceProvider, get_services

router = APIRouter()


# ============== Hosts ==============


@router.get("/hosts", response_model=PaginatedResponse[HostResponse])
async def list_hosts(
    current_user: ActiveUser,
    services: Annotated[ServiceProvider, Depends(get_services)],
    group: str | None = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
) -> PaginatedResponse[HostResponse]:
    """List all hosts with optional group filter."""
    hosts = await services.inventory.list_hosts(group=group)

    # Convert to response models
    items = [HostResponse.from_domain(h) for h in hosts]

    # Paginate
    total = len(items)
    start = (page - 1) * page_size
    end = start + page_size
    paginated_items = items[start:end]

    return PaginatedResponse.create(
        items=paginated_items,
        total=total,
        page=page,
        page_size=page_size,
    )


@router.get("/hosts/{host_name}", response_model=HostResponse)
async def get_host(
    host_name: str,
    current_user: ActiveUser,
    services: Annotated[ServiceProvider, Depends(get_services)],
) -> HostResponse:
    """Get a specific host by name."""
    host = await services.inventory.get_host(host_name)

    if not host:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Host {host_name} not found",
        )

    return HostResponse.from_domain(host)


@router.post("/hosts", response_model=HostResponse, status_code=status.HTTP_201_CREATED)
async def create_host(
    data: HostCreate,
    current_user: ActiveUser,
    services: Annotated[ServiceProvider, Depends(get_services)],
) -> HostResponse:
    """Create a new host."""
    existing = await services.inventory.get_host(data.name)

    if existing:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Host {data.name} already exists",
        )

    try:
        host = await services.inventory.create_host(
            name=data.name,
            ansible_host=data.ansible_host,
            ansible_user=data.ansible_user,
            ansible_port=data.ansible_port,
            labels=data.labels,
            groups=data.groups,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )

    return HostResponse.from_domain(host)


@router.patch("/hosts/{host_name}", response_model=HostResponse)
async def update_host(
    host_name: str,
    data: HostUpdate,
    current_user: ActiveUser,
    services: Annotated[ServiceProvider, Depends(get_services)],
) -> HostResponse:
    """Update an existing host."""
    host = await services.inventory.get_host(host_name)

    if not host:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Host {host_name} not found",
        )

    try:
        updated = await services.inventory.update_host(
            name=host_name,
            ansible_host=data.ansible_host,
            ansible_user=data.ansible_user,
            ansible_port=data.ansible_port,
            labels=data.labels,
            groups=data.groups,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )

    return HostResponse.from_domain(updated)


@router.delete("/hosts/{host_name}", response_model=MessageResponse)
async def delete_host(
    host_name: str,
    current_user: ActiveUser,
    services: Annotated[ServiceProvider, Depends(get_services)],
) -> MessageResponse:
    """Delete a host."""
    host = await services.inventory.get_host(host_name)

    if not host:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Host {host_name} not found",
        )

    try:
        await services.inventory.delete_host(host_name)
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )

    return MessageResponse(message=f"Host {host_name} deleted successfully")


# ============== Groups ==============


@router.get("/groups", response_model=PaginatedResponse[GroupResponse])
async def list_groups(
    current_user: ActiveUser,
    services: Annotated[ServiceProvider, Depends(get_services)],
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
) -> PaginatedResponse[GroupResponse]:
    """List all groups."""
    groups = await services.inventory.list_groups()

    # Convert to response models
    items = [GroupResponse.from_domain(g) for g in groups]

    # Paginate
    total = len(items)
    start = (page - 1) * page_size
    end = start + page_size
    paginated_items = items[start:end]

    return PaginatedResponse.create(
        items=paginated_items,
        total=total,
        page=page,
        page_size=page_size,
    )


@router.get("/groups/{group_name}", response_model=GroupResponse)
async def get_group(
    group_name: str,
    current_user: ActiveUser,
    services: Annotated[ServiceProvider, Depends(get_services)],
) -> GroupResponse:
    """Get a specific group by name."""
    group = await services.inventory.get_group(group_name)

    if not group:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Group {group_name} not found",
        )

    return GroupResponse.from_domain(group)


@router.post("/groups", response_model=GroupResponse, status_code=status.HTTP_201_CREATED)
async def create_group(
    data: GroupCreate,
    current_user: ActiveUser,
    services: Annotated[ServiceProvider, Depends(get_services)],
) -> GroupResponse:
    """Create a new group."""
    existing = await services.inventory.get_group(data.name)

    if existing:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Group {data.name} already exists",
        )

    try:
        group = await services.inventory.create_group(
            name=data.name,
            hosts=data.hosts,
            vars=data.vars,
            children=data.children,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )

    return GroupResponse.from_domain(group)


@router.patch("/groups/{group_name}", response_model=GroupResponse)
async def update_group(
    group_name: str,
    data: GroupUpdate,
    current_user: ActiveUser,
    services: Annotated[ServiceProvider, Depends(get_services)],
) -> GroupResponse:
    """Update an existing group."""
    group = await services.inventory.get_group(group_name)

    if not group:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Group {group_name} not found",
        )

    try:
        updated = await services.inventory.update_group(
            name=group_name,
            hosts=data.hosts,
            vars=data.vars,
            children=data.children,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )

    return GroupResponse.from_domain(updated)


@router.delete("/groups/{group_name}", response_model=MessageResponse)
async def delete_group(
    group_name: str,
    current_user: ActiveUser,
    services: Annotated[ServiceProvider, Depends(get_services)],
) -> MessageResponse:
    """Delete a group."""
    group = await services.inventory.get_group(group_name)

    if not group:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Group {group_name} not found",
        )

    try:
        await services.inventory.delete_group(group_name)
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )

    return MessageResponse(message=f"Group {group_name} deleted successfully")


# ============== Summary ==============


@router.get("/summary", response_model=InventorySummary)
async def get_inventory_summary(
    current_user: ActiveUser,
    services: Annotated[ServiceProvider, Depends(get_services)],
) -> InventorySummary:
    """Get inventory summary with counts."""
    hosts = await services.inventory.list_hosts()
    groups = await services.inventory.list_groups()

    # Count hosts per group
    hosts_by_group: dict[str, int] = {}
    for host in hosts:
        for group in host.groups:
            hosts_by_group[group] = hosts_by_group.get(group, 0) + 1

    return InventorySummary(
        total_hosts=len(hosts),
        total_groups=len(groups),
        hosts_by_group=hosts_by_group,
    )
