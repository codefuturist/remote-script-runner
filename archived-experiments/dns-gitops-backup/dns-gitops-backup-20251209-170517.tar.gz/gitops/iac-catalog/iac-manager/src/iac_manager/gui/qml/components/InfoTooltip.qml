// InfoTooltip.qml - Reusable info icon with tooltip
import QtQuick
import QtQuick.Controls
import "../theme"

Icon {
    id: root
    
    property string tooltipText: ""
    property int tooltipDelay: 500
    
    name: "help-circle"
    size: 16
    color: Theme.textSecondary
    
    ToolTip.visible: mouseArea.containsMouse
    ToolTip.text: root.tooltipText
    ToolTip.delay: root.tooltipDelay
    
    MouseArea {
        id: mouseArea
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
    }
    
    // Hover effect
    opacity: mouseArea.containsMouse ? 1.0 : 0.7
    
    Behavior on opacity {
        NumberAnimation { duration: 150 }
    }
}
