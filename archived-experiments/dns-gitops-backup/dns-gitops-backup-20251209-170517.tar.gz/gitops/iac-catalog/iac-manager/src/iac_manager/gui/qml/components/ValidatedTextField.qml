// ValidatedTextField.qml - Text field with inline validation
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "../theme"

ColumnLayout {
    id: root
    
    property alias text: textField.text
    property alias placeholderText: textField.placeholderText
    property string label: ""
    property string tooltipText: ""
    property string fieldName: ""
    property var backend: null
    property bool required: false
    property bool isValid: true
    property string errorMessage: ""
    
    signal textChanged(string text)
    signal editingFinished()
    
    spacing: Theme.spacing1
    
    // Label with optional tooltip
    RowLayout {
        visible: label.length > 0
        spacing: Theme.spacing1
        
        Label {
            text: root.label + (root.required ? " *" : "")
            font.pixelSize: Theme.fontSizeSmall
            font.weight: Theme.fontWeightMedium
            color: Theme.textPrimary
        }
        
        Icon {
            visible: tooltipText.length > 0
            name: "help-circle"
            size: 14
            color: Theme.textSecondary
            
            ToolTip.visible: hovered
            ToolTip.text: root.tooltipText
            ToolTip.delay: 500
            
            MouseArea {
                anchors.fill: parent
                hoverEnabled: true
            }
        }
    }
    
    // Text field
    TextField {
        id: textField
        Layout.fillWidth: true
        font.pixelSize: Theme.fontSizeNormal
        
        background: Rectangle {
            color: textField.enabled ? Theme.surfaceColor : Theme.disabledColor
            border.color: {
                if (!root.isValid) return Theme.errorColor
                if (textField.activeFocus) return Theme.primaryColor
                return Theme.borderColor
            }
            border.width: textField.activeFocus ? 2 : 1
            radius: Theme.radiusNormal
        }
        
        onTextChanged: {
            root.textChanged(text)
            if (root.backend && root.fieldName.length > 0) {
                // Validate on change (debounced would be better)
                Qt.callLater(function() {
                    root.backend.validateFieldAndEmit(root.fieldName)
                })
            }
        }
        
        onEditingFinished: {
            root.editingFinished()
            if (root.backend && root.fieldName.length > 0) {
                root.backend.validateFieldAndEmit(root.fieldName)
            }
        }
    }
    
    // Validation status
    RowLayout {
        visible: !root.isValid || root.errorMessage.length > 0
        spacing: Theme.spacing1
        Layout.fillWidth: true
        
        Icon {
            name: root.isValid ? "alert-circle" : "x-circle"
            size: 14
            color: root.isValid ? Theme.warningColor : Theme.errorColor
        }
        
        Label {
            text: root.errorMessage
            font.pixelSize: Theme.fontSizeSmall
            color: root.isValid ? Theme.warningColor : Theme.errorColor
            wrapMode: Text.WordWrap
            Layout.fillWidth: true
        }
    }
    
    // Valid indicator (optional, shows checkmark when valid)
    Icon {
        visible: root.isValid && root.text.length > 0 && root.errorMessage.length === 0
        name: "check-circle"
        size: 14
        color: Theme.successColor
        Layout.alignment: Qt.AlignRight
    }
    
    // Connect to backend validation signals
    Connections {
        target: root.backend
        
        function onFieldValidationChanged(fieldName, valid, message) {
            if (fieldName === root.fieldName) {
                root.isValid = valid
                root.errorMessage = message
            }
        }
    }
}
