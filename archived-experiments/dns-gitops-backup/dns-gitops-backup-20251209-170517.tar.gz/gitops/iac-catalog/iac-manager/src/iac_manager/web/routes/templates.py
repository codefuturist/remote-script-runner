"""Template routes."""

from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, status

from iac_manager.models import TargetType
from iac_manager.web.auth.dependencies import ActiveUser
from iac_manager.web.schemas.common import PaginatedResponse
from iac_manager.web.schemas.templates import (
    CategoryInfo,
    TemplateParams,
    TemplateReadme,
    TemplateResponse,
    TemplateSearchRequest,
)
from iac_manager.web.services import ServiceProvider, get_services

router = APIRouter()


@router.get("", response_model=PaginatedResponse[TemplateResponse])
async def list_templates(
    current_user: ActiveUser,
    services: Annotated[ServiceProvider, Depends(get_services)],
    category: str | None = None,
    target_type: TargetType | None = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
) -> PaginatedResponse[TemplateResponse]:
    """List all available templates."""
    templates = await services.templates.list_templates(
        category=category,
    )

    # Filter by target type if specified
    if target_type:
        templates = [t for t in templates if target_type in t.target_types]

    # Convert to response models
    items = [TemplateResponse.from_domain(t) for t in templates]

    # Paginate
    total = len(items)
    start = (page - 1) * page_size
    end = start + page_size
    paginated_items = items[start:end]

    return PaginatedResponse.create(
        items=paginated_items,
        total=total,
        page=page,
        page_size=page_size,
    )


@router.get("/categories", response_model=list[CategoryInfo])
async def list_categories(
    current_user: ActiveUser,
    services: Annotated[ServiceProvider, Depends(get_services)],
) -> list[CategoryInfo]:
    """List all template categories with counts."""
    templates = await services.templates.list_templates()

    # Count templates per category
    category_data: dict[str, dict] = {}
    for template in templates:
        cat = template.category
        if cat not in category_data:
            category_data[cat] = {"count": 0, "subcategories": set()}
        category_data[cat]["count"] += 1
        if template.subcategory:
            category_data[cat]["subcategories"].add(template.subcategory)

    return [
        CategoryInfo(
            name=name,
            count=data["count"],
            subcategories=sorted(data["subcategories"]),
        )
        for name, data in sorted(category_data.items())
    ]


@router.post("/search", response_model=PaginatedResponse[TemplateResponse])
async def search_templates(
    data: TemplateSearchRequest,
    current_user: ActiveUser,
    services: Annotated[ServiceProvider, Depends(get_services)],
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
) -> PaginatedResponse[TemplateResponse]:
    """Search templates by name, description, or category."""
    templates = await services.templates.search_templates(
        query=data.query,
        categories=data.categories,
    )

    # Filter by target types if specified
    if data.target_types:
        templates = [
            t
            for t in templates
            if any(tt in t.target_types for tt in data.target_types)
        ]

    # Convert to response models
    items = [TemplateResponse.from_domain(t) for t in templates]

    # Paginate
    total = len(items)
    start = (page - 1) * page_size
    end = start + page_size
    paginated_items = items[start:end]

    return PaginatedResponse.create(
        items=paginated_items,
        total=total,
        page=page,
        page_size=page_size,
    )


@router.get("/{template_path:path}", response_model=TemplateResponse)
async def get_template(
    template_path: str,
    current_user: ActiveUser,
    services: Annotated[ServiceProvider, Depends(get_services)],
) -> TemplateResponse:
    """Get a specific template by path."""
    template = await services.templates.get_template(template_path)

    if not template:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Template {template_path} not found",
        )

    return TemplateResponse.from_domain(template)


@router.get("/{template_path:path}/params", response_model=TemplateParams)
async def get_template_params(
    template_path: str,
    current_user: ActiveUser,
    services: Annotated[ServiceProvider, Depends(get_services)],
) -> TemplateParams:
    """Get template parameters and their defaults."""
    template = await services.templates.get_template(template_path)

    if not template:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Template {template_path} not found",
        )

    params = await services.templates.get_template_params(template_path)

    return TemplateParams(
        template=template_path,
        required=params.get("required", []),
        optional=params.get("optional", []),
        defaults=params.get("defaults", {}),
    )


@router.get("/{template_path:path}/readme", response_model=TemplateReadme)
async def get_template_readme(
    template_path: str,
    current_user: ActiveUser,
    services: Annotated[ServiceProvider, Depends(get_services)],
) -> TemplateReadme:
    """Get template README content."""
    template = await services.templates.get_template(template_path)

    if not template:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Template {template_path} not found",
        )

    if not template.has_readme:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Template {template_path} has no README",
        )

    content = await services.templates.get_template_readme(template_path)

    return TemplateReadme(
        template=template_path,
        content=content,
        format="markdown",
    )
