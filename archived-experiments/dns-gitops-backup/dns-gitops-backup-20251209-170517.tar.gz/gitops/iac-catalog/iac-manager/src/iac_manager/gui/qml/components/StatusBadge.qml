// StatusBadge.qml - Enhanced status indicator component
import QtQuick
import QtQuick.Controls
import "../theme"

Rectangle {
    id: badge
    
    property string status: "info" // success, warning, error, info, neutral
    property string badgeText: ""
    property string iconName: ""
    property bool dot: false
    property bool outlined: false
    property string size: "medium" // small, medium, large
    
    implicitWidth: badgeContent.implicitWidth + getPadding() * 2
    implicitHeight: getHeight()
    radius: Theme.radiusFull
    
    color: outlined ? "transparent" : getBackgroundColor()
    border.width: outlined ? 2 : 0
    border.color: getColor()
    
    Behavior on color {
        ColorAnimation { duration: Theme.animationDurationFast }
    }
    
    Behavior on border.color {
        ColorAnimation { duration: Theme.animationDurationFast }
    }
    
    Row {
        id: badgeContent
        anchors.centerIn: parent
        spacing: Theme.spacing1
        
        // Status dot
        Rectangle {
            visible: dot
            width: getDotSize()
            height: width
            radius: width / 2
            color: getColor()
            anchors.verticalCenter: parent.verticalCenter
            
            // Pulse animation for errors
            SequentialAnimation on opacity {
                running: status === "error" && dot
                loops: Animation.Infinite
                NumberAnimation { to: 0.4; duration: 800; easing.type: Easing.InOutCubic }
                NumberAnimation { to: 1.0; duration: 800; easing.type: Easing.InOutCubic }
            }
        }
        
        // Icon
        Text {
            visible: iconName !== "" && !dot
            text: getIconCode()
            font.pixelSize: getIconSize()
            color: outlined ? getColor() : "white"
            verticalAlignment: Text.AlignVCenter
            anchors.verticalCenter: parent.verticalCenter
        }
        
        // Text
        Label {
            visible: badgeText !== ""
            text: badge.badgeText
            color: outlined ? getColor() : "white"
            font.pixelSize: getFontSize()
            font.weight: Theme.fontWeightSemiBold
            verticalAlignment: Text.AlignVCenter
            anchors.verticalCenter: parent.verticalCenter
        }
    }
    
    // Helper functions
    function getHeight() {
        switch(size) {
            case "small": return 20
            case "large": return 32
            default: return 24
        }
    }
    
    function getPadding() {
        if (dot && badgeText === "") return Theme.spacing1
        switch(size) {
            case "small": return Theme.spacing2
            case "large": return Theme.spacing4
            default: return Theme.spacing3
        }
    }
    
    function getFontSize() {
        switch(size) {
            case "small": return Theme.fontSizeXS
            case "large": return Theme.fontSizeNormal
            default: return Theme.fontSizeSmall
        }
    }
    
    function getIconSize() {
        switch(size) {
            case "small": return Theme.iconSizeXS
            case "large": return Theme.iconSize
            default: return Theme.iconSizeSmall
        }
    }
    
    function getDotSize() {
        switch(size) {
            case "small": return 6
            case "large": return 10
            default: return 8
        }
    }
    
    function getColor() {
        switch (status) {
            case "success": return Theme.success
            case "warning": return Theme.warning
            case "error": return Theme.error
            case "info": return Theme.info
            case "neutral": return Theme.gray500
            default: return Theme.textSecondary
        }
    }
    
    function getBackgroundColor() {
        if (outlined) return "transparent"
        
        switch (status) {
            case "success": return Theme.success
            case "warning": return Theme.warning
            case "error": return Theme.error
            case "info": return Theme.info
            case "neutral": return Theme.gray500
            default: return Theme.textSecondary
        }
    }
    
    function getIconCode() {
        if (iconName !== "") {
            switch(iconName) {
                case "check": return "✓"
                case "warning": return "⚠"
                case "error": return "✕"
                case "info": return "ℹ"
                case "circle": return "●"
                default: return iconName
            }
        }
        
        // Auto icon based on status
        switch (status) {
            case "success": return "✓"
            case "warning": return "⚠"
            case "error": return "✕"
            case "info": return "ℹ"
            default: return "●"
        }
    }
}

