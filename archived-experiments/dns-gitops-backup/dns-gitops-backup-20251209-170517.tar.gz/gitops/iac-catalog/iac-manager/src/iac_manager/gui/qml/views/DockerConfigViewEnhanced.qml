// DockerConfigView.qml - Enhanced Docker deployment configuration view
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "../components"
import "../theme"

Item {
    id: root
    
    property var backend: null
    property bool showPresets: true
    property bool advancedMode: false
    
    StackView {
        id: stackView
        anchors.fill: parent
        initialItem: showPresets ? presetSelectionView : configurationView
    }
    
    // Preset Selection View
    Component {
        id: presetSelectionView
        
        Rectangle {
            color: Theme.backgroundColor
            
            ScrollView {
                anchors.fill: parent
                anchors.margins: Theme.spacingLarge
                clip: true
                
                ColumnLayout {
                    width: parent.width - Theme.spacingLarge * 2
                    spacing: Theme.spacingMedium
                    
                    Label {
                        text: "Docker Configuration"
                        font.pixelSize: Theme.fontSizeH2
                        font.weight: Theme.fontWeightBold
                        color: Theme.textPrimary
                    }
                    
                    Label {
                        text: "Choose a preset or create a custom configuration"
                        font.pixelSize: Theme.fontSizeNormal
                        color: Theme.textSecondary
                        Layout.fillWidth: true
                    }
                    
                    PresetSelector {
                        Layout.fillWidth: true
                        Layout.preferredHeight: 400
                        backend: root.backend
                        
                        onPresetSelected: function(presetId) {
                            stackView.push(configurationView)
                        }
                    }
                }
            }
        }
    }
    
    // Configuration View
    Component {
        id: configurationView
        
        SplitView {
            orientation: Qt.Horizontal
            
            // Left side: Configuration options
            Rectangle {
                SplitView.preferredWidth: parent.width * 0.4
                SplitView.minimumWidth: 300
                color: Theme.backgroundColor
                
                ScrollView {
                    anchors.fill: parent
                    anchors.margins: Theme.spacingMedium
                    clip: true
                    
                    ColumnLayout {
                        width: parent.width - Theme.spacingMedium * 2
                        spacing: Theme.spacingMedium
                        
                        // Header with back button
                        RowLayout {
                            Layout.fillWidth: true
                            
                            CustomButton {
                                visible: showPresets
                                text: "← Presets"
                                buttonType: "text"
                                size: "small"
                                onClicked: stackView.pop()
                            }
                            
                            Item { Layout.fillWidth: true }
                            
                            // Mode toggle
                            RowLayout {
                                spacing: Theme.spacing1
                                
                                Label {
                                    text: "Mode:"
                                    font.pixelSize: Theme.fontSizeSmall
                                    color: Theme.textSecondary
                                }
                                
                                Switch {
                                    id: modeSwitch
                                    checked: root.advancedMode
                                    onToggled: root.advancedMode = checked
                                    
                                    ToolTip.visible: hovered
                                    ToolTip.text: checked ? "Advanced Mode" : "Basic Mode"
                                }
                            }
                        }
                        
                        Label {
                            text: "Docker Configuration"
                            font.pixelSize: Theme.fontSizeH3
                            font.weight: Theme.fontWeightBold
                            color: Theme.textPrimary
                        }
                        
                        Label {
                            text: root.advancedMode ? 
                                "All configuration options" : 
                                "Essential configuration options"
                            font.pixelSize: Theme.fontSizeNormal
                            color: Theme.textSecondary
                            wrapMode: Text.WordWrap
                            Layout.fillWidth: true
                        }
                        
                        // Deployment Mode Card
                        Card {
                            Layout.fillWidth: true
                            
                            ColumnLayout {
                                anchors.fill: parent
                                spacing: Theme.spacing2
                                
                                RowLayout {
                                    Layout.fillWidth: true
                                    
                                    Label {
                                        text: "Deployment Mode"
                                        font.pixelSize: Theme.fontSizeH5
                                        font.weight: Theme.fontWeightMedium
                                        color: Theme.textPrimary
                                    }
                                    
                                    InfoTooltip {
                                        tooltipText: "Standalone for single host, Swarm for multi-host clusters"
                                    }
                                }
                                
                                RowLayout {
                                    Layout.fillWidth: true
                                    spacing: Theme.spacing2
                                    
                                    ComboBox {
                                        id: deploymentMode
                                        Layout.fillWidth: true
                                        model: ["Docker Standalone", "Docker Swarm"]
                                        
                                        background: Rectangle {
                                            color: Theme.surfaceColor
                                            border.color: Theme.borderColor
                                            border.width: 1
                                            radius: Theme.radiusNormal
                                        }
                                        
                                        onCurrentIndexChanged: {
                                            if (backend && backend.dockerConfig) {
                                                backend.dockerConfig.deploymentMode = 
                                                    currentIndex === 0 ? "standalone" : "swarm"
                                            }
                                        }
                                    }
                                    
                                    RecommendedBadge {
                                        visible: deploymentMode.currentIndex === 0
                                        text: "Beginner"
                                        tooltipText: "Recommended for getting started and single-host deployments"
                                    }
                                }
                                
                                Label {
                                    text: deploymentMode.currentIndex === 0 ?
                                        "✓ Single-host Docker deployment" :
                                        "⚙️ Multi-host cluster with orchestration"
                                    font.pixelSize: Theme.fontSizeSmall
                                    color: Theme.textSecondary
                                    wrapMode: Text.WordWrap
                                    Layout.fillWidth: true
                                }
                            }
                        }
                        
                        // Ingress Card
                        Card {
                            Layout.fillWidth: true
                            visible: !root.advancedMode || ingressEnabled.checked
                            
                            ColumnLayout {
                                anchors.fill: parent
                                spacing: Theme.spacing2
                                
                                RowLayout {
                                    Layout.fillWidth: true
                                    
                                    Label {
                                        text: "Ingress / Reverse Proxy"
                                        font.pixelSize: Theme.fontSizeH5
                                        font.weight: Theme.fontWeightMedium
                                        color: Theme.textPrimary
                                    }
                                    
                                    InfoTooltip {
                                        tooltipText: "Traefik handles routing, SSL certificates, and load balancing"
                                    }
                                }
                                
                                CheckBox {
                                    id: ingressEnabled
                                    text: "Enable Ingress"
                                    
                                    onCheckedChanged: {
                                        if (backend && backend.dockerConfig) {
                                            backend.dockerConfig.ingressEnabled = checked
                                        }
                                    }
                                }
                                
                                ColumnLayout {
                                    visible: ingressEnabled.checked
                                    Layout.fillWidth: true
                                    spacing: Theme.spacing2
                                    
                                    ComboBox {
                                        id: ingressType
                                        Layout.fillWidth: true
                                        model: ["Traefik"]
                                        
                                        background: Rectangle {
                                            color: Theme.surfaceColor
                                            border.color: Theme.borderColor
                                            border.width: 1
                                            radius: Theme.radiusNormal
                                        }
                                    }
                                    
                                    ValidatedTextField {
                                        Layout.fillWidth: true
                                        label: "Traefik Routing Rule"
                                        placeholderText: "Host(`app.example.com`)"
                                        text: "Host(`app.local`)"
                                        fieldName: "traefikRule"
                                        backend: root.backend
                                        tooltipText: "Define how Traefik routes traffic to your service"
                                        
                                        onTextChanged: function(newText) {
                                            if (backend && backend.dockerConfig) {
                                                backend.dockerConfig.traefikRule = newText
                                            }
                                        }
                                    }
                                    
                                    RowLayout {
                                        Layout.fillWidth: true
                                        
                                        CheckBox {
                                            id: sslEnabled
                                            text: "Enable SSL/TLS"
                                            
                                            onCheckedChanged: {
                                                if (backend && backend.dockerConfig) {
                                                    backend.dockerConfig.sslEnabled = checked
                                                }
                                            }
                                        }
                                        
                                        RecommendedBadge {
                                            visible: !sslEnabled.checked
                                            text: "Enable for production"
                                            tooltipText: "SSL/TLS encryption is essential for production deployments"
                                        }
                                    }
                                }
                            }
                        }
                        
                        // Secrets Card
                        Card {
                            Layout.fillWidth: true
                            
                            ColumnLayout {
                                anchors.fill: parent
                                spacing: Theme.spacing2
                                
                                RowLayout {
                                    Layout.fillWidth: true
                                    
                                    Label {
                                        text: "Secrets Management"
                                        font.pixelSize: Theme.fontSizeH5
                                        font.weight: Theme.fontWeightMedium
                                        color: Theme.textPrimary
                                    }
                                    
                                    InfoTooltip {
                                        tooltipText: "Choose how sensitive data like passwords and API keys will be managed"
                                    }
                                }
                                
                                RowLayout {
                                    Layout.fillWidth: true
                                    spacing: Theme.spacing2
                                    
                                    ComboBox {
                                        id: secretType
                                        Layout.fillWidth: true
                                        model: [
                                            "Environment File (.env)",
                                            "File-based Secrets",
                                            "Docker Secrets (Swarm)"
                                        ]
                                        
                                        background: Rectangle {
                                            color: Theme.surfaceColor
                                            border.color: Theme.borderColor
                                            border.width: 1
                                            radius: Theme.radiusNormal
                                        }
                                        
                                        onCurrentIndexChanged: {
                                            if (backend && backend.dockerConfig) {
                                                var types = ["env", "file", "docker-secret"]
                                                backend.dockerConfig.secretType = types[currentIndex]
                                            }
                                        }
                                    }
                                    
                                    RecommendedBadge {
                                        visible: secretType.currentIndex === 0 && deploymentMode.currentIndex === 0
                                        text: "Recommended"
                                        tooltipText: "Best balance of security and simplicity for standalone deployments"
                                    }
                                }
                                
                                // Strategy explanation
                                Rectangle {
                                    Layout.fillWidth: true
                                    Layout.preferredHeight: strategyLabel.implicitHeight + Theme.spacing2 * 2
                                    color: Theme.successColorLight
                                    border.color: Theme.successColor
                                    border.width: 1
                                    radius: Theme.radiusNormal
                                    visible: secretType.currentIndex === 0
                                    
                                    Label {
                                        id: strategyLabel
                                        anchors.fill: parent
                                        anchors.margins: Theme.spacing2
                                        text: "✓ Secrets stored in .env file, not in docker-compose.yml"
                                        font.pixelSize: Theme.fontSizeSmall
                                        color: Theme.successColorDark
                                        wrapMode: Text.WordWrap
                                    }
                                }
                                
                                Label {
                                    text: getSecretDescription()
                                    font.pixelSize: Theme.fontSizeSmall
                                    color: Theme.textSecondary
                                    wrapMode: Text.WordWrap
                                    Layout.fillWidth: true
                                    
                                    function getSecretDescription() {
                                        switch(secretType.currentIndex) {
                                            case 0: return ".env file keeps secrets separate from configuration"
                                            case 1: return "Secrets mounted as files into containers"
                                            case 2: return "Native Docker Swarm secret management (requires Swarm mode)"
                                            default: return ""
                                        }
                                    }
                                }
                            }
                        }
                        
                        // Network Card (Advanced only)
                        Card {
                            Layout.fillWidth: true
                            visible: root.advancedMode
                            
                            ColumnLayout {
                                anchors.fill: parent
                                spacing: Theme.spacing2
                                
                                RowLayout {
                                    Layout.fillWidth: true
                                    
                                    Label {
                                        text: "Network Configuration"
                                        font.pixelSize: Theme.fontSizeH5
                                        font.weight: Theme.fontWeightMedium
                                        color: Theme.textPrimary
                                    }
                                    
                                    InfoTooltip {
                                        tooltipText: "Control how containers communicate with each other and the outside world"
                                    }
                                }
                                
                                ComboBox {
                                    id: networkType
                                    Layout.fillWidth: true
                                    model: ["Bridge (default)", "Overlay (Swarm)", "Host"]
                                    enabled: deploymentMode.currentIndex === 1 || currentIndex === 0
                                    
                                    background: Rectangle {
                                        color: enabled ? Theme.surfaceColor : Theme.disabledColor
                                        border.color: Theme.borderColor
                                        border.width: 1
                                        radius: Theme.radiusNormal
                                    }
                                    
                                    onCurrentIndexChanged: {
                                        if (backend && backend.dockerConfig) {
                                            var types = ["bridge", "overlay", "host"]
                                            backend.dockerConfig.networkType = types[currentIndex]
                                        }
                                    }
                                }
                                
                                CheckBox {
                                    id: networkExternal
                                    text: "Use External Network"
                                    
                                    onCheckedChanged: {
                                        if (backend && backend.dockerConfig) {
                                            backend.dockerConfig.networkExternal = checked
                                        }
                                    }
                                }
                                
                                CheckBox {
                                    id: networkInternal
                                    text: "Internal Only (no external access)"
                                    
                                    onCheckedChanged: {
                                        if (backend && backend.dockerConfig) {
                                            backend.dockerConfig.networkInternal = checked
                                        }
                                    }
                                }
                            }
                        }
                        
                        // Database Card
                        Card {
                            Layout.fillWidth: true
                            
                            ColumnLayout {
                                anchors.fill: parent
                                spacing: Theme.spacing2
                                
                                RowLayout {
                                    Layout.fillWidth: true
                                    
                                    Label {
                                        text: "Database Configuration"
                                        font.pixelSize: Theme.fontSizeH5
                                        font.weight: Theme.fontWeightMedium
                                        color: Theme.textPrimary
                                    }
                                    
                                    InfoTooltip {
                                        tooltipText: "Configure database deployment or connect to external database"
                                    }
                                }
                                
                                ComboBox {
                                    id: dbStrategy
                                    Layout.fillWidth: true
                                    model: ["No Database", "Internal Container", "External Database"]
                                    
                                    background: Rectangle {
                                        color: Theme.surfaceColor
                                        border.color: Theme.borderColor
                                        border.width: 1
                                        radius: Theme.radiusNormal
                                    }
                                    
                                    onCurrentIndexChanged: {
                                        if (backend && backend.dockerConfig) {
                                            var strategies = ["none", "internal", "external"]
                                            backend.dockerConfig.databaseStrategy = strategies[currentIndex]
                                        }
                                    }
                                }
                                
                                // Internal database options
                                ColumnLayout {
                                    visible: dbStrategy.currentIndex === 1
                                    Layout.fillWidth: true
                                    spacing: Theme.spacing2
                                    
                                    RowLayout {
                                        Layout.fillWidth: true
                                        
                                        Label {
                                            text: "Type:"
                                            Layout.preferredWidth: 60
                                            color: Theme.textPrimary
                                        }
                                        
                                        ComboBox {
                                            id: dbType
                                            Layout.fillWidth: true
                                            model: ["mariadb", "postgresql", "mysql", "mongodb"]
                                            
                                            background: Rectangle {
                                                color: Theme.surfaceColor
                                                border.color: Theme.borderColor
                                                border.width: 1
                                                radius: Theme.radiusNormal
                                            }
                                            
                                            onCurrentTextChanged: {
                                                if (backend && backend.dockerConfig) {
                                                    backend.dockerConfig.databaseType = currentText
                                                }
                                            }
                                        }
                                    }
                                    
                                    ValidatedTextField {
                                        Layout.fillWidth: true
                                        label: "Version"
                                        text: "10.6"
                                        fieldName: "databaseVersion"
                                        backend: root.backend
                                        placeholderText: "e.g., 10.6, latest, 14-alpine"
                                        tooltipText: "Docker image tag for the database"
                                        
                                        onTextChanged: function(newText) {
                                            if (backend && backend.dockerConfig) {
                                                backend.dockerConfig.databaseVersion = newText
                                            }
                                        }
                                    }
                                }
                                
                                // External database options
                                ColumnLayout {
                                    visible: dbStrategy.currentIndex === 2
                                    Layout.fillWidth: true
                                    spacing: Theme.spacing2
                                    
                                    ValidatedTextField {
                                        Layout.fillWidth: true
                                        label: "Host"
                                        placeholderText: "db.example.com"
                                        fieldName: "databaseHost"
                                        backend: root.backend
                                        required: true
                                        tooltipText: "Hostname or IP address of the database server"
                                        
                                        onTextChanged: function(newText) {
                                            if (backend && backend.dockerConfig) {
                                                backend.dockerConfig.databaseHost = newText
                                            }
                                        }
                                    }
                                    
                                    ValidatedTextField {
                                        Layout.fillWidth: true
                                        label: "Port"
                                        text: "3306"
                                        fieldName: "databasePort"
                                        backend: root.backend
                                        tooltipText: "Database server port number"
                                        
                                        onTextChanged: function(newText) {
                                            if (backend && backend.dockerConfig) {
                                                backend.dockerConfig.databasePort = parseInt(newText) || 3306
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        
                        // Resource Limits Card (Advanced only)
                        Card {
                            Layout.fillWidth: true
                            visible: root.advancedMode
                            
                            ColumnLayout {
                                anchors.fill: parent
                                spacing: Theme.spacing2
                                
                                RowLayout {
                                    Layout.fillWidth: true
                                    
                                    Label {
                                        text: "Resource Limits"
                                        font.pixelSize: Theme.fontSizeH5
                                        font.weight: Theme.fontWeightMedium
                                        color: Theme.textPrimary
                                    }
                                    
                                    InfoTooltip {
                                        tooltipText: "Set CPU and memory limits to prevent resource exhaustion"
                                    }
                                }
                                
                                ValidatedTextField {
                                    Layout.fillWidth: true
                                    label: "Memory Limit"
                                    placeholderText: "512m, 2g"
                                    fieldName: "memoryLimit"
                                    backend: root.backend
                                    tooltipText: "Maximum memory (e.g., 512m, 2g)"
                                    
                                    onTextChanged: function(newText) {
                                        if (backend && backend.dockerConfig) {
                                            backend.dockerConfig.memoryLimit = newText
                                        }
                                    }
                                }
                                
                                ValidatedTextField {
                                    Layout.fillWidth: true
                                    label: "CPU Limit"
                                    placeholderText: "0.5, 1, 2"
                                    fieldName: "cpuLimit"
                                    backend: root.backend
                                    tooltipText: "Maximum CPU cores (e.g., 0.5, 1, 2)"
                                    
                                    onTextChanged: function(newText) {
                                        if (backend && backend.dockerConfig) {
                                            backend.dockerConfig.cpuLimit = newText
                                        }
                                    }
                                }
                            }
                        }
                        
                        // Add stretch at the end
                        Item {
                            Layout.fillHeight: true
                        }
                    }
                }
            }
            
            // Right side: Live editable preview
            Rectangle {
                SplitView.fillWidth: true
                color: Theme.surfaceColor
                
                ColumnLayout {
                    anchors.fill: parent
                    anchors.margins: Theme.spacingMedium
                    spacing: Theme.spacingMedium
                    
                    // Header
                    RowLayout {
                        Layout.fillWidth: true
                        
                        Label {
                            text: "Preview: docker-compose.yml"
                            font.pixelSize: Theme.fontSizeH4
                            font.weight: Theme.fontWeightBold
                            color: Theme.textPrimary
                        }
                        
                        Item { Layout.fillWidth: true }
                        
                        CustomButton {
                            text: "Regenerate"
                            iconName: "refresh"
                            buttonType: "outlined"
                            size: "small"
                            onClicked: {
                                if (backend) backend.regeneratePreview()
                            }
                        }
                    }
                    
                    Label {
                        text: "This preview updates automatically. You can edit it directly before deployment."
                        font.pixelSize: Theme.fontSizeSmall
                        color: Theme.textSecondary
                        wrapMode: Text.WordWrap
                        Layout.fillWidth: true
                    }
                    
                    // Preview editor with styling
                    Rectangle {
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        color: "#1e1e1e"
                        border.color: Theme.borderColor
                        border.width: 1
                        radius: Theme.radiusNormal
                        
                        ScrollView {
                            anchors.fill: parent
                            anchors.margins: Theme.spacing2
                            clip: true
                            
                            TextArea {
                                id: previewEditor
                                readOnly: false
                                wrapMode: TextEdit.NoWrap
                                font.family: "Monaco, Courier New, monospace"
                                font.pixelSize: 12
                                color: "#d4d4d4"
                                selectionColor: "#264f78"
                                selectedTextColor: "#ffffff"
                                
                                background: Rectangle {
                                    color: "transparent"
                                }
                                
                                Connections {
                                    target: backend
                                    function onPreviewGenerated(yaml) {
                                        previewEditor.text = yaml
                                    }
                                }
                            }
                        }
                    }
                    
                    // Action buttons
                    RowLayout {
                        Layout.fillWidth: true
                        spacing: Theme.spacing2
                        
                        Label {
                            text: previewEditor.text.split('\n').length + " lines"
                            font.pixelSize: Theme.fontSizeSmall
                            color: Theme.textSecondary
                        }
                        
                        Item { Layout.fillWidth: true }
                        
                        CustomButton {
                            text: "Validate"
                            iconName: "check"
                            buttonType: "outlined"
                            size: "medium"
                            onClicked: {
                                if (backend) {
                                    var isValid = backend.validateConfig()
                                    // Show validation result via toast
                                }
                            }
                        }
                        
                        CustomButton {
                            text: "Apply Configuration"
                            iconName: "save"
                            buttonType: "primary"
                            size: "medium"
                            onClicked: {
                                if (backend) {
                                    backend.applyCustomPreview(previewEditor.text)
                                    // Proceed to next step or deploy
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    Component.onCompleted: {
        if (backend) {
            backend.regeneratePreview()
        }
    }
}
