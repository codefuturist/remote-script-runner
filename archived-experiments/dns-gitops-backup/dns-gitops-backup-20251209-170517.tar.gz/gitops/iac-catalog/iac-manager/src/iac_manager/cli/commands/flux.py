"""FluxCD command group for scaffolding and managing FluxCD applications."""

from pathlib import Path
from typing import Optional

import click
from rich.console import Console
from rich.table import Table

from iac_manager.services.flux_service import FluxScaffoldService
from iac_manager.services.secret_import_service import SecretImportService
from iac_manager.utils.k8s_utils import (
    check_cluster_access,
    is_kubectl_available,
)
from iac_manager.utils.sops_utils import (
    encrypt_file,
    get_encryption_info,
    is_sops_available,
    validate_sops_config
)

console = Console()


@click.group(name="flux")
def flux_group():
    """FluxCD application scaffolding and management."""
    pass


@flux_group.command(name="scaffold")
@click.option("--app-name", "-n", required=True, help="Application name")
@click.option("--chart", "-c", required=True, help="Helm chart (e.g., bitnami/postgresql)")
@click.option("--namespace", "-ns", required=True, help="Kubernetes namespace")
@click.option("--cluster", required=True, type=click.Choice(["staging", "production"]), help="Target cluster")
@click.option("--repo-url", "-r", help="Helm repository URL (required unless --oci)")
@click.option("--version", "-v", help="Chart version (default: latest)")
@click.option("--values-file", "-f", type=click.Path(exists=True, path_type=Path), help="Custom values file")
@click.option("--profile", "-p", default="default", help="Preference profile (default: default)")
@click.option("--environment", "-e", help="Environment (default: inferred from cluster)")
@click.option("--oci", is_flag=True, help="Chart is from OCI registry")
@click.option("--no-namespace", is_flag=True, help="Don't create namespace manifest")
@click.option("--no-secret", is_flag=True, help="Don't create secret template")
@click.option("--no-encrypt", is_flag=True, help="Don't auto-encrypt secrets")
@click.option("--repo-root", type=click.Path(exists=True, path_type=Path), help="Repository root (auto-detect if not provided)")
def scaffold_app(
    app_name: str,
    chart: str,
    namespace: str,
    cluster: str,
    repo_url: Optional[str],
    version: Optional[str],
    values_file: Optional[Path],
    profile: str,
    environment: Optional[str],
    oci: bool,
    no_namespace: bool,
    no_secret: bool,
    no_encrypt: bool,
    repo_root: Optional[Path]
):
    """Scaffold a complete FluxCD application structure.
    
    This command generates a complete FluxCD application with:
    - HelmRelease manifest (with preferences applied)
    - HelmRepository/OCIRepository definition
    - SOPS-encrypted external secret (preferred over embedded secrets)
    - Namespace manifest (optional)
    - Kustomization files
    
    The generated HelmRelease will automatically use external secrets via
    'existingSecret' references instead of embedding credentials in values.
    This follows security best practices and GitOps principles.
    
    Examples:
    
        # Basic PostgreSQL app for staging
        iac flux scaffold -n postgres -c bitnami/postgresql \\
          -ns database --cluster staging \\
          -r https://charts.bitnami.com/bitnami
        
        # Production n8n with custom values
        iac flux scaffold -n n8n -c n8n/n8n \\
          -ns automation --cluster production \\
          -r https://riatlas.github.io/chart__n8n \\
          -f n8n-values.yaml -p default -e production
        
        # OCI registry chart
        iac flux scaffold -n redis -c oci://registry-1.docker.io/bitnamicharts/redis \\
          -ns database --cluster production --oci
    """
    # Validate inputs
    if not oci and not repo_url:
        console.print("[red]Error:[/red] --repo-url is required unless --oci is specified")
        raise click.Abort()
    
    # Find repo root
    if repo_root is None:
        current = Path.cwd()
        while current != current.parent:
            if (current / ".git").exists():
                repo_root = current
                break
            current = current.parent
        
        if repo_root is None:
            console.print("[red]Error:[/red] Could not find repository root. Use --repo-root")
            raise click.Abort()
    
    console.print(f"\n[bold cyan]FluxCD Application Scaffolding[/bold cyan]\n")
    console.print(f"App:       {app_name}")
    console.print(f"Chart:     {chart}")
    console.print(f"Namespace: {namespace}")
    console.print(f"Cluster:   {cluster}")
    console.print(f"Profile:   {profile}")
    console.print(f"")
    
    # Check SOPS availability
    if not no_secret and not no_encrypt and not is_sops_available():
        console.print("[yellow]Warning:[/yellow] SOPS not available, secrets will not be encrypted")
        console.print("Install SOPS: brew install sops")
        no_encrypt = True
    
    # Initialize service
    service = FluxScaffoldService(repo_root=repo_root)
    
    try:
        # Scaffold the app
        created_files = service.scaffold_app(
            app_name=app_name,
            chart=chart,
            namespace=namespace,
            cluster=cluster,
            repo_url=repo_url,
            version=version,
            values_file=values_file,
            profile=profile,
            environment=environment,
            oci=oci,
            create_namespace=not no_namespace,
            create_secret=not no_secret,
            auto_encrypt=not no_encrypt
        )
        
        # Show next steps
        console.print("\n[bold cyan]Next Steps:[/bold cyan]")
        console.print("1. Review generated files")
        console.print(f"2. Update secret values in {app_name}-secret.yaml (if encrypted, use: sops {app_name}-secret.yaml)")
        console.print("3. Customize HelmRelease values if needed")
        console.print("4. Commit and push to Git")
        console.print("5. FluxCD will automatically reconcile and deploy")
        
    except Exception as e:
        console.print(f"\n[red]Error:[/red] {str(e)}")
        raise click.Abort()


@flux_group.command(name="validate")
@click.argument("path", type=click.Path(exists=True, path_type=Path))
@click.option("--profile", "-p", default="default", help="Preference profile to validate against")
@click.option("--environment", "-e", default="production", help="Environment context")
@click.option("--repo-root", type=click.Path(exists=True, path_type=Path), help="Repository root")
def validate_apps(
    path: Path,
    profile: str,
    environment: str,
    repo_root: Optional[Path]
):
    """Validate FluxCD applications against preference standards.
    
    Checks for:
    - Required FluxCD fields (interval, timeout, retries)
    - Resource requests and limits
    - SOPS encryption on secrets
    - Standard security contexts
    
    Examples:
    
        # Validate single app
        iac flux validate catalog/gitops/flux/clusters/staging/apps/production/n8n
        
        # Validate all staging apps
        iac flux validate catalog/gitops/flux/clusters/staging/apps
        
        # Validate against hardened profile
        iac flux validate apps/production/postgres -p hardened
    """
    # Find repo root
    if repo_root is None:
        current = Path.cwd()
        while current != current.parent:
            if (current / ".git").exists():
                repo_root = current
                break
            current = current.parent
        
        if repo_root is None:
            repo_root = Path.cwd()
    
    service = FluxScaffoldService(repo_root=repo_root)
    
    console.print(f"\n[bold cyan]Validating FluxCD Applications[/bold cyan]\n")
    console.print(f"Path:    {path}")
    console.print(f"Profile: {profile}")
    console.print(f"Environment: {environment}\n")
    
    # Collect all app directories
    app_dirs = []
    if path.is_dir():
        # Check if this is an app directory (contains helmrelease files)
        if list(path.glob("*-helmrelease.yaml")):
            app_dirs.append(path)
        else:
            # Search for app directories
            for subdir in path.rglob("*"):
                if subdir.is_dir() and list(subdir.glob("*-helmrelease.yaml")):
                    app_dirs.append(subdir)
    
    if not app_dirs:
        console.print("[yellow]No FluxCD applications found in path[/yellow]")
        return
    
    console.print(f"Found {len(app_dirs)} application(s)\n")
    
    # Validate each app
    total_issues = 0
    for app_dir in app_dirs:
        issues = service.validate_app(app_dir, profile=profile, environment=environment)
        
        if issues:
            console.print(f"[red]✗[/red] {app_dir.name}")
            for file_path, file_issues in issues.items():
                console.print(f"  {Path(file_path).name}:")
                for issue in file_issues:
                    console.print(f"    • {issue}")
                    total_issues += 1
        else:
            console.print(f"[green]✓[/green] {app_dir.name}")
    
    # Summary
    console.print(f"\n[bold]Summary:[/bold]")
    if total_issues == 0:
        console.print(f"[green]All applications validated successfully![/green]")
    else:
        console.print(f"[yellow]Found {total_issues} issue(s) across {len([d for d in app_dirs if service.validate_app(d, profile, environment)])} app(s)[/yellow]")
        raise click.Abort()


@flux_group.command(name="encrypt")
@click.argument("files", nargs=-1, type=click.Path(exists=True, path_type=Path), required=True)
@click.option("--check-only", is_flag=True, help="Only check encryption status, don't encrypt")
def encrypt_secrets(files: tuple[Path, ...], check_only: bool):
    """Encrypt secrets with SOPS.
    
    Examples:
    
        # Encrypt a single secret
        iac flux encrypt my-app-secret.yaml
        
        # Encrypt multiple secrets
        iac flux encrypt app1-secret.yaml app2-secret.yaml
        
        # Check encryption status
        iac flux encrypt --check-only **/*-secret.yaml
    """
    if not is_sops_available():
        console.print("[red]Error:[/red] SOPS is not installed")
        console.print("Install with: brew install sops")
        raise click.Abort()
    
    console.print(f"\n[bold cyan]SOPS Secret Encryption[/bold cyan]\n")
    
    # Create table for results
    table = Table(show_header=True, header_style="bold cyan")
    table.add_column("File", style="dim")
    table.add_column("Status")
    table.add_column("Action")
    
    for file_path in files:
        info = get_encryption_info(file_path)
        
        if info["is_encrypted"]:
            table.add_row(
                file_path.name,
                "[green]Encrypted[/green]",
                "✓ Already encrypted"
            )
        elif check_only:
            table.add_row(
                file_path.name,
                "[yellow]Not encrypted[/yellow]",
                "⚠ Needs encryption"
            )
        else:
            # Encrypt the file
            success, msg = encrypt_file(file_path, in_place=True)
            if success:
                table.add_row(
                    file_path.name,
                    "[green]Encrypted[/green]",
                    f"✓ {msg}"
                )
            else:
                table.add_row(
                    file_path.name,
                    "[red]Failed[/red]",
                    f"✗ {msg}"
                )
    
    console.print(table)


@flux_group.command(name="sops-info")
@click.option("--repo-root", type=click.Path(exists=True, path_type=Path), help="Repository root")
def sops_info(repo_root: Optional[Path]):
    """Show SOPS configuration and status.
    
    Examples:
    
        iac flux sops-info
    """
    # Find repo root
    if repo_root is None:
        current = Path.cwd()
        while current != current.parent:
            if (current / ".git").exists():
                repo_root = current
                break
            current = current.parent
        
        if repo_root is None:
            repo_root = Path.cwd()
    
    console.print(f"\n[bold cyan]SOPS Configuration[/bold cyan]\n")
    
    # Check SOPS availability
    if is_sops_available():
        console.print("[green]✓[/green] SOPS is installed")
    else:
        console.print("[red]✗[/red] SOPS is not installed")
        console.print("  Install with: brew install sops")
        return
    
    # Validate SOPS config
    is_valid, issues = validate_sops_config(repo_root)
    
    if is_valid:
        console.print("[green]✓[/green] .sops.yaml configuration is valid")
    else:
        console.print("[red]✗[/red] .sops.yaml configuration has issues:")
        for issue in issues:
            console.print(f"  • {issue}")
    
    # Show config location
    sops_config = repo_root / ".sops.yaml"
    if sops_config.exists():
        console.print(f"\nConfiguration file: {sops_config}")
        console.print(f"Repository root: {repo_root}")
    else:
        console.print(f"\n[yellow]Warning:[/yellow] .sops.yaml not found in {repo_root}")


@flux_group.command(name="import-secret")
@click.argument("secret-name")
@click.option("--namespace", "-ns", default="default", help="Source namespace in cluster")
@click.option("--cluster", required=True, type=click.Choice(["staging", "production"]), help="Target FluxCD cluster")
@click.option("--category", "-cat", help="Secret category (auto-detect if not provided)")
@click.option("--no-encrypt", is_flag=True, help="Don't encrypt with SOPS")
@click.option("--update-kustomization", is_flag=True, help="Automatically update kustomization.yaml")
@click.option("--repo-root", type=click.Path(exists=True, path_type=Path), help="Repository root (auto-detect if not provided)")
def import_secret(
    secret_name: str,
    namespace: str,
    cluster: str,
    category: Optional[str],
    no_encrypt: bool,
    update_kustomization: bool,
    repo_root: Optional[Path]
):
    """Import a Kubernetes secret from cluster to FluxCD with SOPS encryption.
    
    This command fetches an existing secret from your Kubernetes cluster and converts
    it into a SOPS-encrypted FluxCD secret suitable for Git storage.
    
    The secret will be:
    - Fetched from the cluster via kubectl
    - Cleaned of cluster-specific metadata
    - Converted from base64 data to stringData for easier editing
    - Auto-categorized (database, auth, tls, etc.)
    - Encrypted with SOPS
    - Placed in the appropriate FluxCD directory structure
    
    Examples:
    
        # Import a PostgreSQL secret
        iac flux import-secret postgres-credentials \\
          --namespace database --cluster production
        
        # Import without encryption (for review first)
        iac flux import-secret api-keys \\
          --namespace default --cluster staging --no-encrypt
        
        # Import and update kustomization
        iac flux import-secret redis-password \\
          --namespace cache --cluster production --update-kustomization
    """
    # Find repo root
    if repo_root is None:
        current = Path.cwd()
        while current != current.parent:
            if (current / ".git").exists():
                repo_root = current
                break
            current = current.parent
        
        if repo_root is None:
            console.print("[red]Error:[/red] Could not find repository root")
            console.print("Hint: Run from within a Git repository or use --repo-root")
            raise click.Abort()
    
    console.print(f"\n[bold cyan]Importing Kubernetes Secret to FluxCD[/bold cyan]\n")
    
    # Initialize service
    service = SecretImportService(repo_root)
    
    # Validate prerequisites
    console.print("Checking prerequisites...")
    is_valid, issues = service.validate_import_prerequisites()
    
    if not is_valid:
        console.print("[red]Prerequisites not met:[/red]")
        for issue in issues:
            console.print(f"  • {issue}")
        
        console.print("\n[yellow]Install required tools:[/yellow]")
        console.print("  kubectl: https://kubernetes.io/docs/tasks/tools/")
        console.print("  SOPS: brew install sops")
        raise click.Abort()
    
    console.print("[green]✓[/green] All prerequisites met\n")
    
    # Show cluster info
    can_access, cluster_info = check_cluster_access()
    if can_access:
        console.print(f"Connected to cluster: [cyan]{cluster_info}[/cyan]")
    
    console.print(f"Source: [cyan]{namespace}/{secret_name}[/cyan]")
    console.print(f"Target: [cyan]{cluster}[/cyan] cluster")
    if category:
        console.print(f"Category: [cyan]{category}[/cyan]")
    console.print()
    
    # Import the secret
    success, output_path, error = service.import_secret(
        secret_name,
        namespace,
        cluster,
        category=category,
        encrypt=not no_encrypt
    )
    
    if not success:
        console.print(f"[red]✗ Failed to import secret:[/red] {error}")
        raise click.Abort()
    
    if output_path is None:
        console.print("[red]✗ Failed to import secret: No output path returned[/red]")
        raise click.Abort()
    
    # Success!
    console.print(f"[green]✓[/green] Secret imported successfully!")
    console.print(f"Output: [dim]{output_path}[/dim]")
    
    # Determine actual category from path
    actual_category = output_path.parent.name
    
    # Update kustomization if requested
    if update_kustomization:
        console.print("\nUpdating kustomization.yaml...")
        kust_success, kust_error = service.update_kustomization(
            output_path,
            cluster,
            actual_category
        )
        
        if kust_success:
            if kust_error:
                console.print(f"[dim]{kust_error}[/dim]")
            else:
                console.print("[green]✓[/green] Kustomization updated")
    
    # Next steps
    console.print("\n[bold cyan]Next Steps:[/bold cyan]")
    console.print("1. Review the imported secret values")
    if not no_encrypt:
        console.print(f"   [bold]sops {output_path.relative_to(repo_root)}[/bold]")
    else:
        console.print(f"   [bold]cat {output_path.relative_to(repo_root)}[/bold]")
        console.print("2. Encrypt the secret with SOPS")
        console.print(f"   [bold]sops --encrypt --in-place {output_path.relative_to(repo_root)}[/bold]")
    
    if not update_kustomization:
        console.print(f"2. Add to kustomization.yaml in secrets/{actual_category}/")
    
    console.print("3. Commit and push to Git")
    console.print(f"   [bold]git add {output_path.relative_to(repo_root)}[/bold]")
    console.print(f"   [bold]git commit -m 'feat(secrets): import {secret_name} from cluster'[/bold]")


@flux_group.command(name="import-secrets")
@click.option("--namespace", "-ns", required=True, help="Source namespace in cluster")
@click.option("--cluster", required=True, type=click.Choice(["staging", "production"]), help="Target FluxCD cluster")
@click.option("--label-selector", "-l", help="Label selector (e.g., app=myapp)")
@click.option("--include-system", is_flag=True, help="Include system-managed secrets")
@click.option("--no-encrypt", is_flag=True, help="Don't encrypt with SOPS")
@click.option("--dry-run", is_flag=True, help="Show what would be imported without doing it")
@click.option("--repo-root", type=click.Path(exists=True, path_type=Path), help="Repository root (auto-detect if not provided)")
def import_secrets(
    namespace: str,
    cluster: str,
    label_selector: Optional[str],
    include_system: bool,
    no_encrypt: bool,
    dry_run: bool,
    repo_root: Optional[Path]
):
    """Import multiple Kubernetes secrets from a namespace to FluxCD.
    
    This command batch-imports all secrets from a namespace, automatically
    categorizing and encrypting them for FluxCD/GitOps management.
    
    System-managed secrets (tokens, helm releases) are excluded by default.
    
    Examples:
    
        # Import all secrets from a namespace
        iac flux import-secrets --namespace database --cluster production
        
        # Import secrets with specific label
        iac flux import-secrets --namespace apps \\
          --cluster staging --label-selector app=wordpress
        
        # Dry run to see what would be imported
        iac flux import-secrets --namespace default \\
          --cluster production --dry-run
    """
    # Find repo root
    if repo_root is None:
        current = Path.cwd()
        while current != current.parent:
            if (current / ".git").exists():
                repo_root = current
                break
            current = current.parent
        
        if repo_root is None:
            console.print("[red]Error:[/red] Could not find repository root")
            raise click.Abort()
    
    console.print(f"\n[bold cyan]Batch Import Kubernetes Secrets to FluxCD[/bold cyan]\n")
    
    # Initialize service
    service = SecretImportService(repo_root)
    
    # Validate prerequisites (skip if dry-run)
    if not dry_run:
        console.print("Checking prerequisites...")
        is_valid, issues = service.validate_import_prerequisites()
        
        if not is_valid:
            console.print("[red]Prerequisites not met:[/red]")
            for issue in issues:
                console.print(f"  • {issue}")
            raise click.Abort()
        
        console.print("[green]✓[/green] All prerequisites met\n")
    else:
        # Still need kubectl for dry-run
        if not is_kubectl_available():
            console.print("[red]Error:[/red] kubectl is not installed")
            raise click.Abort()
    
    # Show cluster info
    can_access, cluster_info = check_cluster_access()
    if can_access:
        console.print(f"Connected to cluster: [cyan]{cluster_info}[/cyan]")
    
    console.print(f"Source namespace: [cyan]{namespace}[/cyan]")
    if label_selector:
        console.print(f"Label selector: [cyan]{label_selector}[/cyan]")
    console.print(f"Target: [cyan]{cluster}[/cyan] cluster")
    if dry_run:
        console.print("[yellow]DRY RUN - no changes will be made[/yellow]")
    console.print()
    
    # Import secrets
    success_count, skip_count, errors = service.import_secrets_from_namespace(
        namespace,
        cluster,
        label_selector=label_selector,
        exclude_system=not include_system,
        encrypt=not no_encrypt,
        dry_run=dry_run
    )
    
    # Show results
    console.print("\n[bold]Results:[/bold]")
    
    if success_count > 0:
        action = "Would import" if dry_run else "Imported"
        console.print(f"[green]✓[/green] {action} {success_count} secret(s)")
    
    if skip_count > 0:
        console.print(f"[yellow]⊘[/yellow] Skipped {skip_count} system secret(s)")
    
    if errors:
        console.print(f"[red]✗[/red] Failed: {len(errors)} secret(s)")
        console.print("\n[red]Errors:[/red]")
        for error in errors:
            console.print(f"  • {error}")
    
    if success_count == 0 and not errors:
        console.print("[yellow]No secrets found to import[/yellow]")
        return
    
    # Next steps (only for actual imports)
    if not dry_run and success_count > 0:
        console.print("\n[bold cyan]Next Steps:[/bold cyan]")
        console.print("1. Review the imported secrets")
        console.print(f"   [bold]ls catalog/gitops/flux/clusters/{cluster}/infrastructure/secrets/*/[/bold]")
        console.print("2. Edit secrets as needed")
        console.print("   [bold]sops <secret-file>.yaml[/bold]")
        console.print("3. Update kustomization.yaml files")
        console.print("4. Commit and push to Git")


# Register all commands
def register_commands(cli):
    """Register flux commands with the main CLI."""
    cli.add_command(flux_group)
