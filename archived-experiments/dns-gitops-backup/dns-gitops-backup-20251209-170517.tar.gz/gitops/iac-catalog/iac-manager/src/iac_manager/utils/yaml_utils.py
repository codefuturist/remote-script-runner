"""YAML utility functions."""

import shutil
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

import yaml
from ruamel.yaml import YAML


def load_yaml(file_path: Path) -> Dict[str, Any]:
    """Load YAML file safely (legacy PyYAML).

    Args:
        file_path: Path to YAML file

    Returns:
        Dictionary with YAML contents

    Raises:
        FileNotFoundError: If file doesn't exist
        yaml.YAMLError: If YAML is invalid
    """
    if not file_path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    with open(file_path) as f:
        return yaml.safe_load(f) or {}


def save_yaml(data: Dict[str, Any], file_path: Path) -> None:
    """Save data to YAML file (legacy PyYAML).

    Args:
        data: Dictionary to save
        file_path: Path to save to
    """
    file_path.parent.mkdir(parents=True, exist_ok=True)

    with open(file_path, "w") as f:
        yaml.dump(data, f, default_flow_style=False, sort_keys=False)


def load_yaml_preserving(file_path: Path) -> Any:
    """Load YAML file with comment preservation using ruamel.yaml.

    Args:
        file_path: Path to YAML file

    Returns:
        YAML data structure with preserved formatting

    Raises:
        FileNotFoundError: If file doesn't exist
    """
    if not file_path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    yaml_engine = YAML()
    yaml_engine.preserve_quotes = True
    yaml_engine.default_flow_style = False
    yaml_engine.width = 4096  # Prevent line wrapping
    yaml_engine.indent(mapping=2, sequence=2, offset=0)

    with open(file_path) as f:
        return yaml_engine.load(f)


def save_yaml_preserving(data: Any, file_path: Path) -> None:
    """Save data to YAML file with comment preservation using ruamel.yaml.

    Args:
        data: YAML data structure to save
        file_path: Path to save to
    """
    file_path.parent.mkdir(parents=True, exist_ok=True)

    yaml_engine = YAML()
    yaml_engine.preserve_quotes = True
    yaml_engine.default_flow_style = False
    yaml_engine.width = 4096
    yaml_engine.indent(mapping=2, sequence=2, offset=0)

    with open(file_path, "w") as f:
        yaml_engine.dump(data, f)


def backup_file(file_path: Path, suffix: Optional[str] = None) -> Path:
    """Create a backup copy of a file.

    Args:
        file_path: Path to file to backup
        suffix: Optional suffix for backup (default: timestamp)

    Returns:
        Path to backup file

    Raises:
        FileNotFoundError: If source file doesn't exist
    """
    if not file_path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    if suffix is None:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        suffix = f".{timestamp}.bak"
    elif not suffix.startswith("."):
        suffix = f".{suffix}"

    backup_path = file_path.with_suffix(file_path.suffix + suffix)
    shutil.copy2(file_path, backup_path)

    return backup_path


def get_value_at_path(data: Any, path: str) -> Optional[Any]:
    """Get value at a dot-notation path in YAML data.

    Args:
        data: YAML data structure
        path: Dot-notation path (e.g., "spec.values.resources.requests.cpu")

    Returns:
        Value at path, or None if not found
    """
    parts = path.split(".")
    current = data

    for part in parts:
        if isinstance(current, dict):
            if part not in current:
                return None
            current = current[part]
        else:
            return None

    return current


def set_value_at_path(data: Any, path: str, value: Any, create_missing: bool = True) -> None:
    """Set value at a dot-notation path in YAML data.

    Args:
        data: YAML data structure (modified in place)
        path: Dot-notation path (e.g., "spec.values.resources.requests.cpu")
        value: Value to set
        create_missing: Create missing intermediate dictionaries
    """
    parts = path.split(".")
    current = data

    for i, part in enumerate(parts[:-1]):
        if isinstance(current, dict):
            if part not in current:
                if create_missing:
                    current[part] = {}
                else:
                    return
            current = current[part]
        else:
            return

    if isinstance(current, dict):
        current[parts[-1]] = value

