"""API routes package."""

from fastapi import FastAPI

from iac_manager.web.routes.auth import router as auth_router
from iac_manager.web.routes.deployments import router as deployments_router
from iac_manager.web.routes.templates import router as templates_router
from iac_manager.web.routes.gitops import router as gitops_router
from iac_manager.web.routes.inventory import router as inventory_router
from iac_manager.web.routes.secrets import router as secrets_router
from iac_manager.web.routes.dashboard import router as dashboard_router
from iac_manager.web.routes.websocket import router as websocket_router


def register_routes(app: FastAPI) -> None:
    """Register all API routes on the application.

    Args:
        app: FastAPI application instance
    """
    app.include_router(auth_router, prefix="/api/auth", tags=["Authentication"])
    app.include_router(dashboard_router, prefix="/api/dashboard", tags=["Dashboard"])
    app.include_router(deployments_router, prefix="/api/deployments", tags=["Deployments"])
    app.include_router(templates_router, prefix="/api/templates", tags=["Templates"])
    app.include_router(gitops_router, prefix="/api/gitops", tags=["GitOps"])
    app.include_router(inventory_router, prefix="/api/inventory", tags=["Inventory"])
    app.include_router(secrets_router, prefix="/api/secrets", tags=["Secrets"])
    app.include_router(websocket_router, tags=["WebSocket"])
