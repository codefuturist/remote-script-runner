"""Jinja2 template utility functions."""

import shutil
from pathlib import Path
from typing import Any, Dict, List, Optional

from jinja2 import ChoiceLoader, Environment, FileSystemLoader, PrefixLoader, Undefined


class SilentUndefined(Undefined):
    """Custom Undefined class that returns empty string for undefined variables.
    
    This allows templates with many optional parameters to render without errors.
    """

    def _fail_with_undefined_error(self, *args: Any, **kwargs: Any) -> str:
        return ""

    __add__ = __radd__ = __mul__ = __rmul__ = __div__ = __rdiv__ = __truediv__ = (
        __rtruediv__
    ) = __floordiv__ = __rfloordiv__ = __mod__ = __rmod__ = __pos__ = __neg__ = (
        __call__
    ) = __getitem__ = __lt__ = __le__ = __gt__ = __ge__ = __int__ = __float__ = (
        __complex__
    ) = __pow__ = __rpow__ = _fail_with_undefined_error


def render_template(
    template_path: Path,
    variables: Dict[str, Any],
    catalog_root: Optional[Path] = None,
    strict: bool = False,
) -> str:
    """Render a Jinja2 template with advanced features.

    Supports:
    - Multiple search paths for imports
    - Libraries directory mapping (libraries -> _libraries)
    - Optional strict/silent undefined variable handling

    Args:
        template_path: Path to template file (.j2)
        variables: Variables to pass to template
        catalog_root: Root of catalog directory (auto-detected if None)
        strict: If True, raise error on undefined variables. If False, use empty string.

    Returns:
        Rendered template as string

    Raises:
        FileNotFoundError: If template not found
        jinja2.exceptions.UndefinedError: If strict=True and undefined variable encountered
    """
    if not template_path.exists():
        raise FileNotFoundError(f"Template not found: {template_path}")

    template_dir = template_path.parent

    # Auto-detect catalog root if not provided
    if catalog_root is None:
        # Walk up from template to find 'catalog' directory
        current = template_dir
        while current != current.parent:
            if current.name == "catalog":
                catalog_root = current
                break
            current = current.parent

        if catalog_root is None:
            # Fallback: use template's parent directory
            catalog_root = template_dir

    libraries_dir = catalog_root / "_libraries"

    # Create environment with multiple search paths
    loaders: List[Any] = [
        FileSystemLoader(template_dir),  # For the template itself
        FileSystemLoader(template_dir.parent),  # For local macros/
    ]

    # Add libraries mapping if _libraries directory exists
    if libraries_dir.exists():
        loaders.append(
            PrefixLoader(
                {
                    "libraries": FileSystemLoader(libraries_dir),
                }
            )
        )

    loaders.append(FileSystemLoader(catalog_root))  # For other catalog resources

    env = Environment(
        loader=ChoiceLoader(loaders),
        undefined=Undefined if strict else SilentUndefined,
        trim_blocks=True,
        lstrip_blocks=True,
    )

    template = env.get_template(template_path.name)
    return template.render(**variables)


def render_template_to_file(
    template_path: Path,
    output_path: Path,
    variables: Dict[str, Any],
    catalog_root: Optional[Path] = None,
) -> None:
    """Render a Jinja2 template to file.

    Args:
        template_path: Path to template file (.j2)
        output_path: Path to output file
        variables: Variables to pass to template
        catalog_root: Root of catalog directory
    """
    rendered = render_template(template_path, variables, catalog_root)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(rendered)


def render_template_directory(
    source_dir: Path,
    dest_dir: Path,
    variables: Dict[str, Any],
    catalog_root: Optional[Path] = None,
    exclude_patterns: Optional[List[str]] = None,
) -> None:
    """Copy directory tree, rendering Jinja2 templates.

    Args:
        source_dir: Source directory
        dest_dir: Destination directory
        variables: Variables for Jinja2 templates
        catalog_root: Root of catalog directory
        exclude_patterns: Patterns to exclude from copying
    """
    exclude_patterns = exclude_patterns or ["*.pyc", "__pycache__", ".git"]

    for item in source_dir.rglob("*"):
        if item.is_file():
            # Check if excluded
            if any(item.match(pattern) for pattern in exclude_patterns):
                continue

            relative_path = item.relative_to(source_dir)
            dest_path = dest_dir / relative_path

            # Render Jinja2 templates
            if item.suffix == ".j2":
                dest_path = dest_path.with_suffix("")
                render_template_to_file(item, dest_path, variables, catalog_root)
            else:
                # Regular copy
                dest_path.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(item, dest_path)
