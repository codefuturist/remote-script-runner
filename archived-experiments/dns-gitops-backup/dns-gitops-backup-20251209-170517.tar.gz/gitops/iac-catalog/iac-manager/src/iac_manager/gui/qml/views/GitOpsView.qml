// GitOpsView.qml - Modern Git operations management view
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "../components"
import "../theme"

Item {
    id: root
    
    property var backend: null
    
    ColumnLayout {
        anchors.fill: parent
        spacing: Theme.spacingMedium
        
        // Header
        RowLayout {
            Layout.fillWidth: true
            spacing: Theme.spacingMedium
            
            Column {
                spacing: Theme.spacing1
                
                Label {
                    text: "GitOps"
                    font.pixelSize: Theme.fontSizeH3
                    font.weight: Theme.fontWeightBold
                    color: Theme.textPrimary
                }
                
                Label {
                    text: "Manage version control and deployments"
                    font.pixelSize: Theme.fontSizeNormal
                    color: Theme.textSecondary
                }
            }
            
            Item { Layout.fillWidth: true }
            
            CustomButton {
                text: "Refresh"
                iconName: "refresh"
                buttonType: "outlined"
                size: "medium"
                onClicked: {
                    if (backend) backend.refresh()
                }
            }
        }
        
        // Status cards
        GridLayout {
            columns: 3
            rowSpacing: Theme.spacingMedium
            columnSpacing: Theme.spacingMedium
            Layout.fillWidth: true
            
            // Branch info card
            Rectangle {
                Layout.fillWidth: true
                Layout.preferredHeight: 100
                color: Theme.surfaceColor
                radius: Theme.radiusLarge
                
                Shadow {
                    anchors.fill: parent
                    elevation: 1
                    shadowRadius: parent.radius
                }
                RowLayout {
                    anchors.fill: parent
                    anchors.margins: Theme.spacingMedium
                    spacing: Theme.spacing3
                    
                    Rectangle {
                        width: 48
                        height: 48
                        radius: Theme.radiusMedium
                        color: Theme.alpha(Theme.info, 0.1)
                        
                        Text {
                            anchors.centerIn: parent
                            text: "⎇"
                            font.pixelSize: 28
                            color: Theme.info
                        }
                    }
                    
                    Column {
                        spacing: Theme.spacing1
                        Layout.fillWidth: true
                        
                        Label {
                            text: "Current Branch"
                            font.pixelSize: Theme.fontSizeSmall
                            color: Theme.textSecondary
                        }
                        
                        Label {
                            text: backend ? backend.branch : "unknown"
                            font.pixelSize: Theme.fontSizeMedium
                            font.weight: Theme.fontWeightBold
                            color: Theme.info
                        }
                    }
                }
            }
            
            // Modified files card
            Rectangle {
                Layout.fillWidth: true
                Layout.preferredHeight: 100
                color: Theme.surfaceColor
                radius: Theme.radiusLarge
                
                Shadow {
                    anchors.fill: parent
                    elevation: 1
                    shadowRadius: parent.radius
                }
                RowLayout {
                    anchors.fill: parent
                    anchors.margins: Theme.spacingMedium
                    spacing: Theme.spacing3
                    
                    Rectangle {
                        width: 48
                        height: 48
                        radius: Theme.radiusMedium
                        color: Theme.alpha(Theme.warning, 0.1)
                        
                        Text {
                            anchors.centerIn: parent
                            text: "📝"
                            font.pixelSize: 28
                        }
                    }
                    
                    Column {
                        spacing: Theme.spacing1
                        Layout.fillWidth: true
                        
                        Label {
                            text: "Modified Files"
                            font.pixelSize: Theme.fontSizeSmall
                            color: Theme.textSecondary
                        }
                        
                        Label {
                            text: backend ? backend.modifiedCount.toString() : "0"
                            font.pixelSize: Theme.fontSizeH4
                            font.weight: Theme.fontWeightBold
                            color: backend && backend.modifiedCount > 0 ? Theme.warning : Theme.success
                        }
                    }
                }
            }
            
            // Staged files card
            Rectangle {
                Layout.fillWidth: true
                Layout.preferredHeight: 100
                color: Theme.surfaceColor
                radius: Theme.radiusLarge
                
                Shadow {
                    anchors.fill: parent
                    elevation: 1
                    shadowRadius: parent.radius
                }
                RowLayout {
                    anchors.fill: parent
                    anchors.margins: Theme.spacingMedium
                    spacing: Theme.spacing3
                    
                    Rectangle {
                        width: 48
                        height: 48
                        radius: Theme.radiusMedium
                        color: Theme.alpha(Theme.success, 0.1)
                        
                        Text {
                            anchors.centerIn: parent
                            text: "✓"
                            font.pixelSize: 28
                            color: Theme.success
                        }
                    }
                    
                    Column {
                        spacing: Theme.spacing1
                        Layout.fillWidth: true
                        
                        Label {
                            text: "Staged Files"
                            font.pixelSize: Theme.fontSizeSmall
                            color: Theme.textSecondary
                        }
                        
                        Label {
                            text: backend ? backend.stagedCount.toString() : "0"
                            font.pixelSize: Theme.fontSizeH4
                            font.weight: Theme.fontWeightBold
                            color: Theme.success
                        }
                    }
                }
            }
        }
        
        // File lists in split view
        SplitView {
            Layout.fillWidth: true
            Layout.fillHeight: true
            orientation: Qt.Horizontal
            
            // Modified files panel
            Rectangle {
                SplitView.fillWidth: true
                SplitView.minimumWidth: 250
                color: Theme.surfaceColor
                radius: Theme.radiusLarge
                
                Shadow {
                    anchors.fill: parent
                    elevation: 1
                    shadowRadius: parent.radius
                }
                ColumnLayout {
                    anchors.fill: parent
                    anchors.margins: Theme.spacingMedium
                    spacing: Theme.spacing3
                    
                    Label {
                        text: "Modified Files"
                        font.pixelSize: Theme.fontSizeMedium
                        font.weight: Theme.fontWeightBold
                        color: Theme.textPrimary
                    }
                    
                    Rectangle {
                        Layout.fillWidth: true
                        height: 1
                        color: Theme.dividerColor
                    }
                    
                    ListView {
                        id: modifiedList
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        clip: true
                        spacing: Theme.spacing1
                        
                        model: backend ? backend.modifiedModel : null
                        
                        delegate: ItemDelegate {
                            width: modifiedList.width
                            height: 40
                            checkable: true
                            
                            background: Rectangle {
                                color: {
                                    if (parent.checked) return Theme.alpha(Theme.warning, 0.1)
                                    if (parent.hovered) return Theme.gray50
                                    return "transparent"
                                }
                                radius: Theme.radiusNormal
                                
                                Behavior on color {
                                    ColorAnimation { duration: Theme.animationDurationFast }
                                }
                            }
                            
                            contentItem: Row {
                                spacing: Theme.spacing2
                                
                                Rectangle {
                                    width: 6
                                    height: 6
                                    radius: 3
                                    color: Theme.warning
                                    anchors.verticalCenter: parent.verticalCenter
                                }
                                
                                Label {
                                    text: model.filePath
                                    color: Theme.textPrimary
                                    font.pixelSize: Theme.fontSizeSmall
                                    elide: Text.ElideMiddle
                                    anchors.verticalCenter: parent.verticalCenter
                                    width: parent.width - 20
                                }
                            }
                        }
                        
                        ScrollBar.vertical: ScrollBar {
                            policy: ScrollBar.AsNeeded
                        }
                    }
                    
                    RowLayout {
                        Layout.fillWidth: true
                        spacing: Theme.spacing2
                        
                        CustomButton {
                            text: "Stage Selected"
                            iconName: "add"
                            buttonType: "outlined"
                            size: "small"
                            enabled: getSelectedFiles(modifiedList).length > 0
                            Layout.fillWidth: true
                            onClicked: {
                                if (backend) {
                                    backend.stageFiles(getSelectedFiles(modifiedList))
                                }
                            }
                        }
                        
                        CustomButton {
                            text: "Stage All"
                            iconName: "✓"
                            buttonType: "secondary"
                            size: "small"
                            Layout.fillWidth: true
                            onClicked: {
                                if (backend) backend.stageAll()
                            }
                        }
                    }
                }
            }
            
            // Staged files panel
            Rectangle {
                SplitView.fillWidth: true
                SplitView.minimumWidth: 250
                color: Theme.surfaceColor
                radius: Theme.radiusLarge
                
                Shadow {
                    anchors.fill: parent
                    elevation: 1
                    shadowRadius: parent.radius
                }
                ColumnLayout {
                    anchors.fill: parent
                    anchors.margins: Theme.spacingMedium
                    spacing: Theme.spacing3
                    
                    Label {
                        text: "Staged Files"
                        font.pixelSize: Theme.fontSizeMedium
                        font.weight: Theme.fontWeightBold
                        color: Theme.textPrimary
                    }
                    
                    Rectangle {
                        Layout.fillWidth: true
                        height: 1
                        color: Theme.dividerColor
                    }
                    
                    ListView {
                        id: stagedList
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        clip: true
                        spacing: Theme.spacing1
                        
                        model: backend ? backend.stagedModel : null
                        
                        delegate: ItemDelegate {
                            width: stagedList.width
                            height: 40
                            
                            background: Rectangle {
                                color: parent.hovered ? Theme.alpha(Theme.success, 0.1) : "transparent"
                                radius: Theme.radiusNormal
                                
                                Behavior on color {
                                    ColorAnimation { duration: Theme.animationDurationFast }
                                }
                            }
                            
                            contentItem: Row {
                                spacing: Theme.spacing2
                                
                                Rectangle {
                                    width: 6
                                    height: 6
                                    radius: 3
                                    color: Theme.success
                                    anchors.verticalCenter: parent.verticalCenter
                                }
                                
                                Label {
                                    text: model.filePath
                                    color: Theme.textPrimary
                                    font.pixelSize: Theme.fontSizeSmall
                                    elide: Text.ElideMiddle
                                    anchors.verticalCenter: parent.verticalCenter
                                    width: parent.width - 20
                                }
                            }
                        }
                        
                        ScrollBar.vertical: ScrollBar {
                            policy: ScrollBar.AsNeeded
                        }
                    }
                }
            }
        }
        
        // Commit section
        Rectangle {
            Layout.fillWidth: true
            Layout.preferredHeight: 200
            color: Theme.surfaceColor
            radius: Theme.radiusLarge
                
                Shadow {
                    anchors.fill: parent
                    elevation: 1
                    shadowRadius: parent.radius
                }
                ColumnLayout {
                anchors.fill: parent
                anchors.margins: Theme.spacingMedium
                spacing: Theme.spacing3
                
                Label {
                    text: "Commit Changes"
                    font.pixelSize: Theme.fontSizeMedium
                    font.weight: Theme.fontWeightBold
                    color: Theme.textPrimary
                }
                
                Rectangle {
                    Layout.fillWidth: true
                    height: 1
                    color: Theme.dividerColor
                }
                
                ScrollView {
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    
                    TextArea {
                        id: commitMessage
                        placeholderText: "Enter a descriptive commit message...\n\nExample:\nfeat: add new deployment for wordpress\n\n- Configure environment variables\n- Set up persistent volumes"
                        wrapMode: TextArea.Wrap
                        color: Theme.textPrimary
                        font.pixelSize: Theme.fontSizeNormal
                        
                        background: Rectangle {
                            color: Theme.backgroundColor
                            border.color: Theme.borderColor
                            border.width: 1
                            radius: Theme.radiusNormal
                        }
                    }
                }
                
                RowLayout {
                    Layout.fillWidth: true
                    spacing: Theme.spacing2
                    
                    CustomButton {
                        text: "Commit"
                        iconName: "save"
                        buttonType: "outlined"
                        enabled: commitMessage.text.trim().length > 0 && backend && backend.stagedCount > 0
                        onClicked: {
                            if (backend && backend.commit(commitMessage.text)) {
                                commitMessage.text = ""
                            }
                        }
                    }
                    
                    CustomButton {
                        text: "Commit & Push"
                        iconName: "deploy"
                        buttonType: "success"
                        enabled: commitMessage.text.trim().length > 0 && backend && backend.stagedCount > 0
                        onClicked: {
                            if (backend && backend.commitAndPush(commitMessage.text)) {
                                commitMessage.text = ""
                            }
                        }
                    }
                    
                    Item { Layout.fillWidth: true }
                    
                    CustomButton {
                        text: "Push"
                        iconName: "upload"
                        buttonType: "secondary"
                        onClicked: {
                            if (backend) backend.push()
                        }
                    }
                }
            }
        }
        
        // Status bar
        Rectangle {
            Layout.fillWidth: true
            Layout.preferredHeight: 40
            color: {
                if (!backend) return Theme.gray100
                if (backend.statusMessage.includes("✅")) return Theme.alpha(Theme.success, 0.1)
                if (backend.statusMessage.includes("⚠️")) return Theme.alpha(Theme.warning, 0.1)
                if (backend.statusMessage.includes("Error")) return Theme.alpha(Theme.error, 0.1)
                return Theme.gray100
            }
            radius: Theme.radiusNormal
            
            Behavior on color {
                ColorAnimation { duration: Theme.animationDuration }
            }
            
            RowLayout {
                anchors.fill: parent
                anchors.margins: Theme.spacing3
                
                StatusBadge {
                    status: {
                        if (!backend) return "info"
                        if (backend.statusMessage.includes("✅")) return "success"
                        if (backend.statusMessage.includes("⚠️")) return "warning"
                        if (backend.statusMessage.includes("Error")) return "error"
                        return "info"
                    }
                    badgeText: backend ? backend.statusMessage : "Ready"
                    dot: true
                    size: "small"
                }
                
                Item { Layout.fillWidth: true }
            }
        }
    }
    
    // Helper function to get selected files
    function getSelectedFiles(listView) {
        var files = []
        for (var i = 0; i < listView.count; i++) {
            var item = listView.itemAtIndex(i)
            if (item && item.checked) {
                files.push(listView.model.data(listView.model.index(i, 0), 0x0100 + 1))
            }
        }
        return files
    }
    
    // Initialize
    Component.onCompleted: {
        if (backend) backend.refresh()
    }
}

