// PresetSelector.qml - Preset configuration selector
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "../theme"

Card {
    id: root
    
    property var backend: null
    
    signal presetSelected(string presetId)
    
    ColumnLayout {
        anchors.fill: parent
        spacing: Theme.spacing2
        
        Label {
            text: "Quick Start"
            font.pixelSize: Theme.fontSizeH5
            font.weight: Theme.fontWeightBold
            color: Theme.textPrimary
        }
        
        Label {
            text: "Choose a preset configuration to get started quickly"
            font.pixelSize: Theme.fontSizeSmall
            color: Theme.textSecondary
            wrapMode: Text.WordWrap
            Layout.fillWidth: true
        }
        
        // Preset buttons
        GridLayout {
            Layout.fillWidth: true
            columns: 2
            rowSpacing: Theme.spacing2
            columnSpacing: Theme.spacing2
            
            Repeater {
                model: backend ? backend.getAvailablePresets() : []
                
                delegate: Button {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 80
                    
                    contentItem: ColumnLayout {
                        spacing: Theme.spacing1
                        
                        RowLayout {
                            Layout.fillWidth: true
                            spacing: Theme.spacing1
                            
                            Label {
                                text: modelData.icon
                                font.pixelSize: 24
                            }
                            
                            Label {
                                text: modelData.name
                                font.pixelSize: Theme.fontSizeNormal
                                font.weight: Theme.fontWeightMedium
                                color: Theme.textPrimary
                                Layout.fillWidth: true
                            }
                            
                            Rectangle {
                                visible: modelData.difficulty === "beginner"
                                implicitWidth: beginnerLabel.implicitWidth + 8
                                implicitHeight: beginnerLabel.implicitHeight + 4
                                color: Theme.successColorLight
                                radius: Theme.radiusSmall
                                
                                Label {
                                    id: beginnerLabel
                                    anchors.centerIn: parent
                                    text: "Beginner"
                                    font.pixelSize: Theme.fontSizeSmall
                                    color: Theme.successColorDark
                                }
                            }
                        }
                        
                        Label {
                            text: modelData.description
                            font.pixelSize: Theme.fontSizeSmall
                            color: Theme.textSecondary
                            wrapMode: Text.WordWrap
                            Layout.fillWidth: true
                        }
                    }
                    
                    background: Rectangle {
                        color: parent.hovered ? Theme.hoverColor : Theme.surfaceColor
                        border.color: Theme.borderColor
                        border.width: 1
                        radius: Theme.radiusNormal
                        
                        Behavior on color {
                            ColorAnimation { duration: 150 }
                        }
                    }
                    
                    onClicked: {
                        if (backend) {
                            backend.applyPreset(modelData.id)
                            root.presetSelected(modelData.id)
                        }
                    }
                }
            }
        }
        
        // Custom configuration option
        Button {
            Layout.fillWidth: true
            text: "⚙️  Custom Configuration"
            
            background: Rectangle {
                color: parent.hovered ? Theme.hoverColor : "transparent"
                border.color: Theme.borderColor
                border.width: 1
                radius: Theme.radiusNormal
                
                Behavior on color {
                    ColorAnimation { duration: 150 }
                }
            }
            
            onClicked: {
                root.presetSelected("custom")
            }
        }
    }
}
