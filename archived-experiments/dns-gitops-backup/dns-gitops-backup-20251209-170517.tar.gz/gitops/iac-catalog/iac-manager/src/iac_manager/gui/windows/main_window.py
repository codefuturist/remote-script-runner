"""Main application window."""

from typing import Optional

from PyQt6.QtWidgets import (
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QStackedWidget,
    QListWidget,
    QListWidgetItem,
    QStatusBar,
    QMenuBar,
    QToolBar,
    QPushButton,
    QLabel,
    QSplitter,
)
from PyQt6.QtCore import Qt, QSize
from PyQt6.QtGui import QAction, QIcon

from iac_manager.config import Config
from iac_manager.services import (
    DeploymentService,
    TemplateService,
    InventoryService,
    GitOpsService,
    SecretsService,
)
from iac_manager.gui.widgets.dashboard_widget import DashboardWidget
from iac_manager.gui.widgets.template_browser_widget import TemplateBrowserWidget
from iac_manager.gui.widgets.deployment_list_widget import DeploymentListWidget
from iac_manager.gui.widgets.inventory_widget import InventoryWidget
from iac_manager.gui.widgets.gitops_widget import GitOpsWidget


class MainWindow(QMainWindow):
    """Main application window with sidebar navigation."""

    def __init__(self, config: Config):
        """Initialize main window.

        Args:
            config: Configuration object
        """
        super().__init__()
        self.config = config

        # Initialize services
        self.deployment_service = DeploymentService(config)
        self.template_service = TemplateService(config)
        self.inventory_service = InventoryService(config)
        self.gitops_service = GitOpsService(config)
        self.secrets_service = SecretsService(config)

        # Setup UI
        self.setWindowTitle("IaC Management Tool")
        self.setMinimumSize(1280, 800)

        self._setup_ui()
        self._setup_menubar()
        self._setup_toolbar()
        self._setup_statusbar()
        self._apply_theme()

        # Show dashboard by default
        self.sidebar.setCurrentRow(0)

    def _setup_ui(self) -> None:
        """Setup main UI components."""
        # Central widget with horizontal layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        main_layout = QHBoxLayout(central_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # Create splitter for resizable sidebar
        splitter = QSplitter(Qt.Orientation.Horizontal)

        # Sidebar navigation
        self.sidebar = QListWidget()
        self.sidebar.setMaximumWidth(200)
        self.sidebar.setMinimumWidth(150)

        # Add navigation items
        nav_items = [
            ("🏠 Dashboard", "dashboard"),
            ("📦 Templates", "templates"),
            ("🚀 Deployments", "deployments"),
            ("📋 Inventory", "inventory"),
            ("🔄 GitOps", "gitops"),
            ("🔐 Secrets", "secrets"),
        ]

        for text, data in nav_items:
            item = QListWidgetItem(text)
            item.setData(Qt.ItemDataRole.UserRole, data)
            self.sidebar.addItem(item)

        self.sidebar.currentRowChanged.connect(self._on_navigation_changed)

        # Main content area with stacked widget
        self.content_stack = QStackedWidget()

        # Create pages
        self.dashboard_widget = DashboardWidget(self.config, self.deployment_service)
        self.template_widget = TemplateBrowserWidget(self.config, self.template_service)
        self.deployment_widget = DeploymentListWidget(self.config, self.deployment_service)
        self.inventory_widget = InventoryWidget(self.config, self.inventory_service)
        self.gitops_widget = GitOpsWidget(self.config, self.gitops_service)

        # Secrets widget (placeholder)
        secrets_placeholder = QLabel("🔐 Secrets Management\n\nComing soon...")
        secrets_placeholder.setAlignment(Qt.AlignmentFlag.AlignCenter)
        secrets_placeholder.setStyleSheet("font-size: 18px; color: #999;")

        # Add pages to stack
        self.content_stack.addWidget(self.dashboard_widget)
        self.content_stack.addWidget(self.template_widget)
        self.content_stack.addWidget(self.deployment_widget)
        self.content_stack.addWidget(self.inventory_widget)
        self.content_stack.addWidget(self.gitops_widget)
        self.content_stack.addWidget(secrets_placeholder)

        # Add to splitter
        splitter.addWidget(self.sidebar)
        splitter.addWidget(self.content_stack)
        splitter.setStretchFactor(1, 1)

        main_layout.addWidget(splitter)

    def _setup_menubar(self) -> None:
        """Setup application menu bar."""
        menubar = self.menuBar()

        # File menu
        file_menu = menubar.addMenu("&File")

        new_deployment_action = QAction("&New Deployment...", self)
        new_deployment_action.setShortcut("Ctrl+N")
        new_deployment_action.triggered.connect(self._on_new_deployment)
        file_menu.addAction(new_deployment_action)

        refresh_action = QAction("&Refresh", self)
        refresh_action.setShortcut("F5")
        refresh_action.triggered.connect(self._on_refresh)
        file_menu.addAction(refresh_action)

        file_menu.addSeparator()

        exit_action = QAction("E&xit", self)
        exit_action.setShortcut("Ctrl+Q")
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)

        # View menu
        view_menu = menubar.addMenu("&View")

        dark_theme_action = QAction("&Dark Theme", self)
        dark_theme_action.setCheckable(True)
        dark_theme_action.triggered.connect(self._toggle_theme)
        view_menu.addAction(dark_theme_action)

        # Tools menu
        tools_menu = menubar.addMenu("&Tools")

        convert_action = QAction("&Convert Docker Compose...", self)
        convert_action.triggered.connect(self._on_convert)
        tools_menu.addAction(convert_action)

        # Help menu
        help_menu = menubar.addMenu("&Help")

        about_action = QAction("&About", self)
        about_action.triggered.connect(self._on_about)
        help_menu.addAction(about_action)

    def _setup_toolbar(self) -> None:
        """Setup application toolbar."""
        toolbar = QToolBar("Main Toolbar")
        toolbar.setMovable(False)
        self.addToolBar(toolbar)

        # Add quick action buttons
        new_btn = QPushButton("➕ New Deployment")
        new_btn.clicked.connect(self._on_new_deployment)
        toolbar.addWidget(new_btn)

        toolbar.addSeparator()

        refresh_btn = QPushButton("🔄 Refresh")
        refresh_btn.clicked.connect(self._on_refresh)
        toolbar.addWidget(refresh_btn)

        toolbar.addSeparator()

        # Add stretch to push items to the right
        spacer = QWidget()
        spacer.setSizePolicy(
            QWidget().sizePolicy().Policy.Expanding,
            QWidget().sizePolicy().Policy.Preferred,
        )
        toolbar.addWidget(spacer)

    def _setup_statusbar(self) -> None:
        """Setup status bar."""
        statusbar = QStatusBar()
        self.setStatusBar(statusbar)

        # Show repository info
        repo_label = QLabel(f"📁 {self.config.repo_root.name}")
        statusbar.addWidget(repo_label)

        statusbar.addPermanentWidget(QLabel("|"))

        # Show git branch
        git_status = self.gitops_service.get_status()
        branch_label = QLabel(f"🌿 {git_status.get('branch', 'unknown')}")
        statusbar.addPermanentWidget(branch_label)

    def _apply_theme(self, dark: bool = False) -> None:
        """Apply theme to application.

        Args:
            dark: Use dark theme if True
        """
        if dark:
            try:
                import qdarkstyle

                self.setStyleSheet(qdarkstyle.load_stylesheet(qt_api="pyqt6"))
            except ImportError:
                # Fallback to basic dark theme
                self.setStyleSheet(
                    """
                    QMainWindow, QWidget {
                        background-color: #2b2b2b;
                        color: #e0e0e0;
                    }
                    QListWidget {
                        background-color: #1e1e1e;
                        border: none;
                    }
                    QListWidget::item:selected {
                        background-color: #094771;
                    }
                    """
                )
        else:
            self.setStyleSheet("")

    def _on_navigation_changed(self, index: int) -> None:
        """Handle navigation item selection.

        Args:
            index: Selected navigation index
        """
        self.content_stack.setCurrentIndex(index)

    def _on_new_deployment(self) -> None:
        """Handle new deployment action."""
        from iac_manager.gui.windows.deploy_wizard import DeployWizard

        wizard = DeployWizard(self.config, self.template_service, self.deployment_service)
        if wizard.exec():
            # Refresh deployment list
            self.deployment_widget.refresh()
            self.statusBar().showMessage("Deployment configured successfully", 3000)

    def _on_refresh(self) -> None:
        """Handle refresh action."""
        # Refresh current page
        current_widget = self.content_stack.currentWidget()
        if hasattr(current_widget, "refresh"):
            current_widget.refresh()
        self.statusBar().showMessage("Refreshed", 2000)

    def _toggle_theme(self, checked: bool) -> None:
        """Toggle dark/light theme.

        Args:
            checked: Dark theme enabled if True
        """
        self._apply_theme(dark=checked)

    def _on_convert(self) -> None:
        """Handle convert action."""
        from PyQt6.QtWidgets import QMessageBox

        QMessageBox.information(
            self, "Convert", "Docker Compose to Kubernetes converter\n\nComing soon..."
        )

    def _on_about(self) -> None:
        """Show about dialog."""
        from PyQt6.QtWidgets import QMessageBox

        QMessageBox.about(
            self,
            "About IaC Management Tool",
            "<h2>IaC Management Tool</h2>"
            "<p>Version 0.1.0</p>"
            "<p>Modern GUI for Infrastructure as Code management</p>"
            "<p>Built with PyQt6 and iac-core</p>"
            "<p>© 2025 codefuturist</p>",
        )
