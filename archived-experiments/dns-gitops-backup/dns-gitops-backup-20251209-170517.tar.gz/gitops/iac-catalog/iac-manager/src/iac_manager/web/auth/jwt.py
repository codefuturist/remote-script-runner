"""JWT token handling."""

import hashlib
from datetime import UTC, datetime, timedelta
from typing import Any

import jwt
from pydantic import BaseModel

from iac_manager.web.config import get_settings


class TokenPayload(BaseModel):
    """JWT token payload structure."""

    sub: str  # Subject (user ID or email)
    exp: datetime  # Expiration time
    iat: datetime  # Issued at
    type: str  # "access" or "refresh"
    jti: str | None = None  # JWT ID for refresh tokens


class TokenPair(BaseModel):
    """Access and refresh token pair."""

    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int  # Seconds until access token expires


def create_access_token(
    subject: str | int,
    expires_delta: timedelta | None = None,
    extra_claims: dict[str, Any] | None = None,
) -> str:
    """Create a new access token.

    Args:
        subject: User identifier (typically user ID)
        expires_delta: Optional custom expiration time
        extra_claims: Additional claims to include in the token

    Returns:
        Encoded JWT access token
    """
    settings = get_settings()

    if expires_delta is None:
        expires_delta = timedelta(minutes=settings.access_token_expire_minutes)

    now = datetime.now(UTC)
    expire = now + expires_delta

    payload = {
        "sub": str(subject),
        "exp": expire,
        "iat": now,
        "type": "access",
    }

    if extra_claims:
        payload.update(extra_claims)

    return jwt.encode(payload, settings.secret_key, algorithm=settings.algorithm)


def create_refresh_token(
    subject: str | int,
    expires_delta: timedelta | None = None,
) -> tuple[str, str]:
    """Create a new refresh token.

    Args:
        subject: User identifier
        expires_delta: Optional custom expiration time

    Returns:
        Tuple of (encoded token, token hash for storage)
    """
    settings = get_settings()

    if expires_delta is None:
        expires_delta = timedelta(days=settings.refresh_token_expire_days)

    now = datetime.now(UTC)
    expire = now + expires_delta

    # Generate unique token ID
    import secrets

    jti = secrets.token_urlsafe(32)

    payload = {
        "sub": str(subject),
        "exp": expire,
        "iat": now,
        "type": "refresh",
        "jti": jti,
    }

    token = jwt.encode(payload, settings.secret_key, algorithm=settings.algorithm)
    token_hash = hashlib.sha256(token.encode()).hexdigest()

    return token, token_hash


def verify_token(token: str, token_type: str = "access") -> TokenPayload | None:
    """Verify and decode a JWT token.

    Args:
        token: Encoded JWT token
        token_type: Expected token type ("access" or "refresh")

    Returns:
        Token payload if valid, None otherwise
    """
    settings = get_settings()

    try:
        payload = jwt.decode(
            token,
            settings.secret_key,
            algorithms=[settings.algorithm],
        )

        # Verify token type
        if payload.get("type") != token_type:
            return None

        return TokenPayload(**payload)

    except jwt.ExpiredSignatureError:
        return None
    except jwt.InvalidTokenError:
        return None


def create_token_pair(subject: str | int) -> tuple[TokenPair, str]:
    """Create a new access/refresh token pair.

    Args:
        subject: User identifier

    Returns:
        Tuple of (TokenPair, refresh_token_hash)
    """
    settings = get_settings()

    access_token = create_access_token(subject)
    refresh_token, token_hash = create_refresh_token(subject)

    return (
        TokenPair(
            access_token=access_token,
            refresh_token=refresh_token,
            expires_in=settings.access_token_expire_minutes * 60,
        ),
        token_hash,
    )
