// InventoryView.qml - Inventory management view
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Item {
    id: root
    
    // Theme properties
    readonly property color primaryColor: "#2196F3"
    readonly property color backgroundColor: "#f5f5f5"
    readonly property color surfaceColor: "#ffffff"
    readonly property int spacingNormal: 16
    readonly property int spacingLarge: 24
    readonly property int fontSizeMedium: 14
    readonly property int fontSizeLarge: 18
    readonly property int fontSizeXLarge: 24
    
    ColumnLayout {
        anchors.fill: parent
        anchors.margins: root.spacingLarge
        spacing: root.spacingNormal
        
        // Header
        RowLayout {
            spacing: root.spacingNormal
            Layout.fillWidth: true
            
            Label {
                text: "📋 Inventory"
                font.pixelSize: root.fontSizeXLarge
                font.bold: true
                color: "#212121"
            }
            
            Item { Layout.fillWidth: true }
            
            ComboBox {
                id: envFilter
                model: ["All Environments", "development", "staging", "production"]
                Layout.preferredWidth: 200
                
                background: Rectangle {
                    color: "white"
                    border.color: "#BDBDBD"
                    border.width: 1
                    radius: 4
                }
                
                contentItem: Text {
                    leftPadding: 10
                    text: envFilter.displayText
                    font: envFilter.font
                    color: "#212121"
                    verticalAlignment: Text.AlignVCenter
                }
            }
            
            Button {
                text: "🔄 Refresh"
                Layout.preferredHeight: 36
                
                background: Rectangle {
                    color: parent.down ? root.primaryColor : (parent.hovered ? Qt.lighter(root.primaryColor, 1.1) : root.primaryColor)
                    radius: 4
                }
                
                contentItem: Text {
                    text: parent.text
                    color: "white"
                    font.pixelSize: 14
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                }
                
                onClicked: {
                    // Refresh inventory
                }
            }
        }
        
        // Search bar
        TextField {
            id: searchField
            Layout.fillWidth: true
            placeholderText: "🔍 Search hosts and groups..."
            leftPadding: 15
            color: "#212121"
            font.pixelSize: 14
            
            background: Rectangle {
                color: "white"
                border.color: "#BDBDBD"
                border.width: 1
                radius: 4
            }
        }
        
        // Split view
        SplitView {
            Layout.fillWidth: true
            Layout.fillHeight: true
            orientation: Qt.Horizontal
            
            // Groups tree
            GroupBox {
                title: "Inventory Groups"
                SplitView.preferredWidth: 300
                SplitView.minimumWidth: 200
                
                background: Rectangle {
                    color: "white"
                    radius: 8
                    border.color: "#e0e0e0"
                    border.width: 1
                }
                
                label: Label {
                    text: "Inventory Groups"
                    font.pixelSize: root.fontSizeMedium
                    font.bold: true
                    color: "#212121"
                    padding: 8
                }
                
                ScrollView {
                    anchors.fill: parent
                    clip: true
                    
                    TreeView {
                        id: groupsTree
                        model: ListModel {
                            ListElement { name: "all"; type: "group"; icon: "📁" }
                            ListElement { name: "webservers"; type: "group"; icon: "🌐" }
                            ListElement { name: "databases"; type: "group"; icon: "💾" }
                            ListElement { name: "loadbalancers"; type: "group"; icon: "⚖️" }
                        }
                        
                        delegate: ItemDelegate {
                            id: treeDelegate
                            text: model.icon + " " + model.name
                            width: parent.width
                            
                            property bool isHovered: false
                            
                            background: Rectangle {
                                color: treeDelegate.highlighted ? root.primaryColor : (treeDelegate.isHovered ? "#f5f5f5" : "transparent")
                                radius: 4
                            }
                            
                            contentItem: Text {
                                text: treeDelegate.text
                                color: treeDelegate.highlighted ? "white" : "#212121"
                                font: treeDelegate.font
                                verticalAlignment: Text.AlignVCenter
                            }
                            
                            MouseArea {
                                anchors.fill: parent
                                hoverEnabled: true
                                onEntered: treeDelegate.isHovered = true
                                onExited: treeDelegate.isHovered = false
                            }
                        }
                    }
                }
            }
            
            // Hosts list
            GroupBox {
                title: "Hosts"
                SplitView.fillWidth: true
                
                background: Rectangle {
                    color: "white"
                    radius: 8
                    border.color: "#e0e0e0"
                    border.width: 1
                }
                
                label: Label {
                    text: "Hosts"
                    font.pixelSize: root.fontSizeMedium
                    font.bold: true
                    color: "#212121"
                    padding: 8
                }
                
                ColumnLayout {
                    anchors.fill: parent
                    spacing: root.spacingNormal
                    
                    ScrollView {
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        clip: true
                        
                        ListView {
                            id: hostsListView
                            model: ListModel {
                                ListElement {
                                    hostname: "web01.example.com"
                                    ip: "192.168.1.10"
                                    environment: "production"
                                    status: "active"
                                }
                                ListElement {
                                    hostname: "web02.example.com"
                                    ip: "192.168.1.11"
                                    environment: "production"
                                    status: "active"
                                }
                                ListElement {
                                    hostname: "db01.example.com"
                                    ip: "192.168.1.20"
                                    environment: "production"
                                    status: "active"
                                }
                            }
                            spacing: 8
                            
                            delegate: Rectangle {
                                width: ListView.view.width
                                height: 80
                                color: root.surfaceColor
                                radius: 4
                                border.color: root.backgroundColor
                                border.width: 1
                                
                                RowLayout {
                                    anchors.fill: parent
                                    anchors.margins: 12
                                    spacing: 12
                                    
                                    // Icon
                                    Label {
                                        text: "🖥️"
                                        font.pixelSize: 24
                                    }
                                    
                                    // Host info
                                    ColumnLayout {
                                        Layout.fillWidth: true
                                        spacing: 4
                                        
                                        Label {
                                            text: model.hostname
                                            font.pixelSize: root.fontSizeMedium
                                            font.bold: true
                                            color: "#212121"
                                        }
                                        
                                        Label {
                                            text: "IP: " + model.ip
                                            font.pixelSize: 12
                                            color: "#616161"
                                        }
                                    }
                                    
                                    // Environment badge
                                    Rectangle {
                                        Layout.preferredWidth: 90
                                        Layout.preferredHeight: 24
                                        radius: 12
                                        color: {
                                            switch(model.environment) {
                                                case "production": return "#EF5350"  // Softer red
                                                case "staging": return "#FFA726"     // Softer orange
                                                case "development": return "#66BB6A" // Softer green
                                                default: return "#9E9E9E"
                                            }
                                        }
                                        
                                        Label {
                                            anchors.centerIn: parent
                                            text: model.environment
                                            color: "white"
                                            font.pixelSize: 11
                                            font.bold: true
                                        }
                                    }
                                    
                                    // Status
                                    Rectangle {
                                        Layout.preferredWidth: 70
                                        Layout.preferredHeight: 24
                                        radius: 12
                                        color: model.status === "active" ? "#66BB6A" : "#9E9E9E"  // Softer green
                                        
                                        Label {
                                            anchors.centerIn: parent
                                            text: model.status
                                            color: "white"
                                            font.pixelSize: 11
                                        }
                                    }
                                }
                                
                                MouseArea {
                                    anchors.fill: parent
                                    cursorShape: Qt.PointingHandCursor
                                    onClicked: {
                                        hostsListView.currentIndex = index
                                    }
                                }
                            }
                        }
                    }
                    
                    // Host actions
                    RowLayout {
                        spacing: root.spacingNormal
                        
                        Button {
                            text: "➕ Add Host"
                            Layout.preferredHeight: 36
                            
                            background: Rectangle {
                                color: parent.down ? "#616161" : (parent.hovered ? "#757575" : "#9E9E9E")
                                radius: 4
                            }
                            
                            contentItem: Text {
                                text: parent.text
                                color: "white"
                                font.pixelSize: 14
                                horizontalAlignment: Text.AlignHCenter
                                verticalAlignment: Text.AlignVCenter
                            }
                        }
                        
                        Button {
                            text: "✏️ Edit"
                            enabled: hostsListView.currentIndex >= 0
                            Layout.preferredHeight: 36
                            
                            background: Rectangle {
                                color: parent.enabled ? (parent.down ? "#616161" : (parent.hovered ? "#757575" : "#9E9E9E")) : "#E0E0E0"
                                radius: 4
                            }
                            
                            contentItem: Text {
                                text: parent.text
                                color: parent.enabled ? "white" : "#9E9E9E"
                                font.pixelSize: 14
                                horizontalAlignment: Text.AlignHCenter
                                verticalAlignment: Text.AlignVCenter
                            }
                        }
                        
                        Button {
                            text: "🗑️ Remove"
                            enabled: hostsListView.currentIndex >= 0
                            Layout.preferredHeight: 36
                            
                            background: Rectangle {
                                color: parent.enabled ? (parent.down ? "#D32F2F" : (parent.hovered ? "#E53935" : "#EF5350")) : "#E0E0E0"
                                radius: 4
                            }
                            
                            contentItem: Text {
                                text: parent.text
                                color: parent.enabled ? "white" : "#9E9E9E"
                                font.pixelSize: 14
                                horizontalAlignment: Text.AlignHCenter
                                verticalAlignment: Text.AlignVCenter
                            }
                        }
                        
                        Item { Layout.fillWidth: true }
                        
                        Button {
                            text: "📤 Export"
                            Layout.preferredHeight: 36
                            
                            background: Rectangle {
                                color: parent.down ? "#1976D2" : (parent.hovered ? "#1E88E5" : "#2196F3")
                                radius: 4
                            }
                            
                            contentItem: Text {
                                text: parent.text
                                color: "white"
                                font.pixelSize: 14
                                horizontalAlignment: Text.AlignHCenter
                                verticalAlignment: Text.AlignVCenter
                            }
                        }
                    }
                }
            }
        }
    }
}
