"""Template browser widget."""

from typing import Optional

from PyQt6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLineEdit,
    QComboBox,
    QPushButton,
    QScrollArea,
    QLabel,
    QFrame,
    QGridLayout,
    QTextBrowser,
    QSplitter,
    QMessageBox,
)
from PyQt6.QtCore import Qt, QSize, pyqtSignal
from PyQt6.QtGui import QFont

from iac_manager.config import Config
from iac_manager.services import TemplateService
from iac_manager.models import TemplateInfo


class TemplateCard(QFrame):
    """Individual template card widget."""

    clicked = pyqtSignal(TemplateInfo)

    def __init__(self, template: TemplateInfo):
        """Initialize template card.

        Args:
            template: Template information
        """
        super().__init__()
        self.template = template

        self.setFrameStyle(QFrame.Shape.Box | QFrame.Shadow.Raised)
        self.setLineWidth(1)
        self.setMinimumHeight(120)
        self.setMaximumHeight(150)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

        layout = QVBoxLayout(self)

        # Template name
        name_label = QLabel(f"📦 {template.name}")
        name_font = QFont()
        name_font.setPointSize(12)
        name_font.setBold(True)
        name_label.setFont(name_font)
        layout.addWidget(name_label)

        # Category
        category_label = QLabel(f"Category: {template.category}")
        category_label.setStyleSheet("color: #666;")
        layout.addWidget(category_label)

        # Description
        if template.description:
            desc_label = QLabel(template.description[:80] + "...")
            desc_label.setWordWrap(True)
            desc_label.setStyleSheet("color: #555;")
            layout.addWidget(desc_label)

        # Target types
        targets_text = ", ".join(t.value for t in template.target_types)
        targets_label = QLabel(f"🎯 {targets_text}")
        targets_label.setStyleSheet("color: #0066cc; font-size: 10px;")
        layout.addWidget(targets_label)

        layout.addStretch()

    def mousePressEvent(self, event):
        """Handle mouse click."""
        self.clicked.emit(self.template)


class TemplateBrowserWidget(QWidget):
    """Template browser with search and filtering."""

    def __init__(self, config: Config, template_service: TemplateService):
        """Initialize template browser.

        Args:
            config: Configuration object
            template_service: Template service instance
        """
        super().__init__()
        self.config = config
        self.template_service = template_service
        self.templates = []

        self._setup_ui()
        self.refresh()

    def _setup_ui(self) -> None:
        """Setup UI components."""
        layout = QVBoxLayout(self)

        # Header
        header_layout = QHBoxLayout()

        title = QLabel("📦 Template Browser")
        title_font = QFont()
        title_font.setPointSize(16)
        title_font.setBold(True)
        title.setFont(title_font)
        header_layout.addWidget(title)
        header_layout.addStretch()

        refresh_btn = QPushButton("🔄 Refresh")
        refresh_btn.clicked.connect(self.refresh)
        header_layout.addWidget(refresh_btn)

        layout.addLayout(header_layout)

        # Search and filter bar
        filter_layout = QHBoxLayout()

        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("🔍 Search templates...")
        self.search_input.textChanged.connect(self._on_search)
        filter_layout.addWidget(self.search_input, stretch=3)

        self.category_filter = QComboBox()
        self.category_filter.addItem("All Categories")
        self.category_filter.currentTextChanged.connect(self._on_filter_changed)
        filter_layout.addWidget(self.category_filter, stretch=1)

        layout.addLayout(filter_layout)

        # Create splitter for template list and preview
        splitter = QSplitter(Qt.Orientation.Horizontal)

        # Template grid (left side)
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

        self.grid_widget = QWidget()
        self.grid_layout = QGridLayout(self.grid_widget)
        self.grid_layout.setSpacing(10)

        scroll_area.setWidget(self.grid_widget)
        splitter.addWidget(scroll_area)

        # Template preview (right side)
        preview_widget = QWidget()
        preview_layout = QVBoxLayout(preview_widget)

        preview_title = QLabel("Template Preview")
        preview_title_font = QFont()
        preview_title_font.setPointSize(14)
        preview_title_font.setBold(True)
        preview_title.setFont(preview_title_font)
        preview_layout.addWidget(preview_title)

        self.preview_browser = QTextBrowser()
        self.preview_browser.setOpenExternalLinks(True)
        preview_layout.addWidget(self.preview_browser)

        # Deploy button
        self.deploy_btn = QPushButton("🚀 Deploy from Template")
        self.deploy_btn.setEnabled(False)
        self.deploy_btn.clicked.connect(self._on_deploy_clicked)
        preview_layout.addWidget(self.deploy_btn)

        splitter.addWidget(preview_widget)
        splitter.setStretchFactor(0, 2)
        splitter.setStretchFactor(1, 1)

        layout.addWidget(splitter)

        self.selected_template: Optional[TemplateInfo] = None

    def refresh(self) -> None:
        """Refresh template list."""
        # Load templates
        self.templates = self.template_service.list_templates()

        # Update category filter
        categories = sorted(set(t.category for t in self.templates))
        current_text = self.category_filter.currentText()
        self.category_filter.clear()
        self.category_filter.addItem("All Categories")
        self.category_filter.addItems(categories)

        # Restore selection if it still exists
        index = self.category_filter.findText(current_text)
        if index >= 0:
            self.category_filter.setCurrentIndex(index)

        # Update grid
        self._update_grid()

    def _update_grid(self, filtered_templates: Optional[list] = None) -> None:
        """Update template grid.

        Args:
            filtered_templates: Optional list of filtered templates
        """
        # Clear existing grid
        for i in reversed(range(self.grid_layout.count())):
            widget = self.grid_layout.itemAt(i).widget()
            if widget:
                widget.setParent(None)

        templates = filtered_templates if filtered_templates is not None else self.templates

        # Add template cards
        cols = 3
        for i, template in enumerate(templates):
            card = TemplateCard(template)
            card.clicked.connect(self._on_template_selected)
            row = i // cols
            col = i % cols
            self.grid_layout.addWidget(card, row, col)

        # Add stretch at the bottom
        self.grid_layout.setRowStretch(self.grid_layout.rowCount(), 1)

    def _on_search(self, text: str) -> None:
        """Handle search input.

        Args:
            text: Search text
        """
        if not text:
            self._update_grid()
            return

        # Filter templates
        filtered = self.template_service.search_templates(text)

        # Apply category filter if set
        category = self.category_filter.currentText()
        if category != "All Categories":
            filtered = [t for t in filtered if t.category == category]

        self._update_grid(filtered)

    def _on_filter_changed(self, category: str) -> None:
        """Handle category filter change.

        Args:
            category: Selected category
        """
        if category == "All Categories":
            filtered = self.templates
        else:
            filtered = [t for t in self.templates if t.category == category]

        # Apply search filter if set
        search_text = self.search_input.text()
        if search_text:
            query_lower = search_text.lower()
            filtered = [
                t
                for t in filtered
                if query_lower in t.name.lower()
                or (t.description and query_lower in t.description.lower())
            ]

        self._update_grid(filtered)

    def _on_template_selected(self, template: TemplateInfo) -> None:
        """Handle template selection.

        Args:
            template: Selected template
        """
        self.selected_template = template
        self.deploy_btn.setEnabled(True)

        # Load README
        readme = self.template_service.get_template_readme(str(template.path.relative_to(self.config.repo_root)))

        if readme:
            # Convert markdown to HTML (basic)
            try:
                import markdown

                html = markdown.markdown(readme)
                self.preview_browser.setHtml(html)
            except ImportError:
                # Fallback to plain text
                self.preview_browser.setPlainText(readme)
        else:
            self.preview_browser.setHtml(
                f"<h2>{template.name}</h2>"
                f"<p><strong>Category:</strong> {template.category}</p>"
                f"<p><strong>Target Types:</strong> {', '.join(t.value for t in template.target_types)}</p>"
                f"<p>{template.description or 'No description available.'}</p>"
            )

    def _on_deploy_clicked(self) -> None:
        """Handle deploy button click."""
        if not self.selected_template:
            return

        from iac_manager.gui.windows.deploy_wizard import DeployWizard

        wizard = DeployWizard(
            self.config,
            self.template_service,
            None,  # Will create service in wizard
            preselected_template=self.selected_template,
        )
        if wizard.exec():
            QMessageBox.information(
                self, "Success", "Deployment configured successfully!"
            )
