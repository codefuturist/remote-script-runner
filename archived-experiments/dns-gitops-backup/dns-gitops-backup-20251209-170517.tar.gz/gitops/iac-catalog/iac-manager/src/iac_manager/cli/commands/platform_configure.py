"""Enhanced deploy command with platform configuration support."""

import click
from datetime import datetime
from pathlib import Path
from typing import Optional

from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn

from iac_manager.cli.config import Config
from iac_manager.cli.models import EnvironmentType, Manifest, TargetType
from iac_manager.cli.platform_defaults import get_platform_defaults, validate_platform_config
from iac_manager.cli.platform_helpers import (
    select_platform,
    configure_networking_interactive,
    configure_secrets_interactive,
    configure_database_interactive,
    configure_ingress_interactive,
    save_platform_config,
    show_platform_config_summary,
)
from iac_manager.cli.utils import (
    confirm_action,
    copy_with_jinja,
    save_yaml,
    validate_instance_id,
)


@click.command()
@click.option(
    "--template",
    required=True,
    help="Template path (e.g., catalog/containers/erpnext)",
)
@click.option(
    "--instance",
    help="Instance ID (will prompt if not provided)",
)
@click.option(
    "--environment",
    type=click.Choice(["development", "staging", "production", "dr-site"]),
    help="Target environment",
)
@click.option(
    "--platform",
    type=click.Choice(["docker-compose", "docker-swarm", "kubernetes"]),
    help="Deployment platform",
)
@click.option(
    "--use-defaults",
    is_flag=True,
    help="Use platform defaults without prompts",
)
@click.option(
    "--interactive/--no-interactive",
    default=True,
    help="Interactive configuration (default: True)",
)
@click.option(
    "--dry-run",
    is_flag=True,
    help="Show what would be created without creating it",
)
@click.pass_context
def configure_with_platform(
    ctx: click.Context,
    template: str,
    instance: Optional[str],
    environment: Optional[str],
    platform: Optional[str],
    use_defaults: bool,
    interactive: bool,
    dry_run: bool,
) -> None:
    """Configure a new deployment with platform-specific options.

    This enhanced configure command supports platform-aware configuration
    for Docker Compose, Docker Swarm, and Kubernetes deployments.

    Examples:

        # Quick start with defaults
        iac deploy configure --template catalog/erpnext \\
            --platform kubernetes --use-defaults

        # Interactive configuration
        iac deploy configure --template catalog/erpnext \\
            --platform kubernetes --interactive

        # Non-interactive with custom platform
        iac deploy configure --template catalog/erpnext \\
            --platform docker-compose --no-interactive
    """
    config: Config = ctx.obj["config"]
    console: Console = ctx.obj["console"]

    # Validate template
    template_path = config.repo_root / template
    if not template_path.exists():
        console.print(f"[red]Template not found: {template}[/red]")
        ctx.exit(1)

    # Get instance ID
    if not instance:
        instance = click.prompt("Instance ID", type=str)
    
    # instance is now guaranteed to be a string
    assert instance is not None, "Instance ID is required"

    if not validate_instance_id(instance):
        console.print(f"[red]Invalid instance ID: {instance}[/red]")
        ctx.exit(1)

    # Get environment
    if not environment:
        environment = "development"
    
    # environment is now guaranteed to be a string
    assert environment is not None, "Environment is required"

    # Select platform
    if not platform:
        if interactive:
            platform_type = select_platform(console, default="docker-compose")
        else:
            platform_type = TargetType.DOCKER_COMPOSE
    else:
        platform_type = TargetType(platform)

    console.print(f"\n[bold]Selected platform:[/bold] [cyan]{platform_type.value}[/cyan]")

    # Get platform defaults
    platform_config = get_platform_defaults(platform_type)

    # Interactive configuration
    if interactive and not use_defaults:
        console.print("\n[bold cyan]Platform Configuration Wizard[/bold cyan]")
        console.print("[dim]Press Enter to use defaults, or customize as needed[/dim]\n")

        # Configure each component
        networking_config = configure_networking_interactive(
            console, platform_type, platform_config
        )
        platform_config.networking = platform_config.networking.model_copy(
            update=networking_config
        )

        secrets_config = configure_secrets_interactive(
            console, platform_type, platform_config
        )
        platform_config.secrets = platform_config.secrets.model_copy(
            update=secrets_config
        )

        database_config = configure_database_interactive(
            console, platform_type, platform_config
        )
        platform_config.database = platform_config.database.model_copy(
            update=database_config
        )

        ingress_config = configure_ingress_interactive(
            console, platform_type, platform_config
        )
        platform_config.ingress = platform_config.ingress.model_copy(
            update=ingress_config
        )

    # Validate configuration
    validation_errors = validate_platform_config(platform_config)
    if validation_errors:
        console.print("\n[red]Configuration validation errors:[/red]")
        for error in validation_errors:
            console.print(f"  • {error}")
        if not confirm_action("Continue anyway?", default=False):
            ctx.exit(1)

    # Show summary
    show_platform_config_summary(console, platform_config)

    # Determine deployment path
    deployment_path = (
        config.repo_root / config.deployments_dir / environment / instance
    )

    if deployment_path.exists() and not dry_run:
        console.print(
            f"[yellow]Warning: Deployment already exists at {deployment_path}[/yellow]"
        )
        if not confirm_action("Overwrite existing deployment?", default=False):
            console.print("[yellow]Cancelled.[/yellow]")
            ctx.exit(0)

    if dry_run:
        console.print("\n[yellow]Dry run mode - no changes made.[/yellow]")
        return

    # Confirm before proceeding
    if not confirm_action("\nCreate deployment with this configuration?", default=True):
        console.print("[yellow]Cancelled.[/yellow]")
        ctx.exit(0)

    # Create deployment with progress
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task("Creating deployment...", total=None)

        # Create deployment directory
        deployment_path.mkdir(parents=True, exist_ok=True)

        # Save platform configuration
        progress.update(task, description="Saving platform configuration...")
        save_platform_config(platform_config, deployment_path)

        # Copy template files with Jinja2 rendering
        progress.update(task, description="Rendering templates...")
        template_vars = {
            "instance": instance,
            "environment": environment,
            "platform": platform_type.value,
            "config": platform_config.model_dump(),
        }
        
        copy_with_jinja(
            template_path,
            deployment_path,
            template_vars,
            exclude_patterns=["README.md", ".git*", "__pycache__"],
        )

        # Create manifest
        progress.update(task, description="Creating manifest...")
        manifest = Manifest(
            name=instance,
            template=template,
            instance_id=instance,
            environment=EnvironmentType(environment),
            created_at=datetime.now(),
            updated_at=datetime.now(),
        )
        save_yaml(manifest.model_dump(), deployment_path / "manifest.yml")

        # Create scripts directory for init scripts
        scripts_dir = deployment_path / "scripts"
        scripts_dir.mkdir(exist_ok=True)

        # Generate database init script if needed
        if (
            platform_config.database.strategy.value == "internal"
            and platform_config.database.provisioning.enabled
        ):
            progress.update(task, description="Generating database init script...")
            # This would use the database.j2 macro to generate init script
            # For now, create placeholder
            init_script = scripts_dir / "init-db.sh"
            init_script.write_text("#!/bin/bash\n# Database initialization script\n")
            init_script.chmod(0o755)

        # Create .env template
        env_file = deployment_path / ".env"
        if not env_file.exists():
            progress.update(task, description="Creating environment file...")
            env_content = "# Environment variables\n"
            
            # Add secrets based on configuration
            if platform_config.secrets.definitions:
                env_content += "\n# Secrets\n"
                for secret in platform_config.secrets.definitions:
                    env_content += f"{secret.source}=changeme\n"
            
            # Add database credentials
            if platform_config.database.strategy.value == "internal":
                env_content += "\n# Database\n"
                env_content += "DB_ROOT_PASSWORD=changeme\n"
                env_content += "DB_PASSWORD=changeme\n"
            
            env_file.write_text(env_content)

        progress.update(task, description="Done!", completed=True)

    console.print(
        Panel.fit(
            f"[green]✓[/green] Deployment configured successfully!\n\n"
            f"Platform:    [cyan]{platform_type.value}[/cyan]\n"
            f"Location:    [cyan]{deployment_path.relative_to(config.repo_root)}[/cyan]\n\n"
            f"Next steps:\n"
            f"  1. Review configuration: [bold]platform-config.yml[/bold]\n"
            f"  2. Update secrets in: [bold].env[/bold]\n"
            f"  3. Review generated files in deployment directory\n"
            f"  4. Deploy or commit to Git for GitOps\n\n"
            f"Files created:\n"
            f"  • platform-config.yml (platform configuration)\n"
            f"  • manifest.yml (deployment metadata)\n"
            f"  • .env (environment variables)\n"
            f"  • scripts/init-db.sh (database initialization)\n",
            title="Success",
            border_style="green",
        )
    )


if __name__ == "__main__":
    configure_with_platform()
