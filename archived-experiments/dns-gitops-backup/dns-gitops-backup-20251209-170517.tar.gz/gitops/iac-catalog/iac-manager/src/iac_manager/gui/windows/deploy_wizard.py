"""Deployment wizard dialog."""

from typing import Optional, Dict, List, Tuple
from pathlib import Path
from enum import Enum
import re
import secrets
import string

from PyQt6.QtWidgets import (
    QWizard,
    QWizardPage,
    QVBoxLayout,
    QHBoxLayout,
    QFormLayout,
    QLineEdit,
    QComboBox,
    QTextEdit,
    QLabel,
    QCheckBox,
    QSpinBox,
    QGroupBox,
    QScrollArea,
    QWidget,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QHeaderView,
    QFileDialog,
    QFrame,
)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QColor, QBrush

from iac_manager.config import Config
from iac_manager.services import TemplateService, DeploymentService
from iac_manager.models import TemplateInfo, EnvironmentType
from iac_manager.gui.backend.docker_config_backend import DockerConfigBackend


class VariableType(Enum):
    """Type of configuration variable."""
    SECRET = "secret"
    CONFIG = "config"


class VariableCategory(Enum):
    """Category of configuration variable."""
    DATABASE_CONFIG = "Database Configuration"
    DATABASE_SECRET = "Database Secrets"
    APPLICATION_SECRET = "Application Secrets"
    CUSTOM = "Custom Variables"


class DeployWizard(QWizard):
    """Wizard for deploying from template."""

    def __init__(
        self,
        config: Config,
        template_service: TemplateService,
        deployment_service: Optional[DeploymentService] = None,
        preselected_template: Optional[TemplateInfo] = None,
    ):
        """Initialize deployment wizard.

        Args:
            config: Configuration object
            template_service: Template service instance
            deployment_service: Deployment service instance
            preselected_template: Optional preselected template
        """
        super().__init__()
        self.config = config
        self.template_service = template_service
        self.deployment_service = deployment_service or DeploymentService(config)
        self.preselected_template = preselected_template

        self.setWindowTitle("Deploy from Template")
        self.setMinimumSize(800, 600)

        # Create Docker config backend
        self.docker_backend = DockerConfigBackend(config, template_service)

        # Add wizard pages
        self.addPage(TemplateSelectionPage(self))
        self.addPage(DockerConfigPage(self))
        self.addPage(ConfigurationPage(self))
        self.addPage(PreviewPage(self))
        self.addPage(ReviewPage(self))


class TemplateSelectionPage(QWizardPage):
    """Page for selecting template."""

    def __init__(self, wizard: DeployWizard):
        """Initialize page.

        Args:
            wizard: Parent wizard
        """
        super().__init__()
        self.wizard_ref = wizard

        self.setTitle("Select Template")
        self.setSubTitle("Choose a Jinja2 template for your deployment")

        layout = QVBoxLayout(self)

        # Template selection
        form = QFormLayout()
        
        self.template_combo = QComboBox()
        self.template_combo.currentIndexChanged.connect(self._onTemplateChanged)
        form.addRow("Template File:", self.template_combo)

        self.browse_btn = QPushButton("Browse...")
        self.browse_btn.clicked.connect(self._browseTemplate)
        form.addRow("Custom Template:", self.browse_btn)

        layout.addLayout(form)

        # Template info
        info_group = QGroupBox("Template Information")
        info_layout = QVBoxLayout(info_group)
        
        self.template_info = QLabel("Select a template to see details")
        self.template_info.setWordWrap(True)
        info_layout.addWidget(self.template_info)
        
        layout.addWidget(info_group)

        # Variables preview
        vars_group = QGroupBox("Template Variables")
        vars_layout = QVBoxLayout(vars_group)
        
        self.vars_preview = QTextEdit()
        self.vars_preview.setReadOnly(True)
        self.vars_preview.setMaximumHeight(150)
        vars_layout.addWidget(self.vars_preview)
        
        layout.addWidget(vars_group)

        layout.addStretch()

        # Load available templates
        self._loadTemplates()

    def _loadTemplates(self):
        """Load available Jinja2 templates."""
        from pathlib import Path
        
        # Get catalog directory
        catalog_path = self.wizard_ref.config.repo_root / self.wizard_ref.config.catalog_dir
        
        # Find all .j2 files in catalog
        self.templates: List[Dict[str, str]] = []
        
        if catalog_path.exists():
            for j2_file in catalog_path.rglob("*.j2"):
                # Skip hidden files and certain directories
                if any(part.startswith('.') for part in j2_file.parts):
                    continue
                if 'node_modules' in j2_file.parts or '__pycache__' in j2_file.parts:
                    continue
                    
                rel_path = j2_file.relative_to(catalog_path)
                self.templates.append({
                    'name': str(rel_path),
                    'path': str(j2_file),
                    'display': f"{rel_path.parent.name}/{rel_path.name}" if rel_path.parent != Path('.') else rel_path.name
                })

        # Populate combo box
        self.template_combo.clear()
        for tmpl in self.templates:
            self.template_combo.addItem(tmpl['display'], tmpl)

    def _onTemplateChanged(self, index: int):
        """Handle template selection change."""
        if index < 0:
            return
            
        template = self.template_combo.itemData(index)
        if not template:
            return

        # Update info
        self.template_info.setText(f"Path: {template['path']}\n\nThis template will be used to generate your deployment configuration.")

        # Extract and show variables
        variables = self._extractTemplateVariables(template['path'])
        if variables:
            vars_text = "\n".join(f"  • {var}" for var in sorted(variables))
        else:
            vars_text = "No variables detected in template."
        self.vars_preview.setPlainText(vars_text)

    def _extractTemplateVariables(self, template_path: str) -> List[str]:
        """Extract Jinja2 variables from template.

        Args:
            template_path: Path to template file

        Returns:
            List of variable names
        """
        try:
            with open(template_path, 'r') as f:
                content = f.read()

            # Match {{ variable_name }} patterns
            pattern = r'\{\{\s*([a-zA-Z_][a-zA-Z0-9_]*)\s*[\|\}]'
            matches = re.findall(pattern, content)
            
            # Filter out common Jinja2 functions/keywords
            excluded = {'range', 'loop', 'super', 'self', 'varargs', 'kwargs', 'default', 'true', 'false', 'none'}
            variables = [m for m in matches if m not in excluded]
            
            return list(set(variables))  # Remove duplicates
        except Exception as e:
            print(f"Error extracting variables: {e}")
            return []

    def _extractTemplateVariablesWithDefaults(self, template_path: str) -> Dict[str, str]:
        """Extract Jinja2 variables with their default values from template.

        Args:
            template_path: Path to template file

        Returns:
            Dictionary mapping variable names to default values (empty string if no default)
        """
        try:
            with open(template_path, 'r') as f:
                content = f.read()

            variables_with_defaults = {}
            
            # Pattern 1: {{ variable | default('value') }}
            default_pattern1 = r'\{\{\s*([a-zA-Z_][a-zA-Z0-9_]*)\s*\|\s*default\([\'"]([^\'"]*)[\'"]?\)'
            matches1 = re.findall(default_pattern1, content)
            for var_name, default_value in matches1:
                variables_with_defaults[var_name] = default_value
            
            # Pattern 2: {{ variable | default(value) }} - without quotes
            default_pattern2 = r'\{\{\s*([a-zA-Z_][a-zA-Z0-9_]*)\s*\|\s*default\(([^\)]+)\)'
            matches2 = re.findall(default_pattern2, content)
            for var_name, default_value in matches2:
                if var_name not in variables_with_defaults:
                    # Clean up the default value
                    default_value = default_value.strip().strip('"\'')
                    variables_with_defaults[var_name] = default_value
            
            # Pattern 3: Simple {{ variable }} without default
            simple_pattern = r'\{\{\s*([a-zA-Z_][a-zA-Z0-9_]*)\s*[\|\}]'
            simple_matches = re.findall(simple_pattern, content)
            
            # Filter out common Jinja2 functions/keywords
            excluded = {'range', 'loop', 'super', 'self', 'varargs', 'kwargs', 'default', 'true', 'false', 'none'}
            
            for var_name in simple_matches:
                if var_name not in excluded and var_name not in variables_with_defaults:
                    variables_with_defaults[var_name] = ""
            
            return variables_with_defaults
        except Exception as e:
            print(f"Error extracting variables with defaults: {e}")
            return {}

    def _browseTemplate(self):
        """Browse for custom template file."""
        catalog_path = self.wizard_ref.config.repo_root / self.wizard_ref.config.catalog_dir
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Template File",
            str(catalog_path),
            "Jinja2 Templates (*.j2);;All Files (*)"
        )
        
        if file_path:
            # Add to list if not already there
            custom_template = {
                'name': 'custom',
                'path': file_path,
                'display': f"Custom: {Path(file_path).name}"
            }
            self.template_combo.addItem(custom_template['display'], custom_template)
            self.template_combo.setCurrentIndex(self.template_combo.count() - 1)

    def getSelectedTemplate(self) -> Optional[Dict[str, str]]:
        """Get the currently selected template."""
        index = self.template_combo.currentIndex()
        if index >= 0:
            return self.template_combo.itemData(index)
        return None

    def getTemplateVariables(self) -> List[str]:
        """Get variables from selected template."""
        template = self.getSelectedTemplate()
        if template:
            return self._extractTemplateVariables(template['path'])
        return []


class ConfigurationPage(QWizardPage):
    """Page for configuring deployment."""

    def __init__(self, wizard: DeployWizard):
        """Initialize page.

        Args:
            wizard: Parent wizard
        """
        super().__init__()
        self.wizard_ref = wizard

        self.setTitle("Configure Deployment")
        self.setSubTitle("Enter deployment configuration and environment variables")

        main_layout = QVBoxLayout(self)

        # Basic configuration
        form = QFormLayout()

        self.instance_input = QLineEdit()
        form.addRow("Instance ID:", self.instance_input)

        self.env_combo = QComboBox()
        self.env_combo.addItems([e.value for e in EnvironmentType])
        form.addRow("Environment:", self.env_combo)

        main_layout.addLayout(form)

        # Environment Variables Section
        env_group = QGroupBox("Environment Variables")
        env_layout = QVBoxLayout(env_group)

        # Buttons
        btn_layout = QHBoxLayout()
        
        load_btn = QPushButton("Load from Template")
        load_btn.setToolTip("Load variables from the selected template")
        load_btn.clicked.connect(self._loadTemplateVariables)
        btn_layout.addWidget(load_btn)
        
        add_btn = QPushButton("Add Variable")
        add_btn.setToolTip("Add a new empty variable")
        add_btn.clicked.connect(self._addVariable)
        btn_layout.addWidget(add_btn)
        
        clear_all_btn = QPushButton("Clear All Values")
        clear_all_btn.setToolTip("Clear all values but keep variable names")
        clear_all_btn.clicked.connect(self._clearAllValues)
        btn_layout.addWidget(clear_all_btn)
        
        btn_layout.addStretch()
        env_layout.addLayout(btn_layout)

        # Table for variables (now with 4 columns)
        self.env_table = QTableWidget()
        self.env_table.setColumnCount(4)
        self.env_table.setHorizontalHeaderLabels(["Variable", "Value", "Type", "Actions"])
        header = self.env_table.horizontalHeader()
        if header:
            header.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
            header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
            header.setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
            header.setSectionResizeMode(3, QHeaderView.ResizeMode.Fixed)
        self.env_table.setColumnWidth(3, 110)  # Wider for 3 buttons
        env_layout.addWidget(self.env_table)

        # Strategy Preview Section
        self._createStrategyPreview(env_layout)

        main_layout.addWidget(env_group)
    
    def initializePage(self):
        """Initialize page when entered - auto-load template variables."""
        # Auto-load template variables when page is first shown
        if self.env_table.rowCount() == 0:  # Only load if table is empty
            self._loadTemplateVariables()

    def _createStrategyPreview(self, layout: QVBoxLayout):
        """Create strategy preview section.

        Args:
            layout: Parent layout
        """
        preview_frame = QFrame()
        preview_frame.setFrameStyle(QFrame.Shape.StyledPanel | QFrame.Shadow.Raised)
        preview_layout = QVBoxLayout(preview_frame)

        preview_label = QLabel("<b>Secret Strategy Preview</b>")
        preview_layout.addWidget(preview_label)

        self.strategy_preview = QLabel()
        self.strategy_preview.setWordWrap(True)
        self.strategy_preview.setStyleSheet(
            "background-color: #f5f5f5; padding: 10px; "
            "border: 1px solid #ddd; border-radius: 4px; "
            "font-family: monospace; font-size: 10pt; "
            "color: #2c3e50;"  # Dark text color for readability
        )
        self._updateStrategyPreview()
        preview_layout.addWidget(self.strategy_preview)

        layout.addWidget(preview_frame)

    def _updateStrategyPreview(self):
        """Update the strategy preview based on selected strategy."""
        # Get current strategy from Docker config
        try:
            strategy = self.wizard_ref.docker_backend.dockerConfig.secretType
        except:
            strategy = "env"

        previews = {
            "env-inline": (
                "💡 <b>Environment Variables (Inline)</b><br>"
                "Secrets appear directly in docker-compose.yml:<br><br>"
                "📄 <code>MYSQL_DATABASE: myapp_db</code><br>"
                "🔒 <code>MYSQL_PASSWORD: changeme_password</code><br><br>"
                "⚠️ Not recommended for production (secrets visible in file)"
            ),
            "env": (
                "💡 <b>Environment File (.env)</b><br>"
                "Secrets loaded from .env file:<br><br>"
                "📄 <code>MYSQL_DATABASE: myapp_db</code><br>"
                "🔒 <code>MYSQL_PASSWORD: ${DB_PASSWORD}</code><br><br>"
                "✅ Requires .env file with: <code>DB_PASSWORD=actual_secret</code>"
            ),
            "file": (
                "💡 <b>Mounted Files</b><br>"
                "Secrets mounted from files:<br><br>"
                "📄 <code>MYSQL_DATABASE: myapp_db</code><br>"
                "🔒 <code>MYSQL_PASSWORD_FILE: /run/secrets/db_password</code><br><br>"
                "✅ Requires files in ./secrets/ directory"
            ),
            "docker-secret": (
                "💡 <b>Docker Secrets (Swarm)</b><br>"
                "Native Docker Swarm secrets:<br><br>"
                "📄 <code>MYSQL_DATABASE: myapp_db</code><br>"
                "🔒 <code>MYSQL_PASSWORD_FILE: /run/secrets/db_password</code><br><br>"
                "✅ Requires Swarm mode and secrets created via:<br>"
                "<code>echo 'secret' | docker secret create db_password -</code>"
            ),
            "external": (
                "💡 <b>External Provider (Vault, AWS, etc.)</b><br>"
                "Secrets managed by external service:<br><br>"
                "Configuration depends on provider."
            )
        }

        preview_text = previews.get(strategy, previews["env"])
        self.strategy_preview.setText(preview_text)

    def _detectVariableType(self, var_name: str) -> VariableType:
        """Auto-detect if variable is a secret based on name patterns.

        Args:
            var_name: Variable name

        Returns:
            VariableType.SECRET or VariableType.CONFIG
        """
        secret_patterns = [
            'password', 'secret', 'key', 'token', 
            'api_key', 'auth', 'credential', 'passwd',
            'private', 'cert', 'certificate'
        ]
        var_lower = var_name.lower()
        
        if any(pattern in var_lower for pattern in secret_patterns):
            return VariableType.SECRET
        
        return VariableType.CONFIG

    def _categorizeVariable(self, var_name: str, var_type: VariableType) -> VariableCategory:
        """Categorize variable for grouping.

        Args:
            var_name: Variable name
            var_type: Variable type

        Returns:
            VariableCategory
        """
        var_lower = var_name.lower()
        
        # Database configuration (non-secrets)
        if var_type == VariableType.CONFIG:
            if any(x in var_lower for x in ['db_name', 'db_user', 'database', 'mysql_database', 'postgres_db']):
                return VariableCategory.DATABASE_CONFIG
        
        # Database secrets
        if var_type == VariableType.SECRET:
            if any(x in var_lower for x in ['db_', 'mysql_', 'postgres_', 'mariadb_']):
                return VariableCategory.DATABASE_SECRET
            
            # Application secrets (API keys, tokens, etc.)
            return VariableCategory.APPLICATION_SECRET
        
        # Custom/other variables
        return VariableCategory.CUSTOM

    def _loadTemplateVariables(self):
        """Load variables from selected template."""
        template_page = self.wizard_ref.page(0)  # TemplateSelectionPage
        if not isinstance(template_page, TemplateSelectionPage):
            return

        # Get variables with their default values
        template = template_page.getSelectedTemplate()
        if not template:
            return
            
        variables_with_defaults = template_page._extractTemplateVariablesWithDefaults(template['path'])
        
        # Clear existing rows
        self.env_table.setRowCount(0)

        # Group variables by category
        categorized_vars: Dict[VariableCategory, List[Tuple[str, str, VariableType]]] = {
            VariableCategory.DATABASE_CONFIG: [],
            VariableCategory.DATABASE_SECRET: [],
            VariableCategory.APPLICATION_SECRET: [],
            VariableCategory.CUSTOM: []
        }

        # Categorize all variables
        for var in sorted(variables_with_defaults.keys()):
            default_value = variables_with_defaults[var]
            var_type = self._detectVariableType(var)
            category = self._categorizeVariable(var, var_type)
            categorized_vars[category].append((var, default_value, var_type))

        # Add rows in category order
        for category in VariableCategory:
            for var, default_value, var_type in categorized_vars[category]:
                self._addVariableRow(var, default_value, var_type)

        # Update strategy preview
        self._updateStrategyPreview()

    def _addVariable(self):
        """Add a new empty variable row."""
        self._addVariableRow("", "", VariableType.CONFIG)

    def _addVariableRow(self, name: str, value: str, var_type: VariableType):
        """Add a variable row to the table.

        Args:
            name: Variable name
            value: Variable value
            var_type: Variable type (SECRET or CONFIG)
        """
        row = self.env_table.rowCount()
        self.env_table.insertRow(row)

        # Name cell
        name_item = QTableWidgetItem(name)
        name_item.setForeground(QBrush(QColor(0, 0, 0)))  # Black text for readability
        self.env_table.setItem(row, 0, name_item)

        # Value cell - style differently for secrets
        value_item = QTableWidgetItem(value)
        if var_type == VariableType.SECRET:
            # Light yellow background for secrets with dark text
            value_item.setBackground(QBrush(QColor(255, 255, 200)))
            value_item.setForeground(QBrush(QColor(0, 0, 0)))  # Black text for readability
        else:
            # Ensure normal cells also have dark text
            value_item.setForeground(QBrush(QColor(0, 0, 0)))
        self.env_table.setItem(row, 1, value_item)

        # Type cell - dropdown to allow user override
        type_combo = QComboBox()
        type_combo.addItem("📄 Config", VariableType.CONFIG.value)
        type_combo.addItem("🔒 Secret", VariableType.SECRET.value)
        type_combo.setCurrentText("🔒 Secret" if var_type == VariableType.SECRET else "📄 Config")
        type_combo.currentIndexChanged.connect(lambda: self._onTypeChanged(row))
        type_combo.setToolTip(
            "Config: Regular configuration (db_name, db_user)\n"
            "Secret: Sensitive data (passwords, keys, tokens)"
        )
        self.env_table.setCellWidget(row, 2, type_combo)

        # Actions cell
        actions_widget = QWidget()
        actions_layout = QHBoxLayout(actions_widget)
        actions_layout.setContentsMargins(2, 2, 2, 2)
        actions_layout.setSpacing(2)

        # Generate password button (for secrets)
        gen_pass_btn = QPushButton("🔑")
        gen_pass_btn.setToolTip("Generate random password")
        gen_pass_btn.setMaximumWidth(30)
        gen_pass_btn.setEnabled(var_type == VariableType.SECRET)
        gen_pass_btn.clicked.connect(lambda: self._generatePassword(row))
        actions_layout.addWidget(gen_pass_btn)

        # Clear value button
        clear_btn = QPushButton("🧹")
        clear_btn.setToolTip("Clear value (keep variable name)")
        clear_btn.setMaximumWidth(30)
        clear_btn.clicked.connect(lambda: self._clearValue(row))
        actions_layout.addWidget(clear_btn)

        # Remove variable button
        remove_btn = QPushButton("❌")
        remove_btn.setToolTip("Remove variable completely")
        remove_btn.setMaximumWidth(30)
        remove_btn.clicked.connect(lambda: self._removeVariable(row))
        actions_layout.addWidget(remove_btn)

        self.env_table.setCellWidget(row, 3, actions_widget)

    def _onTypeChanged(self, row: int):
        """Handle type change for a variable.

        Args:
            row: Table row index
        """
        # Update Generate button enabled state
        actions_widget = self.env_table.cellWidget(row, 3)
        if actions_widget:
            gen_btn = actions_widget.findChild(QPushButton)
            if gen_btn and gen_btn.toolTip() == "Generate random password":
                type_combo = self.env_table.cellWidget(row, 2)
                if isinstance(type_combo, QComboBox):
                    is_secret = type_combo.currentData() == VariableType.SECRET.value
                    gen_btn.setEnabled(is_secret)
                    
                    # Update cell background
                    value_item = self.env_table.item(row, 1)
                    if value_item:
                        if is_secret:
                            value_item.setBackground(QBrush(QColor(255, 255, 200)))
                            value_item.setForeground(QBrush(QColor(0, 0, 0)))  # Black text
                        else:
                            value_item.setBackground(QBrush(QColor(255, 255, 255)))
                            value_item.setForeground(QBrush(QColor(0, 0, 0)))  # Black text

    def _generatePassword(self, row: int):
        """Generate a random password for a variable.

        Args:
            row: Table row index
        """
        alphabet = string.ascii_letters + string.digits + "!@#$%^&*()-_=+"
        password = ''.join(secrets.choice(alphabet) for _ in range(32))
        
        value_item = self.env_table.item(row, 1)
        if value_item:
            value_item.setText(password)

    def _clearValue(self, row: int):
        """Clear the value of a variable but keep the variable name.

        Args:
            row: Table row index
        """
        value_item = self.env_table.item(row, 1)
        if value_item:
            value_item.setText("")

    def _clearAllValues(self):
        """Clear all values in the table but keep variable names."""
        for row in range(self.env_table.rowCount()):
            value_item = self.env_table.item(row, 1)
            if value_item:
                value_item.setText("")

    def _removeVariable(self, row: int):
        """Remove a variable row.

        Args:
            row: Table row index
        """
        self.env_table.removeRow(row)

    def getEnvironmentVariables(self) -> Dict[str, str]:
        """Get all environment variables from the table.

        Returns:
            Dictionary of variable name to value
        """
        env_vars = {}
        for row in range(self.env_table.rowCount()):
            name_item = self.env_table.item(row, 0)
            value_item = self.env_table.item(row, 1)
            
            if name_item and value_item:
                name = name_item.text().strip()
                value = value_item.text().strip()
                if name:  # Only add non-empty variable names
                    env_vars[name] = value
        
        return env_vars

    def getSecretVariables(self) -> Dict[str, str]:
        """Get only secret variables from the table.

        Returns:
            Dictionary of secret variable name to value
        """
        secret_vars = {}
        for row in range(self.env_table.rowCount()):
            name_item = self.env_table.item(row, 0)
            value_item = self.env_table.item(row, 1)
            type_combo = self.env_table.cellWidget(row, 2)
            
            if name_item and value_item and isinstance(type_combo, QComboBox):
                is_secret = type_combo.currentData() == VariableType.SECRET.value
                if is_secret:
                    name = name_item.text().strip()
                    value = value_item.text().strip()
                    if name:
                        secret_vars[name] = value
        
        return secret_vars

    def getConfigVariables(self) -> Dict[str, str]:
        """Get only config (non-secret) variables from the table.

        Returns:
            Dictionary of config variable name to value
        """
        config_vars = {}
        for row in range(self.env_table.rowCount()):
            name_item = self.env_table.item(row, 0)
            value_item = self.env_table.item(row, 1)
            type_combo = self.env_table.cellWidget(row, 2)
            
            if name_item and value_item and isinstance(type_combo, QComboBox):
                is_config = type_combo.currentData() == VariableType.CONFIG.value
                if is_config:
                    name = name_item.text().strip()
                    value = value_item.text().strip()
                    if name:
                        config_vars[name] = value
        
        return config_vars


class ReviewPage(QWizardPage):
    """Page for reviewing configuration."""

    def __init__(self, wizard: DeployWizard):
        """Initialize page.

        Args:
            wizard: Parent wizard
        """
        super().__init__()
        self.wizard_ref = wizard

        self.setTitle("Review Configuration")
        self.setSubTitle("Review your deployment configuration")

        layout = QVBoxLayout(self)
        self.review_text = QTextEdit()
        self.review_text.setReadOnly(True)
        layout.addWidget(self.review_text)


class DockerConfigPage(QWizardPage):
    """Page for Docker-specific configuration."""

    def __init__(self, wizard: DeployWizard):
        """Initialize page.

        Args:
            wizard: Parent wizard
        """
        super().__init__()
        self.wizard_ref = wizard

        self.setTitle("Docker Configuration")
        self.setSubTitle("Configure Docker deployment options")

        # Main layout
        main_layout = QVBoxLayout(self)

        # Create scroll area for all options
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

        # Container widget for scroll area
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setSpacing(15)

        # Deployment Mode Section
        self._createDeploymentModeSection(layout)

        # Ingress Section
        self._createIngressSection(layout)

        # Secrets Section
        self._createSecretsSection(layout)

        # Network Section
        self._createNetworkSection(layout)

        # Database Section
        self._createDatabaseSection(layout)

        # Advanced Options Section (collapsible)
        self._createAdvancedSection(layout)

        # Add stretch at the end
        layout.addStretch()

        scroll.setWidget(container)
        main_layout.addWidget(scroll)

    def _createDeploymentModeSection(self, layout: QVBoxLayout):
        """Create deployment mode selection.

        Args:
            layout: Parent layout
        """
        group = QGroupBox("Deployment Mode")
        form = QFormLayout(group)

        self.mode_combo = QComboBox()
        self.mode_combo.addItems(["standalone", "swarm"])
        self.mode_combo.currentTextChanged.connect(self._onModeChanged)
        form.addRow("Mode:", self.mode_combo)

        mode_help = QLabel("Choose 'standalone' for single-host Docker or 'swarm' for Docker Swarm cluster")
        mode_help.setWordWrap(True)
        mode_help.setStyleSheet("color: gray; font-size: 10pt;")
        form.addRow("", mode_help)

        layout.addWidget(group)

    def _createIngressSection(self, layout: QVBoxLayout):
        """Create ingress configuration.

        Args:
            layout: Parent layout
        """
        group = QGroupBox("Ingress / Reverse Proxy")
        form = QFormLayout(group)

        self.ingress_enabled = QCheckBox("Enable Ingress")
        self.ingress_enabled.stateChanged.connect(self._onIngressToggled)
        form.addRow(self.ingress_enabled)

        self.ingress_type = QComboBox()
        self.ingress_type.addItems(["traefik"])
        self.ingress_type.setEnabled(False)
        form.addRow("Type:", self.ingress_type)

        self.traefik_rule = QLineEdit("Host(`app.local`)")
        self.traefik_rule.setEnabled(False)
        form.addRow("Traefik Rule:", self.traefik_rule)

        self.ssl_enabled = QCheckBox("Enable SSL/TLS")
        self.ssl_enabled.setEnabled(False)
        form.addRow(self.ssl_enabled)

        ingress_help = QLabel("Traefik provides reverse proxy with automatic SSL via Let's Encrypt")
        ingress_help.setWordWrap(True)
        ingress_help.setStyleSheet("color: gray; font-size: 10pt;")
        form.addRow("", ingress_help)

        layout.addWidget(group)

    def _createSecretsSection(self, layout: QVBoxLayout):
        """Create secrets management configuration.

        Args:
            layout: Parent layout
        """
        group = QGroupBox("Secrets Management")
        form = QFormLayout(group)

        self.secret_type = QComboBox()
        self.secret_type.addItem("Environment File (.env)", "env")
        self.secret_type.addItem("Environment Variables (Inline)", "env-inline")
        self.secret_type.addItem("Mounted Files", "file")
        self.secret_type.addItem("Docker Secrets (Swarm)", "docker-secret")
        self.secret_type.addItem("External Provider (Vault, etc.)", "external")
        self.secret_type.currentIndexChanged.connect(self._onSecretTypeChanged)
        form.addRow("Strategy:", self.secret_type)

        self.secret_provider = QComboBox()
        self.secret_provider.addItems(["local", "vault", "aws-secrets-manager", "azure-keyvault"])
        self.secret_provider.setEnabled(False)
        form.addRow("Provider:", self.secret_provider)

        # Warning label for validation issues
        self.secret_warning = QLabel()
        self.secret_warning.setWordWrap(True)
        self.secret_warning.setStyleSheet("color: orange; font-weight: bold;")
        self.secret_warning.hide()
        form.addRow("", self.secret_warning)

        secrets_help = QLabel(
            "• Environment File: Load from .env file\n"
            "• Inline Variables: Configure directly in docker-compose.yml\n"
            "• Mounted Files: Mount secrets directory as read-only\n"
            "• Docker Secrets: Native Docker Swarm secret management\n"
            "• External: Use external secret provider (Vault, AWS, Azure)"
        )
        secrets_help.setWordWrap(True)
        secrets_help.setStyleSheet("color: gray; font-size: 10pt;")
        form.addRow("", secrets_help)

        layout.addWidget(group)

    def _createNetworkSection(self, layout: QVBoxLayout):
        """Create network configuration.

        Args:
            layout: Parent layout
        """
        group = QGroupBox("Network Configuration")
        form = QFormLayout(group)

        self.network_type = QComboBox()
        self.network_type.addItem("Bridge (default)", "bridge")
        self.network_type.addItem("Overlay (Swarm)", "overlay")
        self.network_type.addItem("Host", "host")
        self.network_type.currentIndexChanged.connect(self._onNetworkTypeChanged)
        form.addRow("Type:", self.network_type)

        self.network_external = QCheckBox("Use External Network")
        form.addRow(self.network_external)

        self.network_internal = QCheckBox("Internal Only (no external access)")
        form.addRow(self.network_internal)

        self.network_warning = QLabel()
        self.network_warning.setWordWrap(True)
        self.network_warning.setStyleSheet("color: orange; font-weight: bold;")
        self.network_warning.hide()
        form.addRow("", self.network_warning)

        network_help = QLabel("Bridge for single host, Overlay for multi-host Swarm clusters")
        network_help.setWordWrap(True)
        network_help.setStyleSheet("color: gray; font-size: 10pt;")
        form.addRow("", network_help)

        layout.addWidget(group)

    def _createDatabaseSection(self, layout: QVBoxLayout):
        """Create database configuration.

        Args:
            layout: Parent layout
        """
        group = QGroupBox("Database Configuration")
        form = QFormLayout(group)

        # Strategy selection with 4 options
        self.db_strategy = QComboBox()
        self.db_strategy.addItem("❌ None - No database needed", "none")
        self.db_strategy.addItem("📦 Managed Container - Create database in this deployment", "managed")
        self.db_strategy.addItem("🔗 Existing Container - Connect to database on same network", "container")
        self.db_strategy.addItem("🌐 External Host - Connect to remote database", "external")
        self.db_strategy.setCurrentIndex(1)  # Default to "managed"
        self.db_strategy.currentIndexChanged.connect(self._onDatabaseStrategyChanged)
        form.addRow("Strategy:", self.db_strategy)

        # Help text (will be updated based on selection)
        self.db_help = QLabel()
        self.db_help.setWordWrap(True)
        self.db_help.setStyleSheet("color: gray; font-size: 10pt; padding: 5px;")
        form.addRow("", self.db_help)

        # Common fields
        self.db_name_label = QLabel("Database Name:")
        self.db_name = QLineEdit("appdb")
        form.addRow(self.db_name_label, self.db_name)

        self.db_username_label = QLabel("Username:")
        self.db_username = QLineEdit("dbuser")
        form.addRow(self.db_username_label, self.db_username)

        self.db_password_label = QLabel("Password:")
        self.db_password = QLineEdit()
        self.db_password.setEchoMode(QLineEdit.EchoMode.Password)
        self.db_password.setPlaceholderText("Leave empty to generate")
        form.addRow(self.db_password_label, self.db_password)

        # Managed container options
        self.db_type_label = QLabel("Type:")
        self.db_type = QComboBox()
        self.db_type.addItems(["mariadb", "postgresql", "mysql", "mongodb", "redis"])
        self.db_type.currentTextChanged.connect(self._onDatabaseTypeChanged)
        form.addRow(self.db_type_label, self.db_type)

        self.db_version_label = QLabel("Version:")
        self.db_version = QLineEdit("10.6")
        form.addRow(self.db_version_label, self.db_version)

        # Container strategy options
        self.db_container_label = QLabel("Container/Service Name:")
        self.db_container_name = QLineEdit()
        self.db_container_name.setPlaceholderText("e.g., postgres-db, mysql-service")
        form.addRow(self.db_container_label, self.db_container_name)

        self.db_network_label = QLabel("Network Name:")
        self.db_network_name = QLineEdit("backend")
        self.db_network_name.setPlaceholderText("e.g., backend-network")
        form.addRow(self.db_network_label, self.db_network_name)

        # External/Container host options
        self.db_host_label = QLabel("Host:")
        self.db_host = QLineEdit()
        self.db_host.setPlaceholderText("e.g., db.example.com, 192.168.1.100")
        form.addRow(self.db_host_label, self.db_host)

        self.db_port_label = QLabel("Port:")
        self.db_port = QSpinBox()
        self.db_port.setRange(1, 65535)
        self.db_port.setValue(3306)
        form.addRow(self.db_port_label, self.db_port)

        # External only - SSL option
        self.db_ssl = QCheckBox("Enable SSL/TLS")
        self.db_ssl.setToolTip("Use encrypted connection to database")
        form.addRow("", self.db_ssl)

        # Connection string preview
        self.db_connection_preview_label = QLabel("Connection:")
        self.db_connection_preview = QLabel()
        self.db_connection_preview.setWordWrap(True)
        self.db_connection_preview.setStyleSheet(
            "background-color: #f0f0f0; padding: 8px; border-radius: 4px; "
            "font-family: monospace; font-size: 10pt; color: #2c3e50;"
        )
        form.addRow(self.db_connection_preview_label, self.db_connection_preview)

        layout.addWidget(group)

        # Connect signals to update preview dynamically
        self.db_name.textChanged.connect(self._updateDatabaseConnectionPreview)
        self.db_username.textChanged.connect(self._updateDatabaseConnectionPreview)
        self.db_container_name.textChanged.connect(self._updateDatabaseConnectionPreview)
        self.db_network_name.textChanged.connect(self._updateDatabaseConnectionPreview)
        self.db_host.textChanged.connect(self._updateDatabaseConnectionPreview)
        self.db_port.valueChanged.connect(self._updateDatabaseConnectionPreview)

        # Set initial visibility and preview
        self._onDatabaseStrategyChanged(1)  # Default to "managed"

    def _createAdvancedSection(self, layout: QVBoxLayout):
        """Create advanced configuration options.

        Args:
            layout: Parent layout
        """
        group = QGroupBox("Advanced Options")
        group.setCheckable(True)
        group.setChecked(False)  # Collapsed by default
        form = QFormLayout(group)

        # Resource Limits
        resources_label = QLabel("<b>Resource Limits</b>")
        form.addRow(resources_label)

        self.cpu_limit = QLineEdit()
        self.cpu_limit.setPlaceholderText("e.g., 2.0 or 2000m")
        form.addRow("CPU Limit:", self.cpu_limit)

        self.memory_limit = QLineEdit()
        self.memory_limit.setPlaceholderText("e.g., 1G or 512M")
        form.addRow("Memory Limit:", self.memory_limit)

        self.cpu_reservation = QLineEdit()
        self.cpu_reservation.setPlaceholderText("e.g., 0.5")
        form.addRow("CPU Reservation:", self.cpu_reservation)

        self.memory_reservation = QLineEdit()
        self.memory_reservation.setPlaceholderText("e.g., 256M")
        form.addRow("Memory Reservation:", self.memory_reservation)

        # Healthcheck
        healthcheck_label = QLabel("<b>Healthcheck</b>")
        form.addRow(healthcheck_label)

        self.healthcheck_enabled = QCheckBox("Enable Healthcheck")
        self.healthcheck_enabled.setChecked(True)
        form.addRow(self.healthcheck_enabled)

        self.healthcheck_interval = QLineEdit("30s")
        form.addRow("Interval:", self.healthcheck_interval)

        self.healthcheck_retries = QSpinBox()
        self.healthcheck_retries.setRange(1, 10)
        self.healthcheck_retries.setValue(3)
        form.addRow("Retries:", self.healthcheck_retries)

        # Restart Policy
        restart_label = QLabel("<b>Restart Policy</b>")
        form.addRow(restart_label)

        self.restart_policy = QComboBox()
        self.restart_policy.addItems([
            "unless-stopped",
            "always",
            "on-failure",
            "no"
        ])
        form.addRow("Policy:", self.restart_policy)

        # Port Mapping
        port_label = QLabel("<b>Port Mapping</b>")
        form.addRow(port_label)

        self.expose_ports = QCheckBox("Expose Ports")
        self.expose_ports.setChecked(True)
        form.addRow(self.expose_ports)

        self.host_port = QSpinBox()
        self.host_port.setRange(1, 65535)
        self.host_port.setValue(8080)
        form.addRow("Host Port:", self.host_port)

        self.container_port = QSpinBox()
        self.container_port.setRange(1, 65535)
        self.container_port.setValue(80)
        form.addRow("Container Port:", self.container_port)

        # Scaling (for Swarm mode)
        scaling_label = QLabel("<b>Scaling (Swarm mode)</b>")
        form.addRow(scaling_label)

        self.replicas = QSpinBox()
        self.replicas.setRange(1, 100)
        self.replicas.setValue(1)
        form.addRow("Replicas:", self.replicas)

        # Logging
        logging_label = QLabel("<b>Logging</b>")
        form.addRow(logging_label)

        self.log_driver = QComboBox()
        self.log_driver.addItems([
            "json-file",
            "journald",
            "syslog",
            "none"
        ])
        form.addRow("Driver:", self.log_driver)

        self.log_max_size = QLineEdit("10m")
        form.addRow("Max Size:", self.log_max_size)

        self.log_max_file = QLineEdit("3")
        form.addRow("Max Files:", self.log_max_file)

        layout.addWidget(group)

    def _onModeChanged(self, mode: str):
        """Handle deployment mode change.

        Args:
            mode: Selected mode
        """
        self.wizard_ref.docker_backend.dockerConfig.deploymentMode = mode
        self._validateConfiguration()

    def _onIngressToggled(self, state: int):
        """Handle ingress toggle.

        Args:
            state: Checkbox state
        """
        enabled = state == Qt.CheckState.Checked.value
        self.wizard_ref.docker_backend.dockerConfig.ingressEnabled = enabled
        self.ingress_type.setEnabled(enabled)
        self.traefik_rule.setEnabled(enabled)
        self.ssl_enabled.setEnabled(enabled)

    def _onSecretTypeChanged(self, index: int):
        """Handle secret type change.

        Args:
            index: Combo box index
        """
        secret_type = self.secret_type.itemData(index)
        self.wizard_ref.docker_backend.dockerConfig.secretType = secret_type
        
        # Update Configuration page preview if it exists (now page 2)
        config_page = self.wizard_ref.page(2)  # ConfigurationPage
        if hasattr(config_page, '_updateStrategyPreview'):
            config_page._updateStrategyPreview()
        
        self._validateConfiguration()

    def _onNetworkTypeChanged(self, index: int):
        """Handle network type change.

        Args:
            index: Combo box index
        """
        network_type = self.network_type.itemData(index)
        self.wizard_ref.docker_backend.dockerConfig.networkType = network_type
        self._validateConfiguration()

    def _onDatabaseStrategyChanged(self, index: int):
        """Handle database strategy change.

        Args:
            index: Combo box index
        """
        strategy = self.db_strategy.itemData(index)
        self.wizard_ref.docker_backend.dockerConfig.databaseStrategy = strategy

        # Update help text based on strategy
        help_texts = {
            "none": "Select this if your application doesn't use a database.",
            "managed": "Creates a new database container in this deployment. Best for development and simple deployments.",
            "container": "Connects to an existing database container on the same Docker network. Use for microservices or when database is managed separately.",
            "external": "Connects to a database on a different host or cloud service (AWS RDS, Azure SQL, etc.)"
        }
        self.db_help.setText(help_texts.get(strategy, ""))

        # Show/hide fields based on strategy
        is_none = strategy == "none"
        is_managed = strategy == "managed"
        is_container = strategy == "container"
        is_external = strategy == "external"

        # Common fields (shown for all except none)
        self.db_name_label.setVisible(not is_none)
        self.db_name.setVisible(not is_none)
        self.db_username_label.setVisible(not is_none)
        self.db_username.setVisible(not is_none)
        self.db_password_label.setVisible(not is_none)
        self.db_password.setVisible(not is_none)

        # Managed-only fields
        self.db_type_label.setVisible(is_managed)
        self.db_type.setVisible(is_managed)
        self.db_version_label.setVisible(is_managed)
        self.db_version.setVisible(is_managed)

        # Container-only fields
        self.db_container_label.setVisible(is_container)
        self.db_container_name.setVisible(is_container)
        self.db_network_label.setVisible(is_container)
        self.db_network_name.setVisible(is_container)

        # External and Container fields
        self.db_host_label.setVisible(is_external)
        self.db_host.setVisible(is_external)

        # Container and External fields (port)
        self.db_port_label.setVisible(is_container or is_external)
        self.db_port.setVisible(is_container or is_external)

        # External-only fields
        self.db_ssl.setVisible(is_external)

        # Connection preview (shown for all except none)
        self.db_connection_preview_label.setVisible(not is_none)
        self.db_connection_preview.setVisible(not is_none)

        # Update connection preview
        self._updateDatabaseConnectionPreview()

    def _onDatabaseTypeChanged(self, db_type: str):
        """Handle database type change to update default port.

        Args:
            db_type: Selected database type
        """
        # Update port to default for selected database type
        port_defaults = {
            'mariadb': 3306,
            'mysql': 3306,
            'postgresql': 5432,
            'mongodb': 27017,
            'redis': 6379
        }
        self.db_port.setValue(port_defaults.get(db_type, 3306))
        
        # Update version defaults
        version_defaults = {
            'mariadb': '10.6',
            'mysql': '8.0',
            'postgresql': '15',
            'mongodb': '7.0',
            'redis': '7.2'
        }
        self.db_version.setText(version_defaults.get(db_type, '1.0'))
        
        # Update backend
        self.wizard_ref.docker_backend.dockerConfig.databaseType = db_type
        
        # Update connection preview
        self._updateDatabaseConnectionPreview()

    def _updateDatabaseConnectionPreview(self):
        """Update the database connection string preview."""
        config = self.wizard_ref.docker_backend.dockerConfig
        
        # Sync current values to backend before generating preview
        config.databaseType = self.db_type.currentText()
        config.databaseName = self.db_name.text()
        config.databaseUsername = self.db_username.text()
        config.databaseHost = self.db_host.text()
        config.databasePort = self.db_port.value()
        config.databaseContainerName = self.db_container_name.text()
        
        preview = config.getDatabaseConnectionPreview()
        self.db_connection_preview.setText(preview)

    def _validateConfiguration(self):
        """Validate current configuration and show warnings."""
        config = self.wizard_ref.docker_backend.dockerConfig
        mode = config.deploymentMode
        secret_type = config.secretType
        network_type = config.networkType

        # Check Docker Secrets
        if secret_type == "docker-secret" and mode != "swarm":
            self.secret_warning.setText("⚠️ Docker Secrets require Swarm mode")
            self.secret_warning.show()
        else:
            self.secret_warning.hide()

        # Check Overlay network
        if network_type == "overlay" and mode != "swarm":
            self.network_warning.setText("⚠️ Overlay networks require Swarm mode")
            self.network_warning.show()
        else:
            self.network_warning.hide()

    def validatePage(self) -> bool:
        """Validate page before moving to next.

        Returns:
            True if valid, False otherwise
        """
        # Sync all values to backend
        config = self.wizard_ref.docker_backend.dockerConfig
        config.ingressType = self.ingress_type.currentText()
        config.traefikRule = self.traefik_rule.text()
        config.sslEnabled = self.ssl_enabled.isChecked()
        config.networkExternal = self.network_external.isChecked()
        config.networkInternal = self.network_internal.isChecked()
        
        # Sync database configuration
        config.databaseType = self.db_type.currentText()
        config.databaseVersion = self.db_version.text()
        config.databaseHost = self.db_host.text()
        config.databasePort = self.db_port.value()
        config.databaseName = self.db_name.text()
        config.databaseUsername = self.db_username.text()
        config.databasePassword = self.db_password.text()
        config.databaseContainerName = self.db_container_name.text()
        config.databaseNetworkName = self.db_network_name.text()
        config.databaseSslEnabled = self.db_ssl.isChecked()

        # Sync advanced options if they exist
        if hasattr(self, 'cpu_limit'):
            config.cpuLimit = self.cpu_limit.text()
            config.memoryLimit = self.memory_limit.text()
            config.cpuReservation = self.cpu_reservation.text()
            config.memoryReservation = self.memory_reservation.text()
            config.healthcheckEnabled = self.healthcheck_enabled.isChecked()
            config.healthcheckInterval = self.healthcheck_interval.text()
            config.healthcheckRetries = self.healthcheck_retries.value()
            config.restartPolicy = self.restart_policy.currentText()
            config.exposePorts = self.expose_ports.isChecked()
            config.hostPort = self.host_port.value()
            config.containerPort = self.container_port.value()
            config.replicas = self.replicas.value()
            config.logDriver = self.log_driver.currentText()
            config.logMaxSize = self.log_max_size.text()

        # Validate
        errors = config.validate()
        if errors:
            # Show errors in a message box or status label
            error_msg = "\n".join(errors)
            # You could add a QMessageBox here if desired
            print(f"Validation errors: {error_msg}")
            return False

        return True


class PreviewPage(QWizardPage):
    """Page for previewing and editing the generated configuration."""

    def __init__(self, wizard: DeployWizard):
        """Initialize page.

        Args:
            wizard: Parent wizard
        """
        super().__init__()
        self.wizard_ref = wizard

        self.setTitle("Configuration Preview")
        self.setSubTitle("Review and edit the generated docker-compose.yml")

        layout = QVBoxLayout(self)

        # Info label
        info_label = QLabel(
            "Below is the generated docker-compose.yml based on your selections. "
            "You can edit it directly before deployment."
        )
        info_label.setWordWrap(True)
        layout.addWidget(info_label)

        # Preview editor
        self.preview_editor = QTextEdit()
        self.preview_editor.setFontFamily("Courier")
        self.preview_editor.setLineWrapMode(QTextEdit.LineWrapMode.NoWrap)
        layout.addWidget(self.preview_editor)

        # Buttons
        button_layout = QHBoxLayout()
        button_layout.addStretch()

        self.regenerate_btn = QPushButton("Regenerate from Config")
        self.regenerate_btn.clicked.connect(self._onRegenerate)
        button_layout.addWidget(self.regenerate_btn)

        layout.addLayout(button_layout)

        # Connect to backend signals
        wizard.docker_backend.previewGenerated.connect(self._onPreviewGenerated)

    def initializePage(self):
        """Initialize page when entered."""
        # Generate initial preview
        self.wizard_ref.docker_backend.regeneratePreview()

    def _onPreviewGenerated(self, yaml_content: str):
        """Handle preview generated signal.

        Args:
            yaml_content: Generated YAML content
        """
        self.preview_editor.setPlainText(yaml_content)

    def _onRegenerate(self):
        """Handle regenerate button click."""
        self.wizard_ref.docker_backend.regeneratePreview()

    def validatePage(self) -> bool:
        """Validate page before moving to next.

        Returns:
            True if valid
        """
        # Store the potentially edited preview
        custom_yaml = self.preview_editor.toPlainText()
        self.wizard_ref.docker_backend.applyCustomPreview(custom_yaml)
        return True

