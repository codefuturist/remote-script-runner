"""Validation utilities for Docker configuration."""

import re
from typing import Optional, Tuple
from ipaddress import ip_address, AddressValueError


class ValidationResult:
    """Result of a validation check."""
    
    def __init__(self, valid: bool, message: str = ""):
        """Initialize validation result.
        
        Args:
            valid: Whether the validation passed
            message: Error message if validation failed
        """
        self.valid = valid
        self.message = message
    
    def __bool__(self) -> bool:
        """Return validation status."""
        return self.valid


class ConfigValidator:
    """Validator for Docker configuration fields."""
    
    # Common ports that shouldn't be exposed publicly
    DANGEROUS_PORTS = {3306, 5432, 27017, 6379, 9200}
    
    @staticmethod
    def validate_hostname(hostname: str) -> ValidationResult:
        """Validate hostname or IP address.
        
        Args:
            hostname: Hostname or IP to validate
            
        Returns:
            ValidationResult with status and message
        """
        if not hostname or not hostname.strip():
            return ValidationResult(False, "Hostname cannot be empty")
        
        hostname = hostname.strip()
        
        # Check if it's an IP address
        try:
            ip_address(hostname)
            return ValidationResult(True)
        except AddressValueError:
            pass
        
        # Validate hostname format (RFC 1123)
        # Must be 1-253 characters, labels 1-63 chars, alphanumeric and hyphens
        hostname_pattern = re.compile(
            r'^(?=.{1,253}$)'  # Total length 1-253
            r'(?!-)'  # No leading hyphen
            r'(?:[a-zA-Z0-9-]{1,63}\.)*'  # Labels with dots
            r'[a-zA-Z0-9-]{1,63}'  # Final label
            r'(?<!-)$'  # No trailing hyphen
        )
        
        if hostname_pattern.match(hostname):
            return ValidationResult(True)
        
        return ValidationResult(
            False, 
            "Invalid hostname format. Use domain name or IP address"
        )
    
    @staticmethod
    def validate_port(port: int, warn_dangerous: bool = True) -> ValidationResult:
        """Validate port number.
        
        Args:
            port: Port number to validate
            warn_dangerous: Whether to warn about dangerous ports
            
        Returns:
            ValidationResult with status and message
        """
        if not isinstance(port, int):
            return ValidationResult(False, "Port must be a number")
        
        if port < 1 or port > 65535:
            return ValidationResult(
                False, 
                "Port must be between 1 and 65535"
            )
        
        # Warn about privileged ports
        if port < 1024:
            return ValidationResult(
                True, 
                "⚠️ Privileged port (< 1024) requires elevated permissions"
            )
        
        # Warn about dangerous database ports
        if warn_dangerous and port in ConfigValidator.DANGEROUS_PORTS:
            return ValidationResult(
                True,
                f"⚠️ Warning: Port {port} is commonly used for databases. "
                "Ensure proper security measures."
            )
        
        return ValidationResult(True)
    
    @staticmethod
    def validate_memory_limit(limit: str) -> ValidationResult:
        """Validate memory limit format.
        
        Args:
            limit: Memory limit (e.g., "512m", "2g")
            
        Returns:
            ValidationResult with status and message
        """
        if not limit or not limit.strip():
            return ValidationResult(True)  # Optional field
        
        limit = limit.strip().lower()
        
        # Pattern: number followed by optional unit (b, k, m, g)
        pattern = re.compile(r'^(\d+(?:\.\d+)?)(b|k|m|g)?$')
        match = pattern.match(limit)
        
        if not match:
            return ValidationResult(
                False,
                "Invalid format. Use: 512m, 2g, 1024m"
            )
        
        value, unit = match.groups()
        value = float(value)
        
        # Warn about very low memory
        if unit in ('m', None) and value < 128:
            return ValidationResult(
                True,
                "⚠️ Warning: Very low memory limit may cause issues"
            )
        
        return ValidationResult(True)
    
    @staticmethod
    def validate_cpu_limit(limit: str) -> ValidationResult:
        """Validate CPU limit format.
        
        Args:
            limit: CPU limit (e.g., "0.5", "2", "1.5")
            
        Returns:
            ValidationResult with status and message
        """
        if not limit or not limit.strip():
            return ValidationResult(True)  # Optional field
        
        limit = limit.strip()
        
        try:
            value = float(limit)
            if value <= 0:
                return ValidationResult(
                    False,
                    "CPU limit must be greater than 0"
                )
            if value > 128:  # Reasonable upper limit
                return ValidationResult(
                    False,
                    "CPU limit seems too high (max: 128)"
                )
            return ValidationResult(True)
        except ValueError:
            return ValidationResult(
                False,
                "Invalid format. Use decimal number: 0.5, 1, 2"
            )
    
    @staticmethod
    def validate_version_tag(version: str) -> ValidationResult:
        """Validate Docker image version tag.
        
        Args:
            version: Version string
            
        Returns:
            ValidationResult with status and message
        """
        if not version or not version.strip():
            return ValidationResult(False, "Version cannot be empty")
        
        version = version.strip()
        
        # Docker tag pattern: alphanumeric, dots, dashes, underscores
        # Max 128 characters
        pattern = re.compile(r'^[a-zA-Z0-9._-]{1,128}$')
        
        if not pattern.match(version):
            return ValidationResult(
                False,
                "Invalid version format. Use: 10.6, latest, 14-alpine"
            )
        
        return ValidationResult(True)
    
    @staticmethod
    def validate_traefik_rule(rule: str) -> ValidationResult:
        """Validate Traefik routing rule.
        
        Args:
            rule: Traefik rule string
            
        Returns:
            ValidationResult with status and message
        """
        if not rule or not rule.strip():
            return ValidationResult(False, "Traefik rule cannot be empty")
        
        rule = rule.strip()
        
        # Common patterns: Host(`example.com`), PathPrefix(`/api`), etc.
        common_matchers = ['Host', 'HostRegexp', 'Path', 'PathPrefix', 
                          'Method', 'Headers', 'Query']
        
        has_matcher = any(matcher in rule for matcher in common_matchers)
        
        if not has_matcher:
            return ValidationResult(
                False,
                "Rule should contain matcher like Host(), PathPrefix(), etc."
            )
        
        # Check for balanced backticks
        if rule.count('`') % 2 != 0:
            return ValidationResult(
                False,
                "Unbalanced backticks in rule"
            )
        
        return ValidationResult(True)
    
    @staticmethod
    def validate_instance_name(name: str) -> ValidationResult:
        """Validate instance/container name.
        
        Args:
            name: Instance name
            
        Returns:
            ValidationResult with status and message
        """
        if not name or not name.strip():
            return ValidationResult(False, "Instance name cannot be empty")
        
        name = name.strip()
        
        # Docker container name rules: alphanumeric, underscores, hyphens, dots
        # Must start with alphanumeric
        pattern = re.compile(r'^[a-zA-Z0-9][a-zA-Z0-9_.-]*$')
        
        if not pattern.match(name):
            return ValidationResult(
                False,
                "Name must start with letter/number and contain only: "
                "letters, numbers, _, -, ."
            )
        
        if len(name) > 63:
            return ValidationResult(
                False,
                "Name too long (max 63 characters)"
            )
        
        return ValidationResult(True)
    
    @staticmethod
    def check_port_conflict(port: int, existing_ports: list) -> ValidationResult:
        """Check if port conflicts with existing deployments.
        
        Args:
            port: Port to check
            existing_ports: List of already used ports
            
        Returns:
            ValidationResult with status and message
        """
        if port in existing_ports:
            return ValidationResult(
                False,
                f"⚠️ Port {port} is already in use by another deployment"
            )
        
        return ValidationResult(True)


class SecretValidator:
    """Validator for secrets and sensitive data."""
    
    WEAK_PASSWORDS = {
        'password', '123456', 'admin', 'root', 'test', 
        'changeme', 'default', '12345678', 'qwerty'
    }
    
    @staticmethod
    def validate_password_strength(password: str) -> ValidationResult:
        """Validate password strength.
        
        Args:
            password: Password to validate
            
        Returns:
            ValidationResult with status and message
        """
        if not password or not password.strip():
            return ValidationResult(False, "Password cannot be empty")
        
        password = password.strip()
        
        # Check against common weak passwords
        if password.lower() in SecretValidator.WEAK_PASSWORDS:
            return ValidationResult(
                False,
                "⚠️ This is a common weak password. Use a stronger password."
            )
        
        # Check minimum length
        if len(password) < 8:
            return ValidationResult(
                False,
                "Password should be at least 8 characters"
            )
        
        # Check for complexity (at least 2 of: lowercase, uppercase, numbers, special)
        has_lower = any(c.islower() for c in password)
        has_upper = any(c.isupper() for c in password)
        has_digit = any(c.isdigit() for c in password)
        has_special = any(not c.isalnum() for c in password)
        
        complexity = sum([has_lower, has_upper, has_digit, has_special])
        
        if complexity < 2:
            return ValidationResult(
                True,
                "⚠️ Consider using a mix of letters, numbers, and symbols"
            )
        
        return ValidationResult(True)
    
    @staticmethod
    def is_likely_secret(var_name: str) -> bool:
        """Check if variable name suggests it contains a secret.
        
        Args:
            var_name: Variable name to check
            
        Returns:
            True if name suggests secret content
        """
        secret_patterns = [
            'password', 'passwd', 'pwd', 'secret', 'key', 'token', 
            'api_key', 'apikey', 'auth', 'credential', 'private',
            'cert', 'certificate', 'salt', 'hash'
        ]
        
        var_lower = var_name.lower()
        return any(pattern in var_lower for pattern in secret_patterns)
