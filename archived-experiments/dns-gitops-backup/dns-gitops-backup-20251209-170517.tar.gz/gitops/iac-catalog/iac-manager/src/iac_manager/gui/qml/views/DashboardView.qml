// DashboardView.qml - Modern dashboard with statistics and quick actions
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "../components"
import "../theme"

Item {
    id: root
    
    property var deploymentBackend: null
    property var gitopsBackend: null
    
    ScrollView {
        anchors.fill: parent
        clip: true
        contentWidth: availableWidth
        
        ColumnLayout {
            width: parent.parent.width
            spacing: Theme.spacingLarge
            
            // Header
            RowLayout {
                Layout.fillWidth: true
                spacing: Theme.spacingMedium
                
                Column {
                    spacing: Theme.spacing1
                    
                    Label {
                        text: "Dashboard"
                        font.pixelSize: Theme.fontSizeH2
                        font.weight: Theme.fontWeightBold
                        color: Theme.textPrimary
                    }
                    
                    Label {
                        text: "Overview of your infrastructure"
                        font.pixelSize: Theme.fontSizeNormal
                        color: Theme.textSecondary
                    }
                }
                
                Item { Layout.fillWidth: true }
                
                CustomButton {
                    text: "Refresh"
                    iconName: "refresh"
                    buttonType: "outlined"
                    size: "medium"
                    onClicked: {
                        if (deploymentBackend) deploymentBackend.refresh()
                        if (gitopsBackend) gitopsBackend.refresh()
                    }
                }
            }
            
            // Statistics Cards with modern design
            GridLayout {
                columns: 4
                rowSpacing: Theme.spacingMedium
                columnSpacing: Theme.spacingMedium
                Layout.fillWidth: true
                
                // Deployments Stat Card
                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 140
                    color: Theme.surfaceColor
                    radius: Theme.radiusLarge
                    
                    Shadow {
                        anchors.fill: parent
                        elevation: 1
                        shadowRadius: parent.radius
                    }
                    
                    // Gradient overlay
                    Rectangle {
                        anchors.fill: parent
                        radius: parent.radius
                        opacity: 0.05
                        gradient: Gradient {
                            GradientStop { position: 0.0; color: Theme.primary }
                            GradientStop { position: 1.0; color: "transparent" }
                        }
                    }
                    
                    ColumnLayout {
                        anchors.fill: parent
                        anchors.margins: Theme.spacingMedium
                        spacing: Theme.spacing2
                        
                        Row {
                            spacing: Theme.spacing3
                            
                            Rectangle {
                                width: 48
                                height: 48
                                radius: Theme.radiusMedium
                                color: Theme.alpha(Theme.primary, 0.1)
                                
                                Text {
                                    anchors.centerIn: parent
                                    text: "🚀"
                                    font.pixelSize: 28
                                }
                            }
                        }
                        
                        Item { Layout.fillHeight: true }
                        
                        Label {
                            text: "Total Deployments"
                            font.pixelSize: Theme.fontSizeSmall
                            font.weight: Theme.fontWeightMedium
                            color: Theme.textSecondary
                        }
                        
                        Row {
                            spacing: Theme.spacing2
                            
                            Label {
                                text: deploymentBackend ? deploymentBackend.model.rowCount() : "0"
                                font.pixelSize: Theme.fontSizeH2
                                font.weight: Theme.fontWeightBold
                                color: Theme.primary
                            }
                            
                            StatusBadge {
                                status: "info"
                                badgeText: "Active"
                                size: "small"
                                anchors.verticalCenter: parent.verticalCenter
                            }
                        }
                    }
                    
                    // Hover effect
                    scale: mouseArea1.containsMouse ? 1.02 : 1.0
                    Behavior on scale {
                        NumberAnimation { duration: Theme.animationDuration; easing.type: Easing.OutCubic }
                    }
                    
                    MouseArea {
                        id: mouseArea1
                        anchors.fill: parent
                        hoverEnabled: true
                    }
                }
                
                // Modified Files Card
                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 140
                    color: Theme.surfaceColor
                    radius: Theme.radiusLarge
                    
                    Shadow {
                        anchors.fill: parent
                        elevation: 1
                        shadowRadius: parent.radius
                    }
                    
                    Rectangle {
                        anchors.fill: parent
                        radius: parent.radius
                        opacity: 0.05
                        gradient: Gradient {
                            GradientStop { position: 0.0; color: Theme.warning }
                            GradientStop { position: 1.0; color: "transparent" }
                        }
                    }
                    
                    ColumnLayout {
                        anchors.fill: parent
                        anchors.margins: Theme.spacingMedium
                        spacing: Theme.spacing2
                        
                        Rectangle {
                            width: 48
                            height: 48
                            radius: Theme.radiusMedium
                            color: Theme.alpha(Theme.warning, 0.1)
                            
                            Text {
                                anchors.centerIn: parent
                                text: "🔄"
                                font.pixelSize: 28
                            }
                        }
                        
                        Item { Layout.fillHeight: true }
                        
                        Label {
                            text: "Modified Files"
                            font.pixelSize: Theme.fontSizeSmall
                            font.weight: Theme.fontWeightMedium
                            color: Theme.textSecondary
                        }
                        
                        Label {
                            text: gitopsBackend ? gitopsBackend.modifiedCount : "0"
                            font.pixelSize: Theme.fontSizeH2
                            font.weight: Theme.fontWeightBold
                            color: gitopsBackend && gitopsBackend.modifiedCount > 0 ? Theme.warning : Theme.success
                        }
                    }
                    
                    scale: mouseArea2.containsMouse ? 1.02 : 1.0
                    Behavior on scale {
                        NumberAnimation { duration: Theme.animationDuration; easing.type: Easing.OutCubic }
                    }
                    
                    MouseArea {
                        id: mouseArea2
                        anchors.fill: parent
                        hoverEnabled: true
                    }
                }
                
                // Staged Files Card
                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 140
                    color: Theme.surfaceColor
                    radius: Theme.radiusLarge
                    
                    Shadow {
                        anchors.fill: parent
                        elevation: 1
                        shadowRadius: parent.radius
                    }
                    
                    Rectangle {
                        anchors.fill: parent
                        radius: parent.radius
                        opacity: 0.05
                        gradient: Gradient {
                            GradientStop { position: 0.0; color: Theme.success }
                            GradientStop { position: 1.0; color: "transparent" }
                        }
                    }
                    
                    ColumnLayout {
                        anchors.fill: parent
                        anchors.margins: Theme.spacingMedium
                        spacing: Theme.spacing2
                        
                        Rectangle {
                            width: 48
                            height: 48
                            radius: Theme.radiusMedium
                            color: Theme.alpha(Theme.success, 0.1)
                            
                            Text {
                                anchors.centerIn: parent
                                text: "📦"
                                font.pixelSize: 28
                            }
                        }
                        
                        Item { Layout.fillHeight: true }
                        
                        Label {
                            text: "Staged Files"
                            font.pixelSize: Theme.fontSizeSmall
                            font.weight: Theme.fontWeightMedium
                            color: Theme.textSecondary
                        }
                        
                        Label {
                            text: gitopsBackend ? gitopsBackend.stagedCount : "0"
                            font.pixelSize: Theme.fontSizeH2
                            font.weight: Theme.fontWeightBold
                            color: Theme.success
                        }
                    }
                    
                    scale: mouseArea3.containsMouse ? 1.02 : 1.0
                    Behavior on scale {
                        NumberAnimation { duration: Theme.animationDuration; easing.type: Easing.OutCubic }
                    }
                    
                    MouseArea {
                        id: mouseArea3
                        anchors.fill: parent
                        hoverEnabled: true
                    }
                }
                
                // System Health Card
                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 140
                    color: Theme.surfaceColor
                    radius: Theme.radiusLarge
                    
                    Shadow {
                        anchors.fill: parent
                        elevation: 1
                        shadowRadius: parent.radius
                    }
                    
                    Rectangle {
                        anchors.fill: parent
                        radius: parent.radius
                        opacity: 0.05
                        gradient: Gradient {
                            GradientStop { position: 0.0; color: Theme.accent }
                            GradientStop { position: 1.0; color: "transparent" }
                        }
                    }
                    
                    ColumnLayout {
                        anchors.fill: parent
                        anchors.margins: Theme.spacingMedium
                        spacing: Theme.spacing2
                        
                        Rectangle {
                            width: 48
                            height: 48
                            radius: Theme.radiusMedium
                            color: Theme.alpha(Theme.accent, 0.1)
                            
                            Text {
                                anchors.centerIn: parent
                                text: "💚"
                                font.pixelSize: 28
                            }
                        }
                        
                        Item { Layout.fillHeight: true }
                        
                        Label {
                            text: "System Health"
                            font.pixelSize: Theme.fontSizeSmall
                            font.weight: Theme.fontWeightMedium
                            color: Theme.textSecondary
                        }
                        
                        Row {
                            spacing: Theme.spacing2
                            
                            Label {
                                text: "Healthy"
                                font.pixelSize: Theme.fontSizeLarge
                                font.weight: Theme.fontWeightBold
                                color: Theme.success
                            }
                            
                            StatusBadge {
                                status: "success"
                                badgeText: "100%"
                                size: "small"
                                anchors.verticalCenter: parent.verticalCenter
                            }
                        }
                    }
                    
                    scale: mouseArea4.containsMouse ? 1.02 : 1.0
                    Behavior on scale {
                        NumberAnimation { duration: Theme.animationDuration; easing.type: Easing.OutCubic }
                    }
                    
                    MouseArea {
                        id: mouseArea4
                        anchors.fill: parent
                        hoverEnabled: true
                    }
                }
            }
            
            // Quick Actions Section
            Rectangle {
                Layout.fillWidth: true
                Layout.preferredHeight: 180
                color: Theme.surfaceColor
                radius: Theme.radiusLarge
                
                Shadow {
                    anchors.fill: parent
                    elevation: 1
                    shadowRadius: parent.radius
                }
                
                ColumnLayout {
                    anchors.fill: parent
                    anchors.margins: Theme.spacingLarge
                    spacing: Theme.spacingMedium
                    
                    Label {
                        text: "Quick Actions"
                        font.pixelSize: Theme.fontSizeLarge
                        font.weight: Theme.fontWeightBold
                        color: Theme.textPrimary
                    }
                    
                    RowLayout {
                        spacing: Theme.spacingMedium
                        Layout.fillWidth: true
                        
                        CustomButton {
                            text: "Refresh Status"
                            iconName: "refresh"
                            buttonType: "primary"
                            Layout.preferredWidth: 180
                            onClicked: {
                                if (deploymentBackend) deploymentBackend.refresh()
                                if (gitopsBackend) gitopsBackend.refresh()
                            }
                        }
                        
                        CustomButton {
                            text: "View Deployments"
                            iconName: "deploy"
                            buttonType: "secondary"
                            Layout.preferredWidth: 180
                        }
                        
                        CustomButton {
                            text: "GitOps"
                            iconName: "🔄"
                            buttonType: "outlined"
                            Layout.preferredWidth: 180
                        }
                        
                        Item { Layout.fillWidth: true }
                    }
                }
            }
            
            // System Status Section
            Rectangle {
                Layout.fillWidth: true
                Layout.preferredHeight: 160
                color: Theme.surfaceColor
                radius: Theme.radiusLarge
                
                Shadow {
                    anchors.fill: parent
                    elevation: 1
                    shadowRadius: parent.radius
                }
                
                ColumnLayout {
                    anchors.fill: parent
                    anchors.margins: Theme.spacingLarge
                    spacing: Theme.spacingMedium
                    
                    Label {
                        text: "System Status"
                        font.pixelSize: Theme.fontSizeLarge
                        font.weight: Theme.fontWeightBold
                        color: Theme.textPrimary
                    }
                    
                    Label {
                        text: gitopsBackend ? gitopsBackend.statusMessage : "Ready"
                        font.pixelSize: Theme.fontSizeNormal
                        color: Theme.textSecondary
                        Layout.fillWidth: true
                        wrapMode: Text.WordWrap
                    }
                    
                    Rectangle {
                        Layout.fillWidth: true
                        height: 1
                        color: Theme.dividerColor
                    }
                    
                    RowLayout {
                        spacing: Theme.spacingLarge
                        
                        Column {
                            spacing: Theme.spacing1
                            
                            Label {
                                text: "Current Branch"
                                font.pixelSize: Theme.fontSizeSmall
                                color: Theme.textSecondary
                            }
                            
                            Label {
                                text: gitopsBackend ? gitopsBackend.branch : "unknown"
                                color: Theme.primary
                                font.pixelSize: Theme.fontSizeMedium
                                font.weight: Theme.fontWeightSemiBold
                            }
                        }
                        
                        Rectangle {
                            width: 1
                            height: 40
                            color: Theme.dividerColor
                        }
                        
                        Column {
                            spacing: Theme.spacing1
                            
                            Label {
                                text: "Repository"
                                font.pixelSize: Theme.fontSizeSmall
                                color: Theme.textSecondary
                            }
                            
                            Label {
                                text: "iac-catalog"
                                color: Theme.textPrimary
                                font.pixelSize: Theme.fontSizeMedium
                                font.weight: Theme.fontWeightSemiBold
                            }
                        }
                    }
                }
            }
            
            Item {
                Layout.fillHeight: true
                Layout.minimumHeight: Theme.spacingLarge
            }
        }
    }
    
    Component.onCompleted: {
        // Initial refresh
        if (deploymentBackend) deploymentBackend.refresh()
        if (gitopsBackend) gitopsBackend.refresh()
    }
}
