// TemplateBrowserView.qml - Modern template browser with cards
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "../components"
import "../theme"

Item {
    id: root
    
    property var backend: templateBackend
    
    Component.onCompleted: {
        if (backend) {
            backend.refresh("all")
        }
    }
    
    ColumnLayout {
        anchors.fill: parent
        spacing: Theme.spacingMedium
        
        // Header with search and filters
        RowLayout {
            spacing: Theme.spacingMedium
            Layout.fillWidth: true
            
            Column {
                spacing: Theme.spacing1
                
                Label {
                    text: "Template Browser"
                    font.pixelSize: Theme.fontSizeH3
                    font.weight: Theme.fontWeightBold
                    color: Theme.textPrimary
                }
                
                Label {
                    text: backend ? backend.status : "Loading templates..."
                    font.pixelSize: Theme.fontSizeNormal
                    color: Theme.textSecondary
                }
            }
            
            Item { Layout.fillWidth: true }
            
            ComboBox {
                id: categoryFilter
                model: ["all", "containers", "cloud", "on-premises", "gitops", "self-hosted"]
                Layout.preferredWidth: 180
                
                onCurrentTextChanged: {
                    if (backend) backend.refresh(currentText)
                }
                
                background: Rectangle {
                    color: Theme.surfaceColor
                    border.color: Theme.borderColor
                    border.width: 1
                    radius: Theme.radiusNormal
                }
                
                contentItem: Text {
                    leftPadding: Theme.spacing3
                    rightPadding: Theme.spacing3
                    text: categoryFilter.displayText
                    font: categoryFilter.font
                    color: Theme.textPrimary
                    verticalAlignment: Text.AlignVCenter
                }
            }
            
            CustomButton {
                text: "Refresh"
                iconName: "refresh"
                buttonType: "outlined"
                size: "medium"
                onClicked: {
                    if (backend) backend.refresh(categoryFilter.currentText)
                }
            }
        }
        
        // Modern search bar
        Rectangle {
            Layout.fillWidth: true
            Layout.preferredHeight: 48
            color: Theme.surfaceColor
            radius: Theme.radiusLarge
            border.width: searchField.activeFocus ? 2 : 1
            border.color: searchField.activeFocus ? Theme.primary : Theme.borderColor
            
            Behavior on border.color {
                ColorAnimation { duration: Theme.animationDurationFast }
            }
            
            RowLayout {
                anchors.fill: parent
                anchors.margins: Theme.spacing3
                spacing: Theme.spacing2
                
                Text {
                    text: "🔍"
                    font.pixelSize: Theme.iconSize
                    color: Theme.textSecondary
                }
                
                TextField {
                    id: searchField
                    Layout.fillWidth: true
                    placeholderText: "Search templates..."
                    color: Theme.textPrimary
                    font.pixelSize: Theme.fontSizeNormal
                    
                    background: Rectangle {
                        color: "transparent"
                    }
                }
            }
        }
        
        // Templates grid with modern cards
        ScrollView {
            Layout.fillWidth: true
            Layout.fillHeight: true
            clip: true
            contentWidth: availableWidth
            
            GridView {
                id: templateGrid
                cellWidth: 300
                cellHeight: 280
                model: backend ? backend.model : null
                
                delegate: Rectangle {
                    id: templateCard
                    width: templateGrid.cellWidth - Theme.spacingMedium
                    height: templateGrid.cellHeight - Theme.spacingMedium
                    color: Theme.surfaceColor
                    radius: Theme.radiusLarge
                    
                    property bool isHovered: false
                    
                    Shadow {
                        anchors.fill: parent
                        elevation: templateCard.isHovered ? 2 : 1
                        shadowRadius: parent.radius
                    }
                    
                    // Gradient overlay for category
                    Rectangle {
                        anchors.fill: parent
                        radius: parent.radius
                        opacity: 0.03
                        gradient: Gradient {
                            GradientStop { position: 0.0; color: getCategoryColor(model.category) }
                            GradientStop { position: 1.0; color: "transparent" }
                        }
                    }
                    
                    // Popular badge
                    Rectangle {
                        visible: model.popular
                        anchors.top: parent.top
                        anchors.right: parent.right
                        anchors.margins: Theme.spacing3
                        width: popularLabel.implicitWidth + Theme.spacing3 * 2
                        height: 24
                        radius: Theme.radiusFull
                        color: Theme.alpha(Theme.accent, 0.9)
                        
                        Label {
                            id: popularLabel
                            anchors.centerIn: parent
                            text: "⭐ Popular"
                            color: "white"
                            font.pixelSize: Theme.fontSizeXS
                            font.weight: Theme.fontWeightSemiBold
                        }
                    }
                    
                    ColumnLayout {
                        anchors.fill: parent
                        anchors.margins: Theme.spacingMedium
                        spacing: Theme.spacing3
                        
                        // Icon and category badge
                        RowLayout {
                            Layout.fillWidth: true
                            spacing: Theme.spacing3
                            
                            Rectangle {
                                width: 56
                                height: 56
                                radius: Theme.radiusMedium
                                color: Theme.alpha(getCategoryColor(model.category), 0.1)
                                
                                Text {
                                    anchors.centerIn: parent
                                    text: model.icon
                                    font.pixelSize: 32
                                }
                            }
                            
                            Column {
                                spacing: Theme.spacing1
                                Layout.fillWidth: true
                                
                                Label {
                                    text: model.name
                                    font.pixelSize: Theme.fontSizeLarge
                                    font.weight: Theme.fontWeightBold
                                    color: Theme.textPrimary
                                    elide: Text.ElideRight
                                    width: parent.width
                                }
                                
                                StatusBadge {
                                    badgeText: model.category
                                    status: getCategoryStatus(model.category)
                                    size: "small"
                                    outlined: true
                                }
                            }
                        }
                        
                        // Description
                        Label {
                            text: model.description
                            font.pixelSize: Theme.fontSizeSmall
                            color: Theme.textSecondary
                            Layout.fillWidth: true
                            wrapMode: Text.WordWrap
                            maximumLineCount: 3
                            elide: Text.ElideRight
                            lineHeight: 1.4
                        }
                        
                        // Target info
                        Rectangle {
                            Layout.fillWidth: true
                            height: 1
                            color: Theme.dividerColor
                        }
                        
                        Row {
                            spacing: Theme.spacing2
                            
                            Text {
                                text: "🎯"
                                font.pixelSize: Theme.iconSizeSmall
                                anchors.verticalCenter: parent.verticalCenter
                            }
                            
                            Label {
                                text: model.targetTypes
                                font.pixelSize: Theme.fontSizeSmall
                                color: Theme.textTertiary
                                anchors.verticalCenter: parent.verticalCenter
                            }
                        }
                        
                        Item { Layout.fillHeight: true }
                        
                        // Action buttons
                        RowLayout {
                            spacing: Theme.spacing2
                            Layout.fillWidth: true
                            
                            CustomButton {
                                text: "Deploy"
                                iconName: "deploy"
                                buttonType: "primary"
                                size: "small"
                                Layout.fillWidth: true
                                onClicked: {
                                    if (backend) {
                                        // TODO: Open deployment dialog
                                        backend.deployTemplate(index, model.name + "-instance")
                                    }
                                }
                            }
                            
                            CustomButton {
                                text: "Preview"
                                iconName: "👁"
                                buttonType: "outlined"
                                size: "small"
                                Layout.fillWidth: true
                                onClicked: {
                                    if (backend) {
                                        var details = backend.getTemplateDetails(index)
                                        console.log(details)
                                        // TODO: Show details in a dialog
                                    }
                                }
                            }
                        }
                    }
                    
                    // Hover and interaction effects
                    scale: templateCard.isHovered ? 1.02 : 1.0
                    Behavior on scale {
                        NumberAnimation { 
                            duration: Theme.animationDuration
                            easing.type: Easing.OutCubic
                        }
                    }
                    
                    MouseArea {
                        id: cardMouseArea
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        
                        onEntered: templateCard.isHovered = true
                        onExited: templateCard.isHovered = false
                        
                        onClicked: {
                            templateGrid.currentIndex = index
                        }
                    }
                }
            }
        }
    }
    
    // Helper functions
    function getCategoryColor(category) {
        switch(category) {
            case "containers": return Theme.primary
            case "cloud": return Theme.success
            case "gitops": return Theme.warning
            case "on-premises": return Theme.accent
            default: return Theme.gray500
        }
    }
    
    function getCategoryStatus(category) {
        switch(category) {
            case "containers": return "info"
            case "cloud": return "success"
            case "gitops": return "warning"
            case "on-premises": return "neutral"
            default: return "neutral"
        }
    }
}
