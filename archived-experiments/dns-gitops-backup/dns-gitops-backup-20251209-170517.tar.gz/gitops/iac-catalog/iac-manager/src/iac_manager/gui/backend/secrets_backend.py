"""Secrets backend for QML."""

from typing import Optional

from PyQt6.QtCore import QObject, pyqtProperty, pyqtSignal, pyqtSlot

from iac_manager.config import Config
from iac_manager.services import SecretsService
from iac_manager.gui.backend.models import SecretsListModel


class SecretsBackend(QObject):
    """Backend bridge for secrets operations in QML."""

    # Signals
    secretsLoaded = pyqtSignal()
    statusChanged = pyqtSignal(str)
    errorOccurred = pyqtSignal(str)
    operationCompleted = pyqtSignal(str)

    def __init__(self, config: Config, secrets_service: SecretsService, parent=None):
        """Initialize secrets backend.

        Args:
            config: Configuration object
            secrets_service: Secrets service instance
            parent: Parent QObject
        """
        super().__init__(parent)
        self._config = config
        self._secrets_service = secrets_service
        self._model = SecretsListModel(self)
        self._status = "Ready"
        self._selected_environment = "all"

    @pyqtProperty(QObject, constant=True)
    def model(self) -> SecretsListModel:
        """Get secrets model for QML."""
        return self._model

    @pyqtProperty(str, notify=statusChanged)
    def status(self) -> str:
        """Get current status message."""
        return self._status

    @status.setter
    def status(self, value: str):
        """Set status message."""
        if self._status != value:
            self._status = value
            self.statusChanged.emit(value)

    @pyqtSlot()
    @pyqtSlot(str)
    def refresh(self, environment: Optional[str] = None):
        """Refresh secrets list.

        Args:
            environment: Optional environment filter
        """
        try:
            self.status = "Loading secrets..."

            # Get secrets data from deployments
            secrets_data = []
            
            # Scan deployments directory for secrets files
            deployments_root = self._config.repo_root / self._config.deployments_dir
            
            if deployments_root.exists():
                for env_dir in deployments_root.iterdir():
                    if not env_dir.is_dir() or env_dir.name.startswith((".", "_")):
                        continue
                    
                    # Filter by environment if specified
                    if environment and environment != "all" and env_dir.name != environment:
                        continue
                    
                    # Scan instances in environment
                    for instance_dir in env_dir.iterdir():
                        if not instance_dir.is_dir() or instance_dir.name.startswith((".", "_")):
                            continue
                        
                        # Check for secrets directory
                        secrets_dir = instance_dir / "secrets"
                        if secrets_dir.exists() and secrets_dir.is_dir():
                            for secret_file in secrets_dir.iterdir():
                                if secret_file.is_file() and not secret_file.name.startswith("."):
                                    secrets_data.append({
                                        "name": secret_file.name,
                                        "environment": env_dir.name,
                                        "instance": instance_dir.name,
                                        "path": str(secret_file),
                                        "encrypted": secret_file.suffix in [".enc", ".encrypted"]
                                    })
                        
                        # Check for .env files
                        env_file = instance_dir / ".env"
                        if env_file.exists():
                            secrets_data.append({
                                "name": ".env",
                                "environment": env_dir.name,
                                "instance": instance_dir.name,
                                "path": str(env_file),
                                "encrypted": False
                            })
            
            # Update model
            self._model.setSecrets(secrets_data)

            # Update status
            count = len(secrets_data)
            self.status = f"Found {count} secret file(s)"

            self.secretsLoaded.emit()

        except Exception as e:
            self.status = f"Error: {str(e)}"
            self.errorOccurred.emit(str(e))

    @pyqtSlot(int, result=str)
    def generatePassword(self, length: int = 32) -> str:
        """Generate a secure password.

        Args:
            length: Password length

        Returns:
            Generated password
        """
        try:
            return self._secrets_service.generate_password(length=length)
        except Exception as e:
            self.errorOccurred.emit(f"Failed to generate password: {str(e)}")
            return ""

    @pyqtSlot(str, result=bool)
    def encryptFile(self, file_path: str) -> bool:
        """Encrypt a file using SOPS.

        Args:
            file_path: Path to file

        Returns:
            True if successful
        """
        try:
            from pathlib import Path
            self.status = f"Encrypting {file_path}..."
            result = self._secrets_service.encrypt_file(Path(file_path))
            if result:
                self.operationCompleted.emit(f"File encrypted: {file_path}")
            return result
        except Exception as e:
            self.errorOccurred.emit(f"Failed to encrypt file: {str(e)}")
            return False

    @pyqtSlot(str, result=bool)
    def decryptFile(self, file_path: str) -> bool:
        """Decrypt a file using SOPS.

        Args:
            file_path: Path to file

        Returns:
            True if successful
        """
        try:
            from pathlib import Path
            self.status = f"Decrypting {file_path}..."
            result = self._secrets_service.decrypt_file(Path(file_path))
            if result:
                self.operationCompleted.emit(f"File decrypted: {file_path}")
            return result
        except Exception as e:
            self.errorOccurred.emit(f"Failed to decrypt file: {str(e)}")
            return False

    @pyqtSlot(result="QStringList")
    def getEnvironments(self) -> list:
        """Get list of available environments.

        Returns:
            List of environment names
        """
        return ["global", "development", "staging", "production", "dr-site"]
