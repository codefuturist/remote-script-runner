"""Log viewing commands for IaC CLI."""

from pathlib import Path
from typing import Optional

import click
from rich.console import Console
from rich.panel import Panel

from iac_manager.cli.config import Config
from iac_manager.cli.utils import run_command


@click.group()
def logs():
    """📋 View application logs."""
    pass


@logs.command()
@click.argument("instance_id")
@click.option(
    "--environment",
    "-e",
    help="Environment name",
)
@click.option(
    "--service",
    "-s",
    help="Specific service to show logs for",
)
@click.option(
    "--follow",
    "-f",
    is_flag=True,
    help="Follow log output (tail -f)",
)
@click.option(
    "--tail",
    "-n",
    type=int,
    default=100,
    help="Number of lines to show from end",
)
@click.option(
    "--since",
    help="Show logs since timestamp (e.g., 2025-11-01, 1h, 10m)",
)
@click.pass_context
def view(
    ctx: click.Context,
    instance_id: str,
    environment: Optional[str],
    service: Optional[str],
    follow: bool,
    tail: int,
    since: Optional[str],
):
    """View logs for a deployment.

    Examples:

        # View recent logs
        iac logs view my-app

        # Follow logs in real-time
        iac logs view my-app --follow

        # View logs for specific service
        iac logs view my-app --service wordpress

        # Show last 200 lines
        iac logs view my-app --tail 200

        # Show logs from last hour
        iac logs view my-app --since 1h
    """
    from iac_manager.cli.commands.deploy import _find_deployment
    
    config: Config = ctx.obj["config"]
    console: Console = ctx.obj["console"]
    
    try:
        # Find deployment
        deployment = _find_deployment(config, instance_id, environment)
        
        if not deployment:
            console.print(f"[red]Deployment not found: {instance_id}[/red]")
            raise click.Abort()
        
        if not deployment.has_docker_compose:
            console.print("[yellow]This deployment doesn't use docker-compose[/yellow]")
            console.print("[dim]Log viewing currently only supports docker-compose deployments[/dim]")
            raise click.Abort()
        
        # Build docker-compose logs command
        compose_file = deployment.deployment_path / "docker-compose.yml"
        
        cmd = ["docker-compose", "-f", str(compose_file), "logs"]
        
        if follow:
            cmd.append("--follow")
        
        if tail:
            cmd.extend(["--tail", str(tail)])
        
        if since:
            cmd.extend(["--since", since])
        
        if service:
            cmd.append(service)
        
        # Show header
        console.print(Panel(
            f"[bold]Deployment:[/bold] {instance_id}\n"
            f"[bold]Environment:[/bold] {deployment.environment}\n"
            f"[bold]Service:[/bold] {service or 'all'}\n"
            f"[bold]Mode:[/bold] {'follow' if follow else 'static'}",
            title="📋 Logs",
            border_style="blue",
        ))
        
        console.print(f"\n[dim]Running: {' '.join(cmd)}[/dim]\n")
        
        # Run docker-compose logs
        result = run_command(cmd, capture_output=False)
        
        if not result.returncode == 0:
            console.print(f"\n[red]Error viewing logs (exit code: {result.returncode})[/red]")
            raise click.Abort()
    
    except KeyboardInterrupt:
        console.print("\n[yellow]Stopped following logs[/yellow]")
    except click.Abort:
        raise
    except Exception as e:
        console.print(f"[red]Error viewing logs: {e}[/red]")
        raise click.Abort()


@logs.command()
@click.argument("instance_id")
@click.option(
    "--environment",
    "-e",
    help="Environment name",
)
@click.option(
    "--output",
    "-o",
    type=click.Path(),
    help="Output file path",
)
@click.pass_context
def export(
    ctx: click.Context,
    instance_id: str,
    environment: Optional[str],
    output: Optional[str],
):
    """Export logs to a file.

    Examples:

        # Export logs to file
        iac logs export my-app --output logs.txt

        # Export with auto-generated filename
        iac logs export my-app
    """
    from iac_manager.cli.commands.deploy import _find_deployment
    from datetime import datetime
    
    config: Config = ctx.obj["config"]
    console: Console = ctx.obj["console"]
    
    try:
        # Find deployment
        deployment = _find_deployment(config, instance_id, environment)
        
        if not deployment:
            console.print(f"[red]Deployment not found: {instance_id}[/red]")
            raise click.Abort()
        
        if not deployment.has_docker_compose:
            console.print("[yellow]This deployment doesn't use docker-compose[/yellow]")
            raise click.Abort()
        
        # Generate output filename if not provided
        if not output:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output = f"{instance_id}_logs_{timestamp}.txt"
        
        output_path = Path(output)
        
        # Build docker-compose logs command
        compose_file = deployment.deployment_path / "docker-compose.yml"
        
        cmd = ["docker-compose", "-f", str(compose_file), "logs", "--no-color"]
        
        console.print(f"[dim]Exporting logs to: {output_path}[/dim]")
        
        # Run and capture output
        result = run_command(cmd, capture_output=True)
        
        if result.returncode == 0:
            # Write to file
            output_path.write_text(result.stdout if hasattr(result, 'stdout') else str(result))
            console.print(f"[green]✓[/green] Logs exported to: {output_path}")
        else:
            console.print(f"[red]Error exporting logs (exit code: {result.returncode})[/red]")
            raise click.Abort()
    
    except click.Abort:
        raise
    except Exception as e:
        console.print(f"[red]Error exporting logs: {e}[/red]")
        raise click.Abort()
