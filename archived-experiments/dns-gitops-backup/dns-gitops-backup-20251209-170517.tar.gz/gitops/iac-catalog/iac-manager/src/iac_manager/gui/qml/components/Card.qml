// Card.qml - Material Design card component with elevation
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "../theme"

Rectangle {
    id: root
    
    property int elevation: 1  // 0-4
    property int elevationHover: elevation + 1
    property bool interactive: false
    property bool hoverable: true
    property alias content: contentLoader.sourceComponent
    property int padding: Theme.spacingMedium
    
    signal clicked()
    signal doubleClicked()
    
    color: Theme.surfaceColor
    radius: Theme.radiusMedium
    border.width: 0
    border.color: Theme.borderColor
    
    // Shadow for elevation
    Shadow {
        anchors.fill: parent
        elevation: mouseArea.containsMouse && hoverable ? elevationHover : root.elevation
        shadowRadius: parent.radius
    }
    
    // Hover scale animation
    scale: mouseArea.pressed ? 0.98 : (mouseArea.containsMouse && interactive ? 1.02 : 1.0)
    Behavior on scale {
        NumberAnimation { 
            duration: Theme.animationDurationFast
            easing.type: Easing.OutCubic
        }
    }
    
    // Content
    Loader {
        id: contentLoader
        anchors.fill: parent
        anchors.margins: root.padding
    }
    
    // Mouse interaction
    MouseArea {
        id: mouseArea
        anchors.fill: parent
        hoverEnabled: root.hoverable || root.interactive
        cursorShape: root.interactive ? Qt.PointingHandCursor : Qt.ArrowCursor
        
        onClicked: root.clicked()
        onDoubleClicked: root.doubleClicked()
    }
    
    // Ripple effect for interactive cards
    Rectangle {
        id: ripple
        anchors.centerIn: parent
        width: 0
        height: width
        radius: width / 2
        color: Theme.alpha(Theme.primary, 0.2)
        opacity: 0
        
        ParallelAnimation {
            id: rippleAnimation
            NumberAnimation {
                target: ripple
                property: "width"
                from: 0
                to: Math.max(root.width, root.height) * 2
                duration: 500
                easing.type: Easing.OutCubic
            }
            NumberAnimation {
                target: ripple
                property: "opacity"
                from: 1
                to: 0
                duration: 500
                easing.type: Easing.OutCubic
            }
        }
    }
    
    Connections {
        target: mouseArea
        function onClicked() {
            if (root.interactive) {
                rippleAnimation.restart()
            }
        }
    }
    
    // Helper functions
    function getShadowBlur() {
        var currentElevation = mouseArea.containsMouse && hoverable ? elevationHover : elevation
        switch(currentElevation) {
            case 0: return 0
            case 1: return 0.5
            case 2: return 1.0
            case 3: return 0.8
            case 4: return 1.0
            default: return 0.6
        }
    }
    
    function getShadowOffset() {
        var currentElevation = mouseArea.containsMouse && hoverable ? elevationHover : elevation
        switch(currentElevation) {
            case 0: return 0
            case 1: return 2
            case 2: return 4
            case 3: return 8
            case 4: return 12
            default: return 4
        }
    }
}
