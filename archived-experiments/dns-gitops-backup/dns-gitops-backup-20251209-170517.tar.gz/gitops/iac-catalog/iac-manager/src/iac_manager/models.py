"""Pydantic models for IaC Core."""

from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class EnvironmentType(str, Enum):
    """Valid environment types."""

    DEVELOPMENT = "development"
    STAGING = "staging"
    PRODUCTION = "production"
    DR_SITE = "dr-site"


class MergeStrategy(str, Enum):
    """Strategy for merging preference values with existing YAML."""

    DEEP = "deep"  # Recursively merge dictionaries and lists
    OVERRIDE = "override"  # Replace entire value at path
    MERGE_LISTS = "merge_lists"  # Merge lists by appending unique items
    REPLACE_LISTS = "replace_lists"  # Replace lists entirely


class TargetType(str, Enum):
    """Valid deployment target types."""

    DOCKER_COMPOSE = "docker-compose"
    KUBERNETES = "kubernetes"
    DOCKER_SWARM = "docker-swarm"


class TargetStrategy(str, Enum):
    """Deployment strategies for multi-target deployments."""

    ROLLING = "rolling"
    PARALLEL = "parallel"
    SERIAL = "serial"
    BLUE_GREEN = "blue-green"
    CANARY = "canary"


class PathRequirement(BaseModel):
    """Remote path requirement for deployment.
    
    The path can be absolute (starts with /) or relative.
    Relative paths are resolved against the base_path.
    """

    path: str
    owner: Optional[str] = "deploy"
    group: Optional[str] = "deploy"
    mode: str = "0755"
    create_parents: bool = True
    base_path: Optional[str] = "/opt/data"  # Default base for relative paths
    
    def get_absolute_path(self, deployment_name: Optional[str] = None) -> str:
        """Get the absolute path, resolving relative paths.
        
        Args:
            deployment_name: Optional deployment name to include in path
            
        Returns:
            Absolute path string
        """
        import os
        
        # If path is already absolute, return as-is
        if self.path.startswith('/'):
            return self.path
        
        # Construct base path
        base = self.base_path or "/opt/data"
        
        # Add deployment name if provided and not already in path
        if deployment_name:
            full_path = os.path.join(base, deployment_name, self.path)
        else:
            full_path = os.path.join(base, self.path)
        
        return full_path


class Target(BaseModel):
    """Deployment target configuration."""

    type: TargetType
    host: Optional[str] = None
    group: Optional[str] = None
    inventory: Path
    strategy: TargetStrategy = TargetStrategy.ROLLING
    health_check_url: Optional[str] = None
    health_check_timeout: int = 300
    required_paths: List[PathRequirement] = Field(default_factory=list)


class Manifest(BaseModel):
    """Deployment manifest configuration."""

    name: str
    template: str
    template_version: str = "latest"
    instance_id: str
    environment: EnvironmentType
    description: Optional[str] = None
    labels: Dict[str, str] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=datetime.now)
    updated_at: datetime = Field(default_factory=datetime.now)


class DeploymentInfo(BaseModel):
    """Information about a deployment instance."""

    instance_id: str
    environment: EnvironmentType
    template: str
    template_version: str
    deployment_path: Path
    manifest: Manifest
    targets: List[Target]
    has_env_file: bool
    has_docker_compose: bool
    has_kubernetes_manifests: bool


class TemplateInfo(BaseModel):
    """Information about a template."""

    name: str
    path: Path
    category: str
    subcategory: Optional[str] = None
    description: Optional[str] = None
    version: str = "latest"
    has_readme: bool
    has_jinja_templates: bool
    target_types: List[TargetType]
    required_params: List[str] = Field(default_factory=list)
    optional_params: List[str] = Field(default_factory=list)


class InventoryHost(BaseModel):
    """Inventory host definition."""

    name: str
    ansible_host: str
    ansible_user: Optional[str] = None
    ansible_port: int = 22
    labels: Dict[str, str] = Field(default_factory=dict)
    groups: List[str] = Field(default_factory=list)


class InventoryGroup(BaseModel):
    """Inventory group definition."""

    name: str
    hosts: List[str]
    vars: Dict[str, Any] = Field(default_factory=dict)
    children: List[str] = Field(default_factory=list)


# Platform Configuration Models


class NetworkType(str, Enum):
    """Network types across platforms."""

    # Docker Compose / Swarm
    BRIDGE = "bridge"
    OVERLAY = "overlay"
    HOST = "host"
    NONE = "none"
    # Kubernetes
    CLUSTER_IP = "ClusterIP"
    NODE_PORT = "NodePort"
    LOAD_BALANCER = "LoadBalancer"


class SecretsStrategy(str, Enum):
    """Secrets management strategies."""

    ENV = "env"
    FILE = "file"
    DOCKER_SECRET = "docker-secret"
    K8S_SECRET = "k8s-secret"


class SecretsProvider(str, Enum):
    """External secrets providers."""

    LOCAL = "local"
    VAULT = "vault"
    AWS_SECRETS_MANAGER = "aws-secretsmanager"
    AZURE_KEYVAULT = "azure-keyvault"
    GCP_SECRET_MANAGER = "gcp-secretmanager"


class VolumeStrategy(str, Enum):
    """Volume storage strategies."""

    LOCAL = "local"
    NFS = "nfs"
    CEPH = "ceph"
    AWS_EBS = "aws-ebs"
    AZURE_DISK = "azure-disk"
    GCP_PD = "gcp-pd"


class VolumeType(str, Enum):
    """Volume types."""

    VOLUME = "volume"
    BIND = "bind"
    TMPFS = "tmpfs"
    PERSISTENT_VOLUME_CLAIM = "persistentVolumeClaim"
    EMPTY_DIR = "emptyDir"


class AccessMode(str, Enum):
    """Kubernetes PVC access modes."""

    READ_WRITE_ONCE = "ReadWriteOnce"
    READ_WRITE_MANY = "ReadWriteMany"
    READ_ONLY_MANY = "ReadOnlyMany"


class IngressStrategy(str, Enum):
    """Ingress controller strategies."""

    NGINX = "nginx"
    TRAEFIK = "traefik"
    HAPROXY = "haproxy"
    ISTIO = "istio"
    KONG = "kong"


class TLSStrategy(str, Enum):
    """TLS certificate strategies."""

    LETSENCRYPT = "letsencrypt"
    CERT_MANAGER = "cert-manager"
    MANUAL = "manual"


class DatabaseStrategy(str, Enum):
    """Database deployment strategies."""

    INTERNAL = "internal"
    EXTERNAL = "external"
    MANAGED = "managed"


class DatabaseType(str, Enum):
    """Database types."""

    MARIADB = "mariadb"
    MYSQL = "mysql"
    POSTGRESQL = "postgresql"
    MONGODB = "mongodb"
    REDIS = "redis"


class PortMapping(BaseModel):
    """Port mapping configuration."""

    container: int
    host: Optional[int] = None
    protocol: str = "tcp"


class NetworkOptions(BaseModel):
    """Network-specific options."""

    subnet: Optional[str] = None
    gateway: Optional[str] = None
    ipv6: bool = False
    dns: List[str] = Field(default_factory=list)


class NetworkConfig(BaseModel):
    """Network configuration."""

    type: NetworkType = NetworkType.BRIDGE
    driver: str = "default"
    external: bool = False
    internal: bool = False
    ports: List[PortMapping] = Field(default_factory=list)
    options: Optional[NetworkOptions] = None


class SecretDefinition(BaseModel):
    """Secret definition."""

    name: str
    source: str
    mode: str = "0400"
    uid: int = 1000
    gid: int = 1000
    external: bool = False


class SecretsConfig(BaseModel):
    """Secrets management configuration."""

    strategy: SecretsStrategy = SecretsStrategy.ENV
    provider: SecretsProvider = SecretsProvider.LOCAL
    definitions: List[SecretDefinition] = Field(default_factory=list)
    env_file: str = ".env.secrets"


class VolumeOptions(BaseModel):
    """Volume driver options."""

    type: Optional[str] = None
    o: Optional[str] = None
    device: Optional[str] = None


class TmpfsOptions(BaseModel):
    """Tmpfs mount options."""

    size: str = "512M"


class VolumeDefinition(BaseModel):
    """Volume definition."""

    name: str
    type: VolumeType = VolumeType.VOLUME
    driver: str = "local"
    size: Optional[str] = None
    storage_class: Optional[str] = None
    access_mode: AccessMode = AccessMode.READ_WRITE_ONCE
    options: Optional[VolumeOptions] = None
    source: Optional[str] = None
    target: str
    read_only: bool = False
    external: bool = False
    tmpfs: Optional[TmpfsOptions] = None


class VolumesConfig(BaseModel):
    """Volumes configuration."""

    strategy: VolumeStrategy = VolumeStrategy.LOCAL
    definitions: List[VolumeDefinition] = Field(default_factory=list)


class IngressPath(BaseModel):
    """Ingress path configuration."""

    path: str
    service: str
    port: int


class IngressRule(BaseModel):
    """Ingress rule configuration."""

    host: str
    paths: List[IngressPath] = Field(default_factory=list)


class TLSCertificate(BaseModel):
    """TLS certificate configuration."""

    secret_name: str
    hosts: List[str] = Field(default_factory=list)


class TLSConfig(BaseModel):
    """TLS configuration."""

    enabled: bool = False
    strategy: TLSStrategy = TLSStrategy.LETSENCRYPT
    email: Optional[str] = None
    certificates: List[TLSCertificate] = Field(default_factory=list)


class IngressConfig(BaseModel):
    """Ingress configuration."""

    enabled: bool = False
    strategy: IngressStrategy = IngressStrategy.NGINX
    rules: List[IngressRule] = Field(default_factory=list)
    tls: Optional[TLSConfig] = None
    annotations: Dict[str, str] = Field(default_factory=dict)


class DatabaseResources(BaseModel):
    """Database resource allocation."""

    cpu: str = "1"
    memory: str = "1Gi"
    storage: str = "20Gi"


class DatabaseBackup(BaseModel):
    """Database backup configuration."""

    enabled: bool = False
    schedule: str = "0 2 * * *"
    retention: int = 7


class PlacementConstraint(BaseModel):
    """Docker Swarm placement constraints."""

    constraints: List[str] = Field(default_factory=list)


class InternalDatabaseConfig(BaseModel):
    """Internal database configuration."""

    type: DatabaseType = DatabaseType.MARIADB
    version: str = "10.6"
    resources: DatabaseResources = Field(default_factory=DatabaseResources)
    replicas: int = 1
    backup: DatabaseBackup = Field(default_factory=DatabaseBackup)
    placement: Optional[PlacementConstraint] = None


class SSLConfig(BaseModel):
    """Database SSL/TLS configuration."""

    enabled: bool = False
    ca_cert: Optional[str] = None
    verify: bool = True


class ExternalDatabaseConfig(BaseModel):
    """External database configuration."""

    host: str
    port: int = 3306
    type: DatabaseType = DatabaseType.MARIADB
    ssl: Optional[SSLConfig] = None


class DatabaseInfo(BaseModel):
    """Database information."""

    name: str
    charset: str = "utf8mb4"
    collation: str = "utf8mb4_unicode_ci"


class DatabaseUserPrivileges(BaseModel):
    """Database user privileges."""

    name: str
    privileges: str = "ALL"


class DatabaseUser(BaseModel):
    """Database user configuration."""

    username: str
    password_secret: str
    databases: List[DatabaseUserPrivileges] = Field(default_factory=list)
    hosts: List[str] = Field(default_factory=lambda: ["%"])


class AdminCredentials(BaseModel):
    """Database admin credentials."""

    username: str = "root"
    password_secret: str = "db_root_password"


class DatabaseProvisioning(BaseModel):
    """Database provisioning configuration."""

    enabled: bool = True
    databases: List[DatabaseInfo] = Field(default_factory=list)
    users: List[DatabaseUser] = Field(default_factory=list)
    admin: AdminCredentials = Field(default_factory=AdminCredentials)


class DatabaseConfig(BaseModel):
    """Database configuration."""

    strategy: DatabaseStrategy = DatabaseStrategy.INTERNAL
    internal: Optional[InternalDatabaseConfig] = None
    external: Optional[ExternalDatabaseConfig] = None
    provisioning: DatabaseProvisioning = Field(default_factory=DatabaseProvisioning)


class PlatformConfig(BaseModel):
    """Complete platform-specific configuration."""

    platform: TargetType
    networking: NetworkConfig = Field(default_factory=NetworkConfig)
    secrets: SecretsConfig = Field(default_factory=SecretsConfig)
    volumes: VolumesConfig = Field(default_factory=VolumesConfig)
    ingress: IngressConfig = Field(default_factory=IngressConfig)
    database: DatabaseConfig = Field(default_factory=DatabaseConfig)


class ConversionConfig(BaseModel):
    """Configuration for Docker Compose to Kubernetes conversion."""

    source_format: str = "docker-compose"
    target_format: str = "kubernetes"

    # Enhancement options
    add_ingress: bool = True
    add_tls: bool = True
    add_resource_limits: bool = True
    add_health_checks: bool = True
    add_security_context: bool = True

    # Resource defaults
    default_cpu_request: str = "100m"
    default_cpu_limit: str = "500m"
    default_memory_request: str = "128Mi"
    default_memory_limit: str = "512Mi"

    # Kubernetes specific
    namespace: str = "default"
    storage_class: Optional[str] = None
    ingress_class: str = "nginx"
    cert_issuer: str = "letsencrypt-prod"

    # Health check defaults
    health_check_path: str = "/health"
    health_check_port: int = 80
    liveness_initial_delay: int = 30
    liveness_period: int = 10
    readiness_initial_delay: int = 5
    readiness_period: int = 5


# Preference Management Models


class ConditionalRule(BaseModel):
    """Conditional rule for applying preferences."""

    path: str  # YAML path to check (e.g., "spec.values.ingress.enabled")
    operator: str = "equals"  # equals, not_equals, exists, not_exists
    value: Optional[Any] = None  # Value to compare against
    apply: Dict[str, Any]  # Preferences to apply if condition matches

    class Config:
        """Pydantic config."""

        arbitrary_types_allowed = True


class PreferenceRule(BaseModel):
    """Single preference rule definition."""

    path: str  # Dot-notation path (e.g., "spec.values.resources.requests.cpu")
    value: Any  # Value to set
    merge_strategy: MergeStrategy = MergeStrategy.DEEP
    environments: Optional[List[str]] = None  # Apply only to these environments
    resource_types: Optional[List[str]] = None  # Apply only to these resource types
    description: Optional[str] = None

    class Config:
        """Pydantic config."""

        arbitrary_types_allowed = True


class PreferenceProfile(BaseModel):
    """Complete preference profile definition."""

    name: str
    version: str = "1.0"
    description: Optional[str] = None
    extends: Optional[str] = None  # Inherit from another profile
    
    # Global preferences (applied to all resources)
    global_preferences: List[PreferenceRule] = Field(default_factory=list)
    
    # Environment-specific overrides
    environment_preferences: Dict[str, List[PreferenceRule]] = Field(default_factory=dict)
    
    # Resource type specific (e.g., HelmRelease, Deployment)
    resource_type_preferences: Dict[str, List[PreferenceRule]] = Field(default_factory=dict)
    
    # Conditional rules
    conditional_rules: List[ConditionalRule] = Field(default_factory=list)
    
    # Metadata
    created_at: datetime = Field(default_factory=datetime.now)
    updated_at: datetime = Field(default_factory=datetime.now)

    class Config:
        """Pydantic config."""

        arbitrary_types_allowed = True


class PreferenceApplicationResult(BaseModel):
    """Result of applying preferences to a YAML file."""

    file_path: Path
    success: bool
    backup_created: Optional[Path] = None
    rules_applied: int = 0
    rules_skipped: int = 0
    errors: List[str] = Field(default_factory=list)
    changes: Dict[str, Any] = Field(default_factory=dict)  # path -> new value
    
    class Config:
        """Pydantic config."""

        arbitrary_types_allowed = True
