// Icon.qml - Material Design icon component
import QtQuick
import "../theme"

Text {
    id: root
    
    property string name: "circle"
    property int size: Theme.iconSize
    property color color: Theme.textPrimary
    property bool filled: false
    
    font.family: "Material Symbols Outlined"
    font.pixelSize: size
    font.weight: filled ? Theme.fontWeightBold : Theme.fontWeightNormal
    text: getIconCode()
    color: root.color
    verticalAlignment: Text.AlignVCenter
    horizontalAlignment: Text.AlignHCenter
    
    // Icon mapping (using common symbols that work without fonts)
    function getIconCode() {
        // Using Unicode symbols as fallback
        switch(name) {
            // Navigation
            case "home": return "🏠"
            case "dashboard": return "📊"
            case "menu": return "☰"
            case "close": return "✕"
            case "arrow-back": return "←"
            case "arrow-forward": return "→"
            case "chevron-left": return "‹"
            case "chevron-right": return "›"
            case "chevron-up": return "˄"
            case "chevron-down": return "˅"
            case "expand-more": return "⌄"
            case "expand-less": return "⌃"
            
            // Actions
            case "add": return "+"
            case "remove": return "−"
            case "delete": return "🗑"
            case "edit": return "✎"
            case "save": return "💾"
            case "refresh": return "↻"
            case "search": return "🔍"
            case "filter": return "⊕"
            case "settings": return "⚙"
            case "more-vert": return "⋮"
            case "more-horiz": return "⋯"
            case "download": return "⬇"
            case "upload": return "⬆"
            case "share": return "⤴"
            case "copy": return "⧉"
            case "check": return "✓"
            case "check-circle": return "✔"
            
            // Status
            case "info": return "ℹ"
            case "warning": return "⚠"
            case "error": return "⚠"
            case "success": return "✓"
            case "help": return "?"
            case "notification": return "🔔"
            
            // Content
            case "folder": return "📁"
            case "folder-open": return "📂"
            case "file": return "📄"
            case "description": return "📝"
            case "article": return "📄"
            case "image": return "🖼"
            case "attach": return "📎"
            
            // Development
            case "code": return "⟨⟩"
            case "terminal": return "▶"
            case "bug": return "🐛"
            case "build": return "🔨"
            case "deploy": return "🚀"
            case "rocket": return "🚀"
            case "package": return "📦"
            case "inventory": return "📋"
            
            // Git & Version Control
            case "git": return "⚡"
            case "branch": return "⎇"
            case "commit": return "●"
            case "pull-request": return "⤴"
            case "merge": return "⎇"
            case "compare": return "⇄"
            
            // Cloud & Server
            case "cloud": return "☁"
            case "cloud-upload": return "☁↑"
            case "cloud-download": return "☁↓"
            case "server": return "🖥"
            case "database": return "🗄"
            case "storage": return "💾"
            
            // People & Organization
            case "person": return "👤"
            case "people": return "👥"
            case "group": return "👥"
            case "account": return "👤"
            
            // UI Elements
            case "visibility": return "👁"
            case "visibility-off": return "🙈"
            case "lock": return "🔒"
            case "lock-open": return "🔓"
            case "star": return "☆"
            case "star-filled": return "★"
            case "favorite": return "♥"
            case "bookmark": return "🔖"
            
            // Status Indicators
            case "circle": return "●"
            case "circle-outline": return "○"
            case "square": return "■"
            case "square-outline": return "□"
            case "play": return "▶"
            case "pause": return "⏸"
            case "stop": return "⏹"
            
            // Environment
            case "production": return "🔴"
            case "staging": return "🟡"
            case "development": return "🟢"
            case "dr-site": return "🔵"
            
            default: return "◆"
        }
    }
    
    // Hover animation
    scale: mouseArea.containsMouse ? 1.1 : 1.0
    Behavior on scale {
        NumberAnimation { 
            duration: Theme.animationDurationFast
            easing.type: Easing.OutCubic
        }
    }
    
    Behavior on color {
        ColorAnimation { duration: Theme.animationDurationFast }
    }
    
    MouseArea {
        id: mouseArea
        anchors.fill: parent
        hoverEnabled: true
        enabled: false  // Enable only when needed
    }
}
