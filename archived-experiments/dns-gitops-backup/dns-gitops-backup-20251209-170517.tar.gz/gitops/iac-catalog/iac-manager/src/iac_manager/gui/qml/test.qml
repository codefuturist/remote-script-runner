// test.qml - Simple test to verify QML loads
import QtQuick
import QtQuick.Controls
import QtQuick.Window

ApplicationWindow {
    id: window
    visible: true
    width: 800
    height: 600
    title: "IaC Manager - Test"
    
    Rectangle {
        anchors.fill: parent
        color: "#f5f5f5"
        
        Column {
            anchors.centerIn: parent
            spacing: 20
            
            Label {
                text: "🚀 IaC Manager"
                font.pixelSize: 32
                font.bold: true
                anchors.horizontalCenter: parent.horizontalCenter
            }
            
            Label {
                text: "QML is working!"
                font.pixelSize: 18
                color: "#666"
                anchors.horizontalCenter: parent.horizontalCenter
            }
        }
    }
}
