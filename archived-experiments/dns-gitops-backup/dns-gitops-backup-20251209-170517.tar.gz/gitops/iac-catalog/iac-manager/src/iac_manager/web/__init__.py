"""Web interface for IaC Manager.

Provides a modern FastAPI-based web API and React frontend for managing
infrastructure deployments, templates, and GitOps workflows.

Components:
- api: FastAPI routes and schemas
- auth: JWT authentication with OAuth support
- websocket: Real-time updates for logs and operations
"""

__all__ = ["create_app"]

from iac_manager.web.main import create_app
