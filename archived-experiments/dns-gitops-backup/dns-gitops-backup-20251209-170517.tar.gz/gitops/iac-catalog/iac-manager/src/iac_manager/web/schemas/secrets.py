"""Secrets management schemas."""

from enum import Enum
from typing import Any

from pydantic import Field

from iac_manager.web.schemas.common import BaseSchema


class SecretType(str, Enum):
    """Type of secret."""

    PASSWORD = "password"
    API_KEY = "api_key"
    SSH_KEY = "ssh_key"
    CERTIFICATE = "certificate"
    GENERIC = "generic"


class SecretCreate(BaseSchema):
    """Request to create a secret."""

    key: str = Field(min_length=1, max_length=253, pattern=r"^[a-zA-Z][a-zA-Z0-9_-]*$")
    value: str = Field(min_length=1)
    secret_type: SecretType = SecretType.GENERIC
    description: str | None = None
    environment: str | None = Field(
        None,
        description="Target environment for the secret",
    )


class SecretResponse(BaseSchema):
    """Secret metadata response (value not included for security)."""

    key: str
    secret_type: SecretType
    description: str | None = None
    environment: str | None = None
    encrypted: bool = True
    created_at: str | None = None


class SecretList(BaseSchema):
    """List of secrets."""

    secrets: list[SecretResponse]
    total: int


class PasswordGenerateRequest(BaseSchema):
    """Request to generate a password."""

    length: int = Field(default=32, ge=8, le=128)
    include_uppercase: bool = True
    include_lowercase: bool = True
    include_digits: bool = True
    include_special: bool = True
    exclude_ambiguous: bool = True  # Exclude O, 0, l, 1, etc.


class PasswordGenerateResponse(BaseSchema):
    """Generated password response."""

    password: str
    entropy_bits: float


class SopsEncryptRequest(BaseSchema):
    """Request to encrypt with SOPS."""

    content: str
    format: str = Field(default="yaml", pattern=r"^(yaml|json|env|ini)$")


class SopsEncryptResponse(BaseSchema):
    """SOPS encryption response."""

    encrypted_content: str
    format: str


class SopsDecryptRequest(BaseSchema):
    """Request to decrypt with SOPS."""

    encrypted_content: str


class SopsDecryptResponse(BaseSchema):
    """SOPS decryption response."""

    content: str
    format: str
