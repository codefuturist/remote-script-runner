# Docker Compose Templates

This directory contains Jinja2 templates for generating Docker Compose configurations.

## Available Templates

### 1. `docker-compose-preview.yml.j2` - Basic Template
**Purpose**: Quick preview and simple deployments

**Features**:
- Essential Docker Compose configuration
- Support for standalone and Swarm modes
- Basic Traefik integration
- Configurable secrets management
- Database support (MySQL, MariaDB, PostgreSQL)
- Resource limits and healthchecks
- Custom environment variables and labels

**Best for**: Development, testing, simple deployments

---

### 2. `docker-compose-full.yml.j2` - Production Template
**Purpose**: Production-ready deployments with advanced features

**Features**:
- Full Traefik reverse proxy with Let's Encrypt SSL
- HTTP to HTTPS redirect
- Advanced Swarm orchestration
- Database-specific healthchecks
- Update and rollback strategies
- Placement constraints
- Backup volumes
- Comprehensive logging configuration
- Security best practices

**Best for**: Production deployments, enterprise environments

---

## Secret Management Strategies

The templates support **4 secret management strategies**:

### 1. Environment File (`.env`)
**Strategy**: `secrets_strategy: 'env'`

Secrets loaded from external `.env` file:
```yaml
services:
  app:
    env_file:
      - .env
```

**Usage**: Create `.env` file separately:
```bash
DB_PASSWORD=secret123
DB_ROOT_PASSWORD=supersecret
API_KEY=abc123xyz
```

**Pros**: Secrets not in version control, easy to manage
**Cons**: Requires manual `.env` file management

---

### 2. Inline Environment Variables
**Strategy**: `secrets_strategy: 'env-inline'`

Secrets configured directly in docker-compose.yml:
```yaml
services:
  app:
    environment:
      DB_PASSWORD: my_actual_password
      API_KEY: abc123xyz
```

**Usage**: Provide secret values via context:
```python
context = {
    'secrets_strategy': 'env-inline',
    'custom_env_vars': {
        'DB_PASSWORD': 'my_actual_password',
        'API_KEY': 'abc123xyz'
    }
}
```

**Pros**: Simple, no external files needed
**Cons**: Secrets visible in compose file (not for production!)

---

### 3. File-based Secrets
**Strategy**: `secrets_strategy: 'file'`

Secrets mounted from files:
```yaml
services:
  app:
    volumes:
      - ./secrets:/run/secrets:ro
```

**Usage**: Create secrets directory with files:
```bash
mkdir secrets
echo "my_password" > secrets/db_password
echo "my_api_key" > secrets/api_key
chmod 600 secrets/*
```

**Pros**: Unix permissions, external secret management
**Cons**: File management overhead

---

### 4. Docker Secrets (Swarm only)
**Strategy**: `secrets_strategy: 'docker-secret'`

Native Docker Swarm secrets:
```yaml
services:
  app:
    secrets:
      - db_password

secrets:
  db_password:
    external: true
```

**Usage**: Create Docker secret first:
```bash
echo "my_password" | docker secret create db_password -
```

**Pros**: Native Docker security, encrypted storage
**Cons**: Requires Swarm mode

---

## Context Variables

### Required Variables
- `instance_name`: Deployment instance identifier
- `deployment_mode`: `'standalone'` or `'swarm'`

### Ingress/Traefik
- `enable_traefik`: Boolean
- `ssl_enabled`: Boolean
- `traefik_rule`: Router rule (e.g., `"Host(\`app.local\`)"`)

### Secrets
- `secrets_strategy`: `'env'`, `'env-inline'`, `'file'`, or `'docker-secret'`
- `secret_env_vars`: Dictionary of secret environment variables (for env-inline)
- `custom_env_vars`: Dictionary of regular environment variables

### Database
- `database_strategy`: `'internal'`, `'external'`, or `'none'`
- `database_type`: `'mysql'`, `'mariadb'`, or `'postgresql'`
- `database_version`: Version string (e.g., `'8.0'`, `'10.6'`)
- `database_host`: Host for external database
- `database_port`: Port number

**For env-inline strategy**:
- `db_name`: Database name
- `db_user`: Database username
- `db_password`: Database password
- `db_root_password`: Root password (MySQL/MariaDB)

### Network
- `network_driver`: `'bridge'`, `'overlay'`, etc.
- `network_external`: Boolean
- `network_internal`: Boolean

### Resources (Swarm mode)
- `cpu_limit`: CPU limit (e.g., `'0.5'`)
- `memory_limit`: Memory limit (e.g., `'512M'`)
- `cpu_reservation`: CPU reservation
- `memory_reservation`: Memory reservation
- `replicas`: Number of replicas

### Healthcheck
- `healthcheck_enabled`: Boolean
- `healthcheck_interval`: Interval string (e.g., `'30s'`)
- `healthcheck_timeout`: Timeout string
- `healthcheck_retries`: Number of retries
- `healthcheck_start_period`: Start period

### Logging
- `log_driver`: `'json-file'`, `'syslog'`, `'journald'`
- `log_max_size`: Max size (e.g., `'10m'`)
- `log_max_file`: Max files (e.g., `'3'`)

### Other
- `restart_policy`: `'always'`, `'unless-stopped'`, `'on-failure'`, `'no'`
- `expose_ports`: Boolean
- `host_port`: Host port number
- `container_port`: Container port number
- `custom_labels`: Dictionary of Docker labels
- `volume_driver`: Volume driver (e.g., `'local'`)

---

## Usage Examples

### Example 1: Development with Inline Secrets
```python
from jinja2 import Environment, FileSystemLoader

env = Environment(loader=FileSystemLoader('templates'))
template = env.get_template('docker-compose-preview.yml.j2')

context = {
    'instance_name': 'myapp',
    'deployment_mode': 'standalone',
    'secrets_strategy': 'env-inline',
    'custom_env_vars': {
        'DB_PASSWORD': 'dev_password',
        'API_KEY': 'dev_key_123'
    },
    'database_strategy': 'internal',
    'database_type': 'postgresql',
    'database_version': '15',
}

output = template.render(**context)
```

### Example 2: Production with External Secrets
```python
context = {
    'instance_name': 'myapp-prod',
    'deployment_mode': 'swarm',
    'secrets_strategy': 'env',  # Use .env file
    'enable_traefik': True,
    'ssl_enabled': True,
    'traefik_rule': 'Host(`myapp.example.com`)',
    'database_strategy': 'internal',
    'database_type': 'postgresql',
    'database_version': '15',
    'replicas': 3,
    'cpu_limit': '1.0',
    'memory_limit': '1G',
}

template = env.get_template('docker-compose-full.yml.j2')
output = template.render(**context)
```

### Example 3: Swarm with Docker Secrets
```python
context = {
    'instance_name': 'myapp-prod',
    'deployment_mode': 'swarm',
    'secrets_strategy': 'docker-secret',
    'enable_traefik': True,
    'ssl_enabled': True,
    'database_strategy': 'internal',
    'database_type': 'mariadb',
    'database_version': '10.6',
}

# First create secrets:
# echo "prod_password" | docker secret create db_password -

template = env.get_template('docker-compose-full.yml.j2')
output = template.render(**context)
```

---

## Best Practices

1. **Never commit secrets**: Use `.env` files and add them to `.gitignore`
2. **Production secrets**: Use Docker Secrets or external secret managers (Vault, AWS Secrets Manager)
3. **Development**: `env-inline` is OK for local development only
4. **File permissions**: Always `chmod 600` for secret files
5. **Rotation**: Regularly rotate secrets and passwords
6. **Environment separation**: Use different secrets for dev/staging/production

---

## Template Development

### Adding New Features
1. Add context variable to backend's `_buildContext()`
2. Update template with Jinja2 conditional logic
3. Document new variable in this README
4. Add validation in backend if needed

### Testing Templates
```python
# Test rendering
context = {...}  # Your test context
output = template.render(**context)

# Validate YAML
import yaml
yaml.safe_load(output)  # Should not raise exception
```

---

## Security Notes

⚠️ **IMPORTANT**:
- Never use `env-inline` strategy in production
- Always use encrypted secret storage for production
- Rotate secrets regularly
- Use least-privilege database users
- Enable SSL/TLS for production deployments
- Review generated compose files before deployment
