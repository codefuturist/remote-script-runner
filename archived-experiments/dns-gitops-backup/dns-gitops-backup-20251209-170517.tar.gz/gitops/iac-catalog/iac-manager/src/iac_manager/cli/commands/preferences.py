"""Preference management CLI commands."""

from pathlib import Path
from typing import Optional

import click
from rich.console import Console
from rich.syntax import Syntax
from rich.table import Table

from iac_manager.cli.config import load_config
from iac_manager.services.preference_service import PreferenceService
from iac_manager.utils.helm_utils import HelmChartValuesFetcher
from iac_manager.utils.yaml_utils import load_yaml_preserving

console = Console()


@click.group()
@click.pass_context
def preferences(ctx: click.Context) -> None:
    """Manage YAML preference profiles for automated configuration."""
    pass


@preferences.command()
@click.option(
    "--profile",
    "-p",
    default="default",
    help="Profile name to use (default: default)",
)
@click.pass_context
def init(ctx: click.Context, profile: str) -> None:
    """Initialize preference system with default profiles."""
    config = ctx.obj["config"]
    preferences_dir = config.repo_root / "iac-manager" / "config" / "preferences"

    if preferences_dir.exists():
        console.print(f"[yellow]Preferences directory already exists at: {preferences_dir}[/yellow]")
        if not click.confirm("Do you want to continue?"):
            return

    preferences_dir.mkdir(parents=True, exist_ok=True)

    # Create default profile if it doesn't exist
    default_profile_path = preferences_dir / f"{profile}.yaml"
    if not default_profile_path.exists():
        console.print(f"[green]Creating {profile} profile at: {default_profile_path}[/green]")
        # This will be created in the next step when we add the default profiles
        console.print("[yellow]Run the profile creation step to add default profiles[/yellow]")
    else:
        console.print(f"[green]Profile {profile} already exists[/green]")

    console.print(f"\n[green]✓[/green] Preferences initialized at: {preferences_dir}")


@preferences.command()
@click.argument("file_path", type=click.Path(exists=True, path_type=Path))
@click.option(
    "--profile",
    "-p",
    default="default",
    help="Preference profile to apply",
)
@click.option(
    "--environment",
    "-e",
    help="Environment name (e.g., production, staging)",
)
@click.option(
    "--resource-type",
    "-t",
    help="Resource type (e.g., HelmRelease, Deployment)",
)
@click.option(
    "--dry-run",
    "-n",
    is_flag=True,
    help="Preview changes without modifying file",
)
@click.option(
    "--no-backup",
    is_flag=True,
    help="Don't create .bak file before modifying",
)
@click.pass_context
def apply(
    ctx: click.Context,
    file_path: Path,
    profile: str,
    environment: Optional[str],
    resource_type: Optional[str],
    dry_run: bool,
    no_backup: bool,
) -> None:
    """Apply preference profile to a YAML file."""
    config = ctx.obj["config"]
    preferences_dir = config.repo_root / "iac-manager" / "config" / "preferences"

    if not preferences_dir.exists():
        console.print("[red]Preferences not initialized. Run 'iac preferences init' first.[/red]")
        ctx.exit(1)

    try:
        service = PreferenceService(preferences_dir)
        profile_obj = service.load_profile(profile)

        console.print(f"\n[bold]Applying preferences to:[/bold] {file_path}")
        console.print(f"[bold]Profile:[/bold] {profile}")
        if environment:
            console.print(f"[bold]Environment:[/bold] {environment}")
        if resource_type:
            console.print(f"[bold]Resource Type:[/bold] {resource_type}")
        if dry_run:
            console.print("[yellow][bold]DRY RUN MODE[/bold] - No changes will be made[/yellow]")

        result = service.apply_preferences(
            file_path=file_path,
            profile=profile_obj,
            environment=environment,
            resource_type=resource_type,
            dry_run=dry_run,
            create_backup=not no_backup,
        )

        if result.success:
            console.print(f"\n[green]✓[/green] Applied {result.rules_applied} rules")
            console.print(f"[dim]  Skipped {result.rules_skipped} rules[/dim]")

            if result.backup_created:
                console.print(f"[dim]  Backup created: {result.backup_created}[/dim]")

            if result.changes:
                console.print("\n[bold]Changes:[/bold]")
                for path, value in result.changes.items():
                    console.print(f"  • {path}: {value}")

        else:
            console.print(f"\n[red]✗[/red] Failed to apply preferences")
            for error in result.errors:
                console.print(f"[red]  Error: {error}[/red]")
            ctx.exit(1)

    except FileNotFoundError as e:
        console.print(f"[red]Error: {e}[/red]")
        ctx.exit(1)
    except Exception as e:
        console.print(f"[red]Unexpected error: {e}[/red]")
        ctx.exit(1)


@preferences.command()
@click.argument("file_path", type=click.Path(exists=True, path_type=Path))
@click.option(
    "--profile",
    "-p",
    default="default",
    help="Preference profile to preview",
)
@click.option(
    "--environment",
    "-e",
    help="Environment name (e.g., production, staging)",
)
@click.option(
    "--resource-type",
    "-t",
    help="Resource type (e.g., HelmRelease, Deployment)",
)
@click.pass_context
def preview(
    ctx: click.Context,
    file_path: Path,
    profile: str,
    environment: Optional[str],
    resource_type: Optional[str],
) -> None:
    """Preview preference changes without modifying file."""
    config = ctx.obj["config"]
    preferences_dir = config.repo_root / "iac-manager" / "config" / "preferences"

    if not preferences_dir.exists():
        console.print("[red]Preferences not initialized. Run 'iac preferences init' first.[/red]")
        ctx.exit(1)

    try:
        service = PreferenceService(preferences_dir)
        profile_obj = service.load_profile(profile)

        # Run in dry-run mode
        result = service.apply_preferences(
            file_path=file_path,
            profile=profile_obj,
            environment=environment,
            resource_type=resource_type,
            dry_run=True,
            create_backup=False,
        )

        console.print(f"\n[bold]Preview for:[/bold] {file_path}")
        console.print(f"[bold]Profile:[/bold] {profile}")

        if result.rules_applied > 0:
            console.print(f"\n[yellow]Would apply {result.rules_applied} rules:[/yellow]")
            for path, value in result.changes.items():
                console.print(f"  • [cyan]{path}[/cyan]: {value}")
        else:
            console.print("\n[dim]No changes would be made[/dim]")

        if result.rules_skipped > 0:
            console.print(f"\n[dim]Would skip {result.rules_skipped} rules[/dim]")

    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        ctx.exit(1)


@preferences.command("list")
@click.pass_context
def list_profiles(ctx: click.Context) -> None:
    """List all available preference profiles."""
    config = ctx.obj["config"]
    preferences_dir = config.repo_root / "iac-manager" / "config" / "preferences"

    if not preferences_dir.exists():
        console.print("[yellow]No preferences found. Run 'iac preferences init' first.[/yellow]")
        ctx.exit(0)

    try:
        service = PreferenceService(preferences_dir)
        profiles = service.list_profiles()

        if not profiles:
            console.print("[yellow]No profiles found in {preferences_dir}[/yellow]")
            return

        table = Table(title="Available Preference Profiles")
        table.add_column("Profile", style="cyan")
        table.add_column("Description", style="white")
        table.add_column("Global Rules", justify="right", style="green")
        table.add_column("Env Rules", justify="right", style="yellow")
        table.add_column("Resource Rules", justify="right", style="blue")

        for profile_name in profiles:
            try:
                info = service.get_profile_info(profile_name)
                env_count = sum(info["environment_rules"].values())
                resource_count = sum(info["resource_type_rules"].values())

                table.add_row(
                    profile_name,
                    info.get("description", ""),
                    str(info["global_rules"]),
                    str(env_count),
                    str(resource_count),
                )
            except Exception as e:
                table.add_row(profile_name, f"[red]Error: {e}[/red]", "-", "-", "-")

        console.print(table)

    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        ctx.exit(1)


@preferences.command("show")
@click.argument("profile_name")
@click.pass_context
def show_profile(ctx: click.Context, profile_name: str) -> None:
    """Show details of a preference profile."""
    config = ctx.obj["config"]
    preferences_dir = config.repo_root / "iac-manager" / "config" / "preferences"

    if not preferences_dir.exists():
        console.print("[red]Preferences not initialized. Run 'iac preferences init' first.[/red]")
        ctx.exit(1)

    try:
        service = PreferenceService(preferences_dir)
        profile = service.load_profile(profile_name)

        console.print(f"\n[bold cyan]Profile: {profile.name}[/bold cyan]")
        if profile.description:
            console.print(f"{profile.description}")
        console.print(f"Version: {profile.version}")
        if profile.extends:
            console.print(f"Extends: [yellow]{profile.extends}[/yellow]")

        # Show global preferences
        if profile.global_preferences:
            console.print(f"\n[bold]Global Preferences ({len(profile.global_preferences)}):[/bold]")
            for rule in profile.global_preferences[:5]:  # Show first 5
                console.print(f"  • {rule.path} = {rule.value} [{rule.merge_strategy.value}]")
            if len(profile.global_preferences) > 5:
                console.print(f"  [dim]... and {len(profile.global_preferences) - 5} more[/dim]")

        # Show environment preferences
        if profile.environment_preferences:
            console.print(f"\n[bold]Environment Preferences:[/bold]")
            for env, rules in profile.environment_preferences.items():
                console.print(f"  [yellow]{env}[/yellow]: {len(rules)} rules")

        # Show resource type preferences
        if profile.resource_type_preferences:
            console.print(f"\n[bold]Resource Type Preferences:[/bold]")
            for rt, rules in profile.resource_type_preferences.items():
                console.print(f"  [blue]{rt}[/blue]: {len(rules)} rules")

        # Show conditional rules
        if profile.conditional_rules:
            console.print(
                f"\n[bold]Conditional Rules ({len(profile.conditional_rules)}):[/bold]"
            )
            for cond in profile.conditional_rules[:3]:
                console.print(
                    f"  • IF {cond.path} {cond.operator} {cond.value} THEN apply {len(cond.apply)} changes"
                )

        # Show full YAML
        profile_path = preferences_dir / f"{profile_name}.yaml"
        yaml_content = profile_path.read_text()
        console.print(f"\n[bold]Profile YAML:[/bold]")
        syntax = Syntax(yaml_content, "yaml", theme="monokai", line_numbers=False)
        console.print(syntax)

    except FileNotFoundError:
        console.print(f"[red]Profile not found: {profile_name}[/red]")
        ctx.exit(1)
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        ctx.exit(1)


@preferences.command("fetch-chart-values")
@click.argument("chart")
@click.option(
    "--repo",
    "-r",
    help="Helm repository URL (e.g., https://charts.bitnami.com/bitnami)",
)
@click.option(
    "--version",
    "-v",
    help="Chart version (default: latest)",
)
@click.option(
    "--output",
    "-o",
    type=click.Path(path_type=Path),
    help="Output file path (default: ./values.yaml)",
)
@click.option(
    "--oci",
    is_flag=True,
    help="Use OCI registry (e.g., oci://registry-1.docker.io/bitnamicharts/postgresql)",
)
@click.pass_context
def fetch_chart_values(
    ctx: click.Context,
    chart: str,
    repo: Optional[str],
    version: Optional[str],
    output: Optional[Path],
    oci: bool,
) -> None:
    """Fetch default values.yaml from a Helm chart.

    Examples:

        # Fetch from Bitnami repository
        iac preferences fetch-chart-values bitnami/postgresql --version 16.4.9

        # Fetch with custom repo URL
        iac preferences fetch-chart-values postgresql \\
            --repo https://charts.bitnami.com/bitnami

        # Fetch from OCI registry
        iac preferences fetch-chart-values \\
            oci://registry-1.docker.io/bitnamicharts/postgresql \\
            --oci --version 16.4.9

        # Save to specific location
        iac preferences fetch-chart-values bitnami/postgresql \\
            --output ./my-values.yaml
    """
    try:
        fetcher = HelmChartValuesFetcher()

        console.print(f"\n[bold]Fetching values for:[/bold] {chart}")
        if version:
            console.print(f"[bold]Version:[/bold] {version}")
        if repo:
            console.print(f"[bold]Repository:[/bold] {repo}")

        with console.status("[bold green]Downloading chart..."):
            if oci:
                values, saved_path = fetcher.fetch_from_oci(
                    oci_url=chart, version=version, save_path=output
                )
            else:
                values, saved_path = fetcher.fetch_chart_values(
                    chart=chart, repo=repo, version=version, save_path=output
                )

        console.print(f"\n[green]✓[/green] Values downloaded successfully!")
        console.print(f"[dim]Saved to: {saved_path}[/dim]")

        # Show sample of values
        console.print("\n[bold]Values preview (first 20 lines):[/bold]")
        values_text = saved_path.read_text()
        lines = values_text.split("\n")[:20]
        preview = "\n".join(lines)
        if len(values_text.split("\n")) > 20:
            preview += "\n..."

        syntax = Syntax(preview, "yaml", theme="monokai", line_numbers=True)
        console.print(syntax)

        # Suggest next steps
        console.print("\n[bold cyan]Next steps:[/bold cyan]")
        console.print(f"  • View full file: [cyan]cat {saved_path}[/cyan]")
        console.print(
            f"  • Apply preferences: [cyan]iac preferences apply -p default {saved_path}[/cyan]"
        )
        console.print(f"  • Edit values: [cyan]$EDITOR {saved_path}[/cyan]")

    except RuntimeError as e:
        console.print(f"[red]Error: {e}[/red]")
        ctx.exit(1)
    except Exception as e:
        console.print(f"[red]Unexpected error: {e}[/red]")
        ctx.exit(1)


@preferences.command("search-charts")
@click.argument("keyword")
@click.option(
    "--repo",
    "-r",
    help="Search in specific repository",
)
@click.pass_context
def search_charts(
    ctx: click.Context,
    keyword: str,
    repo: Optional[str],
) -> None:
    """Search for Helm charts by keyword.

    Examples:

        # Search all repositories
        iac preferences search-charts postgresql

        # Search specific repository
        iac preferences search-charts postgresql --repo bitnami
    """
    try:
        fetcher = HelmChartValuesFetcher()

        console.print(f"\n[bold]Searching for:[/bold] {keyword}")
        if repo:
            console.print(f"[bold]In repository:[/bold] {repo}")

        with console.status("[bold green]Searching..."):
            charts = fetcher.search_charts(keyword, repo)

        if not charts:
            console.print(f"\n[yellow]No charts found matching '{keyword}'[/yellow]")
            return

        # Display results in table
        table = Table(title=f"Helm Charts Matching '{keyword}'")
        table.add_column("Chart", style="cyan", no_wrap=True)
        table.add_column("Version", style="green")
        table.add_column("App Version", style="yellow")
        table.add_column("Description", style="white")

        for chart in charts[:20]:  # Limit to 20 results
            table.add_row(
                chart["name"],
                chart["version"],
                chart["app_version"],
                chart["description"][:60] + "..."
                if len(chart["description"]) > 60
                else chart["description"],
            )

        console.print(f"\n")
        console.print(table)

        if len(charts) > 20:
            console.print(f"\n[dim]Showing 20 of {len(charts)} results[/dim]")

        # Show usage hint
        console.print(f"\n[bold cyan]Fetch values:[/bold cyan]")
        if charts:
            example_chart = charts[0]["name"]
            console.print(
                f"  [cyan]iac preferences fetch-chart-values {example_chart}[/cyan]"
            )

    except RuntimeError as e:
        console.print(f"[red]Error: {e}[/red]")
        ctx.exit(1)
    except Exception as e:
        console.print(f"[red]Unexpected error: {e}[/red]")
        ctx.exit(1)
