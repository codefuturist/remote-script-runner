"""Password hashing utilities using argon2."""

from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError

# Use argon2id which is the recommended variant
_hasher = PasswordHasher(
    time_cost=2,
    memory_cost=65536,
    parallelism=1,
    hash_len=32,
    salt_len=16,
)


def hash_password(password: str) -> str:
    """Hash a password using Argon2id.

    Args:
        password: Plain text password

    Returns:
        Hashed password string
    """
    return _hasher.hash(password)


def verify_password(password: str, hashed: str) -> bool:
    """Verify a password against its hash.

    Args:
        password: Plain text password
        hashed: Hashed password to verify against

    Returns:
        True if password matches, False otherwise
    """
    try:
        _hasher.verify(hashed, password)
        return True
    except VerifyMismatchError:
        return False


def needs_rehash(hashed: str) -> bool:
    """Check if a password hash needs to be rehashed.

    Args:
        hashed: Current password hash

    Returns:
        True if the hash parameters are outdated
    """
    return _hasher.check_needs_rehash(hashed)
