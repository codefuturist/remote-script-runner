"""Inventory management commands."""

from pathlib import Path
from typing import List, Optional

import click
from rich.console import Console

from iac_manager.cli.config import Config
from iac_manager.cli.models import InventoryGroup, InventoryHost
from iac_manager.cli.utils import load_yaml, print_table


@click.group()
def inventory() -> None:
    """📋 Manage infrastructure inventory.

    List and inspect servers, groups, and infrastructure definitions.
    """
    pass


@inventory.command()
@click.option(
    "--environment",
    type=click.Choice(["development", "staging", "production", "dr-site"]),
    help="Filter by environment",
)
@click.pass_context
def hosts(ctx: click.Context, environment: Optional[str]) -> None:
    """List inventory hosts.

    Examples:

        # List all hosts
        iac inventory hosts

        # List production hosts
        iac inventory hosts --environment production
    """
    config: Config = ctx.obj["config"]
    console: Console = ctx.obj["console"]

    inventory_dir = config.repo_root / config.inventory_dir

    if not inventory_dir.exists():
        console.print(f"[red]Inventory directory not found: {inventory_dir}[/red]")
        ctx.exit(1)

    # Collect hosts
    all_hosts: List[InventoryHost] = []

    if environment:
        env_file = inventory_dir / environment / "servers.yml"
        if env_file.exists():
            hosts_data = load_yaml(env_file)
            all_hosts.extend(_parse_hosts(hosts_data, environment))
    else:
        # Load from all environments
        for env_dir in inventory_dir.iterdir():
            if not env_dir.is_dir():
                continue
            env_file = env_dir / "servers.yml"
            if env_file.exists():
                hosts_data = load_yaml(env_file)
                all_hosts.extend(_parse_hosts(hosts_data, env_dir.name))

    if not all_hosts:
        console.print("[yellow]No hosts found.[/yellow]")
        return

    # Print table
    rows = []
    for host in all_hosts:
        groups_str = ", ".join(host.groups) if host.groups else "none"
        rows.append([
            host.name,
            host.ansible_host,
            host.ansible_user or "default",
            groups_str,
        ])

    print_table(
        "Inventory Hosts",
        ["Name", "Address", "User", "Groups"],
        rows,
        console,
    )


@inventory.command()
@click.option(
    "--environment",
    type=click.Choice(["development", "staging", "production", "dr-site"]),
    help="Filter by environment",
)
@click.pass_context
def groups(ctx: click.Context, environment: Optional[str]) -> None:
    """List inventory groups.

    Examples:

        iac inventory groups
        iac inventory groups --environment production
    """
    config: Config = ctx.obj["config"]
    console: Console = ctx.obj["console"]

    inventory_dir = config.repo_root / config.inventory_dir

    if not inventory_dir.exists():
        console.print(f"[red]Inventory directory not found: {inventory_dir}[/red]")
        ctx.exit(1)

    # Collect groups
    all_groups: List[InventoryGroup] = []

    if environment:
        env_file = inventory_dir / environment / "servers.yml"
        if env_file.exists():
            groups_data = load_yaml(env_file)
            all_groups.extend(_parse_groups(groups_data))
    else:
        # Load from all environments
        for env_dir in inventory_dir.iterdir():
            if not env_dir.is_dir():
                continue
            env_file = env_dir / "servers.yml"
            if env_file.exists():
                groups_data = load_yaml(env_file)
                all_groups.extend(_parse_groups(groups_data))

    if not all_groups:
        console.print("[yellow]No groups found.[/yellow]")
        return

    # Print table
    rows = []
    for group in all_groups:
        hosts_str = ", ".join(group.hosts[:3])
        if len(group.hosts) > 3:
            hosts_str += f" (+{len(group.hosts) - 3} more)"
        rows.append([group.name, str(len(group.hosts)), hosts_str])

    print_table(
        "Inventory Groups",
        ["Group Name", "# Hosts", "Hosts"],
        rows,
        console,
    )


def _parse_hosts(inventory_data: dict, environment: str) -> List[InventoryHost]:
    """Parse hosts from inventory YAML."""
    hosts = []

    # Parse 'all' group hosts
    all_group = inventory_data.get("all", {})
    all_hosts = all_group.get("hosts", {})

    for host_name, host_vars in all_hosts.items():
        host = InventoryHost(
            name=host_name,
            ansible_host=host_vars.get("ansible_host", host_name),
            ansible_user=host_vars.get("ansible_user"),
            ansible_port=host_vars.get("ansible_port", 22),
            labels=host_vars.get("labels", {}),
            groups=[],
        )
        hosts.append(host)

    # Find which groups each host belongs to
    children = all_group.get("children", {})
    for group_name, group_data in children.items():
        group_hosts = group_data.get("hosts", {})
        for host_name in group_hosts:
            for host in hosts:
                if host.name == host_name:
                    host.groups.append(group_name)

    return hosts


def _parse_groups(inventory_data: dict) -> List[InventoryGroup]:
    """Parse groups from inventory YAML."""
    groups = []

    all_group = inventory_data.get("all", {})
    children = all_group.get("children", {})

    for group_name, group_data in children.items():
        group = InventoryGroup(
            name=group_name,
            hosts=list(group_data.get("hosts", {}).keys()),
            vars=group_data.get("vars", {}),
            children=list(group_data.get("children", {}).keys()),
        )
        groups.append(group)

    return groups
