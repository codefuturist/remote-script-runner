// ToastNotification.qml - Toast notification component
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "../theme"

Rectangle {
    id: root
    
    property string message: ""
    property string type: "info" // success, warning, error, info
    property int duration: 3000
    property bool autoHide: true
    
    signal closed()
    
    width: Math.min(400, parent.width - Theme.spacing8)
    height: contentLayout.implicitHeight + Theme.spacing4 * 2
    radius: Theme.radiusNormal
    color: getBackgroundColor()
    
    opacity: 0
    visible: false
    
    // Shadow
    Shadow {
        anchors.fill: parent
        elevation: 2
        shadowRadius: parent.radius
    }
    
    // Content
    RowLayout {
        id: contentLayout
        anchors.fill: parent
        anchors.margins: Theme.spacing4
        spacing: Theme.spacing3
        
        // Icon
        Text {
            text: getIcon()
            font.pixelSize: Theme.iconSize
            color: "white"
            Layout.alignment: Qt.AlignVCenter
        }
        
        // Message
        Label {
            text: root.message
            color: "white"
            font.pixelSize: Theme.fontSizeNormal
            wrapMode: Text.WordWrap
            Layout.fillWidth: true
            Layout.alignment: Qt.AlignVCenter
        }
        
        // Close button
        Rectangle {
            width: Theme.iconSizeSmall
            height: Theme.iconSizeSmall
            radius: width / 2
            color: mouseArea.containsMouse ? Theme.alpha("white", 0.2) : "transparent"
            Layout.alignment: Qt.AlignVCenter
            
            Text {
                anchors.centerIn: parent
                text: "✕"
                color: "white"
                font.pixelSize: Theme.fontSizeSmall
            }
            
            MouseArea {
                id: mouseArea
                anchors.fill: parent
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onClicked: hide()
            }
        }
    }
    
    // Auto-hide timer
    Timer {
        id: autoHideTimer
        interval: root.duration
        running: false
        onTriggered: hide()
    }
    
    // Show animation
    ParallelAnimation {
        id: showAnimation
        
        NumberAnimation {
            target: root
            property: "opacity"
            to: 1.0
            duration: Theme.animationDuration
            easing.type: Easing.OutCubic
        }
        
        NumberAnimation {
            target: root
            property: "y"
            from: root.y - 20
            to: root.y
            duration: Theme.animationDuration
            easing.type: Easing.OutCubic
        }
    }
    
    // Hide animation
    ParallelAnimation {
        id: hideAnimation
        
        NumberAnimation {
            target: root
            property: "opacity"
            to: 0
            duration: Theme.animationDuration
            easing.type: Easing.InCubic
        }
        
        NumberAnimation {
            target: root
            property: "y"
            to: root.y - 20
            duration: Theme.animationDuration
            easing.type: Easing.InCubic
        }
        
        onFinished: {
            root.visible = false
            root.closed()
        }
    }
    
    // Public functions
    function show(msg, toastType, customDuration) {
        if (msg) root.message = msg
        if (toastType) root.type = toastType
        if (customDuration) root.duration = customDuration
        
        root.visible = true
        showAnimation.restart()
        
        if (root.autoHide) {
            autoHideTimer.restart()
        }
    }
    
    function hide() {
        autoHideTimer.stop()
        hideAnimation.restart()
    }
    
    // Helper functions
    function getBackgroundColor() {
        switch(type) {
            case "success": return Theme.success
            case "warning": return Theme.warning
            case "error": return Theme.error
            case "info": return Theme.info
            default: return Theme.gray700
        }
    }
    
    function getIcon() {
        switch(type) {
            case "success": return "✓"
            case "warning": return "⚠"
            case "error": return "✕"
            case "info": return "ℹ"
            default: return "●"
        }
    }
}
