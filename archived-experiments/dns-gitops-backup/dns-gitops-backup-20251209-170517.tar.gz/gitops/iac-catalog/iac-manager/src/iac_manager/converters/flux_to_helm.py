"""Converter for transforming FluxCD HelmRelease manifests to Helm commands."""

from pathlib import Path
from typing import Any, Dict, Optional

from ruamel.yaml import YAML


class FluxToHelmConverter:
    """Convert FluxCD HelmRelease manifests to Helm CLI commands."""

    def __init__(self):
        """Initialize the converter."""
        self.yaml = YAML()
        self.yaml.preserve_quotes = True

    def convert(
        self,
        helmrelease_file: Path,
        extract_values: bool = True,
        values_output: Optional[Path] = None,
    ) -> tuple[str, Optional[Path]]:
        """Convert HelmRelease manifest to helm install command.

        Args:
            helmrelease_file: Path to HelmRelease YAML file
            extract_values: Whether to extract values to separate file
            values_output: Path to save extracted values (if extract_values=True)

        Returns:
            Tuple of (helm command string, path to values file or None)

        Raises:
            ValueError: If HelmRelease format is invalid
        """
        # Load HelmRelease manifest
        with open(helmrelease_file) as f:
            manifest = self.yaml.load(f)

        if manifest.get("kind") != "HelmRelease":
            raise ValueError(f"Expected HelmRelease, got {manifest.get('kind')}")

        # Extract metadata
        metadata = manifest.get("metadata", {})
        release_name = metadata.get("name")
        namespace = metadata.get("namespace", "default")

        # Extract spec
        spec = manifest.get("spec", {})
        chart_spec = spec.get("chart", {}).get("spec", {})
        
        chart_name = chart_spec.get("chart")
        version = chart_spec.get("version")
        
        source_ref = chart_spec.get("sourceRef", {})
        repo_name = source_ref.get("name")

        # Extract values
        values = spec.get("values", {})
        values_file_path = None

        if extract_values and values:
            if values_output:
                values_file_path = values_output
            else:
                values_file_path = helmrelease_file.parent / f"{release_name}-values.yaml"
            
            with open(values_file_path, "w") as f:
                self.yaml.dump(values, f)

        # Build helm command
        command_parts = [
            "helm", "install", release_name,
            f"{repo_name}/{chart_name}",
            f"--namespace {namespace}",
            "--create-namespace",
        ]

        if version:
            command_parts.append(f"--version {version}")

        if values_file_path:
            command_parts.append(f"--values {values_file_path}")

        command = " \\\n  ".join(command_parts)

        return command, values_file_path

    def convert_to_upgrade(
        self,
        helmrelease_file: Path,
        extract_values: bool = True,
        values_output: Optional[Path] = None,
    ) -> tuple[str, Optional[Path]]:
        """Convert HelmRelease manifest to helm upgrade command.

        Args:
            helmrelease_file: Path to HelmRelease YAML file
            extract_values: Whether to extract values to separate file
            values_output: Path to save extracted values

        Returns:
            Tuple of (helm upgrade command string, path to values file or None)
        """
        install_cmd, values_path = self.convert(
            helmrelease_file, extract_values, values_output
        )
        
        # Replace 'install' with 'upgrade --install'
        upgrade_cmd = install_cmd.replace(
            "helm install",
            "helm upgrade --install"
        )
        
        return upgrade_cmd, values_path

    def extract_repository_info(
        self,
        helmrepository_file: Path,
    ) -> Dict[str, str]:
        """Extract repository information from HelmRepository manifest.

        Args:
            helmrepository_file: Path to HelmRepository YAML file

        Returns:
            Dictionary with repo_name and repo_url

        Raises:
            ValueError: If HelmRepository format is invalid
        """
        with open(helmrepository_file) as f:
            manifest = self.yaml.load(f)

        kind = manifest.get("kind")
        if kind not in ["HelmRepository", "OCIRepository"]:
            raise ValueError(f"Expected HelmRepository or OCIRepository, got {kind}")

        metadata = manifest.get("metadata", {})
        spec = manifest.get("spec", {})

        return {
            "repo_name": metadata.get("name"),
            "repo_url": spec.get("url"),
            "kind": kind,
        }

    def generate_script(
        self,
        helmrelease_file: Path,
        helmrepository_file: Optional[Path] = None,
        output_file: Optional[Path] = None,
        include_repo_add: bool = True,
    ) -> Path:
        """Generate a complete shell script with helm commands.

        Args:
            helmrelease_file: Path to HelmRelease YAML file
            helmrepository_file: Optional path to HelmRepository YAML file
            output_file: Path to save script (default: deploy-{release}.sh)
            include_repo_add: Whether to include helm repo add command

        Returns:
            Path to generated script file
        """
        # Load HelmRelease
        with open(helmrelease_file) as f:
            manifest = self.yaml.load(f)

        release_name = manifest["metadata"]["name"]

        # Determine output file
        if not output_file:
            output_file = helmrelease_file.parent / f"deploy-{release_name}.sh"

        # Build script
        script_lines = [
            "#!/bin/bash",
            "set -e",
            "",
            f"# Deploy {release_name} using Helm",
            f"# Generated from: {helmrelease_file.name}",
            "",
        ]

        # Add repo add command if repository info available
        if include_repo_add and helmrepository_file and helmrepository_file.exists():
            repo_info = self.extract_repository_info(helmrepository_file)
            repo_name = repo_info["repo_name"]
            repo_url = repo_info["repo_url"]
            
            script_lines.extend([
                "# Add Helm repository",
                f"helm repo add {repo_name} {repo_url}",
                "helm repo update",
                "",
            ])

        # Generate install command
        install_cmd, values_path = self.convert(
            helmrelease_file,
            extract_values=True,
        )

        script_lines.extend([
            "# Install/Upgrade release",
            install_cmd,
            "",
            "# Wait for deployment",
            f"kubectl wait --for=condition=ready pod -l app.kubernetes.io/name={release_name} -n {manifest['metadata']['namespace']} --timeout=300s || true",
            "",
            "echo 'Deployment complete!'",
        ])

        # Write script
        with open(output_file, "w") as f:
            f.write("\n".join(script_lines))

        # Make executable
        output_file.chmod(0o755)

        return output_file

    def batch_convert(
        self,
        input_dir: Path,
        output_dir: Path,
        generate_scripts: bool = False,
    ) -> Dict[str, Any]:
        """Convert all HelmRelease files in a directory.

        Args:
            input_dir: Directory containing HelmRelease files
            output_dir: Directory to save converted files
            generate_scripts: Whether to generate shell scripts

        Returns:
            Dictionary with conversion results
        """
        output_dir.mkdir(parents=True, exist_ok=True)
        
        results = {
            "converted": [],
            "failed": [],
            "values_files": [],
            "scripts": [],
        }

        # Find all HelmRelease files
        for yaml_file in input_dir.rglob("*.yaml"):
            try:
                with open(yaml_file) as f:
                    manifest = self.yaml.load(f)
                
                if manifest.get("kind") != "HelmRelease":
                    continue

                release_name = manifest["metadata"]["name"]
                
                # Convert to helm command
                cmd, values_path = self.convert(
                    yaml_file,
                    extract_values=True,
                    values_output=output_dir / f"{release_name}-values.yaml"
                )

                # Save command to file
                cmd_file = output_dir / f"{release_name}-install.txt"
                cmd_file.write_text(cmd)

                results["converted"].append({
                    "release": release_name,
                    "source": str(yaml_file),
                    "command_file": str(cmd_file),
                })

                if values_path:
                    results["values_files"].append(str(values_path))

                # Generate script if requested
                if generate_scripts:
                    script_path = self.generate_script(
                        yaml_file,
                        output_file=output_dir / f"deploy-{release_name}.sh"
                    )
                    results["scripts"].append(str(script_path))

            except Exception as e:
                results["failed"].append({
                    "file": str(yaml_file),
                    "error": str(e),
                })

        return results
