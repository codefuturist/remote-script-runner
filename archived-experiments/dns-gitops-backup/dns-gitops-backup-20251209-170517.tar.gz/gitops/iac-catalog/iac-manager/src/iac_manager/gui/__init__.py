"""IaC GUI - Modern PyQt6 interface for Infrastructure as Code management."""

__version__ = "0.1.0"
