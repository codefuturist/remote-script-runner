// RecommendedBadge.qml - Badge to show recommended options
import QtQuick
import QtQuick.Controls
import "../theme"

Rectangle {
    id: root
    
    property string text: "Recommended"
    property string tooltipText: ""
    
    implicitWidth: label.implicitWidth + Theme.spacing2 * 2
    implicitHeight: label.implicitHeight + Theme.spacing1 * 2
    
    color: Theme.successColorLight
    border.color: Theme.successColor
    border.width: 1
    radius: Theme.radiusSmall
    
    Label {
        id: label
        anchors.centerIn: parent
        text: "⭐ " + root.text
        font.pixelSize: Theme.fontSizeSmall
        font.weight: Theme.fontWeightMedium
        color: Theme.successColorDark
    }
    
    ToolTip.visible: tooltipText.length > 0 && mouseArea.containsMouse
    ToolTip.text: root.tooltipText
    ToolTip.delay: 500
    
    MouseArea {
        id: mouseArea
        anchors.fill: parent
        hoverEnabled: true
    }
}
