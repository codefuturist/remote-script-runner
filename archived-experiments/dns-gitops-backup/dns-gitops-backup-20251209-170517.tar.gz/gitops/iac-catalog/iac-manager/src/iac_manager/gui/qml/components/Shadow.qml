// Shadow.qml - Clean border-based shadow for all Qt versions
import QtQuick
import "../theme"

// Simple shadow using border and background offset
// Usage: Add as child of the element needing shadow, set anchors.fill: parent
Item {
    id: root
    
    property int elevation: 1  // 0-3 (0=none, 1=small, 2=medium, 3=large)
    property real shadowRadius: 0
    
    // Shadow rectangle behind the parent
    Rectangle {
        anchors.fill: parent
        anchors.topMargin: getOffset()
        radius: shadowRadius
        color: "transparent"
        border.width: 1
        border.color: Theme.alpha("#000000", getOpacity())
        z: -1
        
        Behavior on anchors.topMargin {
            NumberAnimation { duration: Theme.animationDuration }
        }
        
        Behavior on border.color {
            ColorAnimation { duration: Theme.animationDuration }
        }
    }
    
    // Secondary shadow for depth
    Rectangle {
        visible: root.elevation > 1
        anchors.fill: parent
        anchors.topMargin: getOffset() * 2
        radius: shadowRadius
        color: Theme.alpha("#000000", getOpacity() * 0.5)
        z: -2
        
        Behavior on anchors.topMargin {
            NumberAnimation { duration: Theme.animationDuration }
        }
    }
    
    function getOffset() {
        if (elevation === 0) return 0
        if (elevation === 1) return 2
        if (elevation === 2) return 4
        return 6
    }
    
    function getOpacity() {
        if (elevation === 0) return 0
        if (elevation === 1) return 0.08
        if (elevation === 2) return 0.12
        return 0.16
    }
}
