"""Configuration management for IaC Core."""

import os
from pathlib import Path
from typing import Optional

import yaml
from pydantic import BaseModel, Field

try:
    import git
    GIT_AVAILABLE = True
except ImportError:
    GIT_AVAILABLE = False


class Config(BaseModel):
    """Main configuration for IaC management."""

    repo_root: Path
    catalog_dir: Path = Field(default_factory=lambda: Path("catalog"))
    deployments_dir: Path = Field(default_factory=lambda: Path("deployments"))
    inventory_dir: Path = Field(default_factory=lambda: Path("inventory"))
    environments_dir: Path = Field(default_factory=lambda: Path("environments"))
    ansible_dir: Path = Field(default_factory=lambda: Path("ansible"))
    scripts_dir: Path = Field(default_factory=lambda: Path("scripts"))
    preferences_dir: Path = Field(default_factory=lambda: Path("iac-manager/config/preferences"))

    default_environment: str = "development"
    default_target_type: str = "docker-compose"

    # GitOps settings
    git_auto_add: bool = True
    git_auto_commit: bool = False
    git_auto_push: bool = False

    # Preference settings
    active_profile: str = "default"
    auto_backup: bool = True

    class Config:
        """Pydantic config."""

        arbitrary_types_allowed = True


def find_repo_root(start_path: Optional[Path] = None) -> Path:
    """Find the repository root by looking for catalog/ directory.

    Args:
        start_path: Starting path to search from (default: current directory)

    Returns:
        Path to repository root

    Raises:
        RuntimeError: If repository root cannot be found
    """
    current = start_path or Path.cwd()

    # Check up to 5 levels up
    for _ in range(5):
        if (current / "catalog").is_dir() and (current / "deployments").is_dir():
            return current
        if current.parent == current:  # Reached filesystem root
            break
        current = current.parent

    raise RuntimeError(
        "Could not find IaC repository root. "
        "Make sure you're in a directory containing 'catalog/' and 'deployments/' folders."
    )


def load_config(repo_root: Optional[Path] = None) -> Config:
    """Load configuration from file or create default.

    Args:
        repo_root: Path to repository root (will auto-detect if not provided)

    Returns:
        Config object
    """
    # Find repo root
    if repo_root is None:
        repo_root = find_repo_root()

    # Check for user config file
    user_config_path = Path.home() / ".iac-catalog" / "config.yml"
    repo_config_path = repo_root / ".iac-cli.yml"

    config_data = {"repo_root": repo_root}

    # Load user config if exists
    if user_config_path.exists():
        with open(user_config_path) as f:
            user_config = yaml.safe_load(f) or {}
            config_data.update(user_config)

    # Load repo-specific config if exists (overrides user config)
    if repo_config_path.exists():
        with open(repo_config_path) as f:
            repo_config = yaml.safe_load(f) or {}
            config_data.update(repo_config)

    # Make paths absolute
    for key in [
        "catalog_dir",
        "deployments_dir",
        "inventory_dir",
        "environments_dir",
        "ansible_dir",
        "scripts_dir",
    ]:
        if key in config_data and not Path(config_data[key]).is_absolute():
            config_data[key] = repo_root / config_data[key]

    return Config(**config_data)


def save_user_config(config: Config) -> None:
    """Save user configuration to ~/.iac-catalog/config.yml.

    Args:
        config: Configuration to save
    """
    config_dir = Path.home() / ".iac-catalog"
    config_dir.mkdir(parents=True, exist_ok=True)

    config_path = config_dir / "config.yml"

    config_data = {
        "default_environment": config.default_environment,
        "default_target_type": config.default_target_type,
        "git_auto_add": config.git_auto_add,
        "git_auto_commit": config.git_auto_commit,
        "git_auto_push": config.git_auto_push,
    }

    with open(config_path, "w") as f:
        yaml.dump(config_data, f, default_flow_style=False)


def get_current_git_branch(repo_root: Path) -> Optional[str]:
    """Get the current git branch name.

    Args:
        repo_root: Path to repository root

    Returns:
        Branch name or None if not in a git repo or git not available
    """
    if not GIT_AVAILABLE:
        return None

    try:
        repo = git.Repo(repo_root)
        return repo.active_branch.name
    except (git.InvalidGitRepositoryError, git.GitCommandError, AttributeError):
        return None


def infer_environment_from_context(config: Config) -> Optional[str]:
    """Infer environment from context (git branch, cwd, etc.).

    Branch mapping:
    - develop, dev, development -> development
    - main, master, prod, production -> production
    - staging, stage -> staging
    - dr, disaster-recovery, dr-site -> dr-site

    Args:
        config: Configuration object

    Returns:
        Inferred environment name or None
    """
    branch = get_current_git_branch(config.repo_root)

    if branch:
        branch_lower = branch.lower()

        # Map common branch names to environments
        branch_mappings = {
            "develop": "development",
            "dev": "development",
            "development": "development",
            "main": "production",
            "master": "production",
            "prod": "production",
            "production": "production",
            "staging": "staging",
            "stage": "staging",
            "dr": "dr-site",
            "disaster-recovery": "dr-site",
            "dr-site": "dr-site",
        }

        return branch_mappings.get(branch_lower)

    return None


def get_environment_with_fallback(
    config: Config,
    explicit_env: Optional[str] = None,
    allow_inference: bool = True,
) -> str:
    """Get environment with smart fallback.

    Priority:
    1. Explicitly provided environment
    2. Inferred from context (if allowed)
    3. Config default

    Args:
        config: Configuration object
        explicit_env: Explicitly provided environment
        allow_inference: Whether to infer from context

    Returns:
        Environment name
    """
    if explicit_env:
        return explicit_env

    if allow_inference:
        inferred = infer_environment_from_context(config)
        if inferred:
            return inferred

    return config.default_environment
