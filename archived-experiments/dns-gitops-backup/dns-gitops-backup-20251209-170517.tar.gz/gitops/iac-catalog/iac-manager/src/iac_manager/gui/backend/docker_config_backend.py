"""Docker configuration backend for QML."""

from typing import Optional, Dict, Any, List
from pathlib import Path

from PyQt6.QtCore import QObject, pyqtProperty, pyqtSignal, pyqtSlot
from jinja2 import Environment, FileSystemLoader, select_autoescape

from iac_manager.config import Config
from iac_manager.services import TemplateService
from iac_manager.gui.backend.models import DockerDeploymentConfig
from iac_manager.gui.backend.validators import ConfigValidator


class DockerConfigBackend(QObject):
    """Backend bridge for Docker deployment configuration in QML."""

    # Signals
    previewGenerated = pyqtSignal(str)
    errorOccurred = pyqtSignal(str)
    validationErrors = pyqtSignal(list)
    fieldValidationChanged = pyqtSignal(str, bool, str)  # field, valid, message
    recommendationsChanged = pyqtSignal(dict)  # recommendations dict

    def __init__(
        self,
        config: Config,
        template_service: TemplateService,
        parent=None
    ):
        """Initialize Docker config backend.

        Args:
            config: Configuration object
            template_service: Template service instance
            parent: Parent QObject
        """
        super().__init__(parent)
        self._config = config
        self._template_service = template_service
        self._docker_config = DockerDeploymentConfig(self)
        self._preview_text = ""
        self._template_path: Optional[Path] = None
        self._instance_name = "app"
        
        # Initialize Jinja2 environment for built-in templates
        self._builtin_templates_path = Path(__file__).parent.parent.parent / "templates"
        self._jinja_env = Environment(
            loader=FileSystemLoader(str(self._builtin_templates_path)),
            autoescape=select_autoescape(['html', 'xml']),
            trim_blocks=True,
            lstrip_blocks=True
        )

        # Connect to config changes
        self._docker_config.configChanged.connect(self._onConfigChanged)
        self._docker_config.deploymentModeChanged.connect(self._onDeploymentModeChanged)
        
        # Track existing ports for conflict detection
        self._existing_ports: List[int] = []

    @pyqtProperty(QObject, constant=True)
    def dockerConfig(self) -> DockerDeploymentConfig:
        """Get Docker configuration model."""
        return self._docker_config

    @pyqtProperty(str, notify=previewGenerated)
    def preview(self) -> str:
        """Get preview text."""
        return self._preview_text

    @pyqtSlot(str)
    def setInstanceName(self, name: str):
        """Set instance name for the deployment.

        Args:
            name: Instance name
        """
        self._instance_name = name
        self._generatePreview()

    @pyqtSlot(str)
    def setTemplatePath(self, path: str):
        """Set template path for rendering.

        Args:
            path: Path to template directory
        """
        self._template_path = Path(path) if path else None
        self._generatePreview()

    @pyqtSlot()
    def regeneratePreview(self):
        """Regenerate preview from current configuration."""
        self._generatePreview()

    @pyqtSlot(bool)
    def setProductionMode(self, enabled: bool):
        """Switch between basic and production-ready templates.

        Args:
            enabled: True for production template, False for basic
        """
        self._use_production_template = getattr(self, '_use_production_template', False)
        self._use_production_template = enabled
        self._generatePreview()

    @pyqtSlot(str, str)
    def updateConfig(self, key: str, value: str):
        """Update configuration value.

        Args:
            key: Configuration key
            value: Configuration value
        """
        try:
            # Set the property on the docker config model
            if hasattr(self._docker_config, key):
                current_value = getattr(self._docker_config, key)
                # Handle boolean conversion
                if isinstance(current_value, bool):
                    converted_value = value.lower() in ('true', '1', 'yes')
                # Handle integer conversion
                elif isinstance(current_value, int):
                    converted_value = int(value)
                else:
                    converted_value = value
                
                setattr(self._docker_config, key, converted_value)
            else:
                self.errorOccurred.emit(f"Unknown configuration key: {key}")
        except Exception as e:
            self.errorOccurred.emit(f"Error updating config: {str(e)}")

    @pyqtSlot(result=bool)
    def validateConfig(self) -> bool:
        """Validate current configuration.

        Returns:
            True if valid, False otherwise
        """
        errors = self._docker_config.validate()
        if errors:
            self.validationErrors.emit(errors)
            return False
        return True

    @pyqtSlot(result=str)
    def getConfigAsJson(self) -> str:
        """Get configuration as JSON string.

        Returns:
            JSON representation of configuration
        """
        import json
        return json.dumps(self._docker_config.toDict(), indent=2)

    @pyqtSlot(str)
    def applyCustomPreview(self, custom_yaml: str):
        """Apply custom YAML preview.

        Args:
            custom_yaml: Custom YAML content
        """
        self._preview_text = custom_yaml
        self.previewGenerated.emit(custom_yaml)

    def _onConfigChanged(self):
        """Handle configuration changes."""
        self._generatePreview()

    def _generatePreview(self):
        """Generate preview of docker-compose.yml."""
        try:
            # Build context from configuration
            context = self._buildContext()

            # If we have a template path, use it
            if self._template_path and self._template_path.exists():
                template_file = self._template_path / "docker-compose.yml.j2"
                if template_file.exists():
                    preview = self._renderTemplate(template_file, context)
                else:
                    preview = self._generateBasicPreview(context)
            else:
                preview = self._generateBasicPreview(context)

            self._preview_text = preview
            self.previewGenerated.emit(preview)

        except Exception as e:
            error_msg = f"Error generating preview: {str(e)}"
            self.errorOccurred.emit(error_msg)
            self._preview_text = f"# {error_msg}\n"
            self.previewGenerated.emit(self._preview_text)

    def _buildContext(self) -> Dict[str, Any]:
        """Build Jinja2 context from configuration.

        Returns:
            Context dictionary for template rendering
        """
        config_dict = self._docker_config.toDict()
        
        # Build comprehensive context with all configuration options
        context = {
            'instance_name': self._instance_name,
            'environment': 'production',
            'project_name': self._instance_name,
            
            # Deployment configuration
            'deployment_mode': config_dict['deployment_mode'],
            
            # Ingress/Traefik
            'enable_traefik': config_dict['enable_traefik'],
            'ingress_type': config_dict['ingress_type'],
            'ssl_enabled': config_dict['ssl_enabled'],
            'traefik_rule': config_dict['traefik_rule'],
            
            # Secrets management
            'secrets_strategy': config_dict['secret_type'],
            'secrets_provider': config_dict['secret_provider'],
            
            # Network configuration
            'network_type': config_dict['network_type'],
            'network_driver': config_dict['network_driver'],
            'network_external': config_dict['network_external'],
            'network_internal': config_dict['network_internal'],
            
            # Database configuration
            'database_strategy': config_dict['database_strategy'],
            'database_type': config_dict['database_type'],
            'database_version': config_dict['database_version'],
            'database_host': config_dict['database_host'],
            'database_port': config_dict['database_port'],
            
            # Resource limits
            'cpu_limit': config_dict.get('cpu_limit', ''),
            'memory_limit': config_dict.get('memory_limit', ''),
            'cpu_reservation': config_dict.get('cpu_reservation', ''),
            'memory_reservation': config_dict.get('memory_reservation', ''),
            
            # Healthcheck
            'healthcheck_enabled': config_dict.get('healthcheck_enabled', True),
            'healthcheck_interval': config_dict.get('healthcheck_interval', '30s'),
            'healthcheck_timeout': config_dict.get('healthcheck_timeout', '10s'),
            'healthcheck_retries': config_dict.get('healthcheck_retries', 3),
            'healthcheck_start_period': config_dict.get('healthcheck_start_period', '40s'),
            
            # Restart policy
            'restart_policy': config_dict.get('restart_policy', 'unless-stopped'),
            
            # Port mapping
            'expose_ports': config_dict.get('expose_ports', True),
            'host_port': config_dict.get('host_port', 8080),
            'container_port': config_dict.get('container_port', 80),
            
            # Volumes
            'enable_volumes': config_dict.get('enable_volumes', True),
            'volume_driver': config_dict.get('volume_driver', 'local'),
            
            # Scaling
            'replicas': config_dict.get('replicas', 1),
            
            # Logging
            'log_driver': config_dict.get('log_driver', 'json-file'),
            'log_max_size': config_dict.get('log_max_size', '10m'),
            'log_max_file': config_dict.get('log_max_file', '3'),
            
            # Custom variables
            'custom_env_vars': config_dict.get('custom_env_vars', {}),
            'custom_labels': config_dict.get('custom_labels', {}),
            
            # Secret environment variables (for env-inline strategy)
            'secret_env_vars': self._extractSecretEnvVars(config_dict),
            
            # Database credentials (for env-inline strategy)
            'db_name': self._extractEnvValue('DB_NAME', config_dict),
            'db_user': self._extractEnvValue('DB_USER', config_dict),
            'db_password': self._extractEnvValue('DB_PASSWORD', config_dict),
            'db_root_password': self._extractEnvValue('DB_ROOT_PASSWORD', config_dict),
        }
        
        return context

    def _extractSecretEnvVars(self, config_dict: Dict[str, Any]) -> Dict[str, str]:
        """Extract secret-related environment variables from custom env vars.

        Args:
            config_dict: Configuration dictionary

        Returns:
            Dictionary of secret environment variables
        """
        custom_env = config_dict.get('custom_env_vars', {})
        secret_keys = ['PASSWORD', 'SECRET', 'KEY', 'TOKEN', 'API_KEY', 'CREDENTIALS']
        
        secret_vars = {}
        for key, value in custom_env.items():
            key_upper = key.upper()
            if any(secret_key in key_upper for secret_key in secret_keys):
                secret_vars[key] = value
        
        return secret_vars

    def _extractEnvValue(self, key: str, config_dict: Dict[str, Any]) -> str:
        """Extract environment variable value from custom env vars or return placeholder.

        Args:
            key: Environment variable key
            config_dict: Configuration dictionary

        Returns:
            Value or placeholder string
        """
        custom_env = config_dict.get('custom_env_vars', {})
        return custom_env.get(key, f'${{{key}}}')

    def _renderTemplate(self, template_path: Path, context: Dict[str, Any]) -> str:
        """Render Jinja2 template.

        Args:
            template_path: Path to template file
            context: Context dictionary

        Returns:
            Rendered template content
        """
        try:
            # Check if it's a built-in template or external
            if template_path.is_relative_to(self._builtin_templates_path):
                # Use pre-configured environment for built-in templates
                template = self._jinja_env.get_template(template_path.name)
                return template.render(**context)
            else:
                # Create environment for external templates
                env = Environment(
                    loader=FileSystemLoader(str(template_path.parent)),
                    autoescape=select_autoescape(['html', 'xml']),
                    trim_blocks=True,
                    lstrip_blocks=True
                )
                template = env.get_template(template_path.name)
                return template.render(**context)
        except Exception as e:
            raise RuntimeError(f"Template rendering failed: {str(e)}")

    def _generateBasicPreview(self, context: Dict[str, Any]) -> str:
        """Generate docker-compose.yml preview using built-in template.

        Args:
            context: Context dictionary

        Returns:
            Rendered YAML content
        """
        try:
            # Choose template based on mode
            use_production = getattr(self, '_use_production_template', False)
            template_name = "docker-compose-full.yml.j2" if use_production else "docker-compose-preview.yml.j2"
            template_path = self._builtin_templates_path / template_name
            return self._renderTemplate(template_path, context)
        except Exception as e:
            # Fallback to minimal preview if template fails
            return self._generateMinimalPreview(context)

    def _generateMinimalPreview(self, context: Dict[str, Any]) -> str:
        """Generate minimal preview as fallback.

        Args:
            context: Context dictionary

        Returns:
            Minimal YAML content
        """
        return f"""# Docker Compose Configuration
# Generated for: {context['instance_name']}
# Deployment Mode: {context['deployment_mode']}

version: '3.8'

services:
  app:
    image: nginx:latest
    container_name: {context['instance_name']}_app
    restart: {context.get('restart_policy', 'unless-stopped')}
    ports:
      - "8080:80"
    networks:
      - {context['instance_name']}_network

networks:
  {context['instance_name']}_network:
    driver: bridge
"""

    def _onDeploymentModeChanged(self, mode: str):
        """Handle deployment mode changes and apply smart defaults.
        
        Args:
            mode: New deployment mode
        """
        self._docker_config.applySmartDefaults()
        self._generatePreview()
        
        # Emit recommendations
        recommendations = self._docker_config.getRecommendations()
        self.recommendationsChanged.emit(recommendations)

    @pyqtSlot(str)
    def validateFieldAndEmit(self, field_name: str):
        """Validate a field and emit result signal.
        
        Args:
            field_name: Name of field to validate
        """
        result = self._docker_config.validateField(field_name)
        self.fieldValidationChanged.emit(
            field_name,
            result.get('valid', True),
            result.get('message', '')
        )

    @pyqtSlot(str, result='QVariantMap')
    def getPresetConfig(self, preset_name: str) -> Dict[str, Any]:
        """Get a preset configuration.
        
        Args:
            preset_name: Name of preset
            
        Returns:
            Preset configuration dictionary
        """
        presets = {
            'simple-web-app': {
                'name': 'Simple Web Application',
                'description': 'Basic standalone web app with minimal configuration',
                'deployment_mode': 'standalone',
                'ingress_enabled': False,
                'secret_type': 'env',
                'network_type': 'bridge',
                'database_strategy': 'none',
                'host_port': 8080,
                'replicas': 1
            },
            'wordpress-stack': {
                'name': 'WordPress + Database',
                'description': 'WordPress with MariaDB database',
                'deployment_mode': 'standalone',
                'ingress_enabled': True,
                'ssl_enabled': True,
                'secret_type': 'env',
                'network_type': 'bridge',
                'database_strategy': 'internal',
                'database_type': 'mariadb',
                'database_version': '10.6',
                'host_port': 80,
                'replicas': 1
            },
            'production-swarm': {
                'name': 'Production Swarm Setup',
                'description': 'Production-ready Swarm deployment with all features',
                'deployment_mode': 'swarm',
                'ingress_enabled': True,
                'ssl_enabled': True,
                'secret_type': 'docker-secret',
                'network_type': 'overlay',
                'database_strategy': 'external',
                'host_port': 80,
                'replicas': 3,
                'memory_limit': '512m',
                'cpu_limit': '1'
            },
            'development': {
                'name': 'Development Environment',
                'description': 'Fast iteration with hot reload support',
                'deployment_mode': 'standalone',
                'ingress_enabled': False,
                'secret_type': 'env',
                'network_type': 'bridge',
                'database_strategy': 'internal',
                'database_type': 'postgresql',
                'database_version': '14-alpine',
                'host_port': 3000,
                'replicas': 1,
                'restart_policy': 'no'
            }
        }
        
        return presets.get(preset_name, {})

    @pyqtSlot(str)
    def applyPreset(self, preset_name: str):
        """Apply a preset configuration.
        
        Args:
            preset_name: Name of preset to apply
        """
        preset = self.getPresetConfig(preset_name)
        if not preset:
            self.errorOccurred.emit(f"Unknown preset: {preset_name}")
            return
            
        try:
            # Apply preset values to config
            config = self._docker_config
            
            if 'deployment_mode' in preset:
                config.deploymentMode = preset['deployment_mode']
            if 'ingress_enabled' in preset:
                config.ingressEnabled = preset['ingress_enabled']
            if 'ssl_enabled' in preset:
                config.sslEnabled = preset['ssl_enabled']
            if 'secret_type' in preset:
                config.secretType = preset['secret_type']
            if 'network_type' in preset:
                config.networkType = preset['network_type']
            if 'database_strategy' in preset:
                config.databaseStrategy = preset['database_strategy']
            if 'database_type' in preset:
                config.databaseType = preset['database_type']
            if 'database_version' in preset:
                config.databaseVersion = preset['database_version']
            if 'host_port' in preset:
                config.hostPort = preset['host_port']
            if 'replicas' in preset:
                config.replicas = preset['replicas']
            if 'memory_limit' in preset:
                config.memoryLimit = preset['memory_limit']
            if 'cpu_limit' in preset:
                config.cpuLimit = preset['cpu_limit']
            if 'restart_policy' in preset:
                config.restartPolicy = preset['restart_policy']
                
            self._generatePreview()
            
        except Exception as e:
            self.errorOccurred.emit(f"Failed to apply preset: {str(e)}")

    @pyqtSlot(result='QVariantList')
    def getAvailablePresets(self) -> List[Dict[str, str]]:
        """Get list of available preset configurations.
        
        Returns:
            List of preset info dictionaries
        """
        presets = [
            {
                'id': 'simple-web-app',
                'name': 'Simple Web Application',
                'description': 'Basic standalone web app',
                'icon': '🌐',
                'difficulty': 'beginner'
            },
            {
                'id': 'wordpress-stack',
                'name': 'WordPress + Database',
                'description': 'WordPress with MariaDB',
                'icon': '📝',
                'difficulty': 'beginner'
            },
            {
                'id': 'development',
                'name': 'Development Environment',
                'description': 'Fast iteration setup',
                'icon': '🛠️',
                'difficulty': 'beginner'
            },
            {
                'id': 'production-swarm',
                'name': 'Production Swarm',
                'description': 'Production-ready cluster',
                'icon': '🏭',
                'difficulty': 'advanced'
            }
        ]
        return presets

    @pyqtSlot(list)
    def setExistingPorts(self, ports: List[int]):
        """Set list of existing ports for conflict detection.
        
        Args:
            ports: List of ports already in use
        """
        self._existing_ports = ports

    @pyqtSlot(int, result=bool)
    def checkPortConflict(self, port: int) -> bool:
        """Check if port conflicts with existing deployments.
        
        Args:
            port: Port to check
            
        Returns:
            True if conflict exists
        """
        validation = ConfigValidator.check_port_conflict(port, self._existing_ports)
        if not validation.valid:
            self.fieldValidationChanged.emit('hostPort', False, validation.message)
            return True
        return False
