"""Web application configuration."""

from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class WebSettings(BaseSettings):
    """Web application settings with environment variable support."""

    model_config = SettingsConfigDict(
        env_prefix="IAC_WEB_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # Server settings
    host: str = "0.0.0.0"
    port: int = 8000
    reload: bool = False
    workers: int = 1

    # Security
    secret_key: str = Field(
        default="change-me-in-production-use-openssl-rand-hex-32",
        description="Secret key for JWT signing",
    )
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 60 * 24  # 24 hours
    refresh_token_expire_days: int = 30

    # CORS
    cors_origins: list[str] = Field(
        default=["http://localhost:5173", "http://localhost:3000", "http://127.0.0.1:5173"],
        description="Allowed CORS origins",
    )
    cors_allow_credentials: bool = True

    # OAuth providers (optional)
    github_client_id: str | None = None
    github_client_secret: str | None = None
    gitlab_client_id: str | None = None
    gitlab_client_secret: str | None = None
    gitlab_url: str = "https://gitlab.com"

    # Database
    database_url: str = Field(
        default="sqlite+aiosqlite:///./iac_manager.db",
        description="Async database URL",
    )

    # Frontend
    static_dir: Path | None = None
    serve_frontend: bool = True

    # Logging
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR"] = "INFO"

    @property
    def github_enabled(self) -> bool:
        """Check if GitHub OAuth is configured."""
        return bool(self.github_client_id and self.github_client_secret)

    @property
    def gitlab_enabled(self) -> bool:
        """Check if GitLab OAuth is configured."""
        return bool(self.gitlab_client_id and self.gitlab_client_secret)


@lru_cache
def get_settings() -> WebSettings:
    """Get cached settings instance."""
    return WebSettings()
