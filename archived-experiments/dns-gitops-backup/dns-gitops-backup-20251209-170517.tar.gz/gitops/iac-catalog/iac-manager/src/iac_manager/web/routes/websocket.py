"""WebSocket route integration."""

import uuid
from typing import Annotated

from fastapi import APIRouter, Depends, Query, WebSocket

from iac_manager.web.auth.jwt import verify_token
from iac_manager.web.websocket import websocket_handler

router = APIRouter()


@router.websocket("/ws")
async def websocket_endpoint(
    websocket: WebSocket,
    token: str = Query(None, description="JWT access token"),
    client_id: str = Query(None, description="Optional client ID"),
) -> None:
    """WebSocket endpoint for real-time updates.

    Supports optional authentication via token query parameter.
    If no client_id is provided, generates a unique one.

    Channels:
    - git_status: Git repository status updates
    - deployment_logs:{deployment_id}: Real-time deployment logs
    - operation:{operation_id}: Long-running operation progress
    """
    # Validate token if provided
    if token:
        payload = verify_token(token)
        if payload is None:
            await websocket.close(code=4001, reason="Invalid token")
            return

    # Generate client ID if not provided
    if not client_id:
        client_id = str(uuid.uuid4())

    # Handle the WebSocket connection
    await websocket_handler(websocket, client_id)
