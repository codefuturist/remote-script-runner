"""Inventory backend for QML."""

from typing import Optional

from PyQt6.QtCore import QObject, pyqtProperty, pyqtSignal, pyqtSlot

from iac_manager.config import Config
from iac_manager.services import InventoryService
from iac_manager.gui.backend.models import InventoryHostListModel, InventoryGroupListModel


class InventoryBackend(QObject):
    """Backend bridge for inventory operations in QML."""

    # Signals
    hostsLoaded = pyqtSignal()
    groupsLoaded = pyqtSignal()
    statusChanged = pyqtSignal(str)
    errorOccurred = pyqtSignal(str)
    operationCompleted = pyqtSignal(str)

    def __init__(self, config: Config, inventory_service: InventoryService, parent=None):
        """Initialize inventory backend.

        Args:
            config: Configuration object
            inventory_service: Inventory service instance
            parent: Parent QObject
        """
        super().__init__(parent)
        self._config = config
        self._inventory_service = inventory_service
        self._hosts_model = InventoryHostListModel(self)
        self._groups_model = InventoryGroupListModel(self)
        self._status = "Ready"
        self._selected_environment = "all"

    @pyqtProperty(QObject, constant=True)
    def hostsModel(self) -> InventoryHostListModel:
        """Get hosts model for QML."""
        return self._hosts_model

    @pyqtProperty(QObject, constant=True)
    def groupsModel(self) -> InventoryGroupListModel:
        """Get groups model for QML."""
        return self._groups_model

    @pyqtProperty(str, notify=statusChanged)
    def status(self) -> str:
        """Get current status message."""
        return self._status

    @status.setter
    def status(self, value: str):
        """Set status message."""
        if self._status != value:
            self._status = value
            self.statusChanged.emit(value)

    @pyqtSlot()
    @pyqtSlot(str)
    def refresh(self, environment: Optional[str] = None):
        """Refresh inventory.

        Args:
            environment: Optional environment filter
        """
        try:
            self.status = "Loading inventory..."

            # Use environment filter if provided
            env = None if environment == "all" or not environment else environment

            # Load hosts and groups separately
            hosts = self._inventory_service.list_hosts(environment=env)
            groups = self._inventory_service.list_groups(environment=env)

            # Update models
            self._hosts_model.setHosts(hosts)
            self._groups_model.setGroups(groups)

            # Update status
            self.status = f"Loaded {len(hosts)} host(s) and {len(groups)} group(s)"

            self.hostsLoaded.emit()
            self.groupsLoaded.emit()

        except Exception as e:
            self.status = f"Error: {str(e)}"
            self.errorOccurred.emit(str(e))

    @pyqtSlot(int, result=str)
    def getHostDetails(self, index: int) -> str:
        """Get host details as formatted string.

        Args:
            index: Host index

        Returns:
            Formatted details string
        """
        host = self._hosts_model.getHost(index)
        if not host:
            return ""

        details = f"""<h3>{host.name}</h3>
<p><b>Ansible Host:</b> {host.ansible_host}</p>
<p><b>User:</b> {host.ansible_user or 'default'}</p>
<p><b>Port:</b> {host.ansible_port}</p>

<h4>Groups:</h4>
<ul>
{"".join(f"<li>{g}</li>" for g in host.groups) if host.groups else "<li>None</li>"}
</ul>

<h4>Labels:</h4>
<ul>
{"".join(f"<li><b>{k}:</b> {v}</li>" for k, v in host.labels.items()) if host.labels else "<li>None</li>"}
</ul>"""

        return details

    @pyqtSlot(int, result=str)
    def getGroupDetails(self, index: int) -> str:
        """Get group details as formatted string.

        Args:
            index: Group index

        Returns:
            Formatted details string
        """
        group = self._groups_model.getGroup(index)
        if not group:
            return ""

        details = f"""<h3>{group.name}</h3>

<h4>Hosts ({len(group.hosts)}):</h4>
<ul>
{"".join(f"<li>{h}</li>" for h in group.hosts) if group.hosts else "<li>None</li>"}
</ul>

<h4>Child Groups:</h4>
<ul>
{"".join(f"<li>{c}</li>" for c in group.children) if group.children else "<li>None</li>"}
</ul>

<h4>Variables:</h4>
<ul>
{"".join(f"<li><b>{k}:</b> {v}</li>" for k, v in group.vars.items()) if group.vars else "<li>None</li>"}
</ul>"""

        return details

    @pyqtSlot(str, str, int, result=bool)
    def addHost(self, hostname: str, ansible_host: str, port: int = 22) -> bool:
        """Add a new host to inventory.

        Args:
            hostname: Hostname
            ansible_host: Ansible host address
            port: SSH port

        Returns:
            True if successful
        """
        try:
            from pathlib import Path
            from iac_manager.utils.yaml_utils import load_yaml, save_yaml
            
            self.status = f"Adding host {hostname}..."
            
            # Use the selected environment or default to development
            environment = self._selected_environment if self._selected_environment != "all" else "development"
            
            # Build inventory file path
            inventory_path = Path(self._config.inventory_dir) / environment / "hosts.yml"
            
            # Create directory if it doesn't exist
            inventory_path.parent.mkdir(parents=True, exist_ok=True)
            
            # Load or create inventory structure
            if inventory_path.exists():
                inventory_data = load_yaml(inventory_path)
            else:
                inventory_data = {"all": {"hosts": {}, "children": {}}}
            
            # Ensure structure exists
            if "all" not in inventory_data:
                inventory_data["all"] = {}
            if "hosts" not in inventory_data["all"]:
                inventory_data["all"]["hosts"] = {}
            
            # Add host
            inventory_data["all"]["hosts"][hostname] = {
                "ansible_host": ansible_host,
                "ansible_user": "root",
                "ansible_port": port
            }
            
            # Save inventory
            save_yaml(inventory_data, inventory_path)
            
            self.refresh()
            self.operationCompleted.emit(f"Host {hostname} added successfully")
            return True
        except Exception as e:
            self.errorOccurred.emit(f"Failed to add host: {str(e)}")
            return False

    @pyqtSlot(int, result=bool)
    def removeHost(self, index: int) -> bool:
        """Remove a host from inventory.

        Args:
            index: Host index

        Returns:
            True if successful
        """
        host = self._hosts_model.getHost(index)
        if host:
            try:
                from pathlib import Path
                from iac_manager.utils.yaml_utils import load_yaml, save_yaml
                
                self.status = f"Removing host {host.name}..."
                
                # Use the selected environment or default to development
                environment = self._selected_environment if self._selected_environment != "all" else "development"
                
                # Build inventory file path
                inventory_path = Path(self._config.inventory_dir) / environment / "hosts.yml"
                
                if not inventory_path.exists():
                    self.errorOccurred.emit(f"Inventory file not found: {inventory_path}")
                    return False
                
                # Load inventory
                inventory_data = load_yaml(inventory_path)
                
                # Remove host from all locations
                removed = False
                
                # Check in all.hosts
                if "all" in inventory_data and "hosts" in inventory_data["all"]:
                    if host.name in inventory_data["all"]["hosts"]:
                        del inventory_data["all"]["hosts"][host.name]
                        removed = True
                
                # Check in groups
                if "all" in inventory_data and "children" in inventory_data["all"]:
                    for group_name, group_data in inventory_data["all"]["children"].items():
                        if "hosts" in group_data and host.name in group_data["hosts"]:
                            del group_data["hosts"][host.name]
                            removed = True
                
                if removed:
                    # Save inventory
                    save_yaml(inventory_data, inventory_path)
                    self.refresh()
                    self.operationCompleted.emit(f"Host {host.name} removed")
                    return True
                else:
                    self.errorOccurred.emit(f"Host {host.name} not found in inventory")
                    return False
                    
            except Exception as e:
                self.errorOccurred.emit(f"Failed to remove host: {str(e)}")
                return False
        return False

    @pyqtSlot(int, result=bool)
    def testConnection(self, index: int) -> bool:
        """Test connection to a host.

        Args:
            index: Host index

        Returns:
            True if connection successful
        """
        host = self._hosts_model.getHost(index)
        if host:
            try:
                from iac_manager.cli.ssh_utils import check_ssh_connection
                
                self.status = f"Testing connection to {host.name}..."
                
                # Test SSH connection
                ansible_host = host.ansible_host
                ansible_user = host.ansible_user or "root"
                ansible_port = host.ansible_port or 22
                
                result = check_ssh_connection(ansible_host, ansible_user, ansible_port)
                
                if result:
                    self.operationCompleted.emit(f"Connection to {host.name} successful")
                    self.status = f"✅ Connected to {host.name}"
                else:
                    self.errorOccurred.emit(f"Failed to connect to {host.name}")
                    self.status = f"❌ Connection to {host.name} failed"
                    
                return result
            except Exception as e:
                self.errorOccurred.emit(f"Connection test failed: {str(e)}")
                return False
        return False

    @pyqtSlot(result="QStringList")
    def getEnvironments(self) -> list:
        """Get list of available environments.

        Returns:
            List of environment names
        """
        return ["all", "development", "staging", "production", "dr-site"]
