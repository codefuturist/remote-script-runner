"""Inventory widget."""

from typing import List, Optional

from PyQt6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QTreeWidget,
    QTreeWidgetItem,
    QPushButton,
    QComboBox,
    QLabel,
    QLineEdit,
    QMessageBox,
    QTextEdit,
    QDialog,
    QDialogButtonBox,
)
from PyQt6.QtCore import Qt

from iac_manager.config import Config
from iac_manager.services import InventoryService
from iac_manager.models import InventoryHost, InventoryGroup


class InventoryWidget(QWidget):
    """Widget showing inventory."""

    def __init__(self, config: Config, inventory_service: InventoryService):
        """Initialize inventory widget.

        Args:
            config: Configuration object
            inventory_service: Inventory service instance
        """
        super().__init__()
        self.config = config
        self.inventory_service = inventory_service
        self.hosts: List[InventoryHost] = []
        self.groups: List[InventoryGroup] = []

        self._init_ui()
        self.refresh()

    def _init_ui(self) -> None:
        """Initialize the user interface."""
        layout = QVBoxLayout(self)

        # Header with filters
        header = QHBoxLayout()

        # Title
        title = QLabel("📋 Inventory")
        title.setStyleSheet("font-size: 18px; font-weight: bold;")
        header.addWidget(title)

        header.addStretch()

        # Environment filter
        header.addWidget(QLabel("Environment:"))
        self.env_filter = QComboBox()
        self.env_filter.addItem("All", None)
        self.env_filter.addItem("Development", "development")
        self.env_filter.addItem("Staging", "staging")
        self.env_filter.addItem("Production", "production")
        self.env_filter.addItem("DR Site", "dr-site")
        self.env_filter.currentIndexChanged.connect(self.refresh)
        header.addWidget(self.env_filter)

        # Search
        self.search_box = QLineEdit()
        self.search_box.setPlaceholderText("🔍 Search hosts...")
        self.search_box.textChanged.connect(self._filter_tree)
        header.addWidget(self.search_box)

        # Refresh button
        self.refresh_btn = QPushButton("🔄 Refresh")
        self.refresh_btn.clicked.connect(self.refresh)
        header.addWidget(self.refresh_btn)

        layout.addLayout(header)

        # Inventory tree
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["Name", "Type", "IP/Connection", "Environment", "Status"])
        self.tree.setAlternatingRowColors(True)
        self.tree.setColumnWidth(0, 250)
        self.tree.setColumnWidth(1, 100)
        self.tree.setColumnWidth(2, 200)
        self.tree.setColumnWidth(3, 150)
        self.tree.itemDoubleClicked.connect(self._on_item_double_clicked)

        layout.addWidget(self.tree)

        # Action buttons
        actions = QHBoxLayout()

        self.view_btn = QPushButton("👁️ View Details")
        self.view_btn.clicked.connect(self._view_details)
        actions.addWidget(self.view_btn)

        self.ping_btn = QPushButton("🔌 Test Connection")
        self.ping_btn.clicked.connect(self._test_connection)
        actions.addWidget(self.ping_btn)

        self.add_host_btn = QPushButton("➕ Add Host")
        self.add_host_btn.clicked.connect(self._add_host)
        actions.addWidget(self.add_host_btn)

        actions.addStretch()

        layout.addLayout(actions)

        # Status label
        self.status_label = QLabel("Ready")
        self.status_label.setStyleSheet("color: gray;")
        layout.addWidget(self.status_label)

    def refresh(self) -> None:
        """Refresh inventory."""
        try:
            self.status_label.setText("Loading inventory...")
            self.refresh_btn.setEnabled(False)
            self.tree.clear()

            # Get filter
            env = self.env_filter.currentData()

            # Load data
            self.hosts = self.inventory_service.list_hosts(environment=env)
            self.groups = self.inventory_service.list_groups(environment=env)

            # Check if inventory exists
            inventory_path = self.config.repo_root / self.config.inventory_dir
            if not inventory_path.exists():
                self._show_no_inventory_message()
                return

            # Build tree structure
            if self.groups:
                self._build_tree_with_groups()
            elif self.hosts:
                self._build_tree_flat()
            else:
                self._show_empty_inventory()

            # Update status
            host_count = len(self.hosts)
            group_count = len(self.groups)
            env_text = f" in {env}" if env else ""
            self.status_label.setText(
                f"Found {host_count} host{'s' if host_count != 1 else ''} "
                f"in {group_count} group{'s' if group_count != 1 else ''}{env_text}"
            )

        except Exception as e:
            self.status_label.setText(f"Error: {str(e)}")
            QMessageBox.warning(self, "Error", f"Failed to load inventory:\n{str(e)}")

        finally:
            self.refresh_btn.setEnabled(True)

    def _build_tree_with_groups(self) -> None:
        """Build tree view with groups."""
        for group in self.groups:
            group_item = QTreeWidgetItem(self.tree)
            group_item.setText(0, f"📁 {group.name}")
            group_item.setText(1, "Group")
            group_item.setText(4, f"{len(group.hosts)} hosts")
            group_item.setData(0, Qt.ItemDataRole.UserRole, group)

            for host in group.hosts:
                self._add_host_item(group_item, host)

            group_item.setExpanded(True)

    def _build_tree_flat(self) -> None:
        """Build flat tree view without groups."""
        for host in self.hosts:
            self._add_host_item(self.tree, host)

    def _add_host_item(self, parent: QTreeWidgetItem, host: InventoryHost) -> QTreeWidgetItem:
        """Add host item to tree.

        Args:
            parent: Parent tree item or tree widget
            host: Host information

        Returns:
            Created tree item
        """
        if isinstance(parent, QTreeWidget):
            item = QTreeWidgetItem(parent)
        else:
            item = QTreeWidgetItem(parent)

        item.setText(0, f"🖥️ {host.hostname}")
        item.setText(1, "Host")
        item.setText(2, host.ansible_host or "N/A")
        item.setText(3, host.environment or "N/A")
        item.setText(4, "✅ Ready")
        item.setData(0, Qt.ItemDataRole.UserRole, host)

        return item

    def _show_no_inventory_message(self) -> None:
        """Show message when inventory directory doesn't exist."""
        info_item = QTreeWidgetItem(self.tree)
        info_item.setText(0, "ℹ️ No inventory directory found")
        info_item.setText(1, "")
        info_item.setText(2, f"Create: {self.config.inventory_dir}/")
        info_item.setDisabled(True)

    def _show_empty_inventory(self) -> None:
        """Show message when inventory is empty."""
        info_item = QTreeWidgetItem(self.tree)
        info_item.setText(0, "ℹ️ Inventory is empty")
        info_item.setText(1, "")
        info_item.setText(2, "Add hosts to populate inventory")
        info_item.setDisabled(True)

    def _filter_tree(self) -> None:
        """Filter tree based on search text."""
        search_text = self.search_box.text().lower()

        # Show/hide items based on search
        iterator = QTreeWidgetItem.ItemIterator(
            self.tree,
            QTreeWidgetItem.ItemIteratorFlag.All
        )

        while iterator.value():
            item = iterator.value()
            if item.parent() is None:  # Top-level item (group)
                # Check if any child matches
                matches = False
                for i in range(item.childCount()):
                    child = item.child(i)
                    child_text = child.text(0).lower()
                    if not search_text or search_text in child_text:
                        child.setHidden(False)
                        matches = True
                    else:
                        child.setHidden(True)
                item.setHidden(not matches)
            else:  # Child item (host in group)
                # Already handled by parent check
                pass

            iterator += 1

    def _on_item_double_clicked(self, item: QTreeWidgetItem, column: int) -> None:
        """Handle double-click on tree item.

        Args:
            item: Clicked item
            column: Column index
        """
        self._view_details()

    def _view_details(self) -> None:
        """View details of selected item."""
        item = self.tree.currentItem()
        if not item:
            return

        data = item.data(0, Qt.ItemDataRole.UserRole)

        if isinstance(data, InventoryHost):
            self._show_host_details(data)
        elif isinstance(data, InventoryGroup):
            self._show_group_details(data)

    def _show_host_details(self, host: InventoryHost) -> None:
        """Show host details dialog.

        Args:
            host: Host information
        """
        details = f"""
<h3>🖥️ {host.hostname}</h3>

<h4>Connection:</h4>
<ul>
<li><b>Ansible Host:</b> {host.ansible_host or 'N/A'}</li>
<li><b>User:</b> {host.ansible_user or 'default'}</li>
<li><b>Port:</b> {host.ansible_port or '22'}</li>
<li><b>Connection:</b> {host.ansible_connection or 'ssh'}</li>
</ul>

<h4>Environment:</h4>
<ul>
<li><b>Environment:</b> {host.environment or 'N/A'}</li>
</ul>

<h4>Variables:</h4>
"""
        if host.vars:
            details += "<ul>"
            for key, value in host.vars.items():
                details += f"<li><b>{key}:</b> {value}</li>"
            details += "</ul>"
        else:
            details += "<p><i>No custom variables</i></p>"

        msg = QMessageBox(self)
        msg.setWindowTitle("Host Details")
        msg.setTextFormat(Qt.TextFormat.RichText)
        msg.setText(details)
        msg.exec()

    def _show_group_details(self, group: InventoryGroup) -> None:
        """Show group details dialog.

        Args:
            group: Group information
        """
        details = f"""
<h3>📁 {group.name}</h3>

<p><b>Hosts:</b> {len(group.hosts)}</p>

<h4>Group Variables:</h4>
"""
        if group.vars:
            details += "<ul>"
            for key, value in group.vars.items():
                details += f"<li><b>{key}:</b> {value}</li>"
            details += "</ul>"
        else:
            details += "<p><i>No group variables</i></p>"

        details += "<h4>Hosts in group:</h4><ul>"
        for host in group.hosts:
            details += f"<li>🖥️ {host.hostname}</li>"
        details += "</ul>"

        msg = QMessageBox(self)
        msg.setWindowTitle("Group Details")
        msg.setTextFormat(Qt.TextFormat.RichText)
        msg.setText(details)
        msg.exec()

    def _test_connection(self) -> None:
        """Test connection to selected host."""
        item = self.tree.currentItem()
        if not item:
            return

        data = item.data(0, Qt.ItemDataRole.UserRole)
        if not isinstance(data, InventoryHost):
            QMessageBox.information(
                self,
                "Test Connection",
                "Please select a host to test connection."
            )
            return

        # Import SSH utilities for connection test
        from iac_manager.cli.ssh_utils import check_ssh_connection
        
        # Show progress dialog
        progress = QMessageBox(self)
        progress.setWindowTitle("Testing Connection")
        progress.setText(f"Testing SSH connection to {data.name}...")
        progress.setStandardButtons(QMessageBox.StandardButton.NoButton)
        progress.show()
        
        try:
            # Test SSH connection
            host = data.ansible_host
            user = data.ansible_user or "root"
            port = data.ansible_port or 22
            
            success = check_ssh_connection(host, user, port)
            
            progress.close()
            
            if success:
                QMessageBox.information(
                    self,
                    "Test Connection",
                    f"✅ Successfully connected to {data.name}\n\n"
                    f"Host: {host}\n"
                    f"User: {user}\n"
                    f"Port: {port}"
                )
            else:
                QMessageBox.warning(
                    self,
                    "Test Connection",
                    f"❌ Failed to connect to {data.name}\n\n"
                    f"Host: {host}\n"
                    f"User: {user}\n"
                    f"Port: {port}\n\n"
                    f"Please check:\n"
                    f"- Host is reachable\n"
                    f"- SSH service is running\n"
                    f"- SSH keys are configured\n"
                    f"- Firewall allows connection"
                )
        except Exception as e:
            progress.close()
            QMessageBox.critical(
                self,
                "Test Connection Error",
                f"Error testing connection:\n{str(e)}"
            )

    def _add_host(self) -> None:
        """Add a new host to inventory."""
        dialog = QDialog(self)
        dialog.setWindowTitle("Add Host")
        dialog.setMinimumWidth(500)

        layout = QVBoxLayout(dialog)

        # Form fields
        form = QVBoxLayout()

        form.addWidget(QLabel("<b>Hostname:</b>"))
        hostname_edit = QLineEdit()
        hostname_edit.setPlaceholderText("server01")
        form.addWidget(hostname_edit)

        form.addWidget(QLabel("<b>Ansible Host (IP/FQDN):</b>"))
        host_edit = QLineEdit()
        host_edit.setPlaceholderText("192.168.1.100")
        form.addWidget(host_edit)

        form.addWidget(QLabel("<b>Environment:</b>"))
        env_combo = QComboBox()
        env_combo.addItems(["development", "staging", "production", "dr-site"])
        form.addWidget(env_combo)

        form.addWidget(QLabel("<b>Group (optional):</b>"))
        group_edit = QLineEdit()
        group_edit.setPlaceholderText("web_servers")
        form.addWidget(group_edit)

        layout.addLayout(form)

        # Buttons
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)

        if dialog.exec() == QDialog.DialogCode.Accepted:
            try:
                hostname = hostname_edit.text().strip()
                ansible_host = host_edit.text().strip()
                environment = env_combo.currentText()
                group = group_edit.text().strip()
                
                # Validate inputs
                if not hostname:
                    QMessageBox.warning(self, "Add Host", "Hostname is required")
                    return
                if not ansible_host:
                    QMessageBox.warning(self, "Add Host", "Ansible host (IP/FQDN) is required")
                    return
                
                # Build inventory file path
                from pathlib import Path
                inventory_path = Path(self.config.inventory_dir) / environment / "hosts.yml"
                
                # Create directory if it doesn't exist
                inventory_path.parent.mkdir(parents=True, exist_ok=True)
                
                # Load or create inventory structure
                from iac_manager.utils.yaml_utils import load_yaml, save_yaml
                
                if inventory_path.exists():
                    inventory_data = load_yaml(inventory_path)
                else:
                    inventory_data = {"all": {"hosts": {}, "children": {}}}
                
                # Ensure structure exists
                if "all" not in inventory_data:
                    inventory_data["all"] = {}
                if "hosts" not in inventory_data["all"]:
                    inventory_data["all"]["hosts"] = {}
                if "children" not in inventory_data["all"]:
                    inventory_data["all"]["children"] = {}
                
                # Add host to appropriate group or directly to 'all'
                if group:
                    # Add to specified group
                    if group not in inventory_data["all"]["children"]:
                        inventory_data["all"]["children"][group] = {"hosts": {}}
                    if "hosts" not in inventory_data["all"]["children"][group]:
                        inventory_data["all"]["children"][group]["hosts"] = {}
                    
                    inventory_data["all"]["children"][group]["hosts"][hostname] = {
                        "ansible_host": ansible_host,
                        "ansible_user": "root",
                        "ansible_port": 22
                    }
                else:
                    # Add directly to 'all' hosts
                    inventory_data["all"]["hosts"][hostname] = {
                        "ansible_host": ansible_host,
                        "ansible_user": "root",
                        "ansible_port": 22
                    }
                
                # Save inventory
                save_yaml(inventory_data, inventory_path)
                
                QMessageBox.information(
                    self,
                    "Add Host",
                    f"Successfully added host: {hostname}\n\n"
                    f"Inventory file: {inventory_path}"
                )
                
                # Refresh display
                self.refresh()
                
            except Exception as e:
                QMessageBox.critical(
                    self,
                    "Add Host Error",
                    f"Failed to add host:\n{str(e)}"
                )

