"""GitOps widget."""

from typing import List

from PyQt6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QGroupBox,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QLabel,
    QTextEdit,
    QMessageBox,
    QLineEdit,
    QSplitter,
)
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QColor

from iac_manager.config import Config
from iac_manager.services import GitOpsService


class GitOpsWidget(QWidget):
    """Widget for GitOps operations."""

    def __init__(self, config: Config, gitops_service: GitOpsService):
        """Initialize GitOps widget.

        Args:
            config: Configuration object
            gitops_service: GitOps service instance
        """
        super().__init__()
        self.config = config
        self.gitops_service = gitops_service
        self.status_data = {}

        self._init_ui()
        self.refresh()

        # Auto-refresh every 5 seconds
        self.refresh_timer = QTimer()
        self.refresh_timer.timeout.connect(self.refresh)
        self.refresh_timer.start(5000)

    def _init_ui(self) -> None:
        """Initialize the user interface."""
        layout = QVBoxLayout(self)

        # Header
        header = QHBoxLayout()
        title = QLabel("🔄 GitOps")
        title.setStyleSheet("font-size: 18px; font-weight: bold;")
        header.addWidget(title)

        header.addStretch()

        # Refresh button
        self.refresh_btn = QPushButton("🔄 Refresh")
        self.refresh_btn.clicked.connect(self.refresh)
        header.addWidget(self.refresh_btn)

        layout.addLayout(header)

        # Status section
        status_group = QGroupBox("📊 Repository Status")
        status_layout = QVBoxLayout()

        # Status labels
        self.branch_label = QLabel("Branch: <i>Loading...</i>")
        self.branch_label.setTextFormat(Qt.TextFormat.RichText)
        status_layout.addWidget(self.branch_label)

        self.changes_label = QLabel("Changes: <i>Loading...</i>")
        self.changes_label.setTextFormat(Qt.TextFormat.RichText)
        status_layout.addWidget(self.changes_label)

        self.staged_label = QLabel("Staged: <i>Loading...</i>")
        self.staged_label.setTextFormat(Qt.TextFormat.RichText)
        status_layout.addWidget(self.staged_label)

        status_group.setLayout(status_layout)
        layout.addWidget(status_group)

        # Create splitter for files lists
        splitter = QSplitter(Qt.Orientation.Horizontal)

        # Modified files section
        modified_group = QGroupBox("� Modified Files")
        modified_layout = QVBoxLayout()

        self.modified_list = QListWidget()
        self.modified_list.setSelectionMode(QListWidget.SelectionMode.MultiSelection)
        self.modified_list.itemSelectionChanged.connect(self._on_selection_changed)
        modified_layout.addWidget(self.modified_list)

        modified_actions = QHBoxLayout()
        self.stage_btn = QPushButton("➕ Stage Selected")
        self.stage_btn.setEnabled(False)
        self.stage_btn.clicked.connect(self._stage_files)
        modified_actions.addWidget(self.stage_btn)

        self.stage_all_btn = QPushButton("➕ Stage All")
        self.stage_all_btn.clicked.connect(self._stage_all_files)
        modified_actions.addWidget(self.stage_all_btn)

        modified_layout.addLayout(modified_actions)
        modified_group.setLayout(modified_layout)
        splitter.addWidget(modified_group)

        # Staged files section
        staged_group = QGroupBox("✅ Staged Files")
        staged_layout = QVBoxLayout()

        self.staged_list = QListWidget()
        self.staged_list.setSelectionMode(QListWidget.SelectionMode.MultiSelection)
        self.staged_list.itemSelectionChanged.connect(self._on_selection_changed)
        staged_layout.addWidget(self.staged_list)

        staged_actions = QHBoxLayout()
        self.unstage_btn = QPushButton("➖ Unstage Selected")
        self.unstage_btn.setEnabled(False)
        self.unstage_btn.clicked.connect(self._unstage_files)
        staged_actions.addWidget(self.unstage_btn)

        staged_layout.addLayout(staged_actions)
        staged_group.setLayout(staged_layout)
        splitter.addWidget(staged_group)

        layout.addWidget(splitter)

        # Commit section
        commit_group = QGroupBox("💾 Commit Changes")
        commit_layout = QVBoxLayout()

        # Commit message
        commit_layout.addWidget(QLabel("Commit Message:"))
        self.commit_message = QTextEdit()
        self.commit_message.setPlaceholderText(
            "Enter a descriptive commit message...\n\n"
            "Example:\n"
            "feat: add new deployment for wordpress\n\n"
            "- Configure environment variables\n"
            "- Set up persistent volumes\n"
            "- Add ingress configuration"
        )
        self.commit_message.setMaximumHeight(100)
        commit_layout.addWidget(self.commit_message)

        # Commit actions
        commit_actions = QHBoxLayout()

        self.commit_btn = QPushButton("💾 Commit")
        self.commit_btn.setStyleSheet("font-weight: bold;")
        self.commit_btn.clicked.connect(self._commit)
        commit_actions.addWidget(self.commit_btn)

        self.commit_push_btn = QPushButton("🚀 Commit & Push")
        self.commit_push_btn.setStyleSheet("font-weight: bold; background-color: #4CAF50; color: white;")
        self.commit_push_btn.clicked.connect(self._commit_and_push)
        commit_actions.addWidget(self.commit_push_btn)

        commit_actions.addStretch()

        # Push button
        self.push_btn = QPushButton("⬆️ Push")
        self.push_btn.clicked.connect(self._push)
        commit_actions.addWidget(self.push_btn)

        commit_layout.addLayout(commit_actions)
        commit_group.setLayout(commit_layout)
        layout.addWidget(commit_group)

        # Status label
        self.status_label = QLabel("Ready")
        self.status_label.setStyleSheet("color: gray;")
        layout.addWidget(self.status_label)

    def refresh(self) -> None:
        """Refresh GitOps status."""
        try:
            self.status_label.setText("Refreshing...")

            # Get status
            self.status_data = self.gitops_service.get_status()

            # Update branch
            branch = self.status_data.get("branch", "unknown")
            self.branch_label.setText(f"<b>Branch:</b> {branch}")

            # Update modified files
            modified = self.status_data.get("modified", [])
            self.modified_list.clear()
            for file in modified:
                item = QListWidgetItem(f"📝 {file}")
                item.setData(Qt.ItemDataRole.UserRole, file)
                self.modified_list.addItem(item)

            # Update staged files
            staged = self.status_data.get("staged", [])
            self.staged_list.clear()
            for file in staged:
                item = QListWidgetItem(f"✅ {file}")
                item.setData(Qt.ItemDataRole.UserRole, file)
                item.setBackground(QColor(200, 255, 200))
                self.staged_list.addItem(item)

            # Update counts
            self.changes_label.setText(f"<b>Modified:</b> {len(modified)} file{'s' if len(modified) != 1 else ''}")
            self.staged_label.setText(f"<b>Staged:</b> {len(staged)} file{'s' if len(staged) != 1 else ''}")

            # Update status
            if staged:
                self.status_label.setText(f"✅ {len(staged)} file(s) ready to commit")
                self.status_label.setStyleSheet("color: green; font-weight: bold;")
            elif modified:
                self.status_label.setText(f"⚠️ {len(modified)} file(s) modified")
                self.status_label.setStyleSheet("color: orange; font-weight: bold;")
            else:
                self.status_label.setText("✓ Working tree clean")
                self.status_label.setStyleSheet("color: green;")

        except Exception as e:
            self.status_label.setText(f"Error: {str(e)}")
            self.status_label.setStyleSheet("color: red;")

    def _on_selection_changed(self) -> None:
        """Handle selection change in lists."""
        has_modified_selection = bool(self.modified_list.selectedItems())
        has_staged_selection = bool(self.staged_list.selectedItems())

        self.stage_btn.setEnabled(has_modified_selection)
        self.unstage_btn.setEnabled(has_staged_selection)

    def _stage_files(self) -> None:
        """Stage selected modified files."""
        selected = self.modified_list.selectedItems()
        if not selected:
            return

        files = [item.data(Qt.ItemDataRole.UserRole) for item in selected]

        try:
            from pathlib import Path
            file_paths = [Path(f) for f in files]
            
            success = self.gitops_service.add_files(file_paths)
            
            if success:
                self.status_label.setText(f"✅ Staged {len(files)} file(s)")
                self.status_label.setStyleSheet("color: green;")
                self.refresh()
            else:
                raise Exception("Failed to stage files")

        except Exception as e:
            QMessageBox.warning(self, "Error", f"Failed to stage files:\n{str(e)}")

    def _stage_all_files(self) -> None:
        """Stage all modified files."""
        try:
            from pathlib import Path
            files = [Path(self.modified_list.item(i).data(Qt.ItemDataRole.UserRole)) 
                    for i in range(self.modified_list.count())]
            
            if not files:
                QMessageBox.information(self, "Stage All", "No modified files to stage")
                return

            success = self.gitops_service.add_files(files)
            
            if success:
                self.status_label.setText(f"✅ Staged all {len(files)} file(s)")
                self.status_label.setStyleSheet("color: green;")
                self.refresh()
            else:
                raise Exception("Failed to stage files")

        except Exception as e:
            QMessageBox.warning(self, "Error", f"Failed to stage all files:\n{str(e)}")

    def _unstage_files(self) -> None:
        """Unstage selected staged files."""
        selected = self.staged_list.selectedItems()
        if not selected:
            return

        try:
            from pathlib import Path
            
            # Get file paths from selected items
            files = [Path(item.text()) for item in selected]
            
            # Unstage files
            success = self.gitops_service.unstage_files(files)
            
            if success:
                self.status_label.setText(f"✅ Unstaged {len(files)} file(s)")
                self.status_label.setStyleSheet("color: green;")
                self.refresh()
            else:
                raise Exception("Failed to unstage files")
                
        except Exception as e:
            QMessageBox.warning(
                self,
                "Error",
                f"Failed to unstage files:\n{str(e)}"
            )

    def _commit(self) -> None:
        """Commit staged changes."""
        message = self.commit_message.toPlainText().strip()

        if not message:
            QMessageBox.warning(
                self,
                "Commit",
                "Please enter a commit message"
            )
            return

        staged_count = self.staged_list.count()
        if staged_count == 0:
            QMessageBox.warning(
                self,
                "Commit",
                "No staged files to commit"
            )
            return

        reply = QMessageBox.question(
            self,
            "Commit Changes",
            f"Commit {staged_count} file(s) with message:\n\n{message[:100]}{'...' if len(message) > 100 else ''}",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )

        if reply == QMessageBox.StandardButton.Yes:
            try:
                success = self.gitops_service.commit(message)
                
                if success:
                    self.status_label.setText("✅ Changes committed successfully")
                    self.status_label.setStyleSheet("color: green; font-weight: bold;")
                    self.commit_message.clear()
                    self.refresh()
                    
                    QMessageBox.information(
                        self,
                        "Success",
                        f"Successfully committed {staged_count} file(s)"
                    )
                else:
                    raise Exception("Commit failed")

            except Exception as e:
                QMessageBox.warning(self, "Error", f"Failed to commit:\n{str(e)}")

    def _commit_and_push(self) -> None:
        """Commit and push changes."""
        message = self.commit_message.toPlainText().strip()

        if not message:
            QMessageBox.warning(
                self,
                "Commit & Push",
                "Please enter a commit message"
            )
            return

        staged_count = self.staged_list.count()
        if staged_count == 0:
            QMessageBox.warning(
                self,
                "Commit & Push",
                "No staged files to commit"
            )
            return

        branch = self.status_data.get("branch", "unknown")
        reply = QMessageBox.question(
            self,
            "Commit & Push",
            f"Commit {staged_count} file(s) and push to origin/{branch}?\n\n"
            f"Message: {message[:100]}{'...' if len(message) > 100 else ''}",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )

        if reply == QMessageBox.StandardButton.Yes:
            try:
                # Commit
                success = self.gitops_service.commit(message)
                if not success:
                    raise Exception("Commit failed")

                # Push
                success = self.gitops_service.push()
                if not success:
                    raise Exception("Push failed")

                self.status_label.setText("✅ Changes committed and pushed successfully")
                self.status_label.setStyleSheet("color: green; font-weight: bold;")
                self.commit_message.clear()
                self.refresh()
                
                QMessageBox.information(
                    self,
                    "Success",
                    f"Successfully committed {staged_count} file(s) and pushed to origin/{branch}"
                )

            except Exception as e:
                QMessageBox.warning(self, "Error", f"Failed to commit and push:\n{str(e)}")

    def _push(self) -> None:
        """Push commits to remote."""
        branch = self.status_data.get("branch", "unknown")
        
        reply = QMessageBox.question(
            self,
            "Push",
            f"Push commits to origin/{branch}?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )

        if reply == QMessageBox.StandardButton.Yes:
            try:
                success = self.gitops_service.push()
                
                if success:
                    self.status_label.setText(f"✅ Pushed to origin/{branch}")
                    self.status_label.setStyleSheet("color: green; font-weight: bold;")
                    
                    QMessageBox.information(
                        self,
                        "Success",
                        f"Successfully pushed to origin/{branch}"
                    )
                else:
                    raise Exception("Push failed")

            except Exception as e:
                QMessageBox.warning(self, "Error", f"Failed to push:\n{str(e)}")

