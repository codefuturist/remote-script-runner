"""GitOps routes."""

from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, status

from iac_manager.web.auth.dependencies import ActiveUser
from iac_manager.web.schemas.gitops import (
    FileChange,
    FileStatus,
    GitCommitRequest,
    GitCommitResponse,
    GitLogEntry,
    GitLogResponse,
    GitPullRequest,
    GitPullResponse,
    GitPushRequest,
    GitPushResponse,
    GitStageRequest,
    GitStatusResponse,
    GitUnstageRequest,
)
from iac_manager.web.schemas.common import MessageResponse
from iac_manager.web.services import ServiceProvider, get_services

router = APIRouter()


@router.get("/status", response_model=GitStatusResponse)
async def get_git_status(
    current_user: ActiveUser,
    services: Annotated[ServiceProvider, Depends(get_services)],
) -> GitStatusResponse:
    """Get current git repository status."""
    status_data = await services.gitops.get_status()

    # Parse staged files
    staged = [
        FileChange(
            path=f.get("path", f) if isinstance(f, dict) else f,
            status=FileStatus(f.get("status", "modified") if isinstance(f, dict) else "modified"),
            staged=True,
        )
        for f in status_data.get("staged", [])
    ]

    # Parse unstaged files
    unstaged = [
        FileChange(
            path=f.get("path", f) if isinstance(f, dict) else f,
            status=FileStatus(f.get("status", "modified") if isinstance(f, dict) else "modified"),
            staged=False,
        )
        for f in status_data.get("modified", [])
    ]

    return GitStatusResponse(
        branch=status_data.get("branch", "unknown"),
        is_clean=len(staged) == 0 and len(unstaged) == 0,
        ahead=status_data.get("ahead", 0),
        behind=status_data.get("behind", 0),
        staged=staged,
        unstaged=unstaged,
        untracked=status_data.get("untracked", []),
        has_conflicts=status_data.get("has_conflicts", False),
    )


@router.post("/stage", response_model=MessageResponse)
async def stage_files(
    data: GitStageRequest,
    current_user: ActiveUser,
    services: Annotated[ServiceProvider, Depends(get_services)],
) -> MessageResponse:
    """Stage files for commit."""
    from pathlib import Path

    success = await services.gitops.add_files([Path(f) for f in data.files])

    if not success:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Failed to stage files",
        )

    return MessageResponse(message=f"Staged {len(data.files)} file(s)")


@router.post("/unstage", response_model=MessageResponse)
async def unstage_files(
    data: GitUnstageRequest,
    current_user: ActiveUser,
    services: Annotated[ServiceProvider, Depends(get_services)],
) -> MessageResponse:
    """Unstage files from staging area."""
    from pathlib import Path

    success = await services.gitops.unstage_files([Path(f) for f in data.files])

    if not success:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Failed to unstage files",
        )

    return MessageResponse(message=f"Unstaged {len(data.files)} file(s)")


@router.post("/commit", response_model=GitCommitResponse)
async def commit_changes(
    data: GitCommitRequest,
    current_user: ActiveUser,
    services: Annotated[ServiceProvider, Depends(get_services)],
) -> GitCommitResponse:
    """Commit staged changes."""
    from pathlib import Path

    files = [Path(f) for f in data.files] if data.files else None

    try:
        result = await services.gitops.commit(
            message=data.message,
            files=files,
        )
    except Exception as e:
        return GitCommitResponse(
            success=False,
            message=str(e),
        )

    return GitCommitResponse(
        success=True,
        commit_hash=result.get("hash") if isinstance(result, dict) else None,
        message="Changes committed successfully",
    )


@router.post("/push", response_model=GitPushResponse)
async def push_changes(
    data: GitPushRequest,
    current_user: ActiveUser,
    services: Annotated[ServiceProvider, Depends(get_services)],
) -> GitPushResponse:
    """Push commits to remote."""
    try:
        success = await services.gitops.push(
            remote=data.remote,
            branch=data.branch,
        )
    except Exception as e:
        return GitPushResponse(
            success=False,
            message=str(e),
        )

    return GitPushResponse(
        success=success,
        message="Changes pushed successfully" if success else "Push failed",
    )


@router.post("/pull", response_model=GitPullResponse)
async def pull_changes(
    data: GitPullRequest,
    current_user: ActiveUser,
    services: Annotated[ServiceProvider, Depends(get_services)],
) -> GitPullResponse:
    """Pull changes from remote."""
    try:
        result = await services.gitops.pull(
            remote=data.remote,
            branch=data.branch,
            rebase=data.rebase,
        )
    except Exception as e:
        return GitPullResponse(
            success=False,
            message=str(e),
        )

    return GitPullResponse(
        success=True,
        message="Changes pulled successfully",
        commits_pulled=result.get("commits", 0) if isinstance(result, dict) else 0,
    )


@router.get("/log", response_model=GitLogResponse)
async def get_git_log(
    current_user: ActiveUser,
    services: Annotated[ServiceProvider, Depends(get_services)],
    limit: int = Query(20, ge=1, le=100),
) -> GitLogResponse:
    """Get git commit log."""
    try:
        entries = await services.gitops.get_log(limit=limit)
    except Exception:
        entries = []

    return GitLogResponse(
        entries=[
            GitLogEntry(
                hash=e.get("hash", ""),
                short_hash=e.get("short_hash", e.get("hash", "")[:7]),
                author=e.get("author", "Unknown"),
                author_email=e.get("author_email", ""),
                date=e.get("date"),
                message=e.get("message", ""),
            )
            for e in entries
        ],
        has_more=len(entries) >= limit,
    )


@router.get("/diff/{file_path:path}")
async def get_file_diff(
    file_path: str,
    current_user: ActiveUser,
    services: Annotated[ServiceProvider, Depends(get_services)],
    staged: bool = Query(False, description="Show staged diff"),
) -> dict:
    """Get diff for a specific file."""
    try:
        diff = await services.gitops.get_file_diff(file_path, staged=staged)
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )

    return {"file": file_path, "diff": diff, "staged": staged}
