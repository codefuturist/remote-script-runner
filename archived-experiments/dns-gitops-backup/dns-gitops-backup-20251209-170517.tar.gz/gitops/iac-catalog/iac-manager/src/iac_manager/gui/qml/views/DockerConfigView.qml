// DockerConfigView.qml - Modern Docker deployment configuration view
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "../components"
import "../theme"

Item {
    id: root
    
    property var backend: null
    
    SplitView {
        anchors.fill: parent
        orientation: Qt.Horizontal
        
        // Left side: Configuration options
        Rectangle {
            SplitView.preferredWidth: parent.width * 0.4
            SplitView.minimumWidth: 300
            color: Theme.backgroundColor
            
            ScrollView {
                anchors.fill: parent
                anchors.margins: Theme.spacingMedium
                clip: true
                
                ColumnLayout {
                    width: parent.width - Theme.spacingMedium * 2
                    spacing: Theme.spacingMedium
                    
                    // Header
                    Label {
                        text: "Docker Configuration"
                        font.pixelSize: Theme.fontSizeH3
                        font.weight: Theme.fontWeightBold
                        color: Theme.textPrimary
                    }
                    
                    Label {
                        text: "Configure your Docker deployment options"
                        font.pixelSize: Theme.fontSizeNormal
                        color: Theme.textSecondary
                        wrapMode: Text.WordWrap
                        Layout.fillWidth: true
                    }
                    
                    // Deployment Mode Card
                    Card {
                        Layout.fillWidth: true
                        
                        ColumnLayout {
                            anchors.fill: parent
                            spacing: Theme.spacing2
                            
                            Label {
                                text: "Deployment Mode"
                                font.pixelSize: Theme.fontSizeH5
                                font.weight: Theme.fontWeightMedium
                                color: Theme.textPrimary
                            }
                            
                            ComboBox {
                                id: deploymentMode
                                Layout.fillWidth: true
                                model: ["Docker Standalone", "Docker Swarm"]
                                
                                background: Rectangle {
                                    color: Theme.surfaceColor
                                    border.color: Theme.borderColor
                                    border.width: 1
                                    radius: Theme.radiusNormal
                                }
                                
                                onCurrentIndexChanged: {
                                    if (backend && backend.dockerConfig) {
                                        backend.dockerConfig.deploymentMode = 
                                            currentIndex === 0 ? "standalone" : "swarm"
                                    }
                                }
                            }
                            
                            Label {
                                text: "Choose 'Standalone' for single-host Docker or 'Swarm' for multi-host clusters"
                                font.pixelSize: Theme.fontSizeSmall
                                color: Theme.textSecondary
                                wrapMode: Text.WordWrap
                                Layout.fillWidth: true
                            }
                        }
                    }
                    
                    // Ingress Card
                    Card {
                        Layout.fillWidth: true
                        
                        ColumnLayout {
                            anchors.fill: parent
                            spacing: Theme.spacing2
                            
                            Label {
                                text: "Ingress / Reverse Proxy"
                                font.pixelSize: Theme.fontSizeH5
                                font.weight: Theme.fontWeightMedium
                                color: Theme.textPrimary
                            }
                            
                            CheckBox {
                                id: ingressEnabled
                                text: "Enable Ingress"
                                
                                onCheckedChanged: {
                                    if (backend && backend.dockerConfig) {
                                        backend.dockerConfig.ingressEnabled = checked
                                    }
                                }
                            }
                            
                            ComboBox {
                                id: ingressType
                                Layout.fillWidth: true
                                model: ["Traefik"]
                                enabled: ingressEnabled.checked
                                
                                background: Rectangle {
                                    color: enabled ? Theme.surfaceColor : Theme.disabledColor
                                    border.color: Theme.borderColor
                                    border.width: 1
                                    radius: Theme.radiusNormal
                                }
                            }
                            
                            RowLayout {
                                Layout.fillWidth: true
                                spacing: Theme.spacing2
                                
                                Label {
                                    text: "Rule:"
                                    color: ingressEnabled.checked ? Theme.textPrimary : Theme.textSecondary
                                }
                                
                                TextField {
                                    id: traefikRule
                                    Layout.fillWidth: true
                                    text: "Host(`app.local`)"
                                    enabled: ingressEnabled.checked
                                    
                                    background: Rectangle {
                                        color: enabled ? Theme.surfaceColor : Theme.disabledColor
                                        border.color: Theme.borderColor
                                        border.width: 1
                                        radius: Theme.radiusNormal
                                    }
                                }
                            }
                            
                            CheckBox {
                                id: sslEnabled
                                text: "Enable SSL/TLS"
                                enabled: ingressEnabled.checked
                            }
                            
                            Label {
                                text: "Traefik provides reverse proxy with automatic SSL via Let's Encrypt"
                                font.pixelSize: Theme.fontSizeSmall
                                color: Theme.textSecondary
                                wrapMode: Text.WordWrap
                                Layout.fillWidth: true
                            }
                        }
                    }
                    
                    // Secrets Card
                    Card {
                        Layout.fillWidth: true
                        
                        ColumnLayout {
                            anchors.fill: parent
                            spacing: Theme.spacing2
                            
                            Label {
                                text: "Secrets Management"
                                font.pixelSize: Theme.fontSizeH5
                                font.weight: Theme.fontWeightMedium
                                color: Theme.textPrimary
                            }
                            
                            ComboBox {
                                id: secretType
                                Layout.fillWidth: true
                                model: [
                                    "Environment Variables (.env)",
                                    "File-based Secrets",
                                    "Docker Secrets (Swarm only)"
                                ]
                                
                                background: Rectangle {
                                    color: Theme.surfaceColor
                                    border.color: Theme.borderColor
                                    border.width: 1
                                    radius: Theme.radiusNormal
                                }
                                
                                onCurrentIndexChanged: {
                                    if (backend && backend.dockerConfig) {
                                        var types = ["env", "file", "docker-secret"]
                                        backend.dockerConfig.secretType = types[currentIndex]
                                    }
                                }
                            }
                            
                            Label {
                                text: "Choose how sensitive data (passwords, API keys) will be managed"
                                font.pixelSize: Theme.fontSizeSmall
                                color: Theme.textSecondary
                                wrapMode: Text.WordWrap
                                Layout.fillWidth: true
                            }
                        }
                    }
                    
                    // Network Card
                    Card {
                        Layout.fillWidth: true
                        
                        ColumnLayout {
                            anchors.fill: parent
                            spacing: Theme.spacing2
                            
                            Label {
                                text: "Network Configuration"
                                font.pixelSize: Theme.fontSizeH5
                                font.weight: Theme.fontWeightMedium
                                color: Theme.textPrimary
                            }
                            
                            ComboBox {
                                id: networkType
                                Layout.fillWidth: true
                                model: ["Bridge (default)", "Overlay (Swarm)", "Host"]
                                
                                background: Rectangle {
                                    color: Theme.surfaceColor
                                    border.color: Theme.borderColor
                                    border.width: 1
                                    radius: Theme.radiusNormal
                                }
                                
                                onCurrentIndexChanged: {
                                    if (backend && backend.dockerConfig) {
                                        var types = ["bridge", "overlay", "host"]
                                        backend.dockerConfig.networkType = types[currentIndex]
                                    }
                                }
                            }
                            
                            CheckBox {
                                id: networkExternal
                                text: "Use External Network"
                                
                                onCheckedChanged: {
                                    if (backend && backend.dockerConfig) {
                                        backend.dockerConfig.networkExternal = checked
                                    }
                                }
                            }
                            
                            CheckBox {
                                id: networkInternal
                                text: "Internal Only (no external access)"
                                
                                onCheckedChanged: {
                                    if (backend && backend.dockerConfig) {
                                        backend.dockerConfig.networkInternal = checked
                                    }
                                }
                            }
                            
                            Label {
                                text: "Bridge for single host, Overlay for multi-host Swarm clusters"
                                font.pixelSize: Theme.fontSizeSmall
                                color: Theme.textSecondary
                                wrapMode: Text.WordWrap
                                Layout.fillWidth: true
                            }
                        }
                    }
                    
                    // Database Card
                    Card {
                        Layout.fillWidth: true
                        
                        ColumnLayout {
                            anchors.fill: parent
                            spacing: Theme.spacing2
                            
                            Label {
                                text: "Database Configuration"
                                font.pixelSize: Theme.fontSizeH5
                                font.weight: Theme.fontWeightMedium
                                color: Theme.textPrimary
                            }
                            
                            ComboBox {
                                id: dbStrategy
                                Layout.fillWidth: true
                                model: ["Internal Container", "External Database"]
                                
                                background: Rectangle {
                                    color: Theme.surfaceColor
                                    border.color: Theme.borderColor
                                    border.width: 1
                                    radius: Theme.radiusNormal
                                }
                                
                                onCurrentIndexChanged: {
                                    if (backend && backend.dockerConfig) {
                                        backend.dockerConfig.databaseStrategy = 
                                            currentIndex === 0 ? "internal" : "external"
                                    }
                                }
                            }
                            
                            // Internal database options
                            ColumnLayout {
                                visible: dbStrategy.currentIndex === 0
                                Layout.fillWidth: true
                                spacing: Theme.spacing2
                                
                                RowLayout {
                                    Layout.fillWidth: true
                                    
                                    Label {
                                        text: "Type:"
                                        Layout.preferredWidth: 60
                                    }
                                    
                                    ComboBox {
                                        id: dbType
                                        Layout.fillWidth: true
                                        model: ["mariadb", "postgresql", "mysql", "mongodb"]
                                        
                                        background: Rectangle {
                                            color: Theme.surfaceColor
                                            border.color: Theme.borderColor
                                            border.width: 1
                                            radius: Theme.radiusNormal
                                        }
                                    }
                                }
                                
                                RowLayout {
                                    Layout.fillWidth: true
                                    
                                    Label {
                                        text: "Version:"
                                        Layout.preferredWidth: 60
                                    }
                                    
                                    TextField {
                                        id: dbVersion
                                        Layout.fillWidth: true
                                        text: "10.6"
                                        
                                        background: Rectangle {
                                            color: Theme.surfaceColor
                                            border.color: Theme.borderColor
                                            border.width: 1
                                            radius: Theme.radiusNormal
                                        }
                                    }
                                }
                            }
                            
                            // External database options
                            ColumnLayout {
                                visible: dbStrategy.currentIndex === 1
                                Layout.fillWidth: true
                                spacing: Theme.spacing2
                                
                                RowLayout {
                                    Layout.fillWidth: true
                                    
                                    Label {
                                        text: "Host:"
                                        Layout.preferredWidth: 60
                                    }
                                    
                                    TextField {
                                        id: dbHost
                                        Layout.fillWidth: true
                                        placeholderText: "db.example.com"
                                        
                                        background: Rectangle {
                                            color: Theme.surfaceColor
                                            border.color: Theme.borderColor
                                            border.width: 1
                                            radius: Theme.radiusNormal
                                        }
                                    }
                                }
                                
                                RowLayout {
                                    Layout.fillWidth: true
                                    
                                    Label {
                                        text: "Port:"
                                        Layout.preferredWidth: 60
                                    }
                                    
                                    SpinBox {
                                        id: dbPort
                                        Layout.fillWidth: true
                                        from: 1
                                        to: 65535
                                        value: 3306
                                        editable: true
                                    }
                                }
                            }
                            
                            Label {
                                text: "Internal: database runs in a container. External: connect to existing database"
                                font.pixelSize: Theme.fontSizeSmall
                                color: Theme.textSecondary
                                wrapMode: Text.WordWrap
                                Layout.fillWidth: true
                            }
                        }
                    }
                    
                    // Add stretch at the end
                    Item {
                        Layout.fillHeight: true
                    }
                }
            }
        }
        
        // Right side: Live editable preview
        Rectangle {
            SplitView.fillWidth: true
            color: Theme.surfaceColor
            
            ColumnLayout {
                anchors.fill: parent
                anchors.margins: Theme.spacingMedium
                spacing: Theme.spacingMedium
                
                // Header
                RowLayout {
                    Layout.fillWidth: true
                    
                    Label {
                        text: "Preview: docker-compose.yml"
                        font.pixelSize: Theme.fontSizeH4
                        font.weight: Theme.fontWeightBold
                        color: Theme.textPrimary
                    }
                    
                    Item { Layout.fillWidth: true }
                    
                    CustomButton {
                        text: "Regenerate"
                        iconName: "refresh"
                        buttonType: "outlined"
                        size: "small"
                        onClicked: {
                            if (backend) backend.regeneratePreview()
                        }
                    }
                }
                
                Label {
                    text: "This preview updates automatically. You can edit it directly before deployment."
                    font.pixelSize: Theme.fontSizeSmall
                    color: Theme.textSecondary
                    wrapMode: Text.WordWrap
                    Layout.fillWidth: true
                }
                
                // Preview editor with styling
                Rectangle {
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    color: "#1e1e1e"
                    border.color: Theme.borderColor
                    border.width: 1
                    radius: Theme.radiusNormal
                    
                    ScrollView {
                        anchors.fill: parent
                        anchors.margins: Theme.spacing2
                        clip: true
                        
                        TextArea {
                            id: previewEditor
                            readOnly: false
                            wrapMode: TextEdit.NoWrap
                            font.family: "Monaco, Courier New, monospace"
                            font.pixelSize: 12
                            color: "#d4d4d4"
                            selectionColor: "#264f78"
                            selectedTextColor: "#ffffff"
                            
                            background: Rectangle {
                                color: "transparent"
                            }
                            
                            Connections {
                                target: backend
                                function onPreviewGenerated(yaml) {
                                    previewEditor.text = yaml
                                }
                            }
                        }
                    }
                }
                
                // Action buttons
                RowLayout {
                    Layout.fillWidth: true
                    spacing: Theme.spacing2
                    
                    Label {
                        text: previewEditor.text.split('\n').length + " lines"
                        font.pixelSize: Theme.fontSizeSmall
                        color: Theme.textSecondary
                    }
                    
                    Item { Layout.fillWidth: true }
                    
                    CustomButton {
                        text: "Validate"
                        iconName: "check"
                        buttonType: "outlined"
                        size: "medium"
                        onClicked: {
                            if (backend) {
                                var isValid = backend.validateConfig()
                                // Show validation result
                            }
                        }
                    }
                    
                    CustomButton {
                        text: "Apply Configuration"
                        iconName: "save"
                        buttonType: "primary"
                        size: "medium"
                        onClicked: {
                            if (backend) {
                                backend.applyCustomPreview(previewEditor.text)
                                // Proceed to next step or deploy
                            }
                        }
                    }
                }
            }
        }
    }
    
    Component.onCompleted: {
        if (backend) {
            backend.regeneratePreview()
        }
    }
}
