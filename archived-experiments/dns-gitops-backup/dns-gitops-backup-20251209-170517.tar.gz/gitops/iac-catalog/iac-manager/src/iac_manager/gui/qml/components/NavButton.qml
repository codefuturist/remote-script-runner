// NavButton.qml - Navigation button component
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "../theme"

Rectangle {
    id: navBtn
    
    property string icon: ""
    property string label: ""
    property bool collapsed: false
    property bool active: false
    
    signal clicked()
    
    Layout.preferredHeight: 44
    Layout.fillWidth: true
    
    radius: Theme.radiusNormal
    color: {
        if (navBtn.active) return Theme.primary
        if (mouseArea.containsMouse) return Theme.alpha(Theme.primary, 0.08)
        return "transparent"
    }
    
    Behavior on color {
        ColorAnimation { duration: Theme.animationDurationFast }
    }
    
    Row {
        spacing: Theme.spacing3
        anchors.fill: parent
        anchors.leftMargin: Theme.spacing3
        anchors.rightMargin: Theme.spacing3
        
        Text {
            text: navBtn.icon
            font.pixelSize: Theme.iconSize
            color: navBtn.active ? "white" : Theme.textPrimary
            anchors.verticalCenter: parent.verticalCenter
            width: Theme.iconSizeLarge
            horizontalAlignment: Text.AlignHCenter
            
            Behavior on color {
                ColorAnimation { duration: Theme.animationDurationFast }
            }
        }
        
        Label {
            visible: !navBtn.collapsed
            text: navBtn.label
            font.pixelSize: Theme.fontSizeNormal
            font.weight: navBtn.active ? Theme.fontWeightSemiBold : Theme.fontWeightMedium
            color: navBtn.active ? "white" : Theme.textPrimary
            anchors.verticalCenter: parent.verticalCenter
            
            Behavior on color {
                ColorAnimation { duration: Theme.animationDurationFast }
            }
        }
    }
    
    MouseArea {
        id: mouseArea
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        onClicked: navBtn.clicked()
    }
    
    scale: mouseArea.pressed ? 0.96 : 1.0
    Behavior on scale {
        NumberAnimation { 
            duration: Theme.animationDurationFast
            easing.type: Easing.OutCubic
        }
    }
}
