"""Inventory schemas."""

from typing import Any

from pydantic import Field

from iac_manager.web.schemas.common import BaseSchema, PaginatedResponse


class HostCreate(BaseSchema):
    """Request to create a new host."""

    name: str = Field(min_length=1, max_length=253, pattern=r"^[a-zA-Z0-9][a-zA-Z0-9._-]*$")
    ansible_host: str = Field(min_length=1, description="IP address or hostname")
    ansible_user: str | None = None
    ansible_port: int = Field(default=22, ge=1, le=65535)
    labels: dict[str, str] = Field(default_factory=dict)
    groups: list[str] = Field(default_factory=list)
    extra_vars: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional Ansible variables for this host",
    )


class HostUpdate(BaseSchema):
    """Request to update a host."""

    ansible_host: str | None = None
    ansible_user: str | None = None
    ansible_port: int | None = Field(None, ge=1, le=65535)
    labels: dict[str, str] | None = None
    groups: list[str] | None = None
    extra_vars: dict[str, Any] | None = None


class HostResponse(BaseSchema):
    """Host information response."""

    name: str
    ansible_host: str
    ansible_user: str | None = None
    ansible_port: int = 22
    labels: dict[str, str]
    groups: list[str]

    @classmethod
    def from_domain(cls, host) -> "HostResponse":
        """Create response from domain model."""
        return cls(
            name=host.name,
            ansible_host=host.ansible_host,
            ansible_user=host.ansible_user,
            ansible_port=host.ansible_port,
            labels=host.labels,
            groups=host.groups,
        )


class HostList(PaginatedResponse[HostResponse]):
    """Paginated list of hosts."""

    pass


class GroupCreate(BaseSchema):
    """Request to create a new group."""

    name: str = Field(min_length=1, max_length=253, pattern=r"^[a-zA-Z][a-zA-Z0-9_-]*$")
    hosts: list[str] = Field(default_factory=list)
    vars: dict[str, Any] = Field(
        default_factory=dict,
        description="Group variables",
    )
    children: list[str] = Field(
        default_factory=list,
        description="Child groups",
    )


class GroupUpdate(BaseSchema):
    """Request to update a group."""

    hosts: list[str] | None = None
    vars: dict[str, Any] | None = None
    children: list[str] | None = None


class GroupResponse(BaseSchema):
    """Group information response."""

    name: str
    hosts: list[str]
    vars: dict[str, Any]
    children: list[str]

    @classmethod
    def from_domain(cls, group) -> "GroupResponse":
        """Create response from domain model."""
        return cls(
            name=group.name,
            hosts=group.hosts,
            vars=group.vars,
            children=group.children,
        )


class GroupList(PaginatedResponse[GroupResponse]):
    """Paginated list of groups."""

    pass


class InventorySummary(BaseSchema):
    """Summary of the inventory."""

    total_hosts: int
    total_groups: int
    hosts_by_group: dict[str, int]
