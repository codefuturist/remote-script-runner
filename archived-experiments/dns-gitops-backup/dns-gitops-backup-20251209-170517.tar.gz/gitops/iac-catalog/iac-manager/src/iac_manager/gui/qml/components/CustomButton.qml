// CustomButton.qml - Enhanced reusable custom button component
import QtQuick
import QtQuick.Controls
import "../theme"

Button {
    id: control
    
    property string buttonType: "primary" // primary, secondary, success, danger, outlined, ghost
    property string size: "medium" // small, medium, large
    property string iconName: ""
    property int iconSize: Theme.iconSize
    property bool loading: false
    property bool iconOnly: false
    
    implicitWidth: iconOnly ? implicitHeight : Math.max(getMinWidth(), contentItem.implicitWidth + leftPadding + rightPadding)
    implicitHeight: getHeight()
    
    padding: getPadding()
    leftPadding: padding
    rightPadding: padding
    topPadding: padding / 2
    bottomPadding: padding / 2
    
    enabled: !loading
    
    background: Rectangle {
        implicitWidth: getMinWidth()
        implicitHeight: getHeight()
        radius: Theme.radiusNormal
        color: getBackgroundColor()
        border.width: buttonType === "outlined" ? 2 : 0
        border.color: getBorderColor()
        
        // Shadow for elevated buttons
        Shadow {
            anchors.fill: parent
            elevation: (buttonType === "primary" || buttonType === "success" || buttonType === "danger") ? (control.pressed ? 1 : 2) : 0
            shadowRadius: parent.radius
        }
        
        // Smooth color transitions
        Behavior on color {
            ColorAnimation { duration: Theme.animationDurationFast }
        }
        
        Behavior on border.color {
            ColorAnimation { duration: Theme.animationDurationFast }
        }
        
        // Ripple effect
        Rectangle {
            id: ripple
            anchors.centerIn: parent
            width: 0
            height: width
            radius: width / 2
            color: Theme.alpha(Theme.surfaceColor, 0.3)
            opacity: 0
            
            ParallelAnimation {
                id: rippleAnimation
                NumberAnimation {
                    target: ripple
                    property: "width"
                    from: 0
                    to: Math.max(control.width, control.height) * 2.5
                    duration: 600
                    easing.type: Easing.OutCubic
                }
                NumberAnimation {
                    target: ripple
                    property: "opacity"
                    from: 0.8
                    to: 0
                    duration: 600
                    easing.type: Easing.OutCubic
                }
            }
        }
    }
    
    contentItem: Item {
        implicitWidth: rowLayout.implicitWidth
        implicitHeight: rowLayout.implicitHeight
        
        Row {
            id: rowLayout
            anchors.centerIn: parent
            spacing: Theme.spacing2
            
            // Icon
            Text {
                visible: iconName !== "" && !loading
                text: getIconCode()
                font.pixelSize: iconSize
                color: getContentColor()
                verticalAlignment: Text.AlignVCenter
                horizontalAlignment: Text.AlignHCenter
            }
            
            // Loading spinner
            Item {
                visible: loading
                width: iconSize
                height: iconSize
                
                Rectangle {
                    id: spinner
                    anchors.centerIn: parent
                    width: iconSize * 0.8
                    height: width
                    radius: width / 2
                    color: "transparent"
                    border.width: 2
                    border.color: getContentColor()
                    
                    Rectangle {
                        anchors.top: parent.top
                        anchors.horizontalCenter: parent.horizontalCenter
                        width: parent.border.width
                        height: parent.height / 3
                        color: getContentColor()
                    }
                    
                    RotationAnimation {
                        target: spinner
                        from: 0
                        to: 360
                        duration: 1000
                        loops: Animation.Infinite
                        running: loading
                    }
                }
            }
            
            // Text
            Text {
                visible: !iconOnly
                text: control.text
                font.pixelSize: getFontSize()
                font.weight: Theme.fontWeightSemiBold
                color: getContentColor()
                horizontalAlignment: Text.AlignHCenter
                verticalAlignment: Text.AlignVCenter
                elide: Text.ElideRight
            }
        }
    }
    
    // Press animation
    scale: down ? 0.96 : 1.0
    Behavior on scale {
        NumberAnimation { 
            duration: Theme.animationDurationFast
            easing.type: Easing.OutCubic
        }
    }
    
    // Trigger ripple on click
    onPressed: {
        rippleAnimation.restart()
    }
    
    // Hover effect
    hoverEnabled: true
    
    // Helper functions
    function getHeight() {
        switch(size) {
            case "small": return Theme.buttonHeightSmall
            case "large": return Theme.buttonHeightLarge
            default: return Theme.buttonHeight
        }
    }
    
    function getMinWidth() {
        if (iconOnly) return getHeight()
        switch(size) {
            case "small": return 80
            case "large": return 120
            default: return 100
        }
    }
    
    function getPadding() {
        switch(size) {
            case "small": return Theme.spacing3
            case "large": return Theme.spacing5
            default: return Theme.spacing4
        }
    }
    
    function getFontSize() {
        switch(size) {
            case "small": return Theme.fontSizeSmall
            case "large": return Theme.fontSizeMedium
            default: return Theme.fontSizeNormal
        }
    }
    
    function getBaseColor() {
        switch (buttonType) {
            case "primary": return Theme.primary
            case "secondary": return Theme.success
            case "success": return Theme.success
            case "danger": return Theme.error
            case "outlined": return "transparent"
            case "ghost": return "transparent"
            default: return Theme.primary
        }
    }
    
    function getBackgroundColor() {
        if (!control.enabled) {
            return buttonType === "outlined" || buttonType === "ghost" 
                ? Theme.gray100
                : Theme.gray200
        }
        
        var baseColor = getBaseColor()
        
        if (control.down) {
            return buttonType === "outlined" || buttonType === "ghost"
                ? Theme.alpha(baseColor, 0.16)
                : Theme.darken(baseColor, 0.2)
        }
        
        if (control.hovered) {
            return buttonType === "outlined" || buttonType === "ghost"
                ? Theme.alpha(baseColor, 0.08)
                : Theme.lighten(baseColor, 0.1)
        }
        
        return baseColor
    }
    
    function getBorderColor() {
        if (buttonType !== "outlined") return "transparent"
        if (!control.enabled) return Theme.gray400
        
        var baseColor = getBaseColor()
        switch (buttonType.replace("outlined-", "")) {
            case "primary": return Theme.primary
            case "secondary": return Theme.success
            case "success": return Theme.success
            case "danger": return Theme.error
            default: return Theme.primary
        }
    }
    
    function getContentColor() {
        if (!control.enabled) {
            return Theme.gray500
        }
        
        if (buttonType === "outlined" || buttonType === "ghost") {
            switch (buttonType.replace("outlined-", "").replace("ghost-", "")) {
                case "primary": return Theme.primary
                case "secondary": return Theme.success
                case "success": return Theme.success
                case "danger": return Theme.error
                default: return Theme.primary
            }
        }
        
        return "white"
    }
    
    function getIconCode() {
        // Common icon mappings
        switch(iconName) {
            case "refresh": return "↻"
            case "add": return "+"
            case "remove": return "−"
            case "search": return "🔍"
            case "filter": return "⊕"
            case "save": return "💾"
            case "delete": return "🗑"
            case "edit": return "✎"
            case "check": return "✓"
            case "close": return "✕"
            case "settings": return "⚙"
            case "deploy": return "🚀"
            case "rocket": return "🚀"
            case "cloud": return "☁"
            case "download": return "⬇"
            case "upload": return "⬆"
            default: return iconName
        }
    }
}

