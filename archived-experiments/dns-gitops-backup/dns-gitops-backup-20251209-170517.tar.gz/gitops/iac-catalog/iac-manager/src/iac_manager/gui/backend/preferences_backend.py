"""PyQt6 backend for preference management."""

from pathlib import Path
from typing import Dict, List, Optional

from PyQt6.QtCore import QObject, pyqtSignal, pyqtSlot

from iac_manager.models import PreferenceApplicationResult, PreferenceProfile
from iac_manager.services.preference_service import PreferenceService
from iac_manager.utils.helm_utils import HelmChartValuesFetcher


class PreferencesBackend(QObject):
    """Qt backend for preference management."""

    # Signals
    profilesLoaded = pyqtSignal(list)  # List of profile names
    profileLoaded = pyqtSignal(dict)  # Profile info
    preferencesApplied = pyqtSignal(dict)  # Application result
    errorOccurred = pyqtSignal(str)  # Error message
    chartSearchCompleted = pyqtSignal(list)  # Chart search results
    chartDownloadCompleted = pyqtSignal(str)  # Downloaded values.yaml path

    def __init__(self, preferences_dir: Path):
        """Initialize preferences backend.

        Args:
            preferences_dir: Directory containing preference profiles
        """
        super().__init__()
        self.preferences_dir = preferences_dir
        self.service = PreferenceService(preferences_dir)
        self.helm_fetcher = HelmChartValuesFetcher()
        self._current_profile: Optional[PreferenceProfile] = None

    @pyqtSlot()
    def loadProfiles(self) -> None:
        """Load and emit list of available profiles."""
        try:
            profiles = self.service.list_profiles()
            self.profilesLoaded.emit(profiles)
        except Exception as e:
            self.errorOccurred.emit(f"Failed to load profiles: {e}")

    @pyqtSlot(str)
    def loadProfile(self, profile_name: str) -> None:
        """Load a specific profile and emit its info.

        Args:
            profile_name: Name of profile to load
        """
        try:
            self._current_profile = self.service.load_profile(profile_name)
            info = self.service.get_profile_info(profile_name)
            self.profileLoaded.emit(info)
        except Exception as e:
            self.errorOccurred.emit(f"Failed to load profile {profile_name}: {e}")

    @pyqtSlot(str, str, str, str, bool, bool)
    def applyPreferences(
        self,
        file_path: str,
        profile_name: str,
        environment: str = "",
        resource_type: str = "",
        dry_run: bool = False,
        create_backup: bool = True,
    ) -> None:
        """Apply preferences to a YAML file.

        Args:
            file_path: Path to YAML file
            profile_name: Name of profile to apply
            environment: Environment name (optional)
            resource_type: Resource type (optional)
            dry_run: Preview mode
            create_backup: Create backup before modifying
        """
        try:
            profile = self.service.load_profile(profile_name)
            result = self.service.apply_preferences(
                file_path=Path(file_path),
                profile=profile,
                environment=environment if environment else None,
                resource_type=resource_type if resource_type else None,
                dry_run=dry_run,
                create_backup=create_backup,
            )

            # Convert result to dict for Qt signal
            result_dict = {
                "file_path": str(result.file_path),
                "success": result.success,
                "backup_created": str(result.backup_created) if result.backup_created else None,
                "rules_applied": result.rules_applied,
                "rules_skipped": result.rules_skipped,
                "errors": result.errors,
                "changes": {k: str(v) for k, v in result.changes.items()},
            }

            self.preferencesApplied.emit(result_dict)

        except Exception as e:
            self.errorOccurred.emit(f"Failed to apply preferences: {e}")

    @pyqtSlot(str, result=list)
    def getProfileInfo(self, profile_name: str) -> List[Dict]:
        """Get detailed information about a profile.

        Args:
            profile_name: Name of profile

        Returns:
            List of rule dictionaries
        """
        try:
            profile = self.service.load_profile(profile_name)
            rules = []

            # Add global preferences
            for rule in profile.global_preferences:
                rules.append(
                    {
                        "category": "Global",
                        "path": rule.path,
                        "value": str(rule.value),
                        "strategy": rule.merge_strategy.value,
                        "description": rule.description or "",
                    }
                )

            # Add environment preferences
            for env, env_rules in profile.environment_preferences.items():
                for rule in env_rules:
                    rules.append(
                        {
                            "category": f"Environment: {env}",
                            "path": rule.path,
                            "value": str(rule.value),
                            "strategy": rule.merge_strategy.value,
                            "description": rule.description or "",
                        }
                    )

            # Add resource type preferences
            for rt, rt_rules in profile.resource_type_preferences.items():
                for rule in rt_rules:
                    rules.append(
                        {
                            "category": f"Resource: {rt}",
                            "path": rule.path,
                            "value": str(rule.value),
                            "strategy": rule.merge_strategy.value,
                            "description": rule.description or "",
                        }
                    )

            return rules

        except Exception as e:
            self.errorOccurred.emit(f"Failed to get profile info: {e}")
            return []

    @pyqtSlot(str, str, result=list)
    def previewChanges(self, file_path: str, profile_name: str) -> List[Dict]:
        """Preview what changes would be made to a file.

        Args:
            file_path: Path to YAML file
            profile_name: Name of profile to apply

        Returns:
            List of change dictionaries
        """
        try:
            profile = self.service.load_profile(profile_name)
            result = self.service.apply_preferences(
                file_path=Path(file_path),
                profile=profile,
                dry_run=True,
                create_backup=False,
            )

            changes = []
            for path, value in result.changes.items():
                changes.append({"path": path, "value": str(value)})

            return changes

        except Exception as e:
            self.errorOccurred.emit(f"Failed to preview changes: {e}")
            return []

    @pyqtSlot(list, str, str, str)
    def batchApplyPreferences(
        self,
        file_paths: List[str],
        profile_name: str,
        environment: str = "",
        resource_type: str = "",
    ) -> None:
        """Apply preferences to multiple files.

        Args:
            file_paths: List of file paths
            profile_name: Name of profile to apply
            environment: Environment name (optional)
            resource_type: Resource type (optional)
        """
        try:
            profile = self.service.load_profile(profile_name)
            results = []

            for file_path in file_paths:
                result = self.service.apply_preferences(
                    file_path=Path(file_path),
                    profile=profile,
                    environment=environment if environment else None,
                    resource_type=resource_type if resource_type else None,
                    dry_run=False,
                    create_backup=True,
                )

                results.append(
                    {
                        "file_path": str(result.file_path),
                        "success": result.success,
                        "rules_applied": result.rules_applied,
                        "errors": result.errors,
                    }
                )

            # Emit overall results
            self.preferencesApplied.emit({"batch_results": results})

        except Exception as e:
            self.errorOccurred.emit(f"Failed to batch apply preferences: {e}")

    @pyqtSlot(str)
    def searchHelmCharts(self, keyword: str) -> None:
        """Search for Helm charts by keyword.

        Args:
            keyword: Search keyword (e.g., 'postgresql', 'nginx')
        """
        try:
            results = self.helm_fetcher.search_charts(keyword)
            
            # Convert to serializable format for QML
            chart_list = [
                {
                    "name": chart["name"],
                    "version": chart["version"],
                    "description": chart["description"],
                    "repo": chart.get("repo", ""),
                }
                for chart in results
            ]
            
            self.chartSearchCompleted.emit(chart_list)
            
        except Exception as e:
            self.errorOccurred.emit(f"Failed to search charts: {e}")

    @pyqtSlot(str, str, str, str, bool)
    def fetchChartValues(
        self,
        chart_name: str,
        output_path: str,
        repo: str = "",
        version: str = "",
        use_oci: bool = False,
    ) -> None:
        """Fetch default values.yaml from a Helm chart.

        Args:
            chart_name: Name of the chart (e.g., 'bitnami/postgresql')
            output_path: Where to save the values.yaml file
            repo: Repository URL (optional)
            version: Chart version (optional)
            use_oci: Whether to use OCI registry format
        """
        try:
            output_file = Path(output_path)
            
            if use_oci:
                # Both methods return (dict, Path)
                values_dict, saved_path = self.helm_fetcher.fetch_from_oci(
                    oci_url=chart_name,
                    version=version or None,
                    save_path=output_file,
                )
            else:
                values_dict, saved_path = self.helm_fetcher.fetch_chart_values(
                    chart=chart_name,
                    repo=repo or None,
                    version=version or None,
                    save_path=output_file,
                )
            
            self.chartDownloadCompleted.emit(str(saved_path))
            
        except Exception as e:
            self.errorOccurred.emit(f"Failed to fetch chart values: {e}")
