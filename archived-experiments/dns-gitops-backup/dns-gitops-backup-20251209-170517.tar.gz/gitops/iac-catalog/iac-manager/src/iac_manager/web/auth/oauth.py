"""OAuth authentication handlers for GitHub and GitLab."""

from dataclasses import dataclass
from typing import Any

import httpx

from iac_manager.web.config import get_settings


@dataclass
class OAuthUser:
    """Normalized OAuth user data."""

    provider: str
    oauth_id: str
    email: str
    username: str
    full_name: str | None
    avatar_url: str | None


class GitHubOAuth:
    """GitHub OAuth handler."""

    AUTHORIZE_URL = "https://github.com/login/oauth/authorize"
    TOKEN_URL = "https://github.com/login/oauth/access_token"
    API_URL = "https://api.github.com"

    def __init__(self):
        settings = get_settings()
        self.client_id = settings.github_client_id
        self.client_secret = settings.github_client_secret

    def get_authorize_url(self, state: str, redirect_uri: str) -> str:
        """Get the GitHub authorization URL."""
        params = {
            "client_id": self.client_id,
            "redirect_uri": redirect_uri,
            "scope": "user:email",
            "state": state,
        }
        query = "&".join(f"{k}={v}" for k, v in params.items())
        return f"{self.AUTHORIZE_URL}?{query}"

    async def exchange_code(self, code: str, redirect_uri: str) -> str:
        """Exchange authorization code for access token."""
        async with httpx.AsyncClient() as client:
            response = await client.post(
                self.TOKEN_URL,
                data={
                    "client_id": self.client_id,
                    "client_secret": self.client_secret,
                    "code": code,
                    "redirect_uri": redirect_uri,
                },
                headers={"Accept": "application/json"},
            )
            response.raise_for_status()
            data = response.json()
            return data["access_token"]

    async def get_user(self, access_token: str) -> OAuthUser:
        """Get user information from GitHub."""
        async with httpx.AsyncClient() as client:
            # Get user profile
            response = await client.get(
                f"{self.API_URL}/user",
                headers={
                    "Authorization": f"Bearer {access_token}",
                    "Accept": "application/vnd.github.v3+json",
                },
            )
            response.raise_for_status()
            user_data = response.json()

            # Get primary email if not public
            email = user_data.get("email")
            if not email:
                email_response = await client.get(
                    f"{self.API_URL}/user/emails",
                    headers={
                        "Authorization": f"Bearer {access_token}",
                        "Accept": "application/vnd.github.v3+json",
                    },
                )
                email_response.raise_for_status()
                emails = email_response.json()
                primary = next((e for e in emails if e.get("primary")), emails[0])
                email = primary["email"]

            return OAuthUser(
                provider="github",
                oauth_id=str(user_data["id"]),
                email=email,
                username=user_data["login"],
                full_name=user_data.get("name"),
                avatar_url=user_data.get("avatar_url"),
            )


class GitLabOAuth:
    """GitLab OAuth handler."""

    def __init__(self):
        settings = get_settings()
        self.client_id = settings.gitlab_client_id
        self.client_secret = settings.gitlab_client_secret
        self.base_url = settings.gitlab_url.rstrip("/")

    @property
    def authorize_url(self) -> str:
        return f"{self.base_url}/oauth/authorize"

    @property
    def token_url(self) -> str:
        return f"{self.base_url}/oauth/token"

    @property
    def api_url(self) -> str:
        return f"{self.base_url}/api/v4"

    def get_authorize_url(self, state: str, redirect_uri: str) -> str:
        """Get the GitLab authorization URL."""
        params = {
            "client_id": self.client_id,
            "redirect_uri": redirect_uri,
            "response_type": "code",
            "scope": "read_user",
            "state": state,
        }
        query = "&".join(f"{k}={v}" for k, v in params.items())
        return f"{self.authorize_url}?{query}"

    async def exchange_code(self, code: str, redirect_uri: str) -> str:
        """Exchange authorization code for access token."""
        async with httpx.AsyncClient() as client:
            response = await client.post(
                self.token_url,
                data={
                    "client_id": self.client_id,
                    "client_secret": self.client_secret,
                    "code": code,
                    "redirect_uri": redirect_uri,
                    "grant_type": "authorization_code",
                },
            )
            response.raise_for_status()
            data = response.json()
            return data["access_token"]

    async def get_user(self, access_token: str) -> OAuthUser:
        """Get user information from GitLab."""
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{self.api_url}/user",
                headers={"Authorization": f"Bearer {access_token}"},
            )
            response.raise_for_status()
            user_data = response.json()

            return OAuthUser(
                provider="gitlab",
                oauth_id=str(user_data["id"]),
                email=user_data["email"],
                username=user_data["username"],
                full_name=user_data.get("name"),
                avatar_url=user_data.get("avatar_url"),
            )


def get_oauth_handler(provider: str) -> GitHubOAuth | GitLabOAuth:
    """Get the appropriate OAuth handler for a provider.

    Args:
        provider: OAuth provider name ("github" or "gitlab")

    Returns:
        OAuth handler instance

    Raises:
        ValueError: If provider is not supported or not configured
    """
    settings = get_settings()

    if provider == "github":
        if not settings.github_enabled:
            raise ValueError("GitHub OAuth is not configured")
        return GitHubOAuth()
    elif provider == "gitlab":
        if not settings.gitlab_enabled:
            raise ValueError("GitLab OAuth is not configured")
        return GitLabOAuth()
    else:
        raise ValueError(f"Unsupported OAuth provider: {provider}")
