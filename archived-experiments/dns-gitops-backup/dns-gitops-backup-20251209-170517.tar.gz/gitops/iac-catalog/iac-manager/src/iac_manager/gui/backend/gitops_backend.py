"""GitOps backend for QML."""

from PyQt6.QtCore import QObject, pyqtProperty, pyqtSignal, pyqtSlot, QTimer

from iac_manager.config import Config
from iac_manager.services import GitOpsService
from iac_manager.gui.backend.models import FileListModel


class GitOpsBackend(QObject):
    """Backend bridge for GitOps operations in QML."""

    # Signals
    statusUpdated = pyqtSignal()
    branchChanged = pyqtSignal(str)
    filesChanged = pyqtSignal()
    errorOccurred = pyqtSignal(str)
    operationCompleted = pyqtSignal(str)

    def __init__(self, config: Config, gitops_service: GitOpsService, parent=None):
        """Initialize GitOps backend.

        Args:
            config: Configuration object
            gitops_service: GitOps service instance
            parent: Parent QObject
        """
        super().__init__(parent)
        self._config = config
        self._gitops_service = gitops_service
        self._modified_model = FileListModel(self)
        self._staged_model = FileListModel(self)
        
        self._branch = "unknown"
        self._modified_count = 0
        self._staged_count = 0
        self._status_message = "Ready"

        # Auto-refresh timer (will be started after first refresh)
        self._refresh_timer = QTimer(self)
        self._refresh_timer.timeout.connect(self.refresh)
        self._refresh_timer.setInterval(5000)  # Every 5 seconds
        # Don't start timer here - will be started after first manual refresh

    @pyqtProperty(QObject, constant=True)
    def modifiedModel(self) -> FileListModel:
        """Get modified files model."""
        return self._modified_model

    @pyqtProperty(QObject, constant=True)
    def stagedModel(self) -> FileListModel:
        """Get staged files model."""
        return self._staged_model

    @pyqtProperty(str, notify=branchChanged)
    def branch(self) -> str:
        """Get current git branch."""
        return self._branch

    @pyqtProperty(int, notify=filesChanged)
    def modifiedCount(self) -> int:
        """Get count of modified files."""
        return self._modified_count

    @pyqtProperty(int, notify=filesChanged)
    def stagedCount(self) -> int:
        """Get count of staged files."""
        return self._staged_count

    @pyqtProperty(str, notify=statusUpdated)
    def statusMessage(self) -> str:
        """Get status message."""
        return self._status_message

    @pyqtSlot()
    def refresh(self):
        """Refresh git status."""
        try:
            # Start the timer on first refresh if not already running
            if not self._refresh_timer.isActive():
                self._refresh_timer.start()
            
            status_data = self._gitops_service.get_status()

            # Update branch
            new_branch = status_data.get("branch", "unknown")
            if self._branch != new_branch:
                self._branch = new_branch
                self.branchChanged.emit(new_branch)

            # Update modified files
            modified = status_data.get("modified", [])
            self._modified_model.setFiles(modified)
            self._modified_count = len(modified)

            # Update staged files
            staged = status_data.get("staged", [])
            self._staged_model.setFiles(staged)
            self._staged_count = len(staged)

            # Update status message
            if staged:
                self._status_message = f"✅ {len(staged)} file(s) ready to commit"
            elif modified:
                self._status_message = f"⚠️ {len(modified)} file(s) modified"
            else:
                self._status_message = "✓ Working tree clean"

            self.filesChanged.emit()
            self.statusUpdated.emit()

        except Exception as e:
            self._status_message = f"Error: {str(e)}"
            self.statusUpdated.emit()
            self.errorOccurred.emit(str(e))

    @pyqtSlot(list)
    def stageFiles(self, file_paths: list):
        """Stage selected files.

        Args:
            file_paths: List of file paths to stage
        """
        try:
            from pathlib import Path
            paths = [Path(f) for f in file_paths]
            success = self._gitops_service.add_files(paths)
            
            if success:
                self._status_message = f"✅ Staged {len(file_paths)} file(s)"
                self.statusUpdated.emit()
                self.operationCompleted.emit("Files staged successfully")
                self.refresh()
            else:
                raise Exception("Failed to stage files")

        except Exception as e:
            self.errorOccurred.emit(f"Failed to stage files: {str(e)}")

    @pyqtSlot()
    def stageAll(self):
        """Stage all modified files."""
        files = self._modified_model.getFiles()
        if files:
            self.stageFiles(files)
        else:
            self.errorOccurred.emit("No modified files to stage")

    @pyqtSlot(list)
    def unstageFiles(self, file_paths: list):
        """Unstage selected files.

        Args:
            file_paths: List of file paths to unstage
        """
        try:
            import subprocess
            
            # Use git reset to unstage files
            for file_path in file_paths:
                result = subprocess.run(
                    ["git", "reset", "HEAD", file_path],
                    cwd=str(self._config.repo_root),
                    capture_output=True,
                    text=True
                )
                
                if result.returncode != 0:
                    raise Exception(f"Failed to unstage {file_path}: {result.stderr}")
            
            self._status_message = f"✅ Unstaged {len(file_paths)} file(s)"
            self.statusUpdated.emit()
            self.operationCompleted.emit("Files unstaged successfully")
            self.refresh()

        except Exception as e:
            self.errorOccurred.emit(f"Failed to unstage files: {str(e)}")

    @pyqtSlot()
    def unstageAll(self):
        """Unstage all staged files."""
        files = self._staged_model.getFiles()
        if files:
            self.unstageFiles(files)
        else:
            self.errorOccurred.emit("No staged files to unstage")

    @pyqtSlot(str, result=bool)
    def commit(self, message: str) -> bool:
        """Commit staged changes.

        Args:
            message: Commit message

        Returns:
            True if successful
        """
        if not message.strip():
            self.errorOccurred.emit("Please enter a commit message")
            return False

        if self._staged_count == 0:
            self.errorOccurred.emit("No staged files to commit")
            return False

        try:
            success = self._gitops_service.commit(message)
            
            if success:
                self._status_message = "✅ Changes committed successfully"
                self.statusUpdated.emit()
                self.operationCompleted.emit(f"Successfully committed {self._staged_count} file(s)")
                self.refresh()
                return True
            else:
                raise Exception("Commit failed")

        except Exception as e:
            self.errorOccurred.emit(f"Failed to commit: {str(e)}")
            return False

    @pyqtSlot(str, result=bool)
    def commitAndPush(self, message: str) -> bool:
        """Commit and push changes.

        Args:
            message: Commit message

        Returns:
            True if successful
        """
        if not self.commit(message):
            return False

        try:
            success = self._gitops_service.push()
            
            if success:
                self._status_message = f"✅ Pushed to origin/{self._branch}"
                self.statusUpdated.emit()
                self.operationCompleted.emit(f"Successfully pushed to origin/{self._branch}")
                return True
            else:
                raise Exception("Push failed")

        except Exception as e:
            self.errorOccurred.emit(f"Failed to push: {str(e)}")
            return False

    @pyqtSlot(result=bool)
    def push(self) -> bool:
        """Push commits to remote.

        Returns:
            True if successful
        """
        try:
            success = self._gitops_service.push()
            
            if success:
                self._status_message = f"✅ Pushed to origin/{self._branch}"
                self.statusUpdated.emit()
                self.operationCompleted.emit(f"Successfully pushed to origin/{self._branch}")
                return True
            else:
                raise Exception("Push failed")

        except Exception as e:
            self.errorOccurred.emit(f"Failed to push: {str(e)}")
            return False
