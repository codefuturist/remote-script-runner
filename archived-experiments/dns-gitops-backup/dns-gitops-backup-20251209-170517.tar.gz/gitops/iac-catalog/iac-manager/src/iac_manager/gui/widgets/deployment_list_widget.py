"""Deployment list widget."""

from typing import Optional

from PyQt6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QTableWidget,
    QTableWidgetItem,
    QPushButton,
    QComboBox,
    QLabel,
    QHeaderView,
    QMessageBox,
)
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QColor

from iac_manager.config import Config
from iac_manager.services import DeploymentService
from iac_manager.models import DeploymentInfo


class DeploymentListWidget(QWidget):
    """Widget showing list of deployments."""

    deployment_selected = pyqtSignal(object)  # Emits DeploymentInfo

    def __init__(self, config: Config, deployment_service: DeploymentService):
        """Initialize deployment list.

        Args:
            config: Configuration object
            deployment_service: Deployment service instance
        """
        super().__init__()
        self.config = config
        self.deployment_service = deployment_service
        self.deployments = []

        self._init_ui()
        self.refresh()

    def _init_ui(self) -> None:
        """Initialize the user interface."""
        layout = QVBoxLayout(self)

        # Header with filters
        header = QHBoxLayout()

        # Title
        title = QLabel("🚀 Deployments")
        title.setStyleSheet("font-size: 18px; font-weight: bold;")
        header.addWidget(title)

        header.addStretch()

        # Environment filter
        header.addWidget(QLabel("Environment:"))
        self.env_filter = QComboBox()
        self.env_filter.addItem("All", None)
        self.env_filter.addItem("Development", "development")
        self.env_filter.addItem("Staging", "staging")
        self.env_filter.addItem("Production", "production")
        self.env_filter.addItem("DR Site", "dr-site")
        self.env_filter.currentIndexChanged.connect(self.refresh)
        header.addWidget(self.env_filter)

        # Refresh button
        self.refresh_btn = QPushButton("🔄 Refresh")
        self.refresh_btn.clicked.connect(self.refresh)
        header.addWidget(self.refresh_btn)

        layout.addLayout(header)

        # Deployments table
        self.table = QTableWidget()
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels([
            "Instance ID",
            "Environment",
            "Template",
            "Version",
            "Status",
            "Path"
        ])
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        self.table.itemSelectionChanged.connect(self._on_selection_changed)
        self.table.doubleClicked.connect(self._on_double_click)

        # Stretch columns appropriately
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(4, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(5, QHeaderView.ResizeMode.Stretch)

        layout.addWidget(self.table)

        # Action buttons
        actions = QHBoxLayout()
        
        self.view_btn = QPushButton("👁️ View Details")
        self.view_btn.setEnabled(False)
        self.view_btn.clicked.connect(self._view_details)
        actions.addWidget(self.view_btn)

        self.deploy_btn = QPushButton("🚀 Deploy")
        self.deploy_btn.setEnabled(False)
        self.deploy_btn.clicked.connect(self._deploy)
        actions.addWidget(self.deploy_btn)

        self.delete_btn = QPushButton("🗑️ Delete")
        self.delete_btn.setEnabled(False)
        self.delete_btn.clicked.connect(self._delete)
        actions.addWidget(self.delete_btn)

        actions.addStretch()

        layout.addLayout(actions)

        # Status label
        self.status_label = QLabel("Ready")
        self.status_label.setStyleSheet("color: gray;")
        layout.addWidget(self.status_label)

    def refresh(self) -> None:
        """Refresh deployment list."""
        try:
            self.status_label.setText("Loading deployments...")
            self.refresh_btn.setEnabled(False)

            # Get filter
            env = self.env_filter.currentData()

            # Load deployments
            self.deployments = self.deployment_service.list_deployments(
                environment=env
            )

            # Update table
            self.table.setRowCount(len(self.deployments))

            for row, deployment in enumerate(self.deployments):
                # Instance ID
                item = QTableWidgetItem(deployment.instance_id)
                self.table.setItem(row, 0, item)

                # Environment
                env_item = QTableWidgetItem(deployment.environment.value)
                env_item.setData(Qt.ItemDataRole.UserRole, deployment)
                # Color code by environment
                if deployment.environment.value == "production":
                    env_item.setBackground(QColor(255, 200, 200))  # Light red
                elif deployment.environment.value == "staging":
                    env_item.setBackground(QColor(255, 255, 200))  # Light yellow
                elif deployment.environment.value == "development":
                    env_item.setBackground(QColor(200, 255, 200))  # Light green
                self.table.setItem(row, 1, env_item)

                # Template (show relative path)
                template_name = deployment.template.split("/")[-1] if "/" in deployment.template else deployment.template
                self.table.setItem(row, 2, QTableWidgetItem(template_name))

                # Version
                version = deployment.template_version or "latest"
                self.table.setItem(row, 3, QTableWidgetItem(version))

                # Status
                status = self._get_deployment_status(deployment)
                status_item = QTableWidgetItem(status)
                if "✅" in status:
                    status_item.setForeground(QColor(0, 150, 0))
                elif "⚠️" in status:
                    status_item.setForeground(QColor(200, 100, 0))
                self.table.setItem(row, 4, status_item)

                # Path (relative to repo root)
                rel_path = deployment.deployment_path.relative_to(self.config.repo_root)
                self.table.setItem(row, 5, QTableWidgetItem(str(rel_path)))

            # Update status
            count = len(self.deployments)
            env_text = f" in {env}" if env else ""
            self.status_label.setText(f"Found {count} deployment{'s' if count != 1 else ''}{env_text}")

        except Exception as e:
            self.status_label.setText(f"Error: {str(e)}")
            QMessageBox.warning(self, "Error", f"Failed to load deployments:\n{str(e)}")

        finally:
            self.refresh_btn.setEnabled(True)

    def _get_deployment_status(self, deployment: DeploymentInfo) -> str:
        """Get deployment status indicator.

        Args:
            deployment: Deployment info

        Returns:
            Status string with emoji
        """
        checks = []
        
        if deployment.has_env_file:
            checks.append("✅ Env")
        else:
            checks.append("⚠️ No Env")
            
        if deployment.has_docker_compose:
            checks.append("✅ Docker")
        elif deployment.has_kubernetes_manifests:
            checks.append("✅ K8s")
        else:
            checks.append("⚠️ No Runtime")

        return " | ".join(checks)

    def _on_selection_changed(self) -> None:
        """Handle selection change."""
        selected = bool(self.table.selectedItems())
        self.view_btn.setEnabled(selected)
        self.deploy_btn.setEnabled(selected)
        self.delete_btn.setEnabled(selected)

        if selected:
            deployment = self._get_selected_deployment()
            if deployment:
                self.deployment_selected.emit(deployment)

    def _on_double_click(self) -> None:
        """Handle double-click on deployment."""
        self._view_details()

    def _get_selected_deployment(self) -> Optional[DeploymentInfo]:
        """Get currently selected deployment.

        Returns:
            Selected deployment or None
        """
        row = self.table.currentRow()
        if row >= 0 and row < len(self.deployments):
            return self.deployments[row]
        return None

    def _view_details(self) -> None:
        """View deployment details."""
        deployment = self._get_selected_deployment()
        if not deployment:
            return

        details = f"""
<h3>{deployment.instance_id}</h3>
<p><b>Environment:</b> {deployment.environment.value}</p>
<p><b>Template:</b> {deployment.template}</p>
<p><b>Version:</b> {deployment.template_version or 'latest'}</p>
<p><b>Path:</b> {deployment.deployment_path}</p>

<h4>Configuration:</h4>
<ul>
<li>Environment file: {'✅ Yes' if deployment.has_env_file else '❌ No'}</li>
<li>Docker Compose: {'✅ Yes' if deployment.has_docker_compose else '❌ No'}</li>
<li>Kubernetes: {'✅ Yes' if deployment.has_kubernetes_manifests else '❌ No'}</li>
</ul>

<h4>Manifest Details:</h4>
<ul>
<li><b>Name:</b> {deployment.manifest.name}</li>
<li><b>Description:</b> {deployment.manifest.description or 'N/A'}</li>
<li><b>Target:</b> {deployment.manifest.target.value}</li>
</ul>
"""

        msg = QMessageBox(self)
        msg.setWindowTitle("Deployment Details")
        msg.setTextFormat(Qt.TextFormat.RichText)
        msg.setText(details)
        msg.exec()

    def _deploy(self) -> None:
        """Deploy selected deployment."""
        deployment = self._get_selected_deployment()
        if not deployment:
            return

        reply = QMessageBox.question(
            self,
            "Deploy",
            f"Deploy {deployment.instance_id} to {deployment.environment.value}?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )

        if reply == QMessageBox.StandardButton.Yes:
            try:
                # Show progress message
                progress_msg = QMessageBox(self)
                progress_msg.setWindowTitle("Deploying")
                progress_msg.setText(f"Deploying {deployment.instance_id}...")
                progress_msg.setStandardButtons(QMessageBox.StandardButton.NoButton)
                progress_msg.show()
                
                # For PyQt GUI, we'll execute the deployment command
                # In a real implementation, this should be done in a separate thread
                import subprocess
                
                # Change to deployment directory
                deployment_dir = deployment.deployment_path
                
                # Determine deployment command based on available files
                if deployment.has_docker_compose:
                    cmd = ["docker-compose", "up", "-d"]
                    result = subprocess.run(
                        cmd,
                        cwd=deployment_dir,
                        capture_output=True,
                        text=True
                    )
                elif deployment.has_kubernetes_manifests:
                    cmd = ["kubectl", "apply", "-f", str(deployment_dir)]
                    result = subprocess.run(
                        cmd,
                        capture_output=True,
                        text=True
                    )
                else:
                    progress_msg.close()
                    QMessageBox.warning(
                        self,
                        "Deploy",
                        "No deployment method found.\n"
                        "Expected docker-compose.yml or Kubernetes manifests."
                    )
                    return
                
                progress_msg.close()
                
                if result.returncode == 0:
                    QMessageBox.information(
                        self,
                        "Deploy",
                        f"Successfully deployed {deployment.instance_id}\n\n"
                        f"Output:\n{result.stdout[:500]}"
                    )
                    self.refresh()
                else:
                    QMessageBox.warning(
                        self,
                        "Deploy Failed",
                        f"Deployment failed with error:\n{result.stderr[:500]}"
                    )
                    
            except FileNotFoundError as e:
                QMessageBox.warning(
                    self,
                    "Deploy Error",
                    f"Required tool not found: {e}\n\n"
                    "Please ensure docker-compose or kubectl is installed."
                )
            except Exception as e:
                QMessageBox.critical(
                    self,
                    "Deploy Error",
                    f"Deployment failed:\n{str(e)}"
                )

    def _delete(self) -> None:
        """Delete selected deployment."""
        deployment = self._get_selected_deployment()
        if not deployment:
            return

        reply = QMessageBox.warning(
            self,
            "Delete Deployment",
            f"Are you sure you want to delete {deployment.instance_id}?\n\n"
            f"This will remove the deployment directory:\n{deployment.deployment_path}",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )

        if reply == QMessageBox.StandardButton.Yes:
            try:
                # Use the deployment service to delete the deployment
                success = self.deployment_service.delete_deployment(
                    instance=deployment.instance_id,
                    environment=deployment.environment.value,
                    confirm=True
                )
                
                if success:
                    QMessageBox.information(
                        self,
                        "Delete",
                        f"Successfully deleted deployment: {deployment.instance_id}"
                    )
                    self.refresh()
                else:
                    QMessageBox.warning(
                        self,
                        "Delete",
                        f"Failed to delete deployment: {deployment.instance_id}"
                    )
            except Exception as e:
                QMessageBox.critical(
                    self,
                    "Delete Error",
                    f"Failed to delete deployment:\n{str(e)}"
                )

