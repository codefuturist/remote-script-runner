"""Widgets package."""

from iac_manager.gui.widgets.dashboard_widget import DashboardWidget
from iac_manager.gui.widgets.template_browser_widget import TemplateBrowserWidget
from iac_manager.gui.widgets.deployment_list_widget import DeploymentListWidget
from iac_manager.gui.widgets.inventory_widget import InventoryWidget
from iac_manager.gui.widgets.gitops_widget import GitOpsWidget

__all__ = [
    "DashboardWidget",
    "TemplateBrowserWidget",
    "DeploymentListWidget",
    "InventoryWidget",
    "GitOpsWidget",
]
