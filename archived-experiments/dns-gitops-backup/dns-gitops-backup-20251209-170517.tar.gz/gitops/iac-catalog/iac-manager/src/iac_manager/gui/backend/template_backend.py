"""Template backend for QML."""

from typing import Optional

from PyQt6.QtCore import QObject, pyqtProperty, pyqtSignal, pyqtSlot

from iac_manager.config import Config
from iac_manager.services import TemplateService
from iac_manager.gui.backend.models import TemplateListModel


class TemplateBackend(QObject):
    """Backend bridge for template operations in QML."""

    # Signals
    templatesLoaded = pyqtSignal()
    statusChanged = pyqtSignal(str)
    errorOccurred = pyqtSignal(str)
    operationCompleted = pyqtSignal(str)

    def __init__(self, config: Config, template_service: TemplateService, parent=None):
        """Initialize template backend.

        Args:
            config: Configuration object
            template_service: Template service instance
            parent: Parent QObject
        """
        super().__init__(parent)
        self._config = config
        self._template_service = template_service
        self._model = TemplateListModel(self)
        self._status = "Ready"
        self._selected_category = "all"

    @pyqtProperty(QObject, constant=True)
    def model(self) -> TemplateListModel:
        """Get templates model for QML."""
        return self._model

    @pyqtProperty(str, notify=statusChanged)
    def status(self) -> str:
        """Get current status message."""
        return self._status

    @status.setter
    def status(self, value: str):
        """Set status message."""
        if self._status != value:
            self._status = value
            self.statusChanged.emit(value)

    @pyqtSlot()
    @pyqtSlot(str)
    def refresh(self, category: Optional[str] = None):
        """Refresh templates list.

        Args:
            category: Optional category filter
        """
        try:
            self.status = "Loading templates..."

            # Use category filter if provided
            cat = None if category == "all" or not category else category

            # Load templates
            templates = self._template_service.list_templates(category=cat)

            # Update model
            self._model.setTemplates(templates)

            # Update status
            count = len(templates)
            cat_text = f" in {category}" if category and category != "all" else ""
            self.status = f"Found {count} template{'s' if count != 1 else ''}{cat_text}"

            self.templatesLoaded.emit()

        except Exception as e:
            self.status = f"Error: {str(e)}"
            self.errorOccurred.emit(str(e))

    @pyqtSlot(int, result=str)
    def getTemplateDetails(self, index: int) -> str:
        """Get template details as formatted string.

        Args:
            index: Template index

        Returns:
            Formatted details string
        """
        template = self._model.getTemplate(index)
        if not template:
            return ""

        details = f"""<h3>{template.name}</h3>
<p><b>Category:</b> {template.category}</p>
<p><b>Version:</b> {template.version}</p>
<p><b>Description:</b> {template.description or 'N/A'}</p>

<h4>Target Types:</h4>
<ul>
{"".join(f"<li>{t.value}</li>" for t in template.target_types)}
</ul>

<h4>Required Parameters:</h4>
<ul>
{"".join(f"<li>{p}</li>" for p in template.required_params) if template.required_params else "<li>None</li>"}
</ul>

<h4>Optional Parameters:</h4>
<ul>
{"".join(f"<li>{p}</li>" for p in template.optional_params) if template.optional_params else "<li>None</li>"}
</ul>

<h4>Features:</h4>
<ul>
<li>README: {'✅ Yes' if template.has_readme else '❌ No'}</li>
<li>Jinja Templates: {'✅ Yes' if template.has_jinja_templates else '❌ No'}</li>
</ul>"""

        return details

    @pyqtSlot(int, str)
    def deployTemplate(self, index: int, instance_id: str):
        """Deploy selected template.

        Args:
            index: Template index
            instance_id: Instance ID for deployment
        """
        template = self._model.getTemplate(index)
        if template:
            try:
                self.status = f"Preparing to deploy {template.name} as {instance_id}..."
                
                # Signal that we want to open the deployment wizard
                # The main window or QML view should handle this signal
                self.operationCompleted.emit(
                    f"wizard:{template.path}:{instance_id}"
                )
                
                self.status = f"Ready to deploy {template.name}"
            except Exception as e:
                self.errorOccurred.emit(f"Failed to deploy: {str(e)}")

    @pyqtSlot(str, result="QStringList")
    def getCategories(self) -> list:
        """Get list of available template categories.

        Returns:
            List of category names
        """
        try:
            # Get all templates to extract unique categories
            templates = self._template_service.list_templates()
            categories = sorted(set(t.category for t in templates))
            return ["all"] + categories
        except Exception as e:
            self.errorOccurred.emit(f"Failed to get categories: {str(e)}")
            return ["all"]
