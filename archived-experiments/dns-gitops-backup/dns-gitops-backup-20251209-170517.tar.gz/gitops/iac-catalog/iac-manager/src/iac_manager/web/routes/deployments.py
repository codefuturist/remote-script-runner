"""Deployment routes."""

from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, status

from iac_manager.models import EnvironmentType
from iac_manager.web.auth.dependencies import ActiveUser
from iac_manager.web.schemas.common import MessageResponse, PaginatedResponse
from iac_manager.web.schemas.deployments import (
    DeploymentCreate,
    DeploymentPreview,
    DeploymentResponse,
    DeploymentUpdate,
)
from iac_manager.web.services import ServiceProvider, get_services

router = APIRouter()


@router.get("", response_model=PaginatedResponse[DeploymentResponse])
async def list_deployments(
    current_user: ActiveUser,
    services: Annotated[ServiceProvider, Depends(get_services)],
    environment: EnvironmentType | None = None,
    template: str | None = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
) -> PaginatedResponse[DeploymentResponse]:
    """List all deployments with optional filtering."""
    deployments = await services.deployments.list_deployments(
        environment=environment.value if environment else None,
        template=template,
    )

    # Convert to response models
    items = [DeploymentResponse.from_domain(d) for d in deployments]

    # Paginate
    total = len(items)
    start = (page - 1) * page_size
    end = start + page_size
    paginated_items = items[start:end]

    return PaginatedResponse.create(
        items=paginated_items,
        total=total,
        page=page,
        page_size=page_size,
    )


@router.get("/{environment}/{instance_id}", response_model=DeploymentResponse)
async def get_deployment(
    environment: EnvironmentType,
    instance_id: str,
    current_user: ActiveUser,
    services: Annotated[ServiceProvider, Depends(get_services)],
) -> DeploymentResponse:
    """Get a specific deployment."""
    deployment = await services.deployments.get_deployment(
        instance=instance_id,
        environment=environment.value,
    )

    if not deployment:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Deployment {instance_id} not found in {environment.value}",
        )

    return DeploymentResponse.from_domain(deployment)


@router.post("", response_model=DeploymentResponse, status_code=status.HTTP_201_CREATED)
async def create_deployment(
    data: DeploymentCreate,
    current_user: ActiveUser,
    services: Annotated[ServiceProvider, Depends(get_services)],
) -> DeploymentResponse:
    """Create a new deployment from a template."""
    # Check if deployment already exists
    existing = await services.deployments.get_deployment(
        instance=data.instance_id,
        environment=data.environment.value,
    )

    if existing:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Deployment {data.instance_id} already exists in {data.environment.value}",
        )

    # Verify template exists
    template = await services.templates.get_template(data.template)
    if not template:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Template {data.template} not found",
        )

    # Create the deployment
    try:
        deployment = await services.deployments.create_deployment(
            template=data.template,
            instance_id=data.instance_id,
            environment=data.environment.value,
            values=data.values,
            description=data.description,
            labels=data.labels,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )

    return DeploymentResponse.from_domain(deployment)


@router.post("/{environment}/{instance_id}/preview", response_model=DeploymentPreview)
async def preview_deployment(
    environment: EnvironmentType,
    instance_id: str,
    data: DeploymentCreate,
    current_user: ActiveUser,
    services: Annotated[ServiceProvider, Depends(get_services)],
) -> DeploymentPreview:
    """Preview files that would be generated for a deployment."""
    try:
        preview = await services.deployments.preview_deployment(
            template=data.template,
            instance_id=instance_id,
            environment=environment.value,
            values=data.values,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )

    return DeploymentPreview(
        files=preview.get("files", {}),
        warnings=preview.get("warnings", []),
        missing_values=preview.get("missing_values", []),
    )


@router.patch("/{environment}/{instance_id}", response_model=DeploymentResponse)
async def update_deployment(
    environment: EnvironmentType,
    instance_id: str,
    data: DeploymentUpdate,
    current_user: ActiveUser,
    services: Annotated[ServiceProvider, Depends(get_services)],
) -> DeploymentResponse:
    """Update an existing deployment."""
    deployment = await services.deployments.get_deployment(
        instance=instance_id,
        environment=environment.value,
    )

    if not deployment:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Deployment {instance_id} not found in {environment.value}",
        )

    try:
        updated = await services.deployments.update_deployment(
            instance=instance_id,
            environment=environment.value,
            values=data.values,
            description=data.description,
            labels=data.labels,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )

    return DeploymentResponse.from_domain(updated)


@router.delete("/{environment}/{instance_id}", response_model=MessageResponse)
async def delete_deployment(
    environment: EnvironmentType,
    instance_id: str,
    current_user: ActiveUser,
    services: Annotated[ServiceProvider, Depends(get_services)],
    force: bool = Query(False, description="Force deletion"),
) -> MessageResponse:
    """Delete a deployment."""
    deployment = await services.deployments.get_deployment(
        instance=instance_id,
        environment=environment.value,
    )

    if not deployment:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Deployment {instance_id} not found in {environment.value}",
        )

    try:
        await services.deployments.delete_deployment(
            instance=instance_id,
            environment=environment.value,
            force=force,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )

    return MessageResponse(message=f"Deployment {instance_id} deleted successfully")
