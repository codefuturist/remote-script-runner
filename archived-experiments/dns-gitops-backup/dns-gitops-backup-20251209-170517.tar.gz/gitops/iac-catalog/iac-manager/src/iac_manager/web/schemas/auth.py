"""Authentication schemas."""

from datetime import datetime

from pydantic import EmailStr, Field

from iac_manager.web.schemas.common import BaseSchema, TimestampSchema


class LoginRequest(BaseSchema):
    """Login request schema."""

    email: EmailStr
    password: str = Field(min_length=8)


class RegisterRequest(BaseSchema):
    """User registration request schema."""

    email: EmailStr
    username: str = Field(min_length=3, max_length=50, pattern=r"^[a-zA-Z0-9_-]+$")
    password: str = Field(min_length=8, max_length=128)
    full_name: str | None = Field(None, max_length=255)


class TokenResponse(BaseSchema):
    """Token response schema."""

    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int  # Seconds


class RefreshTokenRequest(BaseSchema):
    """Refresh token request schema."""

    refresh_token: str


class UserResponse(TimestampSchema):
    """User response schema."""

    id: int
    email: str
    username: str
    full_name: str | None = None
    is_active: bool
    is_superuser: bool
    oauth_provider: str | None = None
    avatar_url: str | None = None


class UserUpdate(BaseSchema):
    """User update request schema."""

    email: EmailStr | None = None
    username: str | None = Field(None, min_length=3, max_length=50)
    full_name: str | None = Field(None, max_length=255)
    password: str | None = Field(None, min_length=8, max_length=128)


class PasswordChangeRequest(BaseSchema):
    """Password change request schema."""

    current_password: str
    new_password: str = Field(min_length=8, max_length=128)


class OAuthCallbackRequest(BaseSchema):
    """OAuth callback request schema."""

    code: str
    state: str


class OAuthUrlResponse(BaseSchema):
    """OAuth authorization URL response."""

    url: str
    state: str
