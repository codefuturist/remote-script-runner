"""WebSocket handlers for real-time updates."""

import asyncio
import json
import logging
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from fastapi import WebSocket, WebSocketDisconnect
from pydantic import BaseModel

logger = logging.getLogger(__name__)


class MessageType(str, Enum):
    """WebSocket message types."""

    # Client -> Server
    SUBSCRIBE = "subscribe"
    UNSUBSCRIBE = "unsubscribe"
    PING = "ping"

    # Server -> Client
    PONG = "pong"
    ERROR = "error"
    GIT_STATUS = "git_status"
    DEPLOYMENT_LOG = "deployment_log"
    OPERATION_PROGRESS = "operation_progress"
    NOTIFICATION = "notification"


class WebSocketMessage(BaseModel):
    """WebSocket message structure."""

    type: MessageType
    channel: str | None = None
    data: dict[str, Any] | None = None
    error: str | None = None


@dataclass
class ConnectionManager:
    """Manages WebSocket connections and subscriptions."""

    # Active connections by client ID
    connections: dict[str, WebSocket] = field(default_factory=dict)

    # Channel subscriptions: channel -> set of client IDs
    subscriptions: dict[str, set[str]] = field(default_factory=dict)

    # Background tasks
    _tasks: list[asyncio.Task] = field(default_factory=list)

    async def connect(self, websocket: WebSocket, client_id: str) -> None:
        """Accept a new WebSocket connection.

        Args:
            websocket: WebSocket connection
            client_id: Unique client identifier
        """
        await websocket.accept()
        self.connections[client_id] = websocket
        logger.info(f"WebSocket connected: {client_id}")

    def disconnect(self, client_id: str) -> None:
        """Handle WebSocket disconnection.

        Args:
            client_id: Client identifier to disconnect
        """
        if client_id in self.connections:
            del self.connections[client_id]

        # Remove from all subscriptions
        for channel in self.subscriptions:
            self.subscriptions[channel].discard(client_id)

        logger.info(f"WebSocket disconnected: {client_id}")

    def subscribe(self, client_id: str, channel: str) -> None:
        """Subscribe a client to a channel.

        Args:
            client_id: Client identifier
            channel: Channel name to subscribe to
        """
        if channel not in self.subscriptions:
            self.subscriptions[channel] = set()
        self.subscriptions[channel].add(client_id)
        logger.debug(f"Client {client_id} subscribed to {channel}")

    def unsubscribe(self, client_id: str, channel: str) -> None:
        """Unsubscribe a client from a channel.

        Args:
            client_id: Client identifier
            channel: Channel name to unsubscribe from
        """
        if channel in self.subscriptions:
            self.subscriptions[channel].discard(client_id)
        logger.debug(f"Client {client_id} unsubscribed from {channel}")

    async def send_to_client(self, client_id: str, message: WebSocketMessage) -> bool:
        """Send a message to a specific client.

        Args:
            client_id: Target client identifier
            message: Message to send

        Returns:
            True if message was sent, False if client not found
        """
        if client_id not in self.connections:
            return False

        try:
            websocket = self.connections[client_id]
            await websocket.send_json(message.model_dump())
            return True
        except Exception as e:
            logger.error(f"Failed to send to {client_id}: {e}")
            self.disconnect(client_id)
            return False

    async def broadcast_to_channel(
        self,
        channel: str,
        message: WebSocketMessage,
    ) -> int:
        """Broadcast a message to all subscribers of a channel.

        Args:
            channel: Target channel
            message: Message to broadcast

        Returns:
            Number of clients that received the message
        """
        if channel not in self.subscriptions:
            return 0

        sent_count = 0
        failed_clients = []

        for client_id in self.subscriptions[channel]:
            if await self.send_to_client(client_id, message):
                sent_count += 1
            else:
                failed_clients.append(client_id)

        # Clean up failed connections
        for client_id in failed_clients:
            self.disconnect(client_id)

        return sent_count

    async def broadcast_all(self, message: WebSocketMessage) -> int:
        """Broadcast a message to all connected clients.

        Args:
            message: Message to broadcast

        Returns:
            Number of clients that received the message
        """
        sent_count = 0
        failed_clients = []

        for client_id in list(self.connections.keys()):
            if await self.send_to_client(client_id, message):
                sent_count += 1
            else:
                failed_clients.append(client_id)

        # Clean up failed connections
        for client_id in failed_clients:
            self.disconnect(client_id)

        return sent_count


# Global connection manager instance
manager = ConnectionManager()


async def websocket_handler(websocket: WebSocket, client_id: str) -> None:
    """Handle a WebSocket connection lifecycle.

    Args:
        websocket: WebSocket connection
        client_id: Unique client identifier
    """
    await manager.connect(websocket, client_id)

    try:
        while True:
            # Receive message
            data = await websocket.receive_json()

            try:
                message = WebSocketMessage(**data)
            except Exception as e:
                await manager.send_to_client(
                    client_id,
                    WebSocketMessage(type=MessageType.ERROR, error=f"Invalid message: {e}"),
                )
                continue

            # Handle message types
            if message.type == MessageType.PING:
                await manager.send_to_client(
                    client_id,
                    WebSocketMessage(type=MessageType.PONG),
                )

            elif message.type == MessageType.SUBSCRIBE:
                if message.channel:
                    manager.subscribe(client_id, message.channel)
                    await manager.send_to_client(
                        client_id,
                        WebSocketMessage(
                            type=MessageType.NOTIFICATION,
                            data={"message": f"Subscribed to {message.channel}"},
                        ),
                    )

            elif message.type == MessageType.UNSUBSCRIBE:
                if message.channel:
                    manager.unsubscribe(client_id, message.channel)
                    await manager.send_to_client(
                        client_id,
                        WebSocketMessage(
                            type=MessageType.NOTIFICATION,
                            data={"message": f"Unsubscribed from {message.channel}"},
                        ),
                    )

    except WebSocketDisconnect:
        manager.disconnect(client_id)
    except Exception as e:
        logger.error(f"WebSocket error for {client_id}: {e}")
        manager.disconnect(client_id)


# Helper functions for broadcasting updates


async def broadcast_git_status(status: dict[str, Any]) -> None:
    """Broadcast git status update to subscribers.

    Args:
        status: Git status data
    """
    await manager.broadcast_to_channel(
        "git_status",
        WebSocketMessage(
            type=MessageType.GIT_STATUS,
            channel="git_status",
            data=status,
        ),
    )


async def broadcast_deployment_log(
    deployment_id: str,
    log_line: str,
    level: str = "info",
) -> None:
    """Broadcast deployment log entry to subscribers.

    Args:
        deployment_id: Deployment identifier
        log_line: Log content
        level: Log level (info, warning, error)
    """
    channel = f"deployment_logs:{deployment_id}"
    await manager.broadcast_to_channel(
        channel,
        WebSocketMessage(
            type=MessageType.DEPLOYMENT_LOG,
            channel=channel,
            data={
                "deployment_id": deployment_id,
                "log": log_line,
                "level": level,
            },
        ),
    )


async def broadcast_operation_progress(
    operation_id: str,
    progress: int,
    status: str,
    message: str | None = None,
) -> None:
    """Broadcast operation progress update.

    Args:
        operation_id: Operation identifier
        progress: Progress percentage (0-100)
        status: Current status
        message: Optional status message
    """
    channel = f"operation:{operation_id}"
    await manager.broadcast_to_channel(
        channel,
        WebSocketMessage(
            type=MessageType.OPERATION_PROGRESS,
            channel=channel,
            data={
                "operation_id": operation_id,
                "progress": progress,
                "status": status,
                "message": message,
            },
        ),
    )


async def broadcast_notification(
    title: str,
    message: str,
    level: str = "info",
) -> None:
    """Broadcast a notification to all connected clients.

    Args:
        title: Notification title
        message: Notification message
        level: Notification level (info, success, warning, error)
    """
    await manager.broadcast_all(
        WebSocketMessage(
            type=MessageType.NOTIFICATION,
            data={
                "title": title,
                "message": message,
                "level": level,
            },
        ),
    )
