"""Template schemas."""

from pathlib import Path
from typing import Any

from pydantic import Field

from iac_manager.models import TargetType
from iac_manager.web.schemas.common import BaseSchema, PaginatedResponse


class TemplateParamInfo(BaseSchema):
    """Information about a template parameter."""

    name: str
    description: str | None = None
    default: Any = None
    required: bool = True
    type: str = "string"  # string, number, boolean, array, object


class TemplateResponse(BaseSchema):
    """Template information response."""

    name: str
    path: str  # String path for JSON serialization
    category: str
    subcategory: str | None = None
    description: str | None = None
    version: str
    has_readme: bool
    has_jinja_templates: bool
    target_types: list[TargetType]
    required_params: list[str]
    optional_params: list[str]

    @classmethod
    def from_domain(cls, template) -> "TemplateResponse":
        """Create response from domain model.

        Args:
            template: TemplateInfo domain model

        Returns:
            API response schema
        """
        return cls(
            name=template.name,
            path=str(template.path),
            category=template.category,
            subcategory=template.subcategory,
            description=template.description,
            version=template.version,
            has_readme=template.has_readme,
            has_jinja_templates=template.has_jinja_templates,
            target_types=template.target_types,
            required_params=template.required_params,
            optional_params=template.optional_params,
        )


class TemplateList(PaginatedResponse[TemplateResponse]):
    """Paginated list of templates."""

    pass


class TemplateParams(BaseSchema):
    """Template parameters response."""

    template: str
    required: list[TemplateParamInfo]
    optional: list[TemplateParamInfo]
    defaults: dict[str, Any]


class TemplateReadme(BaseSchema):
    """Template README content."""

    template: str
    content: str
    format: str = "markdown"


class TemplateSearchRequest(BaseSchema):
    """Template search request."""

    query: str = Field(min_length=1, max_length=200)
    categories: list[str] | None = None
    target_types: list[TargetType] | None = None


class CategoryInfo(BaseSchema):
    """Category information with counts."""

    name: str
    count: int
    subcategories: list[str]
