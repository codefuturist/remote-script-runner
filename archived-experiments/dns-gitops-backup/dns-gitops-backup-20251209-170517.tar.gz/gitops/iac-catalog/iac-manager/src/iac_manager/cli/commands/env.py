"""Environment management commands."""

from pathlib import Path
from typing import Optional

import click
from rich.console import Console

from iac_manager.cli.config import Config
from iac_manager.cli.utils import load_yaml, print_table


@click.group()
def environment() -> None:
    """🌍 Manage environments.

    List and inspect environment configurations.
    """
    pass


@environment.command(name="list")
@click.pass_context
def list_environments(ctx: click.Context) -> None:
    """List all environments.

    Examples:

        iac environment list
    """
    config: Config = ctx.obj["config"]
    console: Console = ctx.obj["console"]

    environments_dir = config.repo_root / config.environments_dir

    if not environments_dir.exists():
        console.print(f"[red]Environments directory not found: {environments_dir}[/red]")
        ctx.exit(1)

    # Find all environments
    environments = []
    for env_dir in environments_dir.iterdir():
        if not env_dir.is_dir():
            continue

        # Check for defaults.yml
        defaults_file = env_dir / "defaults.yml"
        has_defaults = defaults_file.exists()

        # Count deployments in this environment
        deployments_dir = config.repo_root / config.deployments_dir / env_dir.name
        num_deployments = (
            len(list(deployments_dir.iterdir()))
            if deployments_dir.exists()
            else 0
        )

        environments.append({
            "name": env_dir.name,
            "has_defaults": has_defaults,
            "num_deployments": num_deployments,
            "path": env_dir,
        })

    if not environments:
        console.print("[yellow]No environments found.[/yellow]")
        return

    # Print table
    rows = []
    for env in sorted(environments, key=lambda e: e["name"]):
        rows.append([
            env["name"],
            "✓" if env["has_defaults"] else "✗",
            str(env["num_deployments"]),
        ])

    print_table(
        "Environments",
        ["Environment", "Has Defaults", "Deployments"],
        rows,
        console,
    )


@environment.command()
@click.argument("environment_name")
@click.pass_context
def info(ctx: click.Context, environment_name: str) -> None:
    """Show environment details.

    Examples:

        iac environment info production
    """
    config: Config = ctx.obj["config"]
    console: Console = ctx.obj["console"]

    env_dir = config.repo_root / config.environments_dir / environment_name

    if not env_dir.exists():
        console.print(f"[red]Environment not found: {environment_name}[/red]")
        ctx.exit(1)

    console.print(f"\n[bold]Environment:[/bold] {environment_name}")
    console.print(f"[bold]Path:[/bold] {env_dir.relative_to(config.repo_root)}")

    # Show defaults if exists
    defaults_file = env_dir / "defaults.yml"
    if defaults_file.exists():
        console.print("\n[bold]Defaults:[/bold]")
        try:
            defaults = load_yaml(defaults_file)
            for key, value in defaults.items():
                console.print(f"  {key}: {value}")
        except Exception as e:
            console.print(f"[red]Error loading defaults: {e}[/red]")

    # Show deployment count
    deployments_dir = config.repo_root / config.deployments_dir / environment_name
    if deployments_dir.exists():
        num_deployments = len(list(deployments_dir.iterdir()))
        console.print(f"\n[bold]Deployments:[/bold] {num_deployments}")

    # Show inventory
    inventory_file = config.repo_root / config.inventory_dir / environment_name / "servers.yml"
    if inventory_file.exists():
        console.print("\n[bold]Inventory:[/bold]")
        try:
            inventory = load_yaml(inventory_file)
            all_hosts = inventory.get("all", {}).get("hosts", {})
            console.print(f"  Hosts: {len(all_hosts)}")

            children = inventory.get("all", {}).get("children", {})
            console.print(f"  Groups: {len(children)}")
        except Exception as e:
            console.print(f"[red]Error loading inventory: {e}[/red]")
