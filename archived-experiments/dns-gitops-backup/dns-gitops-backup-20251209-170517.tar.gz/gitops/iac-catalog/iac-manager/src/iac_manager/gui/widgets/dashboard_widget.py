"""Dashboard widget showing overview."""

from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel, QGridLayout, QFrame
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont

from iac_manager.config import Config
from iac_manager.services import DeploymentService


class DashboardWidget(QWidget):
    """Dashboard showing overview and statistics."""

    def __init__(self, config: Config, deployment_service: DeploymentService):
        """Initialize dashboard.

        Args:
            config: Configuration object
            deployment_service: Deployment service instance
        """
        super().__init__()
        self.config = config
        self.deployment_service = deployment_service

        self._setup_ui()
        self.refresh()

    def _setup_ui(self) -> None:
        """Setup UI components."""
        layout = QVBoxLayout(self)

        # Title
        title = QLabel("🏠 Dashboard")
        title_font = QFont()
        title_font.setPointSize(16)
        title_font.setBold(True)
        title.setFont(title_font)
        layout.addWidget(title)

        # Statistics grid
        stats_layout = QGridLayout()

        # Statistics cards
        self.total_deployments_label = self._create_stat_card("Total Deployments", "0")
        self.prod_deployments_label = self._create_stat_card("Production", "0")
        self.staging_deployments_label = self._create_stat_card("Staging", "0")
        self.dev_deployments_label = self._create_stat_card("Development", "0")

        stats_layout.addWidget(self.total_deployments_label, 0, 0)
        stats_layout.addWidget(self.prod_deployments_label, 0, 1)
        stats_layout.addWidget(self.staging_deployments_label, 0, 2)
        stats_layout.addWidget(self.dev_deployments_label, 0, 3)

        layout.addLayout(stats_layout)
        layout.addStretch()

    def _create_stat_card(self, title: str, value: str) -> QFrame:
        """Create a statistics card.

        Args:
            title: Card title
            value: Card value

        Returns:
            Frame widget
        """
        frame = QFrame()
        frame.setFrameStyle(QFrame.Shape.Box | QFrame.Shadow.Raised)
        frame.setLineWidth(2)
        frame.setMinimumHeight(100)

        layout = QVBoxLayout(frame)

        title_label = QLabel(title)
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title_label.setStyleSheet("color: #666; font-size: 14px;")
        layout.addWidget(title_label)

        value_label = QLabel(value)
        value_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        value_label.setStyleSheet("font-size: 32px; font-weight: bold; color: #0066cc;")
        value_label.setObjectName("value")
        layout.addWidget(value_label)

        return frame

    def refresh(self) -> None:
        """Refresh dashboard data."""
        deployments = self.deployment_service.list_deployments()

        # Update statistics
        self._update_stat_card(self.total_deployments_label, str(len(deployments)))

        prod_count = len([d for d in deployments if d.environment.value == "production"])
        self._update_stat_card(self.prod_deployments_label, str(prod_count))

        staging_count = len([d for d in deployments if d.environment.value == "staging"])
        self._update_stat_card(self.staging_deployments_label, str(staging_count))

        dev_count = len([d for d in deployments if d.environment.value == "development"])
        self._update_stat_card(self.dev_deployments_label, str(dev_count))

    def _update_stat_card(self, card: QFrame, value: str) -> None:
        """Update stat card value.

        Args:
            card: Card frame
            value: New value
        """
        value_label = card.findChild(QLabel, "value")
        if value_label:
            value_label.setText(value)
