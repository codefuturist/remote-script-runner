// DeploymentListView.qml - Modern deployment management view
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import "../components"
import "../theme"

Item {
    id: root
    
    property var backend: null
    
    ColumnLayout {
        anchors.fill: parent
        spacing: Theme.spacingMedium
        
        // Header with filters
        RowLayout {
            Layout.fillWidth: true
            spacing: Theme.spacingMedium
            
            Column {
                spacing: Theme.spacing1
                
                Label {
                    text: "Deployments"
                    font.pixelSize: Theme.fontSizeH3
                    font.weight: Theme.fontWeightBold
                    color: Theme.textPrimary
                }
                
                Label {
                    text: "Manage your infrastructure deployments"
                    font.pixelSize: Theme.fontSizeNormal
                    color: Theme.textSecondary
                }
            }
            
            Item { Layout.fillWidth: true }
            
            Label {
                text: "Environment:"
                color: Theme.textSecondary
                font.weight: Theme.fontWeightMedium
            }
            
            ComboBox {
                id: envFilter
                model: ["all", "development", "staging", "production", "dr-site"]
                currentIndex: 0
                Layout.preferredWidth: 140
                
                onCurrentTextChanged: {
                    if (backend) backend.refresh(currentText)
                }
                
                background: Rectangle {
                    color: Theme.surfaceColor
                    border.color: Theme.borderColor
                    border.width: 1
                    radius: Theme.radiusNormal
                }
                
                contentItem: Text {
                    leftPadding: Theme.spacing3
                    rightPadding: Theme.spacing3
                    text: envFilter.displayText
                    font: envFilter.font
                    color: Theme.textPrimary
                    verticalAlignment: Text.AlignVCenter
                }
            }
            
            CustomButton {
                text: "Refresh"
                iconName: "refresh"
                buttonType: "outlined"
                size: "medium"
                onClicked: {
                    if (backend) backend.refresh(envFilter.currentText)
                }
            }
            
            CustomButton {
                text: "New Deployment"
                iconName: "add"
                buttonType: "primary"
                size: "medium"
                onClicked: {
                    // Open the wizard with Docker configuration
                    if (backend) {
                        backend.openDeploymentWizard()
                    } else {
                        newDeploymentDialog.open()
                    }
                }
            }
        }
        
        // Deployments table with modern design
        Rectangle {
            Layout.fillWidth: true
            Layout.fillHeight: true
            color: Theme.surfaceColor
            radius: Theme.radiusLarge
            
            Shadow {
                anchors.fill: parent
                elevation: 1
                shadowRadius: parent.radius
            }
            
            ColumnLayout {
                anchors.fill: parent
                spacing: 0
                
                // Table header
                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 50
                    color: Theme.gray50
                    radius: Theme.radiusLarge
                    
                    Rectangle {
                        anchors.bottom: parent.bottom
                        anchors.left: parent.left
                        anchors.right: parent.right
                        height: parent.height / 2
                        color: parent.color
                    }
                    
                    RowLayout {
                        anchors.fill: parent
                        anchors.leftMargin: Theme.spacingMedium
                        anchors.rightMargin: Theme.spacingMedium
                        spacing: Theme.spacingMedium
                        
                        Label {
                            text: "Instance ID"
                            font.weight: Theme.fontWeightSemiBold
                            font.pixelSize: Theme.fontSizeSmall
                            color: Theme.textSecondary
                            Layout.preferredWidth: 150
                        }
                        
                        Label {
                            text: "Environment"
                            font.weight: Theme.fontWeightSemiBold
                            font.pixelSize: Theme.fontSizeSmall
                            color: Theme.textSecondary
                            Layout.preferredWidth: 130
                        }
                        
                        Label {
                            text: "Template"
                            font.weight: Theme.fontWeightSemiBold
                            font.pixelSize: Theme.fontSizeSmall
                            color: Theme.textSecondary
                            Layout.preferredWidth: 200
                        }
                        
                        Label {
                            text: "Version"
                            font.weight: Theme.fontWeightSemiBold
                            font.pixelSize: Theme.fontSizeSmall
                            color: Theme.textSecondary
                            Layout.preferredWidth: 100
                        }
                        
                        Label {
                            text: "Status"
                            font.weight: Theme.fontWeightSemiBold
                            font.pixelSize: Theme.fontSizeSmall
                            color: Theme.textSecondary
                            Layout.fillWidth: true
                        }
                    }
                }
                
                Rectangle {
                    Layout.fillWidth: true
                    height: 1
                    color: Theme.dividerColor
                }
                
                // Table content
                ListView {
                    id: deploymentList
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    clip: true
                    
                    model: backend ? backend.model : null
                    
                    delegate: ItemDelegate {
                        width: deploymentList.width
                        height: 64
                        
                        background: Rectangle {
                            color: {
                                if (parent.ListView.isCurrentItem) return Theme.alpha(Theme.primary, 0.1)
                                if (parent.hovered) return Theme.gray50
                                return index % 2 ? Theme.surfaceColor : Theme.alpha(Theme.gray50, 0.3)
                            }
                            
                            Behavior on color {
                                ColorAnimation { duration: Theme.animationDurationFast }
                            }
                            
                            Rectangle {
                                visible: parent.parent.ListView.isCurrentItem
                                anchors.left: parent.left
                                width: 4
                                height: parent.height
                                color: Theme.primary
                                radius: 2
                            }
                        }
                        
                        RowLayout {
                            anchors.fill: parent
                            anchors.leftMargin: Theme.spacingMedium
                            anchors.rightMargin: Theme.spacingMedium
                            spacing: Theme.spacingMedium
                            
                            Label {
                                text: model.instanceId
                                font.pixelSize: Theme.fontSizeNormal
                                font.weight: Theme.fontWeightMedium
                                color: Theme.textPrimary
                                elide: Text.ElideRight
                                Layout.preferredWidth: 150
                            }
                            
                            StatusBadge {
                                badgeText: model.environment
                                status: getEnvironmentStatus(model.environment)
                                size: "small"
                                Layout.preferredWidth: 130
                            }
                            
                            Column {
                                spacing: Theme.spacing1
                                Layout.preferredWidth: 200
                                
                                Label {
                                    text: model.template
                                    font.pixelSize: Theme.fontSizeNormal
                                    font.weight: Theme.fontWeightMedium
                                    color: Theme.textPrimary
                                    elide: Text.ElideRight
                                    width: parent.width
                                }
                                
                                Label {
                                    text: "Template"
                                    font.pixelSize: Theme.fontSizeXS
                                    color: Theme.textTertiary
                                }
                            }
                            
                            StatusBadge {
                                badgeText: model.version
                                status: "neutral"
                                outlined: true
                                size: "small"
                                Layout.preferredWidth: 100
                            }
                            
                            Row {
                                spacing: Theme.spacing2
                                Layout.fillWidth: true
                                
                                StatusBadge {
                                    status: getStatusType(model.status)
                                    badgeText: model.status
                                    dot: true
                                    size: "small"
                                }
                            }
                            
                            // Action buttons
                            Row {
                                spacing: Theme.spacing2
                                
                                Rectangle {
                                    width: 32
                                    height: 32
                                    radius: Theme.radiusFull
                                    color: viewMouseArea.containsMouse ? Theme.alpha(Theme.primary, 0.1) : "transparent"
                                    
                                    Text {
                                        anchors.centerIn: parent
                                        text: "👁"
                                        font.pixelSize: Theme.iconSizeSmall
                                    }
                                    
                                    MouseArea {
                                        id: viewMouseArea
                                        anchors.fill: parent
                                        hoverEnabled: true
                                        cursorShape: Qt.PointingHandCursor
                                        onClicked: {
                                            deploymentList.currentIndex = index
                                            viewDetailsDialog.open()
                                        }
                                    }
                                    
                                    Behavior on color {
                                        ColorAnimation { duration: Theme.animationDurationFast }
                                    }
                                }
                                
                                Rectangle {
                                    width: 32
                                    height: 32
                                    radius: Theme.radiusFull
                                    color: deleteMouseArea.containsMouse ? Theme.alpha(Theme.error, 0.1) : "transparent"
                                    
                                    Text {
                                        anchors.centerIn: parent
                                        text: "🗑"
                                        font.pixelSize: Theme.iconSizeSmall
                                    }
                                    
                                    MouseArea {
                                        id: deleteMouseArea
                                        anchors.fill: parent
                                        hoverEnabled: true
                                        cursorShape: Qt.PointingHandCursor
                                        onClicked: {
                                            deploymentList.currentIndex = index
                                            deleteConfirmDialog.open()
                                        }
                                    }
                                    
                                    Behavior on color {
                                        ColorAnimation { duration: Theme.animationDurationFast }
                                    }
                                }
                            }
                        }
                        
                        onClicked: deploymentList.currentIndex = index
                        onDoubleClicked: viewDetailsDialog.open()
                    }
                    
                    ScrollBar.vertical: ScrollBar {
                        policy: ScrollBar.AsNeeded
                        
                        contentItem: Rectangle {
                            implicitWidth: 6
                            radius: 3
                            color: parent.pressed ? Theme.primary : Theme.gray400
                            opacity: parent.active ? 1.0 : 0.5
                            
                            Behavior on color {
                                ColorAnimation { duration: Theme.animationDurationFast }
                            }
                            
                            Behavior on opacity {
                                NumberAnimation { duration: Theme.animationDuration }
                            }
                        }
                    }
                }
            }
        }
        
        // Action bar
        RowLayout {
            Layout.fillWidth: true
            spacing: Theme.spacingMedium
            
            CustomButton {
                text: "View Details"
                iconName: "👁"
                buttonType: "outlined"
                enabled: deploymentList.currentIndex >= 0
                onClicked: viewDetailsDialog.open()
            }
            
            CustomButton {
                text: "Deploy"
                iconName: "deploy"
                buttonType: "success"
                enabled: deploymentList.currentIndex >= 0
                onClicked: {
                    if (backend) {
                        backend.deployDeployment(deploymentList.currentIndex)
                    }
                }
            }
            
            CustomButton {
                text: "Delete"
                iconName: "delete"
                buttonType: "danger"
                enabled: deploymentList.currentIndex >= 0
                onClicked: deleteConfirmDialog.open()
            }
            
            Item { Layout.fillWidth: true }
            
            StatusBadge {
                status: "success"
                badgeText: backend ? backend.status : "Ready"
                dot: true
                size: "small"
            }
        }
    }
    
    // Modern Details dialog
    Dialog {
        id: viewDetailsDialog
        title: "Deployment Details"
        width: 600
        height: 500
        x: (parent.width - width) / 2
        y: (parent.height - height) / 2
        modal: true
        
        background: Rectangle {
            color: Theme.surfaceColor
            radius: Theme.radiusLarge
            
            Shadow {
                anchors.fill: parent
                elevation: 3
                shadowRadius: parent.radius
            }
        }
        
        header: Rectangle {
            height: 60
            color: Theme.primary
            radius: Theme.radiusLarge
            
            Rectangle {
                anchors.bottom: parent.bottom
                anchors.left: parent.left
                anchors.right: parent.right
                height: parent.height / 2
                color: parent.color
            }
            
            RowLayout {
                anchors.fill: parent
                anchors.margins: Theme.spacingMedium
                
                Label {
                    text: "Deployment Details"
                    font.pixelSize: Theme.fontSizeLarge
                    font.weight: Theme.fontWeightBold
                    color: "white"
                }
                
                Item { Layout.fillWidth: true }
                
                Rectangle {
                    width: 32
                    height: 32
                    radius: Theme.radiusFull
                    color: closeMouseArea.containsMouse ? Theme.alpha("white", 0.2) : "transparent"
                    
                    Text {
                        anchors.centerIn: parent
                        text: "✕"
                        color: "white"
                        font.pixelSize: Theme.fontSizeMedium
                    }
                    
                    MouseArea {
                        id: closeMouseArea
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: viewDetailsDialog.close()
                    }
                }
            }
        }
        
        ScrollView {
            anchors.fill: parent
            contentWidth: availableWidth
            
            Label {
                width: parent.width
                text: backend && deploymentList.currentIndex >= 0 
                    ? backend.getDeploymentDetails(deploymentList.currentIndex)
                    : ""
                textFormat: Text.RichText
                wrapMode: Text.WordWrap
                color: Theme.textPrimary
                padding: Theme.spacingMedium
            }
        }
    }
    
    // Modern Delete confirmation dialog
    Dialog {
        id: deleteConfirmDialog
        title: "Confirm Deletion"
        width: 400
        height: 200
        x: (parent.width - width) / 2
        y: (parent.height - height) / 2
        modal: true
        
        background: Rectangle {
            color: Theme.surfaceColor
            radius: Theme.radiusLarge
            border.width: 2
            border.color: Theme.error
            
            Shadow {
                anchors.fill: parent
                elevation: 3
                shadowRadius: parent.radius
            }
        }
        
        ColumnLayout {
            anchors.fill: parent
            spacing: Theme.spacingMedium
            
            Rectangle {
                Layout.preferredWidth: 48
                Layout.preferredHeight: 48
                radius: Theme.radiusFull
                color: Theme.alpha(Theme.error, 0.1)
                Layout.alignment: Qt.AlignHCenter
                
                Text {
                    anchors.centerIn: parent
                    text: "⚠"
                    font.pixelSize: 28
                    color: Theme.error
                }
            }
            
            Label {
                text: "Delete Deployment?"
                font.pixelSize: Theme.fontSizeLarge
                font.weight: Theme.fontWeightBold
                color: Theme.textPrimary
                Layout.alignment: Qt.AlignHCenter
            }
            
            Label {
                text: "Are you sure you want to delete this deployment?\nThis action cannot be undone."
                wrapMode: Text.WordWrap
                horizontalAlignment: Text.AlignHCenter
                color: Theme.textSecondary
                Layout.fillWidth: true
                Layout.alignment: Qt.AlignHCenter
            }
            
            Item { Layout.fillHeight: true }
            
            RowLayout {
                Layout.fillWidth: true
                spacing: Theme.spacingMedium
                
                CustomButton {
                    text: "Cancel"
                    buttonType: "outlined"
                    Layout.fillWidth: true
                    onClicked: deleteConfirmDialog.close()
                }
                
                CustomButton {
                    text: "Delete"
                    buttonType: "danger"
                    Layout.fillWidth: true
                    onClicked: {
                        if (backend) {
                            backend.deleteDeployment(deploymentList.currentIndex)
                        }
                        deleteConfirmDialog.close()
                    }
                }
            }
        }
    }
    
    // New Deployment dialog
    Dialog {
        id: newDeploymentDialog
        title: "Create New Deployment"
        width: 600
        height: 500
        x: (parent.width - width) / 2
        y: (parent.height - height) / 2
        modal: true
        
        background: Rectangle {
            color: Theme.surfaceColor
            radius: Theme.radiusLarge
            
            Shadow {
                anchors.fill: parent
                elevation: 3
                shadowRadius: parent.radius
            }
        }
        
        header: Rectangle {
            height: 60
            color: Theme.primary
            radius: Theme.radiusLarge
            
            Rectangle {
                anchors.bottom: parent.bottom
                anchors.left: parent.left
                anchors.right: parent.right
                height: parent.height / 2
                color: parent.color
            }
            
            RowLayout {
                anchors.fill: parent
                anchors.margins: Theme.spacingMedium
                spacing: Theme.spacing3
                
                Text {
                    text: "🚀"
                    font.pixelSize: Theme.iconSizeLarge
                }
                
                Label {
                    text: "Create New Deployment"
                    font.pixelSize: Theme.fontSizeLarge
                    font.weight: Theme.fontWeightBold
                    color: "white"
                    Layout.fillWidth: true
                }
                
                Rectangle {
                    width: 32
                    height: 32
                    radius: Theme.radiusFull
                    color: Theme.alpha("white", 0.2)
                    
                    Text {
                        anchors.centerIn: parent
                        text: "✕"
                        font.pixelSize: Theme.iconSize
                        color: "white"
                    }
                    
                    MouseArea {
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        onClicked: newDeploymentDialog.close()
                    }
                }
            }
        }
        
        contentItem: ColumnLayout {
            spacing: Theme.spacingMedium
            
            ScrollView {
                Layout.fillWidth: true
                Layout.fillHeight: true
                clip: true
                
                ColumnLayout {
                    width: parent.parent.width
                    spacing: Theme.spacingMedium
                    
                    // Instance ID
                    Column {
                        spacing: Theme.spacing2
                        Layout.fillWidth: true
                        
                        Label {
                            text: "Instance ID *"
                            font.weight: Theme.fontWeightSemiBold
                            color: Theme.textPrimary
                        }
                        
                        TextField {
                            id: instanceIdField
                            width: parent.width
                            placeholderText: "e.g., my-app-prod-001"
                            color: Theme.textPrimary
                            
                            background: Rectangle {
                                color: Theme.surfaceColor
                                border.width: instanceIdField.activeFocus ? 2 : 1
                                border.color: instanceIdField.activeFocus ? Theme.primary : Theme.borderColor
                                radius: Theme.radiusNormal
                            }
                        }
                    }
                    
                    // Environment
                    Column {
                        spacing: Theme.spacing2
                        Layout.fillWidth: true
                        
                        Label {
                            text: "Environment *"
                            font.weight: Theme.fontWeightSemiBold
                            color: Theme.textPrimary
                        }
                        
                        ComboBox {
                            id: environmentField
                            width: parent.width
                            model: ["development", "staging", "production", "dr-site"]
                            
                            background: Rectangle {
                                color: Theme.surfaceColor
                                border.color: Theme.borderColor
                                border.width: 1
                                radius: Theme.radiusNormal
                            }
                            
                            contentItem: Text {
                                leftPadding: Theme.spacing3
                                text: environmentField.displayText
                                color: Theme.textPrimary
                                verticalAlignment: Text.AlignVCenter
                            }
                        }
                    }
                    
                    // Template
                    Column {
                        spacing: Theme.spacing2
                        Layout.fillWidth: true
                        
                        Label {
                            text: "Template *"
                            font.weight: Theme.fontWeightSemiBold
                            color: Theme.textPrimary
                        }
                        
                        ComboBox {
                            id: templateField
                            width: parent.width
                            model: ["Docker Compose", "Kubernetes", "Terraform", "Ansible"]
                            
                            background: Rectangle {
                                color: Theme.surfaceColor
                                border.color: Theme.borderColor
                                border.width: 1
                                radius: Theme.radiusNormal
                            }
                            
                            contentItem: Text {
                                leftPadding: Theme.spacing3
                                text: templateField.displayText
                                color: Theme.textPrimary
                                verticalAlignment: Text.AlignVCenter
                            }
                        }
                    }
                    
                    // Version
                    Column {
                        spacing: Theme.spacing2
                        Layout.fillWidth: true
                        
                        Label {
                            text: "Version"
                            font.weight: Theme.fontWeightSemiBold
                            color: Theme.textPrimary
                        }
                        
                        TextField {
                            id: versionField
                            width: parent.width
                            placeholderText: "e.g., 1.0.0"
                            text: "1.0.0"
                            color: Theme.textPrimary
                            
                            background: Rectangle {
                                color: Theme.surfaceColor
                                border.width: versionField.activeFocus ? 2 : 1
                                border.color: versionField.activeFocus ? Theme.primary : Theme.borderColor
                                radius: Theme.radiusNormal
                            }
                        }
                    }
                    
                    // Description
                    Column {
                        spacing: Theme.spacing2
                        Layout.fillWidth: true
                        
                        Label {
                            text: "Description"
                            font.weight: Theme.fontWeightSemiBold
                            color: Theme.textPrimary
                        }
                        
                        TextArea {
                            id: descriptionField
                            width: parent.width
                            height: 80
                            placeholderText: "Optional description for this deployment..."
                            color: Theme.textPrimary
                            wrapMode: TextArea.Wrap
                            
                            background: Rectangle {
                                color: Theme.surfaceColor
                                border.width: descriptionField.activeFocus ? 2 : 1
                                border.color: descriptionField.activeFocus ? Theme.primary : Theme.borderColor
                                radius: Theme.radiusNormal
                            }
                        }
                    }
                }
            }
            
            // Action buttons
            RowLayout {
                Layout.fillWidth: true
                spacing: Theme.spacing3
                
                Item { Layout.fillWidth: true }
                
                CustomButton {
                    text: "Cancel"
                    buttonType: "outlined"
                    onClicked: newDeploymentDialog.close()
                }
                
                CustomButton {
                    text: "Create Deployment"
                    buttonType: "primary"
                    iconName: "check"
                    enabled: instanceIdField.text.length > 0
                    onClicked: {
                        if (backend) {
                            // Call backend to create deployment
                            console.log("Creating deployment:", instanceIdField.text, 
                                       environmentField.currentText, 
                                       templateField.currentText,
                                       versionField.text)
                        }
                        newDeploymentDialog.close()
                    }
                }
            }
        }
    }
    
    // Helper functions
    function getEnvironmentStatus(env) {
        switch(env) {
            case "production": return "error"
            case "staging": return "warning"
            case "development": return "success"
            case "dr-site": return "info"
            default: return "neutral"
        }
    }
    
    function getStatusType(status) {
        if (status.toLowerCase().includes("running") || status.toLowerCase().includes("active")) return "success"
        if (status.toLowerCase().includes("pending") || status.toLowerCase().includes("deploying")) return "warning"
        if (status.toLowerCase().includes("failed") || status.toLowerCase().includes("error")) return "error"
        return "info"
    }
    
    // Initialize
    Component.onCompleted: {
        if (backend) backend.refresh("all")
    }
}
