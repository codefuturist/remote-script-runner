#!/usr/bin/env python3
"""Test script to verify GUI can launch."""

import sys
import os

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

print("🔍 Testing IaC Manager GUI...")
print(f"Python: {sys.version}")
print(f"Path: {sys.path[:3]}")

try:
    print("\n1️⃣ Testing PyQt6 import...")
    from PyQt6.QtWidgets import QApplication
    print("   ✅ PyQt6 imported successfully")
    
    print("\n2️⃣ Testing iac_manager.config import...")
    from iac_manager.config import load_config, find_repo_root
    print("   ✅ Config imported successfully")
    
    print("\n3️⃣ Testing iac_manager.gui.windows import...")
    from iac_manager.gui.windows.main_window import MainWindow
    print("   ✅ MainWindow imported successfully")
    
    print("\n4️⃣ Testing iac_manager.gui.main import...")
    from iac_manager.gui.main import main
    print("   ✅ GUI main imported successfully")
    
    print("\n✅ All imports successful!")
    print("\n📝 To run the GUI:")
    print("   cd /Users/colin/Developer/Projects/personal/iac-catalog")
    print("   iac-gui")
    print("\nOr:")
    print("   python -m iac_manager.gui.main")
    
except ImportError as e:
    print(f"\n❌ Import error: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)
except Exception as e:
    print(f"\n❌ Error: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)
