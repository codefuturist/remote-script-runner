# Example: Simple Web Application Deployment

## Overview

This example demonstrates deploying a simple Nginx web server to a single server in the development environment.

**What you'll learn:**

- How to use a template from the catalog
- How to configure a deployment
- How to commit and deploy via GitOps
- How runtime and infrastructure work together

## Prerequisites

- Repository cloned and initialized
- Development environment configured
- At least one server defined in `infrastructure/development/targets/servers.yml`

## Step-by-Step Guide

### 1. Check Available Servers

First, let's see what servers are available in development:

```bash
cat infrastructure/development/targets/servers.yml
```

You should see something like:

```yaml
servers:
  - id: dev-server-01
    hostname: dev01.example.com
    ip: 192.168.1.10
    ssh_user: deploy
    tags:
      - development
      - web
```

### 2. Browse Available Templates

Check what web server templates are available:

```bash
ls catalog/docker-compose/web-servers/
```

You'll see:

```text
nginx/
apache/
caddy/
```

Let's use Nginx!

### 3. Review the Template

Look at what the Nginx template provides:

```bash
cat catalog/docker-compose/web-servers/nginx/README.md
cat catalog/docker-compose/web-servers/nginx/docker-compose.yml
```

### 4. Configure Your Deployment

Use the CLI tool to configure a deployment:

```bash
./scripts/deploy/configure.sh \
  --template catalog/docker-compose/web-servers/nginx \
  --instance my-nginx-server \
  --environment development \
  --target dev-server-01 \
  --param domain=dev.example.com \
  --param port=8080
```

**What happens:**

The CLI creates these files:

```text
runtime/development/deployments/my-nginx-server/
├── manifest.yml           # Tracks template source and version
├── docker-compose.yml     # Configured Nginx stack
├── .env                   # Environment variables
└── target.yml             # Points to dev-server-01
```

### 5. Review Generated Files

Check what was created:

```bash
ls -la runtime/development/deployments/my-nginx-server/
cat runtime/development/deployments/my-nginx-server/manifest.yml
cat runtime/development/deployments/my-nginx-server/docker-compose.yml
cat runtime/development/deployments/my-nginx-server/target.yml
```

**manifest.yml:**

```yaml
name: my-nginx-server
template: catalog/docker-compose/web-servers/nginx
version: 1.0.0
environment: development
created: 2025-11-05T12:00:00Z
```

**docker-compose.yml:**

```yaml
version: '3.8'
services:
  nginx:
    image: nginx:latest
    ports:
      - "${PORT}:80"
    environment:
      - DOMAIN=${DOMAIN}
    volumes:
      - ./html:/usr/share/nginx/html
```

**.env:**

```bash
DOMAIN=dev.example.com
PORT=8080
```

**target.yml:**

```yaml
targets:
  - type: docker-compose
    host: dev-server-01
    inventory: ../../infrastructure/development/targets/servers.yml
```

### 6. Commit to Git

Now commit the deployment:

```bash
# Stage the files
git add runtime/development/deployments/my-nginx-server/

# Commit with descriptive message
git commit -m "feat: deploy nginx server to development"

# Push to trigger GitOps
git push
```

### 7. GitOps Takes Over

The GitOps agent:

1. Detects the new deployment in `runtime/development/deployments/`
2. Reads `manifest.yml` to understand what was deployed
3. Reads `target.yml` to know where to deploy
4. Looks up `dev-server-01` in `infrastructure/development/targets/servers.yml`
5. Connects to the server and deploys the Docker Compose stack
6. Records the deployment in `.iac-system/deployments/state/`

### 8. Verify Deployment

Check the deployment status:

```bash
./scripts/manage/status.sh --instance my-nginx-server --environment development
```

Or manually:

```bash
ssh deploy@dev01.example.com "docker-compose -f /opt/deployments/my-nginx-server/docker-compose.yml ps"
```

### 9. Test the Service

Visit your web server:

```bash
curl http://dev01.example.com:8080
```

You should see the Nginx welcome page!

## What Just Happened?

### The Flow

```text
1. Template (catalog/docker-compose/web-servers/nginx)
        ↓
2. CLI Configure (creates instance)
        ↓
3. Instance Files (runtime/development/deployments/my-nginx-server/)
        ↓
4. Git Commit & Push
        ↓
5. GitOps Agent (detects change)
        ↓
6. Lookup Target (infrastructure/development/targets/servers.yml)
        ↓
7. Deploy (to dev-server-01)
        ↓
8. Running Service! 🎉
```

### Key Relationships

**Template → Instance:**

- Template is reusable, generic
- Instance is configured, specific

**Instance → Target:**

- Instance defines WHAT to deploy
- Target defines WHERE to deploy

**Environment Isolation:**

- Development deployment
- On development server
- Using development config
- No risk to production!

## Making Changes

### Update Configuration

To change the port:

```bash
# Edit the .env file
vim runtime/development/deployments/my-nginx-server/.env
# Change: PORT=8080 → PORT=9090

# Commit the change
git add runtime/development/deployments/my-nginx-server/.env
git commit -m "chore: change nginx port to 9090"
git push
```

GitOps agent will detect the change and redeploy!

### Remove Deployment

To remove the deployment:

```bash
./scripts/deploy/remove.sh \
  --instance my-nginx-server \
  --environment development

git add runtime/development/deployments/
git commit -m "chore: remove my-nginx-server from development"
git push
```

## Next Steps

Now that you understand the basics, try:

1. **[02-multi-tier-app](../02-multi-tier-app/)** - Deploy an app with database
2. **[03-kubernetes-deployment](../03-kubernetes-deployment/)** - Deploy to Kubernetes
3. Deploy to staging environment
4. Create your own custom template

## Troubleshooting

### Deployment not showing up?

```bash
# Check GitOps agent logs
cat .iac-system/gitops/agent.log

# Verify files exist
ls runtime/development/deployments/my-nginx-server/

# Check target is valid
cat infrastructure/development/targets/servers.yml | grep dev-server-01
```

### Can't connect to server?

```bash
# Test SSH connection
ssh deploy@dev01.example.com

# Check server is in inventory
cat infrastructure/development/targets/servers.yml
```

### Service not accessible?

```bash
# Check if container is running
ssh deploy@dev01.example.com "docker ps"

# Check logs
ssh deploy@dev01.example.com "docker logs my-nginx-server_nginx_1"
```

## Related Documentation

- [STRUCTURE.md](../../STRUCTURE.md) - Understanding the repository layout
- [catalog/README.md](../../catalog/README.md) - How templates work
- [runtime/README.md](../../runtime/README.md) - Deployments explained
- [infrastructure/README.md](../../infrastructure/README.md) - Infrastructure config
