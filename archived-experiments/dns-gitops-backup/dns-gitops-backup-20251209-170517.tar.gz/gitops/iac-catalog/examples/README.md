# Examples - Working Examples

## Purpose

Complete, working examples demonstrating how to use the IaC Catalog system. These examples show end-to-end workflows from template selection to deployment.

## Available Examples

### 01 - Simple Web Application

**[01-simple-webapp/](./01-simple-webapp/)**

A basic single-server deployment demonstrating:
- Template selection
- Instance configuration
- GitOps deployment workflow
- Basic troubleshooting

**Best for:** First-time users, learning the basics.

**Time to complete:** 15-20 minutes

### 02 - GitOps Deployment with IaC CLI

**[02-gitops-deployment/](./02-gitops-deployment/)**

Complete GitOps workflow using the IaC CLI tool:
- Using IaC CLI commands for deployments
- Multi-environment deployments (dev/staging/prod)
- Flux CD GitOps integration
- Secrets management
- Git commit and push workflows
- Deployment monitoring

**Best for:** Learning the IaC CLI tool, GitOps workflows, multi-environment deployments.

**Time to complete:** 20-30 minutes

**Quick start:**
```bash
cd examples/02-gitops-deployment
./demo.sh           # Interactive demo
./quick-start.sh    # Quick walkthrough
```

### 03 - Docker Compose with Jinja2 Templates

**[03-docker-compose-wordpress/](./03-docker-compose-wordpress/)**

Deploy Docker Compose applications using Jinja2 templates:
- WordPress + MySQL stack deployment
- Jinja2 template rendering
- Environment-specific configurations (dev/staging/prod)
- Docker Compose workflow
- Template variable management
- Multi-instance deployments

**Best for:** Docker Compose users, learning Jinja2 templating, container deployments.

**Time to complete:** 25-35 minutes

**Quick start:**
```bash
cd examples/03-docker-compose-wordpress
./deploy-demo.sh    # Interactive deployment demo
```

### 04 - Multi-Tier Application (Coming Soon)

**[04-multi-tier-app/](./04-multi-tier-app/)**

A multi-server deployment with:
- Web server + Database
- Multi-server targeting
- Environment configuration
- Service dependencies

**Best for:** Understanding multi-component deployments.

### 05 - Kubernetes Deployment (Coming Soon)

**[03-kubernetes-deployment/](./03-kubernetes-deployment/)**

Kubernetes-based deployment showing:
- Helm charts
- Kubernetes manifests
- Cluster targeting
- Rolling updates

**Best for:** Kubernetes users.

## Quick Start

### For Complete Beginners

1. Start with **[01-simple-webapp](./01-simple-webapp/)**
2. Follow the step-by-step README
3. Complete the example from start to finish
4. Understand the full workflow

### For Experienced Users

- Browse examples relevant to your use case
- Use as reference implementations
- Adapt patterns to your needs

## Example Structure

Each example follows this structure:

```text
[example-name]/
├── README.md                     # Step-by-step walkthrough
├── template/                     # Template(s) used
│   ├── docker-compose.yml
│   └── template.yml
├── deployment/                   # Example deployment config
│   ├── manifest.yml
│   ├── docker-compose.yml
│   ├── .env
│   └── target.yml
└── screenshots/ (optional)       # Visual aids
```

## Learning Path

### Path 1: From Zero to First Deployment

1. **Read [STRUCTURE.md](../STRUCTURE.md)** - Understand the layout
2. **Complete [01-simple-webapp](./01-simple-webapp/)** - First deployment
3. **Read [catalog/README.md](../catalog/README.md)** - Find more templates
4. **Create your own deployment** - Apply what you learned

### Path 2: Specific Technology

**Docker Compose Users:**
1. [01-simple-webapp](./01-simple-webapp/) - Basic Docker Compose
2. [02-multi-tier-app](./02-multi-tier-app/) - Multi-container stacks
3. Browse [catalog/containers/docker/](../catalog/containers/docker/)

**Kubernetes Users:**
1. [03-kubernetes-deployment](./03-kubernetes-deployment/) - K8s basics
2. Browse [catalog/containers/kubernetes/](../catalog/containers/kubernetes/)

**Terraform Users:**
1. Browse [catalog/cloud/](../catalog/cloud/)
2. Check [docs/guides/](../docs/guides/) for Terraform-specific guides

## What You'll Learn

### From All Examples

- How to find and use templates from the catalog
- How to configure template instances
- How to use the CLI tools
- How GitOps deployment works
- How to troubleshoot issues
- How environments work
- How inventory works

### Example-Specific Learning

**01-simple-webapp:**
- Basic workflow
- Single-server deployment
- Environment variables
- Target configuration

**02-multi-tier-app:**
- Multi-server deployments
- Service dependencies
- Server groups
- Environment overrides

**03-kubernetes-deployment:**
- Kubernetes manifests
- Helm charts
- Cluster targeting
- Rolling updates

## Prerequisites

Before starting any example:

1. **Repository cloned and initialized**

```bash
git clone https://github.com/codefuturist/iac-catalog.git
cd iac-catalog
```

2. **Dependencies installed** (varies by example)

```bash
# Common dependencies
- Git
- Docker (for Docker Compose examples)
- kubectl (for Kubernetes examples)
- terraform (for Terraform examples)
```

3. **At least one environment configured**

```bash
# Check if environments exist
ls environments/
ls inventory/
```

## Using Examples

### Option 1: Follow Along (Recommended)

Read the example README and execute commands step-by-step:

```bash
cd examples/01-simple-webapp
cat README.md
# Follow the instructions
```

### Option 2: Quick Copy

Copy the example configuration and adapt it:

```bash
# Copy deployment config
cp -r examples/01-simple-webapp/deployment/* deployments/development/my-app/

# Modify as needed
vim deployments/development/my-app/manifest.yml
```

### Option 3: Reference

Use examples as reference while building your own:

```bash
# Keep example open while working
cat examples/01-simple-webapp/README.md

# Apply patterns to your deployment
./scripts/cli/configure.sh --template ... --instance my-app
```

## Example Checklist

When completing an example, verify:

- [ ] I understand what the template does
- [ ] I can configure an instance from the template
- [ ] I can review the generated files
- [ ] I understand the GitOps workflow
- [ ] I can troubleshoot basic issues
- [ ] I can adapt this to my own use case

## Contributing Examples

Have a great example to share? Contributions welcome!

### Example Contribution Guidelines

1. **Clear objective** - What does this example teach?
2. **Complete documentation** - Step-by-step README
3. **Self-contained** - Works without external dependencies where possible
4. **Tested** - Verified in multiple environments
5. **Clean** - No secrets, no sensitive data

See [CONTRIBUTING.md](../CONTRIBUTING.md) for details.

## Common Pitfalls

### "Template not found"

- Verify template path: `ls -la catalog/path/to/template/`
- Check template.yml exists

### "Target not found"

- Check inventory: `cat inventory/development/servers.yml`
- Verify server ID matches

### "Environment not configured"

- Check environment exists: `ls environments/development/`
- Check defaults.yml exists

### "GitOps not deploying"

- Check GitOps agent is running
- Check logs: `.gitops/agent.log`
- Verify deployment files are committed and pushed

## Getting Help

### While following examples:

1. **Read error messages carefully**
2. **Check the troubleshooting section** in example README
3. **Verify prerequisites** are met
4. **Check logs** in `.deployments/` and `.gitops/`

### Still stuck?

- Check [docs/guides/troubleshooting/](../docs/guides/troubleshooting/)
- Review [STRUCTURE.md](../STRUCTURE.md)
- Look at similar deployments in `deployments/`

## Related Documentation

- **[STRUCTURE.md](../STRUCTURE.md)** - Repository structure guide
- **[QUICKSTART.md](../QUICKSTART.md)** - Quick start guide
- **[catalog/README.md](../catalog/README.md)** - Template catalog
- **[docs/ARCHITECTURE.md](../docs/ARCHITECTURE.md)** - Architecture details
- **[docs/guides/](../docs/guides/)** - Detailed guides

## What's Next?

After completing examples:

1. **Explore the catalog** - [catalog/](../catalog/)
2. **Try your own deployment** - Use what you learned
3. **Read architecture docs** - [docs/ARCHITECTURE.md](../docs/ARCHITECTURE.md)
4. **Join the community** - Contribute your own examples!

---

**Start here:** [01-simple-webapp](./01-simple-webapp/) - Your first deployment in 15 minutes!
