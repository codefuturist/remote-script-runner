# Example 05: Platform Migration - Docker Compose to Kubernetes

## 📋 Overview

This example demonstrates how to migrate a Docker Compose deployment to Kubernetes using the `iac convert` command. The conversion automatically adds production-ready features like resource limits, health checks, and ingress configuration.

## 🎯 What You'll Learn

- How to convert Docker Compose files to Kubernetes manifests
- Understanding the conversion enhancements applied
- Best practices for Kubernetes deployments
- How to deploy the converted manifests

## 📁 Example Application

We'll convert a simple web application with:

- **Web App**: Python/Flask application
- **Database**: PostgreSQL database
- **Redis**: Cache layer
- **Persistent Storage**: Data volumes

## 🚀 Quick Start

### Step 1: Review the Docker Compose File

```bash
cd examples/05-platform-migration
cat source/docker-compose.yml
```

### Step 2: Convert to Kubernetes

```bash
# Basic conversion
iac convert compose-to-k8s \
  --input source/docker-compose.yml \
  --output target/kubernetes

# With custom configuration
iac convert compose-to-k8s \
  --input source/docker-compose.yml \
  --output target/kubernetes \
  --namespace production \
  --storage-class gp3
```

### Step 3: Review Generated Manifests

```bash
cd target/kubernetes
ls -la

# Files generated:
# - app-deployment.yaml      (with resource limits, health checks, security)
# - app-service.yaml
# - db-deployment.yaml
# - db-service.yaml
# - db-pvc.yaml
# - redis-deployment.yaml
# - redis-service.yaml
# - app-ingress.yaml         (with TLS)
```

### Step 4: Deploy to Kubernetes

```bash
# Create namespace
kubectl create namespace production

# Apply manifests
kubectl apply -n production -f target/kubernetes/

# Monitor deployment
kubectl get pods -n production -w
```

## 🔍 What Gets Added

The conversion process automatically adds:

### 1. Resource Limits

```yaml
resources:
  requests:
    cpu: 100m
    memory: 128Mi
  limits:
    cpu: 500m
    memory: 512Mi
```

### 2. Health Checks

```yaml
livenessProbe:
  httpGet:
    path: /health
    port: 80
  initialDelaySeconds: 30
  periodSeconds: 10

readinessProbe:
  httpGet:
    path: /health
    port: 80
  initialDelaySeconds: 5
  periodSeconds: 5
```

### 3. Security Context

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  fsGroup: 1000
  capabilities:
    drop:
      - ALL
```

### 4. Ingress with TLS

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  annotations:
    cert-manager.io/cluster-issuer: letsencrypt-prod
    kubernetes.io/ingress.class: nginx
spec:
  tls:
    - hosts:
        - app.example.com
      secretName: app-tls
  rules:
    - host: app.example.com
      http:
        paths:
          - path: /
            pathType: Prefix
            backend:
              service:
                name: app
                port:
                  number: 80
```

### 5. Standard Labels

```yaml
labels:
  app: myapp
  app.kubernetes.io/name: myapp
  app.kubernetes.io/managed-by: iac-cli
```

## 📊 Comparison: Before and After

### Docker Compose (Before)

```yaml
services:
  app:
    image: myapp:latest
    ports:
      - "8080:80"
    environment:
      - DB_HOST=db
    volumes:
      - app_data:/app/data
```

### Kubernetes (After)

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: app
  labels:
    app: app
    app.kubernetes.io/name: app
    app.kubernetes.io/managed-by: iac-cli
spec:
  replicas: 1
  selector:
    matchLabels:
      app: app
  template:
    metadata:
      labels:
        app: app
    spec:
      securityContext:
        runAsNonRoot: true
        runAsUser: 1000
        fsGroup: 1000
      containers:
        - name: app
          image: myapp:latest
          ports:
            - containerPort: 80
          env:
            - name: DB_HOST
              value: db
          resources:
            requests:
              cpu: 100m
              memory: 128Mi
            limits:
              cpu: 500m
              memory: 512Mi
          livenessProbe:
            httpGet:
              path: /health
              port: 80
            initialDelaySeconds: 30
            periodSeconds: 10
          readinessProbe:
            httpGet:
              path: /health
              port: 80
            initialDelaySeconds: 5
            periodSeconds: 5
          volumeMounts:
            - name: app-data
              mountPath: /app/data
      volumes:
        - name: app-data
          persistentVolumeClaim:
            claimName: app-data-pvc
```

## 🛠️ Customization

### Disable Specific Enhancements

While the CLI doesn't yet support disabling individual enhancements via flags, you can:

1. Convert with defaults
2. Edit generated manifests as needed
3. Commit to version control

### Adjust Resource Limits

Edit the generated deployment files:

```bash
# Edit resource limits
vi target/kubernetes/app-deployment.yaml

# Update:
resources:
  requests:
    cpu: 200m      # Increased
    memory: 256Mi  # Increased
  limits:
    cpu: 1000m
    memory: 1Gi
```

### Configure Ingress Host

```bash
# Update ingress host
vi target/kubernetes/app-ingress.yaml

# Change:
rules:
  - host: myapp.example.com  # Your actual domain
```

## 📝 Best Practices

### 1. Review Before Deploying

Always review generated manifests before deploying:

```bash
# Validate syntax
kubectl apply --dry-run=client -f target/kubernetes/

# Review each file
for file in target/kubernetes/*.yaml; do
  echo "=== $file ==="
  cat "$file"
done
```

### 2. Update Secrets

Never commit secrets to version control:

```bash
# Create secrets separately
kubectl create secret generic app-secrets \
  --from-literal=db_password=your-secure-password \
  -n production

# Or from file
kubectl create secret generic app-secrets \
  --from-env-file=.env.production \
  -n production
```

### 3. Configure Storage Class

Ensure your cluster has the storage class:

```bash
# List available storage classes
kubectl get storageclasses

# If needed, create or specify correct class
# Edit PVC files or use --storage-class flag
```

### 4. Test in Staging First

```bash
# Convert for staging
iac convert compose-to-k8s \
  --input source/docker-compose.yml \
  --output target/staging \
  --namespace staging

# Deploy to staging
kubectl apply -n staging -f target/staging/

# Test thoroughly before production
```

## 🐛 Troubleshooting

### Kompose Not Installed

```bash
# macOS
brew install kompose

# Linux
curl -L https://github.com/kubernetes/kompose/releases/download/v1.31.2/kompose-linux-amd64 -o /tmp/kompose
chmod +x /tmp/kompose
sudo mv /tmp/kompose /usr/local/bin/
```

### Conversion Warnings

Some Docker Compose features may not translate directly:

- **Build contexts**: Replace with pre-built images
- **Host networking**: Use Services with NodePort/LoadBalancer
- **Privileged mode**: Requires SecurityContext adjustments

### Deployment Failures

```bash
# Check pod status
kubectl get pods -n production

# View logs
kubectl logs -n production deployment/app

# Describe pod for events
kubectl describe pod -n production <pod-name>

# Common issues:
# - ImagePullBackOff: Check image exists and credentials
# - CrashLoopBackOff: Check health checks and application logs
# - Pending: Check resource availability and PVC binding
```

## 📚 Additional Resources

- [Kubernetes Documentation](https://kubernetes.io/docs/)
- [Kompose Documentation](https://kompose.io/)
- [Cert-Manager](https://cert-manager.io/)
- [IaC CLI Platform Guide](../../iac-cli/PLATFORM_CONFIG_GUIDE.md)

## 🎓 Next Steps

1. **Try the migration**: Convert your own Docker Compose files
2. **Customize**: Adjust resource limits and configurations
3. **Integrate**: Use with GitOps workflows
4. **Scale**: Add horizontal pod autoscaling
5. **Monitor**: Set up Prometheus and Grafana

## 💡 Tips

- Start with development environment conversions
- Test conversions in isolated namespaces
- Use `--dry-run` to preview before creating files
- Version control your Kubernetes manifests
- Document any manual adjustments needed
- Consider using Kustomize for environment-specific overlays

---

**Questions or Issues?**

Open an issue in the repository or consult the full implementation plan in `iac-cli/KOMPOSE_IMPLEMENTATION_PLAN.md`.
