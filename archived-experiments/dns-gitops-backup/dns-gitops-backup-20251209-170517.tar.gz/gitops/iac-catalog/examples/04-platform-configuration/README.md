# Platform Configuration Example

This example demonstrates the new platform-aware deployment configuration features.

## Overview

The IaC CLI now supports platform-specific configuration for:
- Docker Compose (development)
- Docker Swarm (production on-premises)
- Kubernetes (cloud/enterprise)

Each platform has smart defaults and customization options for:
- Networking and ports
- Secrets management
- Volume storage
- Ingress/load balancing
- Database deployment

## Quick Start

### Using the Wizard

The easiest way to explore platform configuration:

```bash
cd /path/to/iac-catalog
iac deploy wizard
```

Follow the prompts to:
1. Select a template (e.g., `catalog/containers/erpnext`)
2. Choose instance name (e.g., `erp-demo`)
3. Select environment (`development`)
4. Choose platform (`docker-compose`)
5. Use defaults or customize

### Example 1: Docker Compose Development Setup

```bash
iac deploy configure-platform \
  --template catalog/containers/erpnext \
  --instance erp-dev \
  --environment development \
  --platform docker-compose \
  --use-defaults
```

**Result:** Creates a Docker Compose deployment with:
- Bridge networking
- Environment file secrets (.env)
- Local bind mounts for development
- Internal MariaDB container
- Direct port mapping (no ingress)

### Example 2: Docker Swarm Production Setup

```bash
iac deploy wizard

# Selections:
# Template: catalog/containers/erpnext
# Instance: erp-prod
# Environment: production
# Platform: docker-swarm
# Customize configuration:
#   - Enable ingress (Traefik)
#   - Enable TLS (Let's Encrypt)
#   - Configure database placement
```

**Result:** Creates a Docker Swarm deployment with:
- Overlay network
- Docker secrets for sensitive data
- Traefik ingress with automatic TLS
- MariaDB with node placement constraints
- Automated backups

### Example 3: Kubernetes Cloud Deployment

```bash
iac deploy wizard

# Selections:
# Template: catalog/containers/erpnext
# Instance: erp-cloud
# Environment: production
# Platform: kubernetes
# Customize configuration:
#   - Database: Managed (AWS RDS)
#   - Ingress: nginx with cert-manager
#   - Volumes: aws-ebs storage class
#   - Secrets: k8s-secret
```

**Result:** Creates a Kubernetes deployment with:
- ClusterIP service
- Kubernetes secrets with cert-manager
- PersistentVolumeClaims with EBS
- nginx-ingress with automatic TLS
- Connection to managed RDS database

## Configuration Files

### Platform Config Example (Kubernetes)

```yaml
# platform-config.yml
platform: kubernetes

networking:
  type: LoadBalancer
  ports:
    - container: 80
      host: 80
      protocol: tcp
    - container: 443
      host: 443
      protocol: tcp

secrets:
  strategy: k8s-secret
  provider: local
  definitions:
    - name: db_password
      source: DB_PASSWORD
      mode: "0400"
      uid: 1000
      gid: 1000
    - name: admin_password
      source: ADMIN_PASSWORD
      mode: "0400"
      uid: 1000
      gid: 1000

volumes:
  strategy: aws-ebs
  definitions:
    - name: app_data
      type: persistentVolumeClaim
      size: 20Gi
      storage_class: gp3
      access_mode: ReadWriteOnce
      target: /app/data
      read_only: false

ingress:
  enabled: true
  strategy: nginx
  tls:
    enabled: true
    strategy: cert-manager
    email: admin@example.com
    certificates:
      - secret_name: erp-cloud-tls
        hosts:
          - erp.example.com
  rules:
    - host: erp.example.com
      paths:
        - path: /
          service: app
          port: 80
  annotations:
    cert-manager.io/cluster-issuer: letsencrypt-prod
    nginx.ingress.kubernetes.io/ssl-redirect: "true"

database:
  strategy: managed
  external:
    host: mydb.abc123.us-east-1.rds.amazonaws.com
    port: 5432
    type: postgresql
    ssl:
      enabled: true
      verify: true
  provisioning:
    enabled: false
```

### Environment Variables (.env)

```bash
# Database connection
DB_HOST=mydb.abc123.us-east-1.rds.amazonaws.com
DB_PORT=5432
DB_NAME=erpnext
DB_USER=erpnext
DB_PASSWORD=your-secure-password-here

# Application
ADMIN_PASSWORD=your-admin-password-here
SITE_NAME=erp.example.com

# Optional
REDIS_HOST=redis
REDIS_PORT=6379
```

## Directory Structure

After running the wizard/configure command:

```
deployments/production/erp-cloud/
├── platform-config.yml      # Platform configuration
├── manifest.yml             # Deployment metadata
├── .env                     # Environment variables (gitignored)
├── deployment.yaml          # Kubernetes Deployment
├── service.yaml             # Kubernetes Service
├── ingress.yaml             # Kubernetes Ingress
├── secrets.yaml             # Kubernetes Secrets (template)
├── pvc.yaml                 # PersistentVolumeClaim
└── scripts/
    └── init-db.sh          # Database initialization (if needed)
```

## Platform Comparison

| Feature | Docker Compose | Docker Swarm | Kubernetes |
|---------|---------------|--------------|------------|
| **Best For** | Development | Small/Med Production | Enterprise |
| **Networking** | bridge | overlay | ClusterIP/LB |
| **Secrets** | .env files | Docker secrets | k8s Secrets |
| **Volumes** | Bind mounts | Named volumes | PVCs |
| **Ingress** | Port mapping | Traefik | nginx-ingress |
| **Auto-scaling** | ✗ | Limited | ✓ HPA |
| **HA Database** | ✗ | Limited | ✓ StatefulSets |
| **Cloud Native** | ✗ | Partial | ✓ Full |

## Deployment Workflow

### 1. Configure Deployment

```bash
iac deploy wizard
```

### 2. Review Configuration

```bash
cd deployments/production/erp-cloud
cat platform-config.yml
```

### 3. Update Secrets

```bash
vi .env
# Update all passwords and secrets
```

### 4. Review Generated Files

```bash
ls -la
# Check all generated YAML files
```

### 5. Deploy

**Docker Compose:**
```bash
docker-compose up -d
```

**Docker Swarm:**
```bash
docker stack deploy -c docker-compose.yml erp-cloud
```

**Kubernetes:**
```bash
kubectl apply -f .
```

### 6. Verify Deployment

**Docker Compose:**
```bash
docker-compose ps
docker-compose logs
```

**Docker Swarm:**
```bash
docker stack ps erp-cloud
docker service logs erp-cloud_app
```

**Kubernetes:**
```bash
kubectl get pods
kubectl get services
kubectl get ingress
kubectl logs deployment/erp-cloud
```

## Advanced Examples

### Multi-Environment Setup

Create deployments for each environment:

```bash
# Development (Docker Compose)
iac deploy wizard
# Select: development, docker-compose, defaults

# Staging (Docker Swarm)
iac deploy wizard
# Select: staging, docker-swarm, custom

# Production (Kubernetes)
iac deploy wizard
# Select: production, kubernetes, custom
```

### Platform Migration

Migrate from Docker Compose to Kubernetes:

```bash
# 1. Export current config
cd deployments/development/my-app
cp platform-config.yml ../../../platform-config-compose.yml

# 2. Create new deployment
iac deploy wizard
# Select: production, kubernetes
# Reference compose config for settings

# 3. Test in staging first
iac deploy wizard
# Select: staging, kubernetes
# Test before production migration
```

### Custom Storage Classes

For Kubernetes with custom storage:

```yaml
# platform-config.yml
volumes:
  strategy: local
  definitions:
    - name: app_data
      type: persistentVolumeClaim
      size: 50Gi
      storage_class: fast-ssd  # Custom storage class
      access_mode: ReadWriteOnce
```

### External Secrets Provider

Using HashiCorp Vault:

```yaml
# platform-config.yml
secrets:
  strategy: k8s-secret
  provider: vault
  definitions:
    - name: db_password
      source: secret/data/myapp/db_password
      external: true
```

## Troubleshooting

### Platform Config Not Found

If templates don't render properly:

```bash
# Check if platform-config.yml exists
ls deployments/production/my-app/platform-config.yml

# Regenerate if needed
iac deploy configure-platform --template catalog/erpnext ...
```

### Validation Errors

If you see validation errors:

```bash
Configuration validation errors:
  • Network type LoadBalancer not valid for Docker Compose
```

Solution: Use correct network type for platform or change platform

### Missing Dependencies

Ensure required tools are installed:

**Docker Compose:**
```bash
docker-compose --version
```

**Docker Swarm:**
```bash
docker swarm init
```

**Kubernetes:**
```bash
kubectl version
```

## Next Steps

1. **Try the examples**: Run through each platform example
2. **Customize**: Modify platform-config.yml for your needs
3. **Read the guide**: See PLATFORM_CONFIG_GUIDE.md
4. **Explore templates**: Check catalog/* for more applications

## Support

- Full guide: `iac-cli/PLATFORM_CONFIG_GUIDE.md`
- Architecture: `iac-cli/ARCHITECTURE_DIAGRAM.md`
- Proposal: `iac-cli/DEPLOYMENT_CONFIG_PROPOSAL.md`
