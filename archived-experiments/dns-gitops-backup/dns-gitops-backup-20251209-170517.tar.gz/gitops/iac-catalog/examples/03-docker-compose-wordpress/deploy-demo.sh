#!/bin/bash
# WordPress Docker Compose Deployment Demo
# Demonstrates deploying WordPress using Jinja2 templates

set -e

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${CYAN}╔═══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║   WordPress Deployment with Jinja2 Templates                 ║${NC}"
echo -e "${CYAN}╚═══════════════════════════════════════════════════════════════╝${NC}"
echo ""

# Navigate to repo root
REPO_ROOT=$(git rev-parse --show-toplevel 2>/dev/null || pwd)
cd "$REPO_ROOT"

echo -e "${BLUE}Working directory: $REPO_ROOT${NC}"
echo ""

# Check prerequisites
echo -e "${BLUE}Checking prerequisites...${NC}"

# Check Docker
if ! command -v docker &> /dev/null; then
    echo -e "${RED}✗ Docker not found. Please install Docker Desktop${NC}"
    echo "  https://www.docker.com/products/docker-desktop"
    exit 1
fi
echo -e "${GREEN}✓ Docker installed${NC}"

# Check Docker Compose
if ! docker compose version &> /dev/null; then
    echo -e "${RED}✗ Docker Compose not found${NC}"
    exit 1
fi
echo -e "${GREEN}✓ Docker Compose available${NC}"

# Check Python
if command -v python3 &> /dev/null; then
    PYTHON_CMD="python3"
elif command -v python &> /dev/null; then
    PYTHON_CMD="python"
else
    echo -e "${RED}✗ Python not found${NC}"
    exit 1
fi
echo -e "${GREEN}✓ Python available: $PYTHON_CMD${NC}"

# Check if WordPress template exists
if [ ! -f "catalog/containers/docker/compose-stacks/wordpress/docker-compose.yml.j2" ]; then
    echo -e "${RED}✗ WordPress template not found${NC}"
    exit 1
fi
echo -e "${GREEN}✓ WordPress template found${NC}"

echo ""
read -p "Press Enter to start deployment demonstration..."
clear

# Step 1: Show template
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}Step 1: WordPress Jinja2 Template${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo ""
echo -e "${YELLOW}Let's look at the Jinja2 template structure:${NC}"
echo ""
echo -e "${BLUE}Template: catalog/containers/docker/compose-stacks/wordpress/docker-compose.yml.j2${NC}"
echo ""
head -30 catalog/containers/docker/compose-stacks/wordpress/docker-compose.yml.j2
echo "..."
echo ""
echo -e "${YELLOW}Key features:${NC}"
echo "  • Dynamic image versions: {{ wordpress_version | default('latest') }}"
echo "  • Configurable ports: {{ wordpress_port | default('8080') }}"
echo "  • Environment-specific settings"
echo "  • Named volumes with instance prefix"
echo ""
read -p "Press Enter to continue..."
clear

# Step 2: Environment configurations
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}Step 2: Environment Configurations${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo ""
echo -e "${GREEN}Development (catalog/containers/docker/compose-stacks/wordpress/environments/dev.yml):${NC}"
cat catalog/containers/docker/compose-stacks/wordpress/environments/dev.yml
echo ""
read -p "Press Enter to see staging config..."

echo ""
echo -e "${GREEN}Staging (catalog/containers/docker/compose-stacks/wordpress/environments/staging.yml):${NC}"
cat catalog/containers/docker/compose-stacks/wordpress/environments/staging.yml 2>/dev/null || echo "  (File not shown)"
echo ""
read -p "Press Enter to continue..."
clear

# Step 3: Create deployment
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}Step 3: Creating Development Deployment${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo ""

# Create deployment directory
DEPLOY_DIR="$REPO_ROOT/deployments/development/wordpress-demo"
mkdir -p "$DEPLOY_DIR"

echo -e "${YELLOW}Creating custom values file...${NC}"

# Create values file
cat > "$DEPLOY_DIR/values.yml" << 'EOF'
# WordPress Development Deployment
instance_name: wordpress-demo
environment: development

# WordPress Configuration
wordpress_version: "6.4-apache"
wordpress_port: 8888

# Database Configuration
mysql_version: "8.0"
db_name: wordpress_demo
db_user: wpuser
db_password: DemoSecurePass123
db_root_password: DemoRootPass123

# Table prefix
table_prefix: wp_demo_
EOF

echo -e "${GREEN}✓ Values file created: $DEPLOY_DIR/values.yml${NC}"
echo ""
cat "$DEPLOY_DIR/values.yml"
echo ""
read -p "Press Enter to render template..."
clear

# Step 4: Render template
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}Step 4: Rendering Jinja2 Template${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo ""

cd catalog/containers/docker/compose-stacks/wordpress

echo -e "${BLUE}Command:${NC}"
echo "python render.py \\"
echo "  --template docker-compose.yml.j2 \\"
echo "  --vars $DEPLOY_DIR/values.yml \\"
echo "  --output $DEPLOY_DIR/docker-compose.yml"
echo ""

if [ -f "render.py" ]; then
    $PYTHON_CMD render.py \
        --template docker-compose.yml.j2 \
        --vars "$DEPLOY_DIR/values.yml" \
        --output "$DEPLOY_DIR/docker-compose.yml" 2>&1 || {
        echo -e "${YELLOW}Using fallback rendering method...${NC}"
        # Simple fallback if render.py doesn't work
        cp docker-compose.yml.j2 "$DEPLOY_DIR/docker-compose.yml.template"
    }
fi

cd "$REPO_ROOT"

if [ -f "$DEPLOY_DIR/docker-compose.yml" ]; then
    echo -e "${GREEN}✓ Template rendered successfully!${NC}"
else
    echo -e "${YELLOW}⚠ Using template as-is (manual variable substitution needed)${NC}"
    cp catalog/containers/docker/compose-stacks/wordpress/docker-compose.yml "$DEPLOY_DIR/" 2>/dev/null || true
fi

echo ""
read -p "Press Enter to view generated file..."
clear

# Step 5: Show generated file
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}Step 5: Generated Docker Compose File${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo ""

if [ -f "$DEPLOY_DIR/docker-compose.yml" ]; then
    head -50 "$DEPLOY_DIR/docker-compose.yml"
    echo "..."
else
    echo -e "${YELLOW}Showing template structure:${NC}"
    head -50 catalog/containers/docker/compose-stacks/wordpress/docker-compose.yml
    echo "..."
fi

echo ""
read -p "Press Enter to continue..."
clear

# Step 6: Deployment options
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}Step 6: Deployment Options${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo ""

echo -e "${YELLOW}To deploy this WordPress stack:${NC}"
echo ""
echo -e "${BLUE}1. Review the configuration:${NC}"
echo "   cd $DEPLOY_DIR"
echo "   cat docker-compose.yml"
echo ""
echo -e "${BLUE}2. Validate the compose file:${NC}"
echo "   docker compose config"
echo ""
echo -e "${BLUE}3. Start the services:${NC}"
echo "   docker compose up -d"
echo ""
echo -e "${BLUE}4. Check status:${NC}"
echo "   docker compose ps"
echo "   docker compose logs -f"
echo ""
echo -e "${BLUE}5. Access WordPress:${NC}"
echo "   http://localhost:8888"
echo ""
echo -e "${BLUE}6. Stop services:${NC}"
echo "   docker compose down"
echo ""

read -p "Would you like to start the deployment now? (y/N) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo ""
    echo -e "${GREEN}Starting WordPress deployment...${NC}"
    cd "$DEPLOY_DIR"
    
    if [ -f "docker-compose.yml" ]; then
        docker compose up -d
        echo ""
        echo -e "${GREEN}✓ WordPress deployed successfully!${NC}"
        echo ""
        echo -e "${CYAN}Access your WordPress site:${NC}"
        echo "  URL: http://localhost:8888"
        echo ""
        echo -e "${CYAN}View logs:${NC}"
        echo "  docker compose logs -f"
        echo ""
        echo -e "${CYAN}Check status:${NC}"
        docker compose ps
    else
        echo -e "${YELLOW}⚠ docker-compose.yml not found, skipping deployment${NC}"
    fi
else
    echo ""
    echo -e "${YELLOW}Deployment skipped. You can deploy later with:${NC}"
    echo "  cd $DEPLOY_DIR"
    echo "  docker compose up -d"
fi

cd "$REPO_ROOT"
echo ""
read -p "Press Enter to continue..."
clear

# Step 7: Multi-environment
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}Step 7: Multi-Environment Workflow${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo ""

echo -e "${YELLOW}Typical workflow for multiple environments:${NC}"
echo ""
echo -e "${GREEN}Development → Staging → Production${NC}"
echo ""
echo -e "${BLUE}1. Development:${NC}"
echo "   • Port 8888, debug enabled"
echo "   • Simple passwords (local only)"
echo "   • Latest versions for testing"
echo ""
echo -e "${BLUE}2. Staging:${NC}"
echo "   • Port 80, SSL with Traefik"
echo "   • Secure passwords from vault"
echo "   • Pinned versions"
echo ""
echo -e "${BLUE}3. Production:${NC}"
echo "   • Port 80, SSL certificates"
echo "   • Strong passwords, secrets management"
echo "   • High availability, monitoring"
echo ""
read -p "Press Enter to see summary..."
clear

# Summary
echo -e "${CYAN}╔═══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║   Deployment Demo Complete! 🎉                                ║${NC}"
echo -e "${CYAN}╚═══════════════════════════════════════════════════════════════╝${NC}"
echo ""

echo -e "${GREEN}What we covered:${NC}"
echo "  ✓ Jinja2 template structure"
echo "  ✓ Environment-specific configurations"
echo "  ✓ Template rendering workflow"
echo "  ✓ Generated docker-compose.yml"
echo "  ✓ Deployment process"
echo "  ✓ Multi-environment strategy"
echo ""

echo -e "${BLUE}Generated files:${NC}"
echo "  • $DEPLOY_DIR/values.yml"
echo "  • $DEPLOY_DIR/docker-compose.yml"
echo ""

echo -e "${YELLOW}Next steps:${NC}"
echo "  1. Read the full tutorial: examples/03-docker-compose-wordpress/README.md"
echo "  2. Customize your deployment"
echo "  3. Deploy to staging and production"
echo "  4. Commit to Git for GitOps workflow"
echo ""

echo -e "${CYAN}Useful commands:${NC}"
echo "  cd $DEPLOY_DIR"
echo "  docker compose up -d              # Start services"
echo "  docker compose ps                 # Check status"
echo "  docker compose logs -f wordpress  # View logs"
echo "  docker compose down               # Stop services"
echo ""

echo -e "${GREEN}Happy deploying with Docker Compose! 🐳🚀${NC}"
echo ""
