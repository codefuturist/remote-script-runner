# Example 03: Docker Compose Deployment - WordPress with Jinja2

## 📋 Overview

This example demonstrates deploying a Docker Compose application (WordPress) using the IaC CLI with Jinja2 template rendering across multiple environments.

**What you'll learn:**
- Using Jinja2 templates for Docker Compose
- Deploying WordPress with MySQL
- Environment-specific configurations
- Template rendering workflow
- Managing Docker Compose deployments with IaC CLI

**Time to complete:** 25-35 minutes

## 🎯 Prerequisites

1. **IaC CLI installed**:
   ```bash
   cd /path/to/iac-catalog/iac-cli
   uv pip install -e .
   ```

2. **Docker and Docker Compose**:
   ```bash
   docker --version
   docker compose version
   ```

3. **Python with Jinja2**:
   ```bash
   pip install jinja2 pyyaml
   ```

4. **Git repository** (for GitOps workflow)

## 📁 What We'll Deploy

A production-ready WordPress stack with:
- **WordPress** - CMS application
- **MySQL 8.0** - Database backend
- **Persistent volumes** - Data persistence
- **Custom networking** - Isolated network
- **Environment-specific configs** - Dev/Staging/Production

## 🏗️ Template Structure

The WordPress template uses Jinja2 for dynamic configuration:

```
catalog/containers/docker/compose-stacks/wordpress/
├── manifest.yml              # Template metadata
├── template.yml              # IaC CLI template definition
├── docker-compose.yml.j2     # Jinja2 template
├── .env.example.j2           # Environment variables template
├── render.py                 # Standalone renderer
└── environments/
    ├── base.yml              # Base configuration
    ├── dev.yml               # Development overrides
    ├── staging.yml           # Staging overrides
    └── production.yml        # Production overrides
```

## 🚀 Step-by-Step Tutorial

### Step 1: Search for the WordPress Template

```bash
# Navigate to repo
cd /path/to/iac-catalog

# Search for WordPress templates
iac search wordpress

# View template details
iac template show catalog/containers/docker/compose-stacks/wordpress/template.yml

# List all Docker Compose templates
iac search "docker compose"
```

### Step 2: Examine the Jinja2 Template

Let's look at the template structure:

```bash
# View the Jinja2 template
cat catalog/containers/docker/compose-stacks/wordpress/docker-compose.yml.j2
```

**Key Jinja2 features used:**

```jinja
services:
  wordpress:
    image: wordpress:{{ wordpress_version | default('latest') }}
    container_name: {{ instance_name }}_wordpress
    ports:
      - "{{ wordpress_port | default('8080') }}:80"
    environment:
      WORDPRESS_DB_PASSWORD: {{ db_password }}
      WORDPRESS_DB_NAME: {{ db_name | default('wordpress') }}
```

**Template variables:**
- `{{ variable }}` - Required variable
- `{{ variable | default('value') }}` - Optional with default
- `{{ instance_name }}` - Unique instance identifier

### Step 3: Review Environment Configurations

Each environment has specific settings:

**Development** (`environments/dev.yml`):
```yaml
environment: development
wordpress_version: latest
wordpress_port: 8080
db_password: dev_password_123  # Not secure, local only
enable_traefik: false
```

**Staging** (`environments/staging.yml`):
```yaml
environment: staging
wordpress_version: "6.4"
wordpress_port: 80
db_password: "{{ vault_staging_db_password }}"
enable_traefik: true
```

**Production** (`environments/production.yml`):
```yaml
environment: production
wordpress_version: "6.4"
wordpress_port: 80
db_password: "{{ vault_prod_db_password }}"
enable_traefik: true
replica_count: 3
```

### Step 4: Create Development Deployment

Let's deploy WordPress to development:

```bash
# Use the template command to render the configuration
iac template render \
  catalog/containers/docker/compose-stacks/wordpress/docker-compose.yml.j2 \
  --vars catalog/containers/docker/compose-stacks/wordpress/environments/dev.yml \
  --set instance_name=my-wordpress-dev \
  --output deployments/development/wordpress/docker-compose.yml

# Or use deploy command
iac deploy create wordpress-dev \
  --environment development \
  --template catalog/containers/docker/compose-stacks/wordpress/template.yml \
  --set instance_name=my-wordpress-dev \
  --set db_password=dev_secure_pass_123
```

### Step 5: Customize Your Deployment

Create a custom values file:

```bash
# Create deployment directory
mkdir -p deployments/development/wordpress

# Create values file
cat > deployments/development/wordpress/values.yml << 'EOF'
# WordPress Development Deployment
instance_name: my-wordpress-dev
environment: development

# WordPress Configuration
wordpress_version: "6.4-apache"
wordpress_port: 8080

# Database Configuration
mysql_version: "8.0"
db_name: wordpress_dev
db_user: wpuser
db_password: DevSecurePass123!
db_root_password: DevRootPass123!

# Table prefix (for security)
table_prefix: wp_dev_

# Volumes
wordpress_data_path: ./data/wordpress
mysql_data_path: ./data/mysql

# Development settings
enable_debug: true
enable_xdebug: false
memory_limit: 256M
max_upload_size: 64M
EOF
```

### Step 6: Render the Template

Now render the Jinja2 template with your values:

```bash
# Using the standalone renderer
cd catalog/containers/docker/compose-stacks/wordpress

python render.py \
  --template docker-compose.yml.j2 \
  --vars ../../../../deployments/development/wordpress/values.yml \
  --output ../../../../deployments/development/wordpress/docker-compose.yml

# Or use the IaC CLI (when template command is implemented)
cd /path/to/iac-catalog
iac template render \
  catalog/containers/docker/compose-stacks/wordpress/docker-compose.yml.j2 \
  --values deployments/development/wordpress/values.yml \
  --output deployments/development/wordpress/docker-compose.yml
```

### Step 7: Review Generated Configuration

Check the rendered docker-compose.yml:

```bash
# View the generated file
cat deployments/development/wordpress/docker-compose.yml

# Validate it
docker compose -f deployments/development/wordpress/docker-compose.yml config
```

**Expected output:**
```yaml
services:
  wordpress:
    image: wordpress:6.4-apache
    container_name: my-wordpress-dev_wordpress
    restart: unless-stopped
    ports:
      - "8080:80"
    environment:
      WORDPRESS_DB_HOST: mysql:3306
      WORDPRESS_DB_USER: wpuser
      WORDPRESS_DB_PASSWORD: DevSecurePass123!
      WORDPRESS_DB_NAME: wordpress_dev
      WORDPRESS_TABLE_PREFIX: wp_dev_
    volumes:
      - wordpress_data:/var/www/html
    # ... etc
```

### Step 8: Deploy to Docker

Now deploy the application:

```bash
# Navigate to deployment directory
cd deployments/development/wordpress

# Start the services
docker compose up -d

# Check status
docker compose ps

# View logs
docker compose logs -f wordpress

# Test the deployment
curl http://localhost:8080
```

### Step 9: Access WordPress

Open your browser:

```
http://localhost:8080
```

Complete the WordPress installation:
1. Select language
2. Set site title
3. Create admin user
4. Install WordPress

### Step 10: Deploy to Staging

Create staging deployment:

```bash
# Create staging values
cat > deployments/staging/wordpress/values.yml << 'EOF'
instance_name: my-wordpress-staging
environment: staging

# Production-like versions
wordpress_version: "6.4-apache"
wordpress_port: 80

# Database Configuration
mysql_version: "8.0"
db_name: wordpress_staging
db_user: wpuser
db_password: "{{ STAGING_DB_PASSWORD }}"  # From secrets
db_root_password: "{{ STAGING_ROOT_PASSWORD }}"

# Security hardening
table_prefix: wpstg_
enable_debug: false

# Resource limits
memory_limit: 512M
max_upload_size: 128M

# SSL/TLS (with Traefik)
enable_traefik: true
domain: wordpress-staging.example.com
EOF

# Render staging template
iac template render \
  catalog/containers/docker/compose-stacks/wordpress/docker-compose.yml.j2 \
  --values deployments/staging/wordpress/values.yml \
  --set db_password="${STAGING_DB_PASSWORD}" \
  --set db_root_password="${STAGING_ROOT_PASSWORD}" \
  --output deployments/staging/wordpress/docker-compose.yml

# Deploy to staging server
cd deployments/staging/wordpress
docker compose up -d
```

### Step 11: Deploy to Production

Production deployment with full hardening:

```bash
# Create production values
cat > deployments/production/wordpress/values.yml << 'EOF'
instance_name: my-wordpress-prod
environment: production

# Pinned versions for stability
wordpress_version: "6.4-apache"
wordpress_port: 80

# Database Configuration
mysql_version: "8.0.35"
db_name: wordpress_production
db_user: wpuser
db_password: "{{ PROD_DB_PASSWORD }}"
db_root_password: "{{ PROD_ROOT_PASSWORD }}"

# Security
table_prefix: wpprod_
enable_debug: false
disable_file_edit: true

# Performance
memory_limit: 1024M
max_upload_size: 256M
opcache_enabled: true

# High Availability
replica_count: 3
enable_redis: true

# SSL/TLS
enable_traefik: true
domain: wordpress.example.com
enable_ssl: true
ssl_cert_resolver: letsencrypt

# Backup
backup_enabled: true
backup_schedule: "0 2 * * *"

# Monitoring
enable_prometheus: true
enable_healthchecks: true
EOF

# Render production template
iac template render \
  catalog/containers/docker/compose-stacks/wordpress/docker-compose.yml.j2 \
  --values deployments/production/wordpress/values.yml \
  --set db_password="${PROD_DB_PASSWORD}" \
  --set db_root_password="${PROD_ROOT_PASSWORD}" \
  --output deployments/production/wordpress/docker-compose.yml

# Deploy to production
cd deployments/production/wordpress
docker compose up -d
```

### Step 12: GitOps Workflow

Commit your deployments to Git:

```bash
# Check what we're committing
git status

# Use IaC CLI GitOps
iac gitops commit -m "feat: deploy WordPress across all environments

- Development: localhost:8080, debug enabled
- Staging: SSL-enabled, production-like
- Production: HA setup with monitoring" --push

# Or manual git
git add deployments/
git commit -m "feat: deploy WordPress stack"
git push origin develop
```

## 🎨 Advanced Usage

### Custom Jinja2 Filters

Add custom filters to the template:

```python
# In render.py or custom script
def format_size(value):
    """Convert MB to Docker format"""
    return f"{value}m"

# Use in template
{{ memory_limit | format_size }}
```

### Multi-Instance Deployment

Deploy multiple WordPress instances:

```bash
# Site 1
iac template render \
  catalog/containers/docker/compose-stacks/wordpress/docker-compose.yml.j2 \
  --set instance_name=blog \
  --set wordpress_port=8081 \
  --output deployments/development/wordpress-blog/docker-compose.yml

# Site 2
iac template render \
  catalog/containers/docker/compose-stacks/wordpress/docker-compose.yml.j2 \
  --set instance_name=shop \
  --set wordpress_port=8082 \
  --output deployments/development/wordpress-shop/docker-compose.yml
```

### Environment Variable Substitution

Use environment variables in values:

```yaml
# values.yml
db_password: "${DB_PASSWORD}"
db_root_password: "${ROOT_PASSWORD}"

# Render with env vars
export DB_PASSWORD="secure_password"
export ROOT_PASSWORD="root_secure_password"
iac template render ... --expand-env
```

### Ansible Integration

Use Ansible to deploy rendered templates:

```yaml
# playbooks/deploy-wordpress.yml
---
- name: Deploy WordPress with Docker Compose
  hosts: web_servers
  vars:
    wordpress_path: /opt/wordpress
  
  tasks:
    - name: Render WordPress template
      template:
        src: catalog/containers/docker/compose-stacks/wordpress/docker-compose.yml.j2
        dest: "{{ wordpress_path }}/docker-compose.yml"
      vars:
        instance_name: "wordpress_{{ inventory_hostname }}"
        wordpress_port: 80
        db_password: "{{ vault_wordpress_db_password }}"
    
    - name: Deploy WordPress
      docker_compose:
        project_src: "{{ wordpress_path }}"
        state: present
```

## 📊 Complete Workflow Diagram

```mermaid
graph TD
    A[Select Template] --> B[Choose Environment]
    B --> C[Create Values File]
    C --> D[Render Jinja2 Template]
    D --> E[Review docker-compose.yml]
    E --> F{Valid?}
    F -->|No| C
    F -->|Yes| G[Commit to Git]
    G --> H[Deploy with Docker Compose]
    H --> I[Verify Deployment]
    I --> J{Success?}
    J -->|No| K[Check Logs]
    K --> C
    J -->|Yes| L[Monitor Application]
```

## 🔍 Verification

### Check Docker Services

```bash
# List running containers
docker compose ps

# View logs
docker compose logs wordpress
docker compose logs mysql

# Check resource usage
docker stats
```

### Test WordPress

```bash
# Check WordPress is responding
curl -I http://localhost:8080

# Test database connection
docker compose exec wordpress wp db check

# Check WordPress version
docker compose exec wordpress wp --version
```

### Health Checks

```bash
# MySQL health
docker compose exec mysql mysqladmin ping -h localhost -u root -p

# WordPress PHP info
curl http://localhost:8080/info.php
```

## 🐛 Troubleshooting

### Template Rendering Issues

```bash
# Validate Jinja2 syntax
python -c "from jinja2 import Template; Template(open('docker-compose.yml.j2').read())"

# Check for missing variables
iac template render --dry-run --show-undefined
```

### Docker Compose Issues

```bash
# Validate compose file
docker compose config

# View detailed logs
docker compose logs --tail=100 --follow

# Restart services
docker compose restart

# Rebuild containers
docker compose up -d --build
```

### Database Connection Errors

```bash
# Check MySQL is ready
docker compose exec mysql mysql -u root -p -e "SHOW DATABASES;"

# Test from WordPress container
docker compose exec wordpress nc -zv mysql 3306

# Check environment variables
docker compose exec wordpress env | grep WORDPRESS_DB
```

## 📝 Best Practices

### 1. Version Pinning

Always pin versions in production:

```yaml
# ❌ Don't use in production
wordpress_version: latest

# ✅ Use specific versions
wordpress_version: "6.4-apache"
mysql_version: "8.0.35"
```

### 2. Secrets Management

Never commit passwords:

```bash
# Use environment variables
export DB_PASSWORD=$(openssl rand -base64 32)

# Or use Docker secrets
docker secret create db_password -
docker secret create db_root_password -
```

### 3. Data Persistence

Use named volumes or bind mounts:

```yaml
volumes:
  wordpress_data:
    driver: local
    driver_opts:
      type: none
      o: bind
      device: /mnt/wordpress-data
```

### 4. Health Checks

Add health checks to your services:

```yaml
wordpress:
  healthcheck:
    test: ["CMD", "curl", "-f", "http://localhost"]
    interval: 30s
    timeout: 10s
    retries: 3
```

## 🎓 What's Next?

- **[Example 04: Multi-Stack Deployment](../04-multi-stack/)** - Deploy multiple applications
- **[Example 05: Kubernetes Migration](../05-k8s-migration/)** - Migrate to Kubernetes
- **[Template Documentation](../../catalog/containers/docker/README.md)** - More templates

## 📚 Additional Resources

- [Docker Compose Documentation](https://docs.docker.com/compose/)
- [Jinja2 Documentation](https://jinja.palletsprojects.com/)
- [WordPress Docker Hub](https://hub.docker.com/_/wordpress)
- [MySQL Docker Hub](https://hub.docker.com/_/mysql)
- [IaC CLI Template Guide](../../iac-cli/docs/templates.md)

---

**Deploy with confidence!** 🚀🐳
