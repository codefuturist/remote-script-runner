# Docker Compose Deployment Cheat Sheet

Quick reference for deploying Docker Compose applications with Jinja2 templates.

## 🚀 Quick Commands

### Template Rendering

```bash
# Render a Jinja2 template
python render.py \
  --template docker-compose.yml.j2 \
  --vars values.yml \
  --output docker-compose.yml

# With IaC CLI
iac template render \
  path/to/template.j2 \
  --values values.yml \
  --output docker-compose.yml

# With environment variables
iac template render template.j2 \
  --set var=value \
  --set another_var=value2 \
  --output output.yml
```

### Docker Compose Operations

```bash
# Validate configuration
docker compose config

# Start services
docker compose up -d

# Check status
docker compose ps

# View logs
docker compose logs -f
docker compose logs wordpress
docker compose logs mysql

# Restart services
docker compose restart

# Stop services
docker compose stop

# Remove services
docker compose down

# Remove with volumes
docker compose down -v
```

## 📝 WordPress Deployment Workflow

### 1. Create Values File

```yaml
# values.yml
instance_name: my-wordpress
environment: development

wordpress_version: "6.4-apache"
wordpress_port: 8080

mysql_version: "8.0"
db_name: wordpress
db_user: wpuser
db_password: SecurePass123
db_root_password: RootPass123

table_prefix: wp_
```

### 2. Render Template

```bash
cd catalog/containers/docker/compose-stacks/wordpress

python render.py \
  --template docker-compose.yml.j2 \
  --vars /path/to/values.yml \
  --output /path/to/docker-compose.yml
```

### 3. Deploy

```bash
cd /path/to/deployment
docker compose up -d
```

### 4. Verify

```bash
# Check containers
docker compose ps

# Test connection
curl http://localhost:8080

# Check logs
docker compose logs -f
```

## 🌍 Multi-Environment Setup

### Development

```yaml
# deployments/development/wordpress/values.yml
instance_name: wordpress-dev
environment: development
wordpress_port: 8888
db_password: dev_pass_123
enable_debug: true
```

### Staging

```yaml
# deployments/staging/wordpress/values.yml
instance_name: wordpress-staging
environment: staging
wordpress_port: 80
db_password: "{{ STAGING_DB_PASSWORD }}"
enable_traefik: true
domain: staging.example.com
```

### Production

```yaml
# deployments/production/wordpress/values.yml
instance_name: wordpress-prod
environment: production
wordpress_port: 80
db_password: "{{ PROD_DB_PASSWORD }}"
enable_traefik: true
domain: www.example.com
enable_ssl: true
backup_enabled: true
```

## 🔧 Common Tasks

### Update WordPress

```bash
# Edit values.yml to change version
wordpress_version: "6.5-apache"

# Re-render template
python render.py --template docker-compose.yml.j2 --vars values.yml --output docker-compose.yml

# Pull new image and restart
docker compose pull wordpress
docker compose up -d wordpress
```

### Backup Data

```bash
# Backup database
docker compose exec mysql mysqldump -u root -p wordpress > backup.sql

# Backup WordPress files
docker compose cp wordpress:/var/www/html ./wordpress-backup

# Or backup volumes
docker run --rm -v wordpress_data:/data -v $(pwd):/backup alpine tar czf /backup/wordpress-backup.tar.gz /data
```

### Restore Data

```bash
# Restore database
docker compose exec -T mysql mysql -u root -p wordpress < backup.sql

# Restore files
docker compose cp ./wordpress-backup wordpress:/var/www/html
```

### Scale Services (if configured)

```bash
# Scale WordPress instances
docker compose up -d --scale wordpress=3
```

### View Resource Usage

```bash
# Real-time stats
docker stats

# Specific containers
docker compose top
```

## 🐛 Troubleshooting

### Check Template Syntax

```bash
# Validate Jinja2
python -c "from jinja2 import Template; print(Template(open('template.j2').read()).render())"
```

### Validate Docker Compose

```bash
# Validate syntax
docker compose config

# Validate and show
docker compose config --services
docker compose config --volumes
```

### Connection Issues

```bash
# Test MySQL connection
docker compose exec wordpress nc -zv mysql 3306

# Check environment variables
docker compose exec wordpress env | grep WORDPRESS

# MySQL logs
docker compose logs mysql | grep ERROR
```

### Permission Issues

```bash
# Check file permissions
docker compose exec wordpress ls -la /var/www/html

# Fix permissions
docker compose exec wordpress chown -R www-data:www-data /var/www/html
```

## 📊 Monitoring

### Health Checks

```bash
# Check container health
docker compose ps

# Inspect health
docker inspect wordpress-demo_wordpress | jq '.[0].State.Health'
```

### Logs

```bash
# Follow all logs
docker compose logs -f

# Specific service
docker compose logs -f wordpress

# Last N lines
docker compose logs --tail=100 wordpress

# Since timestamp
docker compose logs --since="2025-01-01T00:00:00" wordpress
```

## 🔐 Security

### Strong Passwords

```bash
# Generate secure password
openssl rand -base64 32

# Use in values.yml
db_password: "$(openssl rand -base64 32)"
```

### Environment Variables

```bash
# Use .env file
cat > .env << EOF
DB_PASSWORD=$(openssl rand -base64 32)
DB_ROOT_PASSWORD=$(openssl rand -base64 32)
EOF

# Reference in values.yml
db_password: "${DB_PASSWORD}"
```

### Secrets Management

```bash
# Docker secrets (Swarm mode)
echo "secret_password" | docker secret create db_password -

# In docker-compose.yml
secrets:
  db_password:
    external: true
```

## 📚 Quick Reference

| Task | Command |
|------|---------|
| Render template | `python render.py --template template.j2 --vars values.yml` |
| Start services | `docker compose up -d` |
| Stop services | `docker compose down` |
| View logs | `docker compose logs -f` |
| Check status | `docker compose ps` |
| Restart service | `docker compose restart wordpress` |
| Update image | `docker compose pull && docker compose up -d` |
| Backup DB | `docker compose exec mysql mysqldump > backup.sql` |
| Shell access | `docker compose exec wordpress bash` |
| Remove all | `docker compose down -v` |

---

**Keep this handy for quick deployments!** 🐳✨
