#!/bin/bash
# Practical Deployment Example using IaC CLI
# This script demonstrates a real deployment workflow

set -e

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${CYAN}╔═══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║     IaC CLI - Practical Deployment Demonstration             ║${NC}"
echo -e "${CYAN}╚═══════════════════════════════════════════════════════════════╝${NC}"
echo ""

# Navigate to repo root
REPO_ROOT=$(git rev-parse --show-toplevel 2>/dev/null || pwd)
cd "$REPO_ROOT"

echo -e "${BLUE}Working directory: $REPO_ROOT${NC}"
echo ""

# Determine the Python command to use
if command -v python3 &> /dev/null; then
    PYTHON_CMD="python3"
elif command -v python &> /dev/null; then
    PYTHON_CMD="python"
else
    echo -e "${RED}✗ Python not found. Please install Python 3.11+${NC}"
    exit 1
fi

echo -e "${GREEN}✓ Using Python: $PYTHON_CMD${NC}"
echo ""

# Check if iac-cli is available
if command -v iac &> /dev/null; then
    IAC_CMD="iac"
    echo -e "${GREEN}✓ IaC CLI installed globally${NC}"
elif $PYTHON_CMD -m iac_cli --version &> /dev/null; then
    IAC_CMD="$PYTHON_CMD -m iac_cli"
    echo -e "${GREEN}✓ IaC CLI available as module${NC}"
else
    echo -e "${YELLOW}⚠️  IaC CLI not found. Installing...${NC}"
    cd iac-cli
    uv pip install -e . || pip install -e .
    cd ..
    IAC_CMD="$PYTHON_CMD -m iac_cli"
fi

echo ""
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}Step 1: List Available Environments${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo ""
echo -e "${BLUE}Command: $IAC_CMD env list${NC}"
echo ""
$IAC_CMD env list || echo -e "${YELLOW}(Running from repo root: $REPO_ROOT)${NC}"
echo ""
read -p "Press Enter to continue..."

echo ""
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}Step 2: Search for Templates${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo ""
echo -e "${BLUE}Command: $IAC_CMD search gitops${NC}"
echo ""
$IAC_CMD search gitops 2>/dev/null || echo -e "${YELLOW}Search results depend on catalog content${NC}"
echo ""
read -p "Press Enter to continue..."

echo ""
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}Step 3: Create a Deployment (Simulation)${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo ""
echo -e "${YELLOW}We'll simulate creating a deployment using our sample configs${NC}"
echo ""
echo -e "${BLUE}Simulated command:${NC}"
echo "  $IAC_CMD deploy create my-web-app \\"
echo "    --environment development \\"
echo "    --template catalog/gitops/flux/tenants/basic-tenant.yaml \\"
echo "    --name my-web-app \\"
echo "    --namespace apps-dev"
echo ""
echo -e "${GREEN}✓ This would create: deployments/development/my-web-app/${NC}"
echo ""
echo -e "${YELLOW}Using sample configuration from:${NC}"
echo "  examples/02-gitops-deployment/sample-deployments/development/my-web-app/"
echo ""

# Show sample deployment config
if [ -f "examples/02-gitops-deployment/sample-deployments/development/my-web-app/values.yaml" ]; then
    echo -e "${BLUE}Sample Development Configuration:${NC}"
    echo "----------------------------------------"
    head -25 examples/02-gitops-deployment/sample-deployments/development/my-web-app/values.yaml
    echo "..."
fi
echo ""
read -p "Press Enter to continue..."

echo ""
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}Step 4: Compare Environment Configurations${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo ""
echo -e "${YELLOW}Comparing deployment configurations across environments:${NC}"
echo ""

echo -e "${GREEN}Development (2 replicas, debug):${NC}"
if [ -f "examples/02-gitops-deployment/sample-deployments/development/my-web-app/values.yaml" ]; then
    grep -A 3 "^app:" examples/02-gitops-deployment/sample-deployments/development/my-web-app/values.yaml | head -5
fi
echo ""

echo -e "${GREEN}Staging (3 replicas, TLS):${NC}"
if [ -f "examples/02-gitops-deployment/sample-deployments/staging/my-web-app/values.yaml" ]; then
    grep -A 3 "^app:" examples/02-gitops-deployment/sample-deployments/staging/my-web-app/values.yaml | head -5
fi
echo ""

echo -e "${GREEN}Production (5 replicas, HA):${NC}"
if [ -f "examples/02-gitops-deployment/sample-deployments/production/my-web-app/values.yaml" ]; then
    grep -A 3 "^app:" examples/02-gitops-deployment/sample-deployments/production/my-web-app/values.yaml | head -5
fi
echo ""
read -p "Press Enter to continue..."

echo ""
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}Step 5: GitOps Workflow${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo ""
echo -e "${YELLOW}After making changes, you would commit them:${NC}"
echo ""
echo -e "${BLUE}Command: $IAC_CMD gitops commit -m 'feat: deploy my-web-app' --push${NC}"
echo ""
echo "This would:"
echo "  1. Show git status and changed files"
echo "  2. Prompt for confirmation"
echo "  3. Stage all changes (git add)"
echo "  4. Commit with your message"
echo "  5. Push to remote repository"
echo "  6. Flux CD automatically syncs!"
echo ""
read -p "Press Enter to continue..."

echo ""
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}Step 6: Available Commands Summary${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo ""
echo -e "${YELLOW}Main command groups:${NC}"
echo ""
$IAC_CMD --help 2>/dev/null || cat << 'EOF'
Usage: iac [OPTIONS] COMMAND [ARGS]...

Commands:
  env          🌍 Environment management
  search       🔍 Search templates
  template     📦 Template operations
  deploy       🚀 Deployment operations
  secrets      🔐 Secrets management
  gitops       🔄 GitOps integration
  inventory    📋 Inventory management
  status       📊 Status checks
  logs         📜 View logs
  interactive  🎯 Interactive mode
EOF

echo ""
echo -e "${BLUE}Try these commands:${NC}"
echo "  $IAC_CMD interactive       # Start guided mode"
echo "  $IAC_CMD env list          # List environments"
echo "  $IAC_CMD search <keyword>  # Search templates"
echo "  $IAC_CMD deploy list       # List deployments"
echo "  $IAC_CMD --help            # Show all commands"
echo ""

echo ""
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}Deployment Complete! 🎉${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo ""
echo -e "${GREEN}What we demonstrated:${NC}"
echo "  ✓ Environment listing"
echo "  ✓ Template searching"
echo "  ✓ Deployment creation workflow"
echo "  ✓ Multi-environment configurations"
echo "  ✓ GitOps commit process"
echo ""
echo -e "${BLUE}Next steps:${NC}"
echo "  1. Try: $IAC_CMD interactive"
echo "  2. Read: examples/02-gitops-deployment/README.md"
echo "  3. Explore: examples/02-gitops-deployment/CHEATSHEET.md"
echo ""
echo -e "${YELLOW}For a real deployment:${NC}"
echo "  - Configure your Kubernetes cluster"
echo "  - Install Flux CD"
echo "  - Set up Git repository"
echo "  - Run: $IAC_CMD deploy create <name>"
echo ""
echo -e "${GREEN}Happy deploying! 🚀${NC}"
echo ""
