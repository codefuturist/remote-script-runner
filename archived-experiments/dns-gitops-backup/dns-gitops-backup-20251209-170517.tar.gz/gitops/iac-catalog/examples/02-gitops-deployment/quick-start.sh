#!/bin/bash
# Quick Start Script for GitOps Deployment Example
# This script demonstrates the IaC CLI tool in action

set -e

echo "🚀 IaC CLI GitOps Deployment Example"
echo "======================================"
echo ""

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if iac CLI is installed
if ! command -v iac &> /dev/null; then
    echo -e "${YELLOW}⚠️  IaC CLI not found. Installing...${NC}"
    cd ../../../iac-cli
    uv pip install -e .
    cd -
fi

echo -e "${GREEN}✓ IaC CLI is installed${NC}"
echo ""

# Navigate to repo root
REPO_ROOT=$(git rev-parse --show-toplevel 2>/dev/null || echo "../../..")
cd "$REPO_ROOT"

echo "📋 Step 1: Search for available templates"
echo "==========================================="
echo ""
echo "Command: iac search flux"
iac search flux || echo "Note: Search feature may be limited in demo"
echo ""
read -p "Press Enter to continue..."

echo ""
echo "🎯 Step 2: Create development deployment"
echo "=========================================="
echo ""
echo "Command: iac deploy create my-web-app --environment development"
echo ""
echo "This would create a new deployment in: deployments/development/my-web-app/"
echo "Sample files are provided in: examples/02-gitops-deployment/sample-deployments/"
echo ""
read -p "Press Enter to continue..."

echo ""
echo "📝 Step 3: Review configuration"
echo "================================"
echo ""
echo "Sample development configuration:"
cat examples/02-gitops-deployment/sample-deployments/development/my-web-app/values.yaml | head -30
echo "..."
echo ""
read -p "Press Enter to continue..."

echo ""
echo "✅ Step 4: Validate deployment"
echo "==============================="
echo ""
echo "Command: iac deploy preview my-web-app --environment development"
echo "Command: iac status my-web-app --environment development"
echo ""
echo "These commands would validate and show the deployment status."
echo ""
read -p "Press Enter to continue..."

echo ""
echo "🔄 Step 5: GitOps - Commit changes"
echo "==================================="
echo ""
echo "Command: iac gitops commit -m 'feat: add my-web-app to development'"
echo ""
echo "This would:"
echo "  1. Check git status"
echo "  2. Show you what will be committed"
echo "  3. Add all changes"
echo "  4. Commit with your message"
echo "  5. (Optional with --push) Push to remote"
echo ""
read -p "Press Enter to continue..."

echo ""
echo "🎨 Step 6: Deploy to other environments"
echo "========================================="
echo ""
echo "Commands:"
echo "  iac deploy create my-web-app --environment staging"
echo "  iac deploy create my-web-app --environment production"
echo ""
echo "Sample configurations for all environments are in:"
echo "  - examples/02-gitops-deployment/sample-deployments/development/"
echo "  - examples/02-gitops-deployment/sample-deployments/staging/"
echo "  - examples/02-gitops-deployment/sample-deployments/production/"
echo ""

echo ""
echo "📊 Environment Comparison"
echo "========================="
echo ""
echo -e "${BLUE}Development:${NC}"
echo "  - 2 replicas"
echo "  - No TLS"
echo "  - Debug logging"
echo "  - Branch: develop"
echo ""
echo -e "${BLUE}Staging:${NC}"
echo "  - 3 replicas"
echo "  - TLS enabled"
echo "  - Info logging"
echo "  - Autoscaling: 3-6 replicas"
echo "  - Branch: main"
echo ""
echo -e "${BLUE}Production:${NC}"
echo "  - 5 replicas"
echo "  - TLS with production certs"
echo "  - Warning logging only"
echo "  - Autoscaling: 5-20 replicas"
echo "  - Pod Disruption Budget"
echo "  - Security hardening"
echo "  - Branch: main"
echo ""

echo ""
echo "🎓 Next Steps"
echo "=============="
echo ""
echo "1. Read the full tutorial: examples/02-gitops-deployment/README.md"
echo "2. Try the interactive mode: iac interactive"
echo "3. Explore more commands: iac --help"
echo "4. Check out the CLI documentation: iac-cli/README.md"
echo ""
echo -e "${GREEN}✨ Happy deploying with IaC CLI! ✨${NC}"
echo ""
