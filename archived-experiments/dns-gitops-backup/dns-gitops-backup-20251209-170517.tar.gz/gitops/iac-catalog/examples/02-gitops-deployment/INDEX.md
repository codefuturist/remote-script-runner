# Example 02: GitOps Deployment - File Index

## 📁 Directory Structure

```
02-gitops-deployment/
├── README.md                    # Main tutorial (comprehensive guide)
├── CHEATSHEET.md               # Quick reference for common commands
├── INDEX.md                    # This file
├── demo.sh                     # Interactive demo script
├── quick-start.sh              # Quick walkthrough script
└── sample-deployments/         # Sample deployment configurations
    ├── development/
    │   └── my-web-app/
    │       ├── values.yaml
    │       └── kustomization.yaml
    ├── staging/
    │   └── my-web-app/
    │       └── values.yaml
    └── production/
        └── my-web-app/
            └── values.yaml
```

## 📖 Where to Start

### 1. **Complete Beginners**
Start here: [`README.md`](./README.md)
- Full step-by-step tutorial
- Explains every command
- 20-30 minute complete walkthrough

### 2. **Interactive Learners**
Run this: `./demo.sh`
- Interactive demonstration
- Shows the full workflow
- Visual and engaging

### 3. **Quick Overview**
Run this: `./quick-start.sh`
- Fast walkthrough
- Shows key concepts
- 5-10 minutes

### 4. **Command Reference**
Read this: [`CHEATSHEET.md`](./CHEATSHEET.md)
- All commands in one place
- Quick copy-paste reference
- Common workflows

## 📚 Document Descriptions

### README.md (Main Tutorial)
**Purpose**: Comprehensive step-by-step guide  
**Length**: ~600 lines  
**Time**: 20-30 minutes  
**Best for**: Learning the complete workflow

**Contains**:
- Prerequisites and setup
- 10-step deployment process
- Multi-environment deployment
- Secrets management
- GitOps workflows
- Monitoring and troubleshooting
- Best practices
- Advanced usage patterns

### CHEATSHEET.md (Quick Reference)
**Purpose**: Quick command reference  
**Length**: ~400 lines  
**Time**: Use as needed  
**Best for**: Looking up commands quickly

**Contains**:
- Command syntax reference
- Common workflow examples
- Troubleshooting commands
- Best practices summary
- Tips and tricks

### demo.sh (Interactive Demo)
**Purpose**: Interactive walkthrough  
**Type**: Bash script  
**Time**: 5-10 minutes  
**Best for**: Visual learners

**Shows**:
- Searching templates
- Viewing environments
- Creating deployments
- GitOps commit workflow
- Multi-environment progression

**Run it**:
```bash
cd examples/02-gitops-deployment
./demo.sh
```

### quick-start.sh (Quick Overview)
**Purpose**: Fast overview of key concepts  
**Type**: Bash script  
**Time**: 5-10 minutes  
**Best for**: Quick introduction

**Demonstrates**:
- Template search
- Deployment creation
- Configuration review
- GitOps commits
- Environment comparison

**Run it**:
```bash
cd examples/02-gitops-deployment
./quick-start.sh
```

## 📦 Sample Deployments

Pre-configured example deployments for three environments:

### Development (`sample-deployments/development/`)
- **Replicas**: 2
- **TLS**: Disabled
- **Logging**: Debug level
- **Branch**: develop
- **Purpose**: Fast iteration and testing

### Staging (`sample-deployments/staging/`)
- **Replicas**: 3 (autoscaling to 6)
- **TLS**: Enabled (staging certs)
- **Logging**: Info level
- **Branch**: main
- **Purpose**: Pre-production validation

### Production (`sample-deployments/production/`)
- **Replicas**: 5 (autoscaling to 20)
- **TLS**: Enabled (production certs)
- **Logging**: Warning level only
- **Branch**: main
- **Security**: Hardened
- **Purpose**: Live production deployment

**Each includes**:
- `values.yaml` - Configuration values
- `kustomization.yaml` - Kustomize manifest

## 🎯 Learning Paths

### Path 1: Guided Learning (Recommended)
1. Read: [`README.md`](./README.md) - Complete tutorial
2. Run: `./demo.sh` - See it in action
3. Reference: [`CHEATSHEET.md`](./CHEATSHEET.md) - Keep handy
4. Practice: Create your own deployment

### Path 2: Hands-On First
1. Run: `./demo.sh` - Interactive demo
2. Run: `./quick-start.sh` - Quick overview
3. Read: [`README.md`](./README.md) - Deep dive
4. Reference: [`CHEATSHEET.md`](./CHEATSHEET.md) - Commands

### Path 3: Reference Only
1. Skim: [`README.md`](./README.md) - Understand concepts
2. Use: [`CHEATSHEET.md`](./CHEATSHEET.md) - Command reference
3. Study: `sample-deployments/` - Example configs

## 🔗 Related Resources

### In This Repository
- **IaC CLI Docs**: `../../iac-cli/README.md`
- **Quick Start Guide**: `../../iac-cli/QUICKSTART.md`
- **Catalog Structure**: `../../STRUCTURE.md`
- **Main Examples**: `../README.md`

### External Resources
- [Flux CD Documentation](https://fluxcd.io/docs/)
- [GitOps Principles](https://opengitops.dev/)
- [Kubernetes Docs](https://kubernetes.io/docs/)

## 💡 Quick Commands

```bash
# View this example
cd /path/to/iac-catalog/examples/02-gitops-deployment

# Run interactive demo
./demo.sh

# Quick walkthrough
./quick-start.sh

# Read full tutorial
cat README.md | less

# Open cheat sheet
cat CHEATSHEET.md | less

# View sample configs
ls sample-deployments/*/my-web-app/
cat sample-deployments/development/my-web-app/values.yaml
```

## 🤝 Contributing

Found an issue or improvement? See `../../CONTRIBUTING.md`

## 📝 Notes

- All scripts are executable (`chmod +x *.sh`)
- Sample deployments are ready to use as templates
- Scripts are safe to run (they don't modify anything)
- Demo scripts work in any shell (bash/zsh)

---

**Choose your path and start learning!** 🚀
