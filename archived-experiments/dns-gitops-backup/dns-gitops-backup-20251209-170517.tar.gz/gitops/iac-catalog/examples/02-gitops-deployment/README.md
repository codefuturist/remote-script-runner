# Example 02: GitOps Deployment with IaC CLI

## 📋 Overview

This example demonstrates a complete GitOps workflow using the IaC CLI tool to deploy a multi-environment application with Flux CD.

**What you'll learn:**
- Using the IaC CLI for GitOps workflows
- Deploying applications across multiple environments
- Managing secrets and configurations
- Committing and syncing with Git
- Monitoring deployment status

**Time to complete:** 20-30 minutes

## 🎯 Prerequisites

1. **IaC CLI installed**:
   ```bash
   cd /path/to/iac-catalog/iac-cli
   uv pip install -e .
   ```

2. **Git repository initialized**:
   ```bash
   cd /path/to/iac-catalog
   git status  # Should show you're in a git repo
   ```

3. **Flux CD knowledge** (helpful but not required)

## 📁 What We'll Deploy

A simple web application with:
- **Development environment** - Testing and development
- **Staging environment** - Pre-production validation
- **Production environment** - Live deployment

Using Flux CD GitOps patterns for automatic reconciliation.

## 🚀 Step-by-Step Tutorial

### Step 1: Initialize and Explore

First, let's see what's available in our catalog:

```bash
# Navigate to the repo root
cd /path/to/iac-catalog

# Search for GitOps templates
iac search gitops

# Search for Flux-specific templates
iac search flux

# View template details
iac template show catalog/gitops/flux/tenants/basic-tenant.yaml
```

### Step 2: Interactive Deployment Setup

Let's use the interactive mode to set up our first deployment:

```bash
# Start interactive mode
iac interactive

# Follow the prompts:
# 1. Choose "Deploy" option
# 2. Select environment: "development"
# 3. Choose template: Browse to flux tenant template
# 4. Configure deployment settings
```

**Or use direct commands:**

```bash
# Create development deployment
iac deploy create my-web-app \
  --environment development \
  --template catalog/gitops/flux/tenants/basic-tenant.yaml \
  --name my-web-app \
  --namespace apps-dev
```

### Step 3: Configure the Deployment

Edit the generated deployment configuration:

```bash
# Edit the deployment configuration
iac deploy edit my-web-app --environment development

# Or manually edit:
# deployments/development/my-web-app/values.yaml
```

**Example configuration** (values.yaml):

```yaml
# Application settings
app:
  name: my-web-app
  namespace: apps-dev
  replicas: 2
  
# Image configuration
image:
  repository: nginx
  tag: "1.25-alpine"
  pullPolicy: IfNotPresent

# Service configuration
service:
  type: ClusterIP
  port: 80
  
# Ingress configuration
ingress:
  enabled: true
  host: my-web-app.dev.example.com
  tls:
    enabled: false

# Flux GitOps settings
gitops:
  source:
    branch: develop
    interval: 1m
  kustomization:
    interval: 5m
    prune: true
    wait: true
```

### Step 4: Add Secrets (Optional)

If your application needs secrets:

```bash
# Create a secret for the development environment
iac secrets create database-credentials \
  --environment development \
  --key DB_PASSWORD \
  --value "dev-secret-password"

# View secrets (values are masked)
iac secrets list --environment development

# Export secret to file (for manual encryption with SOPS/Sealed Secrets)
iac secrets export database-credentials \
  --environment development \
  --output deployments/development/my-web-app/secrets.yaml
```

### Step 5: Validate the Deployment

Before committing, let's validate everything:

```bash
# Check deployment status
iac status my-web-app --environment development

# View generated Kubernetes manifests
iac deploy preview my-web-app --environment development

# List all deployments
iac deploy list --environment development
```

### Step 6: GitOps - Commit Changes

Now let's commit our deployment to Git:

```bash
# Check what will be committed
git status

# Use GitOps commit command (interactive)
iac gitops commit

# Or with a specific message
iac gitops commit -m "feat: add my-web-app to development environment"

# Commit and push in one command
iac gitops commit --push -m "feat: add my-web-app to development"
```

### Step 7: Deploy to Staging

Now let's promote to staging:

```bash
# Create staging deployment (copy from dev)
iac deploy create my-web-app \
  --environment staging \
  --template catalog/gitops/flux/tenants/basic-tenant.yaml \
  --name my-web-app \
  --namespace apps-staging

# Update staging-specific values
iac deploy edit my-web-app --environment staging

# Validate
iac deploy preview my-web-app --environment staging

# Commit staging changes
iac gitops commit -m "feat: promote my-web-app to staging" --push
```

**Staging configuration changes** (values.yaml):

```yaml
app:
  name: my-web-app
  namespace: apps-staging
  replicas: 3  # More replicas in staging

image:
  repository: nginx
  tag: "1.25-alpine"

ingress:
  host: my-web-app.staging.example.com
  tls:
    enabled: true  # Enable TLS in staging

gitops:
  source:
    branch: main  # Use main branch for staging
    interval: 2m
```

### Step 8: Deploy to Production

Finally, promote to production with extra validation:

```bash
# Create production deployment
iac deploy create my-web-app \
  --environment production \
  --template catalog/gitops/flux/tenants/basic-tenant.yaml \
  --name my-web-app \
  --namespace apps-prod

# Edit production values
iac deploy edit my-web-app --environment production

# Preview changes carefully
iac deploy preview my-web-app --environment production

# Validate before commit
iac status my-web-app --environment production

# Commit with detailed message
iac gitops commit -m "feat: deploy my-web-app to production

- Configured for high availability (5 replicas)
- Enabled TLS with production certificates
- Set resource limits and requests
- Configured monitoring and alerts" --push
```

**Production configuration** (values.yaml):

```yaml
app:
  name: my-web-app
  namespace: apps-prod
  replicas: 5  # High availability

image:
  repository: nginx
  tag: "1.25-alpine"

resources:
  requests:
    cpu: 100m
    memory: 128Mi
  limits:
    cpu: 500m
    memory: 512Mi

ingress:
  host: my-web-app.example.com
  tls:
    enabled: true
    secretName: prod-tls-cert

gitops:
  source:
    branch: main
    interval: 5m  # Less frequent checks in prod
  kustomization:
    interval: 10m
    prune: true
    wait: true
    timeout: 5m
```

### Step 9: Monitor Deployments

Track your deployments across environments:

```bash
# View all environments
iac env list

# Check specific environment status
iac status --environment development
iac status --environment staging  
iac status --environment production

# View deployment logs (if integrated with Flux)
iac logs my-web-app --environment production --follow

# List all deployments across all environments
iac deploy list --all-environments
```

### Step 10: Make Updates

When you need to update your application:

```bash
# Update the image tag in development
iac deploy edit my-web-app --environment development
# Change image.tag to "1.26-alpine"

# Preview the changes
iac deploy preview my-web-app --environment development

# Commit the update
iac gitops commit -m "chore: update my-web-app to nginx 1.26" --push

# Flux will automatically sync the changes!
```

## 📊 Complete Workflow Summary

```mermaid
graph TD
    A[Search Templates] --> B[Create Deployment]
    B --> C[Configure Values]
    C --> D[Add Secrets]
    D --> E[Validate]
    E --> F{Ready?}
    F -->|No| C
    F -->|Yes| G[GitOps Commit]
    G --> H[Push to Git]
    H --> I[Flux Syncs]
    I --> J[Monitor Status]
    J --> K{Issues?}
    K -->|Yes| C
    K -->|No| L[Deploy Next Env]
```

## 🎨 Advanced Usage

### Multi-Application Deployment

Deploy multiple apps at once:

```bash
# Create multiple deployments
for app in frontend backend api; do
  iac deploy create $app \
    --environment development \
    --template catalog/gitops/flux/tenants/basic-tenant.yaml \
    --name $app \
    --namespace apps-dev
done

# Commit all at once
iac gitops commit -m "feat: deploy complete application stack" --push
```

### Environment Comparison

Compare configurations across environments:

```bash
# Compare dev vs staging
iac deploy diff my-web-app \
  --from development \
  --to staging

# Compare staging vs production
iac deploy diff my-web-app \
  --from staging \
  --to production
```

### Rollback Procedure

If something goes wrong:

```bash
# View git history
git log --oneline deployments/production/

# Revert to previous version
git revert HEAD

# Or reset to specific commit
git reset --hard <commit-hash>

# Push rollback
git push origin main

# Flux will automatically sync the rollback!
```

## 🔍 Verification

After deployment, verify everything is working:

```bash
# Check Flux reconciliation
kubectl get gitrepositories -A
kubectl get kustomizations -A

# Check your application
kubectl get pods -n apps-dev
kubectl get pods -n apps-staging
kubectl get pods -n apps-prod

# View Flux events
kubectl events -n flux-system

# Check application logs
kubectl logs -n apps-prod -l app=my-web-app --tail=50
```

## 📝 Best Practices

1. **Always validate before committing**:
   ```bash
   iac deploy preview <name> --environment <env>
   ```

2. **Use meaningful commit messages**:
   ```bash
   iac gitops commit -m "feat: description" --push
   ```

3. **Test in development first**:
   - Deploy to dev → validate → staging → validate → production

4. **Keep secrets secure**:
   - Use sealed secrets or SOPS
   - Never commit plain-text secrets

5. **Monitor after deployment**:
   ```bash
   iac logs <name> --environment <env> --follow
   ```

6. **Document changes**:
   - Add comments to your values.yaml files
   - Keep deployment notes in commit messages

## 🐛 Troubleshooting

### Deployment not syncing?

```bash
# Check Flux logs
kubectl logs -n flux-system deploy/source-controller
kubectl logs -n flux-system deploy/kustomize-controller

# Force reconciliation
flux reconcile source git <source-name>
flux reconcile kustomization <kustomization-name>
```

### Configuration errors?

```bash
# Validate YAML syntax
iac deploy preview <name> --environment <env>

# Check Kubernetes events
kubectl get events -n <namespace> --sort-by='.lastTimestamp'
```

### Git push fails?

```bash
# Check git status
git status

# Pull latest changes first
git pull origin develop

# Resolve conflicts and retry
iac gitops commit -m "message" --push
```

## 🎓 What's Next?

- **[Example 03: Multi-Cluster Deployment](../03-multi-cluster/)** - Deploy across multiple clusters
- **[Example 04: Advanced Flux Patterns](../04-advanced-flux/)** - Complex GitOps workflows
- **[IaC CLI Documentation](../../iac-cli/README.md)** - Full CLI reference

## 📚 Additional Resources

- [Flux CD Documentation](https://fluxcd.io/docs/)
- [GitOps Principles](https://opengitops.dev/)
- [Kubernetes Best Practices](https://kubernetes.io/docs/concepts/configuration/overview/)
- [IaC Catalog Structure](../../STRUCTURE.md)

## 🤝 Contributing

Found an issue or have suggestions? See [CONTRIBUTING.md](../../CONTRIBUTING.md)

---

**Happy deploying!** 🚀
