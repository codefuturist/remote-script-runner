# IaC CLI GitOps Deployment - Cheat Sheet

Quick reference for common IaC CLI commands used in GitOps workflows.

## 🚀 Quick Start Commands

```bash
# Interactive mode (easiest for beginners)
iac interactive

# Get help
iac --help
iac deploy --help
iac gitops --help
```

## 📦 Template Management

```bash
# Search for templates
iac search <keyword>
iac search gitops
iac search flux
iac search kubernetes

# View template details
iac template show <path/to/template.yaml>

# List all templates
iac template list
```

## 🌍 Environment Management

```bash
# List environments
iac env list

# Show environment details
iac env show <environment>

# Set default environment
iac env set <environment>
```

## 🚢 Deployment Operations

```bash
# Create a deployment
iac deploy create <name> \
  --environment <env> \
  --template <template-path> \
  --name <app-name> \
  --namespace <k8s-namespace>

# List deployments
iac deploy list
iac deploy list --environment <env>
iac deploy list --all-environments

# Edit deployment configuration
iac deploy edit <name> --environment <env>

# Preview deployment (dry-run)
iac deploy preview <name> --environment <env>

# Compare deployments across environments
iac deploy diff <name> \
  --from <env1> \
  --to <env2>

# Delete a deployment
iac deploy delete <name> --environment <env>
```

## 🔐 Secrets Management

```bash
# Create a secret
iac secrets create <name> \
  --environment <env> \
  --key <KEY_NAME> \
  --value <secret-value>

# List secrets (values masked)
iac secrets list --environment <env>

# Show secret details
iac secrets show <name> --environment <env>

# Export secret to file
iac secrets export <name> \
  --environment <env> \
  --output <path/to/file.yaml>

# Delete a secret
iac secrets delete <name> --environment <env>
```

## 🔄 GitOps Operations

```bash
# Check git status
git status

# Commit changes (interactive)
iac gitops commit

# Commit with message
iac gitops commit -m "feat: description"

# Commit and push
iac gitops commit --push -m "feat: description"

# Manual git operations
git add .
git commit -m "feat: description"
git push origin <branch>
```

## 📊 Monitoring & Status

```bash
# Check deployment status
iac status <name> --environment <env>
iac status --environment <env>  # All deployments

# View logs
iac logs <name> --environment <env>
iac logs <name> --environment <env> --follow
iac logs <name> --environment <env> --tail 100

# List inventory
iac inventory list
iac inventory show <name>
```

## 🎯 Complete Workflow Examples

### Deploy to Development

```bash
# 1. Search for a template
iac search flux

# 2. Create deployment
iac deploy create my-app \
  --environment development \
  --template catalog/gitops/flux/tenants/basic-tenant.yaml \
  --name my-app \
  --namespace apps-dev

# 3. Edit configuration
iac deploy edit my-app --environment development

# 4. Preview changes
iac deploy preview my-app --environment development

# 5. Commit to Git
iac gitops commit -m "feat: add my-app to development" --push

# 6. Monitor deployment
iac logs my-app --environment development --follow
```

### Promote to Staging

```bash
# 1. Create staging deployment
iac deploy create my-app \
  --environment staging \
  --template catalog/gitops/flux/tenants/basic-tenant.yaml \
  --name my-app \
  --namespace apps-staging

# 2. Edit staging config (increase replicas, enable TLS, etc.)
iac deploy edit my-app --environment staging

# 3. Compare with dev
iac deploy diff my-app --from development --to staging

# 4. Validate and commit
iac deploy preview my-app --environment staging
iac gitops commit -m "feat: promote my-app to staging" --push
```

### Deploy to Production

```bash
# 1. Create production deployment
iac deploy create my-app \
  --environment production \
  --template catalog/gitops/flux/tenants/basic-tenant.yaml \
  --name my-app \
  --namespace apps-prod

# 2. Configure for production (HA, security, monitoring)
iac deploy edit my-app --environment production

# 3. Review carefully
iac deploy preview my-app --environment production
iac deploy diff my-app --from staging --to production

# 4. Add production secrets
iac secrets create db-credentials \
  --environment production \
  --key DB_PASSWORD \
  --value "secure-production-password"

# 5. Commit with detailed message
iac gitops commit -m "feat: deploy my-app to production

- Configured 5 replicas for HA
- Enabled TLS with production certificates
- Set resource limits and requests
- Configured PodDisruptionBudget
- Added monitoring and alerts" --push

# 6. Monitor production deployment
iac status my-app --environment production
iac logs my-app --environment production --follow
```

### Update Application

```bash
# 1. Edit configuration (e.g., update image tag)
iac deploy edit my-app --environment development

# 2. Preview changes
iac deploy preview my-app --environment development

# 3. Commit update
iac gitops commit -m "chore: update my-app to v1.2.0" --push

# 4. Flux automatically syncs the changes!

# 5. Promote through environments
iac deploy edit my-app --environment staging
iac gitops commit -m "chore: update my-app to v1.2.0 in staging" --push

iac deploy edit my-app --environment production
iac gitops commit -m "chore: update my-app to v1.2.0 in production" --push
```

### Rollback

```bash
# Git-based rollback
git log --oneline deployments/production/my-app/
git revert <commit-hash>
git push origin main

# Flux will automatically sync the rollback

# Or reset to specific version
git reset --hard <good-commit-hash>
git push --force origin main
```

## 🔧 Troubleshooting Commands

```bash
# Check if in git repo
git status
git remote -v

# View git history
git log --oneline --graph --decorate

# Check what will be committed
git diff
git diff --cached

# View Flux resources (if Flux is installed)
kubectl get gitrepositories -A
kubectl get kustomizations -A
kubectl get helmreleases -A

# Check Flux logs
kubectl logs -n flux-system deploy/source-controller
kubectl logs -n flux-system deploy/kustomize-controller
kubectl logs -n flux-system deploy/helm-controller

# Force Flux reconciliation
flux reconcile source git <name>
flux reconcile kustomization <name>

# Check application status
kubectl get pods -n <namespace>
kubectl describe pod <pod-name> -n <namespace>
kubectl logs <pod-name> -n <namespace>

# View events
kubectl get events -n <namespace> --sort-by='.lastTimestamp'
```

## 💡 Tips & Best Practices

### Commit Messages

Follow conventional commit format:

```bash
# Feature
iac gitops commit -m "feat: add new application"

# Bug fix
iac gitops commit -m "fix: correct replica count"

# Configuration change
iac gitops commit -m "chore: update resource limits"

# Documentation
iac gitops commit -m "docs: add deployment notes"

# Rollback
iac gitops commit -m "revert: rollback to previous version"
```

### Environment Progression

Always follow this order:

1. **Development** → Test and validate
2. **Staging** → Pre-production verification
3. **Production** → Live deployment

### Validation Checklist

Before committing to production:

- [ ] Preview changes: `iac deploy preview`
- [ ] Compare environments: `iac deploy diff`
- [ ] Check secrets: `iac secrets list`
- [ ] Review resource limits
- [ ] Verify replica counts
- [ ] Confirm TLS settings
- [ ] Check health probes
- [ ] Review monitoring config

## 📚 Additional Resources

- **Full Tutorial**: `examples/02-gitops-deployment/README.md`
- **CLI Documentation**: `iac-cli/README.md`
- **Quick Start Guide**: `iac-cli/QUICKSTART.md`
- **Template Catalog**: `catalog/README.md`

## 🎯 Common Use Cases

| Task | Command |
|------|---------|
| Start interactive mode | `iac interactive` |
| Search templates | `iac search <keyword>` |
| Create deployment | `iac deploy create <name> --environment <env>` |
| Edit config | `iac deploy edit <name> --environment <env>` |
| Preview changes | `iac deploy preview <name> --environment <env>` |
| Commit changes | `iac gitops commit -m "message" --push` |
| Check status | `iac status <name> --environment <env>` |
| View logs | `iac logs <name> --environment <env> --follow` |
| Compare envs | `iac deploy diff <name> --from <env1> --to <env2>` |
| Add secret | `iac secrets create <name> --environment <env>` |

---

**Keep this cheat sheet handy for quick reference!** 📋✨
