#!/bin/bash
# Interactive Demo Script for GitOps Deployment
# This script shows a full workflow with the IaC CLI

set -e

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
CYAN='\033[0;36m'
NC='\033[0m'

clear

echo -e "${CYAN}"
cat << "EOF"
╔═══════════════════════════════════════════════════════════════╗
║                                                               ║
║   IaC CLI - GitOps Deployment Interactive Demo               ║
║                                                               ║
║   This demo walks through deploying a web application        ║
║   across multiple environments using GitOps principles       ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
EOF
echo -e "${NC}"
echo ""

# Check prerequisites
echo -e "${BLUE}Checking prerequisites...${NC}"
echo ""

if ! command -v iac &> /dev/null; then
    echo -e "${RED}✗ IaC CLI not installed${NC}"
    echo "Please install it first: cd iac-cli && uv pip install -e ."
    exit 1
fi
echo -e "${GREEN}✓ IaC CLI installed${NC}"

if ! command -v git &> /dev/null; then
    echo -e "${RED}✗ Git not installed${NC}"
    exit 1
fi
echo -e "${GREEN}✓ Git available${NC}"

REPO_ROOT=$(git rev-parse --show-toplevel 2>/dev/null || echo "")
if [ -z "$REPO_ROOT" ]; then
    echo -e "${RED}✗ Not in a git repository${NC}"
    exit 1
fi
cd "$REPO_ROOT"
echo -e "${GREEN}✓ In git repository${NC}"
echo ""

read -p "Press Enter to start the demo..."
clear

# Demo 1: Search Templates
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}Demo 1: Searching for Templates${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo ""
echo -e "${YELLOW}Let's search for GitOps templates in our catalog...${NC}"
echo ""
echo -e "${BLUE}$ iac search gitops${NC}"
sleep 1
iac search gitops || echo -e "${YELLOW}(Search results may vary based on catalog content)${NC}"
echo ""
read -p "Press Enter to continue..."
clear

# Demo 2: List Environments
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}Demo 2: Viewing Available Environments${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo ""
echo -e "${YELLOW}Let's see what environments we can deploy to...${NC}"
echo ""
echo -e "${BLUE}$ iac env list${NC}"
sleep 1
iac env list
echo ""
read -p "Press Enter to continue..."
clear

# Demo 3: View Template
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}Demo 3: Examining a Template${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo ""
echo -e "${YELLOW}Let's look at a Flux GitOps template...${NC}"
echo ""
echo -e "${BLUE}$ iac template show catalog/gitops/flux/tenants/basic-tenant.yaml${NC}"
sleep 1
iac template show catalog/gitops/flux/tenants/basic-tenant.yaml 2>/dev/null || \
    echo -e "${YELLOW}Template details would be shown here${NC}"
echo ""
read -p "Press Enter to continue..."
clear

# Demo 4: Sample Deployment Configuration
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}Demo 4: Deployment Configuration${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo ""
echo -e "${YELLOW}Here's a sample deployment configuration for development:${NC}"
echo ""
echo -e "${BLUE}File: deployments/development/my-web-app/values.yaml${NC}"
echo ""
cat examples/02-gitops-deployment/sample-deployments/development/my-web-app/values.yaml | head -40
echo "..."
echo ""
read -p "Press Enter to continue..."
clear

# Demo 5: Environment Progression
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}Demo 5: Multi-Environment Deployment${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo ""
echo -e "${YELLOW}Typical deployment progression:${NC}"
echo ""
echo -e "${GREEN}1. Development${NC}"
echo "   iac deploy create my-web-app --environment development"
echo "   - Fast iteration, debug logging"
echo "   - 2 replicas, no TLS"
echo ""
echo -e "${GREEN}2. Staging${NC}"
echo "   iac deploy create my-web-app --environment staging"
echo "   - Pre-production testing"
echo "   - 3 replicas, TLS enabled, autoscaling"
echo ""
echo -e "${GREEN}3. Production${NC}"
echo "   iac deploy create my-web-app --environment production"
echo "   - High availability, security hardened"
echo "   - 5 replicas, full monitoring, PDB"
echo ""
read -p "Press Enter to continue..."
clear

# Demo 6: GitOps Workflow
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}Demo 6: GitOps Commit Workflow${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo ""
echo -e "${YELLOW}After making changes, commit them to Git:${NC}"
echo ""
echo -e "${BLUE}$ iac gitops commit -m 'feat: deploy my-web-app' --push${NC}"
echo ""
echo "This command will:"
echo "  1. Show you what changed"
echo "  2. Stage all deployment files"
echo "  3. Commit with your message"
echo "  4. Push to remote repository"
echo "  5. Flux will automatically sync!"
echo ""
read -p "Press Enter to continue..."
clear

# Demo 7: Monitoring
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}Demo 7: Monitoring Deployments${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo ""
echo -e "${YELLOW}Monitor your deployments across environments:${NC}"
echo ""
echo -e "${BLUE}$ iac status --environment production${NC}"
echo ""
echo -e "${BLUE}$ iac logs my-web-app --environment production --follow${NC}"
echo ""
echo -e "${BLUE}$ iac deploy list --all-environments${NC}"
echo ""
read -p "Press Enter to continue..."
clear

# Demo 8: Interactive Mode
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}Demo 8: Interactive Mode${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════${NC}"
echo ""
echo -e "${YELLOW}For a guided experience, use interactive mode:${NC}"
echo ""
echo -e "${BLUE}$ iac interactive${NC}"
echo ""
echo "Interactive mode provides:"
echo "  • Step-by-step guidance"
echo "  • Menu-driven interface"
echo "  • Best practices built-in"
echo "  • Perfect for beginners"
echo ""
read -p "Press Enter to see summary..."
clear

# Summary
echo -e "${CYAN}"
cat << "EOF"
╔═══════════════════════════════════════════════════════════════╗
║                                                               ║
║   Demo Complete! 🎉                                           ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
EOF
echo -e "${NC}"
echo ""
echo -e "${GREEN}What you learned:${NC}"
echo ""
echo "  ✓ Searching for templates"
echo "  ✓ Viewing environments"
echo "  ✓ Creating deployments"
echo "  ✓ Multi-environment workflow"
echo "  ✓ GitOps commit process"
echo "  ✓ Monitoring and logs"
echo ""
echo -e "${BLUE}Try it yourself:${NC}"
echo ""
echo "  1. Run: iac interactive"
echo "  2. Read: examples/02-gitops-deployment/README.md"
echo "  3. Explore: iac --help"
echo ""
echo -e "${YELLOW}Resources:${NC}"
echo ""
echo "  • Full Tutorial: examples/02-gitops-deployment/README.md"
echo "  • CLI Docs: iac-cli/README.md"
echo "  • Quick Start: iac-cli/QUICKSTART.md"
echo ""
echo -e "${GREEN}Happy deploying! 🚀${NC}"
echo ""
