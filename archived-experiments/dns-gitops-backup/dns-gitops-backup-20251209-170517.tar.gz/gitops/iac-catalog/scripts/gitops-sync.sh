#!/usr/bin/env bash
# GitOps Auto-Sync Service
# Clones repository and manages multiple application deployments with SOPS encryption

set -euo pipefail

# Configuration
REPO_URL="${REPO_URL:-https://github.com/codefuturist/iac-catalog.git}"
REPO_BRANCH="${REPO_BRANCH:-develop}"
GITOPS_ROOT="${GITOPS_ROOT:-/opt/gitops}"
REPO_PATH="$GITOPS_ROOT/iac-catalog"
AGE_KEY_FILE="${AGE_KEY_FILE:-$GITOPS_ROOT/.age.key}"
LOCK_FILE="/tmp/gitops-sync.lock"
LOG_FILE="${LOG_FILE:-/tmp/gitops-sync.log}"

# Logging
log() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] $*" | tee -a "$LOG_FILE"
}

# Acquire lock to prevent concurrent runs
acquire_lock() {
    if [ -f "$LOCK_FILE" ]; then
        local pid=$(cat "$LOCK_FILE")
        if kill -0 "$pid" 2>/dev/null; then
            log "Another sync is already running (PID: $pid)"
            exit 0
        else
            log "Removing stale lock file"
            rm -f "$LOCK_FILE"
        fi
    fi
    echo $$ > "$LOCK_FILE"
}

# Release lock
release_lock() {
    rm -f "$LOCK_FILE"
}

# Ensure cleanup on exit
trap release_lock EXIT

# Check prerequisites
check_prerequisites() {
    local missing=()
    
    command -v git >/dev/null 2>&1 || missing+=("git")
    command -v sops >/dev/null 2>&1 || missing+=("sops")
    command -v docker >/dev/null 2>&1 || missing+=("docker")
    
    if [ ${#missing[@]} -gt 0 ]; then
        log "ERROR: Missing required tools: ${missing[*]}"
        exit 1
    fi
    
    if [ ! -f "$AGE_KEY_FILE" ]; then
        log "ERROR: Age key not found at $AGE_KEY_FILE"
        exit 1
    fi
}

# Clone or update repository
sync_repo() {
    log "Syncing repository from $REPO_URL (branch: $REPO_BRANCH)"
    
    if [ -d "$REPO_PATH/.git" ]; then
        log "Updating existing repository..."
        cd "$REPO_PATH"
        
        # Disable credential helpers to avoid interactive prompts
        git config --local credential.helper ""
        
        # Fetch latest changes
        if ! git fetch origin "$REPO_BRANCH" 2>&1 | tee -a "$LOG_FILE"; then
            log "ERROR: Failed to fetch repository"
            return 1
        fi
        
        # Check if there are updates
        local local_hash=$(git rev-parse HEAD)
        local remote_hash=$(git rev-parse "origin/$REPO_BRANCH")
        
        if [ "$local_hash" = "$remote_hash" ]; then
            log "Repository is up to date (commit: ${local_hash:0:8})"
            return 2  # No changes
        fi
        
        log "Updates available: $local_hash -> $remote_hash"
        
        # Reset to latest
        if ! git reset --hard "origin/$REPO_BRANCH" 2>&1 | tee -a "$LOG_FILE"; then
            log "ERROR: Failed to reset repository"
            return 1
        fi
        
        log "Repository updated successfully"
    else
        log "Cloning repository for the first time..."
        mkdir -p "$GITOPS_ROOT"
        
        # Clone with explicit config to avoid credential manager
        if ! GIT_TERMINAL_PROMPT=0 git clone --branch "$REPO_BRANCH" "$REPO_URL" "$REPO_PATH" 2>&1 | tee -a "$LOG_FILE"; then
            log "ERROR: Failed to clone repository"
            return 1
        fi
        
        # Disable credential helpers
        cd "$REPO_PATH"
        git config --local credential.helper ""
        
        log "Repository cloned successfully"
    fi
    
    return 0
}

# Find all .sops files (both .env.sops and individual secret files)
find_encrypted_secrets() {
    find "$REPO_PATH/deployments" -type f -name "*.sops" 2>/dev/null || true
}

# Decrypt a single .sops file
decrypt_sops_file() {
    local sops_file="$1"
    local decrypted_file="${sops_file%.sops}"  # Remove .sops extension
    
    log "Decrypting: $sops_file"
    
    export SOPS_AGE_KEY_FILE="$AGE_KEY_FILE"
    
    if ! sops --decrypt "$sops_file" > "$decrypted_file" 2>&1 | tee -a "$LOG_FILE"; then
        log "ERROR: Failed to decrypt $sops_file"
        return 1
    fi
    
    chmod 600 "$decrypted_file"
    log "✓ Decrypted to: $decrypted_file"
    return 0
}

# Decrypt all secrets in repository
decrypt_all_secrets() {
    log "Searching for encrypted secrets..."
    
    local sops_files=$(find_encrypted_secrets)
    local count=0
    local failed=0
    
    if [ -z "$sops_files" ]; then
        log "No .sops files found"
        return 0
    fi
    
    while IFS= read -r sops_file; do
        if decrypt_sops_file "$sops_file"; then
            ((count++))
        else
            ((failed++))
        fi
    done <<< "$sops_files"
    
    log "Decryption complete: $count succeeded, $failed failed"
    return 0
}

# Find docker-compose stacks that need restarting
find_compose_stacks() {
    local changed_dirs=()
    local seen_dirs=()
    
    # Find all docker-compose.yml files in deployments
    while IFS= read -r compose_file; do
        local dir=$(dirname "$compose_file")
        
        # Skip if already added
        if [[ " ${seen_dirs[@]} " =~ " ${dir} " ]]; then
            continue
        fi
        
        # Check if directory has decrypted secrets (.env or secrets/*)
        if [ -f "$dir/.env" ] || [ -n "$(find "$dir/secrets" -type f ! -name "*.sops" ! -name "*.example" ! -name ".gitignore" 2>/dev/null)" ]; then
            changed_dirs+=("$dir")
            seen_dirs+=("$dir")
        fi
    done < <(find "$REPO_PATH/deployments" -type f -name "docker-compose.yml" 2>/dev/null || true)
    
    printf '%s\n' "${changed_dirs[@]}"
}

# Restart a docker-compose stack
restart_stack() {
    local stack_dir="$1"
    local stack_name=$(basename "$stack_dir")
    
    log "Restarting stack: $stack_name"
    
    cd "$stack_dir"
    
    # Check if stack is running
    if docker compose ps --quiet 2>/dev/null | grep -q .; then
        log "Stack $stack_name is running, restarting..."
        
        if docker compose restart 2>&1 | tee -a "$LOG_FILE"; then
            log "✓ Stack $stack_name restarted successfully"
            return 0
        else
            log "ERROR: Failed to restart stack $stack_name"
            return 1
        fi
    else
        log "Stack $stack_name is not running, skipping restart"
        return 0
    fi
}

# Restart all affected stacks
restart_all_stacks() {
    log "Checking for stacks to restart..."
    
    local stacks=$(find_compose_stacks)
    local count=0
    
    if [ -z "$stacks" ]; then
        log "No stacks need restarting"
        return 0
    fi
    
    while IFS= read -r stack_dir; do
        if restart_stack "$stack_dir"; then
            ((count++))
        fi
    done <<< "$stacks"
    
    log "Restart complete: $count stacks restarted"
    return 0
}

# Main execution
main() {
    log "=== GitOps Sync Started ==="
    
    acquire_lock
    check_prerequisites
    
    # Sync repository
    if ! sync_repo; then
        repo_status=$?
        if [ $repo_status -eq 2 ]; then
            log "No updates needed"
            log "=== GitOps Sync Complete (no changes) ==="
            exit 0
        else
            log "=== GitOps Sync Failed ==="
            exit 1
        fi
    fi
    
    # Decrypt all secrets
    if ! decrypt_all_secrets; then
        log "=== GitOps Sync Failed (decryption errors) ==="
        exit 1
    fi
    
    # Restart affected stacks
    if ! restart_all_stacks; then
        log "WARNING: Some stacks failed to restart"
    fi
    
    log "=== GitOps Sync Complete ==="
}

# Run main function
main "$@"
