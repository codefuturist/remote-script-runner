#!/bin/bash
# Reconcile FluxCD and Portainer after git push
# Usage: ./reconcile.sh [--wait]
#   --wait: Block until reconciliation completes (default: non-blocking)

set -uo pipefail

TIMEOUT_SECS=30
FLUX_CONTEXT="k3s-prod"
LOG_FILE="/tmp/iac-catalog-reconcile.log"
WAIT_MODE=false

# Parse args
[[ "${1:-}" == "--wait" ]] && WAIT_MODE=true

# Timeout wrapper - uses timeout command if available, otherwise runs without timeout
run_with_timeout() {
  local secs="$1"
  shift
  if command -v timeout &> /dev/null; then
    timeout "$secs" "$@"
  elif command -v gtimeout &> /dev/null; then
    gtimeout "$secs" "$@"  # macOS with coreutils
  else
    # No timeout available - run directly with flux's built-in timeout
    "$@"
  fi
}

reconcile() {
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] Reconciliation triggered" | tee -a "$LOG_FILE"
  
  # FluxCD reconciliation
  if command -v flux &> /dev/null; then
    echo "  -> FluxCD git source..." | tee -a "$LOG_FILE"
    run_with_timeout "$TIMEOUT_SECS" flux --context "$FLUX_CONTEXT" reconcile source git flux-system --timeout="${TIMEOUT_SECS}s" 2>&1 | tee -a "$LOG_FILE" || true
    
    echo "  -> FluxCD kustomizations..." | tee -a "$LOG_FILE"
    run_with_timeout "$TIMEOUT_SECS" flux --context "$FLUX_CONTEXT" reconcile kustomization infrastructure --timeout="${TIMEOUT_SECS}s" 2>&1 | tee -a "$LOG_FILE" &
    local pid1=$!
    run_with_timeout "$TIMEOUT_SECS" flux --context "$FLUX_CONTEXT" reconcile kustomization apps --timeout="${TIMEOUT_SECS}s" 2>&1 | tee -a "$LOG_FILE" &
    local pid2=$!
    
    if $WAIT_MODE; then
      wait $pid1 $pid2 2>/dev/null || true
    fi
  else
    echo "  [SKIP] flux CLI not found" | tee -a "$LOG_FILE"
  fi
  
  # Portainer webhook (configure via PORTAINER_WEBHOOK env var)
  if [[ -n "${PORTAINER_WEBHOOK:-}" ]]; then
    echo "  -> Portainer webhook..." | tee -a "$LOG_FILE"
    run_with_timeout 10 curl -s -X POST "$PORTAINER_WEBHOOK" 2>&1 | tee -a "$LOG_FILE" &
    $WAIT_MODE && wait
  fi
  
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] Done" | tee -a "$LOG_FILE"
}

if $WAIT_MODE; then
  reconcile
else
  reconcile &
  disown 2>/dev/null || true  # Detach from shell
  echo "Reconciliation running in background (log: $LOG_FILE)"
fi
