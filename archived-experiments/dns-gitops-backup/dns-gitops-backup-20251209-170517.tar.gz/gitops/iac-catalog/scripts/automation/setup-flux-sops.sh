#!/usr/bin/env bash
# setup-flux-sops.sh
# 
# Automated setup script for FluxCD with SOPS age encryption
# 
# This script automates the complete setup process for FluxCD with encrypted secrets.
# It handles everything from checking prerequisites to configuring SOPS encryption.
#
# PREREQUISITES (will be checked and installation instructions provided):
#   - flux CLI: FluxCD command-line tool
#   - age: File encryption tool
#   - sops: Secret Operations tool
#   - kubectl: Kubernetes command-line tool
#   - git: Version control
#   - Access to a Kubernetes cluster (local or cloud)
#   - GitHub account and personal access token (for Flux bootstrap)
#
# WHAT THIS SCRIPT DOES:
#   1. Checks all prerequisites are installed
#   2. Verifies Kubernetes cluster access
#   3. Confirms Flux is bootstrapped (or provides instructions)
#   4. Verifies Flux kustomize-controller has SOPS support (built-in)
#   5. Generates age encryption key pair
#   6. Creates Kubernetes secret with the private key (server-side)
#   7. Configures .sops.yaml with the public key (client-side)
#   8. Updates .gitignore to prevent key commits
#   9. Adds SOPS decryption config to Flux kustomizations (server-side)
#   10. Tests SOPS encryption/decryption
#   11. Validates Flux can decrypt secrets in the cluster
#
# SERVER-SIDE COMPONENTS:
#   - Flux kustomize-controller: Has built-in SOPS support (no extra installation)
#   - Age private key: Stored as Kubernetes secret in flux-system namespace
#   - Kustomization decryption config: Tells Flux to use SOPS with the age key
#   - No SOPS or age binary needed on the server/cluster
#
# CLIENT-SIDE COMPONENTS:
#   - age: For generating keys
#   - sops: For encrypting secrets before committing to Git
#   - .sops.yaml: Configuration file with age public key
#
# USAGE:
#   # Basic usage (uses defaults)
#   ./scripts/automation/setup-flux-sops.sh
#
#   # With custom configuration
#   CLUSTER_PATH=catalog/gitops/flux/clusters/staging \
#   AGE_KEY_FILE=staging.agekey \
#   FLUX_NAMESPACE=flux-staging \
#   SECRET_NAME=sops-age \
#   BRANCH=main \
#   ./scripts/automation/setup-flux-sops.sh
#
# ENVIRONMENT VARIABLES:
#   CLUSTER_PATH     - Path to Flux cluster config (default: catalog/gitops/flux/clusters/production)
#   AGE_KEY_FILE     - Name of age key file (default: age.agekey)
#   FLUX_NAMESPACE   - Flux namespace (default: flux-system)
#   SECRET_NAME      - Name of SOPS secret (default: sops-age)
#   BRANCH           - Git branch for Flux (default: develop)
#
# SECURITY NOTES:
#   - The age private key is stored ONLY in the cluster as a Kubernetes secret
#   - The age private key file (age.agekey) should NEVER be committed to Git
#   - The script automatically adds the key file to .gitignore
#   - Use different age keys for different environments (dev/staging/prod)
#   - Back up the age private key in a secure location (password manager, vault)
#
# AUTHOR: IAC Catalog Team
# LICENSE: MIT

set -e  # Exit on error
set -o pipefail  # Exit on pipe failure

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
CLUSTER_PATH="${CLUSTER_PATH:-catalog/gitops/flux/clusters/production}"
AGE_KEY_FILE="${AGE_KEY_FILE:-age.agekey}"
FLUX_NAMESPACE="${FLUX_NAMESPACE:-flux-system}"
SECRET_NAME="${SECRET_NAME:-sops-age}"
BRANCH="${BRANCH:-develop}"

# Helper functions
log_info() {
    echo -e "${BLUE}ℹ${NC} $1"
}

log_success() {
    echo -e "${GREEN}✔${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

log_error() {
    echo -e "${RED}✖${NC} $1"
}

check_command() {
    if ! command -v "$1" &> /dev/null; then
        log_error "$1 is not installed"
        return 1
    fi
    log_success "$1 is installed"
}

# Display installation instructions for missing tools
show_installation_instructions() {
    local os_type="$(uname -s)"
    
    echo ""
    log_error "Missing required tools. Installation instructions:"
    echo ""
    
    if [ "$os_type" = "Darwin" ]; then
        # macOS
        log_info "macOS Installation (using Homebrew):"
        echo ""
        echo "  # Install Homebrew if not already installed"
        echo "  /bin/bash -c \"\$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)\""
        echo ""
        echo "  # Install all required tools"
        echo "  brew install fluxcd/tap/flux age sops kubectl git"
        echo ""
        echo "  # Verify installations"
        echo "  flux --version"
        echo "  age --version"
        echo "  sops --version"
        echo "  kubectl version --client"
        echo ""
    elif [ "$os_type" = "Linux" ]; then
        # Linux
        log_info "Linux Installation:"
        echo ""
        echo "  # Flux CLI"
        echo "  curl -s https://fluxcd.io/install.sh | sudo bash"
        echo ""
        echo "  # Age"
        echo "  wget https://github.com/FiloSottile/age/releases/latest/download/age-linux-amd64.tar.gz"
        echo "  tar xzf age-linux-amd64.tar.gz"
        echo "  sudo mv age/age age/age-keygen /usr/local/bin/"
        echo ""
        echo "  # SOPS"
        echo "  wget https://github.com/getsops/sops/releases/latest/download/sops-linux-amd64"
        echo "  chmod +x sops-linux-amd64"
        echo "  sudo mv sops-linux-amd64 /usr/local/bin/sops"
        echo ""
        echo "  # kubectl (if not already installed)"
        echo "  curl -LO \"https://dl.k8s.io/release/\$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl\""
        echo "  sudo install -o root -g root -m 0755 kubectl /usr/local/bin/kubectl"
        echo ""
        echo "  # Git (usually pre-installed, or use package manager)"
        echo "  sudo apt-get install git  # Debian/Ubuntu"
        echo "  sudo yum install git       # RHEL/CentOS"
        echo ""
    else
        log_warning "Unsupported OS: $os_type"
        echo "  Please install manually:"
        echo "  - Flux: https://fluxcd.io/flux/installation/"
        echo "  - Age: https://github.com/FiloSottile/age"
        echo "  - SOPS: https://github.com/getsops/sops"
        echo "  - kubectl: https://kubernetes.io/docs/tasks/tools/"
        echo "  - Git: https://git-scm.com/downloads"
        echo ""
    fi
    
    log_info "Alternative: Install all at once (macOS with Homebrew):"
    echo "  brew install fluxcd/tap/flux age sops kubectl"
    echo ""
    log_info "After installation, run this script again."
    echo ""
}

# Check prerequisites
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    local all_installed=true
    
    check_command flux || all_installed=false
    check_command age || all_installed=false
    check_command sops || all_installed=false
    check_command kubectl || all_installed=false
    check_command git || all_installed=false
    
    if [ "$all_installed" = false ]; then
        show_installation_instructions
        exit 1
    fi
    
    log_success "All prerequisites are installed"
}

# Check Kubernetes cluster access
check_cluster_access() {
    log_info "Checking Kubernetes cluster access..."
    
    if ! kubectl cluster-info &> /dev/null; then
        log_error "Cannot connect to Kubernetes cluster"
        echo ""
        log_info "You need access to a Kubernetes cluster. Options:"
        echo ""
        echo "  Option 1: Local Development Cluster"
        echo "    # Using kind (Kubernetes in Docker)"
        echo "    brew install kind  # macOS"
        echo "    kind create cluster --name flux-demo"
        echo ""
        echo "    # Using k3d (k3s in Docker)"
        echo "    brew install k3d  # macOS"
        echo "    k3d cluster create flux-demo"
        echo ""
        echo "    # Using minikube"
        echo "    brew install minikube  # macOS"
        echo "    minikube start"
        echo ""
        echo "  Option 2: Cloud Provider Cluster"
        echo "    # Set up kubeconfig for your cluster"
        echo "    # AWS EKS:"
        echo "    aws eks update-kubeconfig --name your-cluster --region your-region"
        echo ""
        echo "    # Google GKE:"
        echo "    gcloud container clusters get-credentials your-cluster --region your-region"
        echo ""
        echo "    # Azure AKS:"
        echo "    az aks get-credentials --resource-group your-rg --name your-cluster"
        echo ""
        echo "  Option 3: Existing kubeconfig"
        echo "    export KUBECONFIG=/path/to/your/kubeconfig"
        echo ""
        log_warning "After setting up cluster access, run this script again."
        exit 1
    fi
    
    local cluster_info=$(kubectl cluster-info 2>&1 | head -1)
    log_success "Connected to cluster: $cluster_info"
}

# Verify Flux kustomize-controller supports SOPS
verify_flux_sops_support() {
    log_info "Verifying Flux kustomize-controller has SOPS support..."
    
    # Check if kustomize-controller is running
    if ! kubectl get deployment -n "$FLUX_NAMESPACE" kustomize-controller &> /dev/null; then
        log_error "kustomize-controller not found in $FLUX_NAMESPACE"
        log_error "Flux may not be properly bootstrapped"
        return 1
    fi
    
    log_success "kustomize-controller is running"
    
    # Check controller image for SOPS support (should be built-in for recent versions)
    local controller_image=$(kubectl get deployment -n "$FLUX_NAMESPACE" kustomize-controller -o jsonpath='{.spec.template.spec.containers[0].image}' 2>/dev/null)
    
    if [ -n "$controller_image" ]; then
        log_info "Using kustomize-controller image: $controller_image"
        
        # Extract version
        local version=$(echo "$controller_image" | grep -oE 'v[0-9]+\.[0-9]+\.[0-9]+' || echo "unknown")
        
        if [ "$version" != "unknown" ]; then
            log_success "Controller version: $version (SOPS support is built-in for v0.21.0+)"
        fi
    fi
    
    log_success "Flux components are ready for SOPS"
}

# Check if Flux is bootstrapped
check_flux_bootstrap() {
    log_info "Checking if Flux is bootstrapped..."
    
    if ! kubectl get namespace "$FLUX_NAMESPACE" &> /dev/null 2>&1; then
        log_error "Flux namespace '$FLUX_NAMESPACE' not found"
        log_error "Flux is not bootstrapped yet. You need to bootstrap it first."
        echo ""
        log_info "Step 1: Create a GitHub Personal Access Token"
        echo "  1. Go to: https://github.com/settings/tokens/new"
        echo "  2. Token name: 'FluxCD Bootstrap - iac-catalog'"
        echo "  3. Expiration: 90 days (or as per your policy)"
        echo "  4. Select scopes:"
        echo "     ✓ repo (full control of repositories)"
        echo "     ✓ workflow (optional, for GitHub Actions)"
        echo "     ✓ admin:repo_hook (optional, for webhooks)"
        echo "  5. Click 'Generate token' and copy it"
        echo ""
        log_info "Step 2: Export the token"
        echo "  export GITHUB_TOKEN=ghp_your_token_here"
        echo ""
        log_info "Step 3: Bootstrap Flux"
        echo "  # Get your GitHub username"
        echo "  GITHUB_USER=\$(git config --get user.name | tr '[:upper:]' '[:lower:]' | tr ' ' '-')"
        echo "  # Or set it manually"
        echo "  GITHUB_USER=your-github-username"
        echo ""
        echo "  # Bootstrap Flux to your cluster"
        echo "  flux bootstrap github \\"
        echo "    --owner=\$GITHUB_USER \\"
        echo "    --repository=iac-catalog \\"
        echo "    --branch=$BRANCH \\"
        echo "    --path=$CLUSTER_PATH \\"
        echo "    --personal \\"
        echo "    --components-extra=image-reflector-controller,image-automation-controller \\"
        echo "    --network-policy=true \\"
        echo "    --watch-all-namespaces=true"
        echo ""
        log_info "Step 4: Verify Flux installation"
        echo "  flux check"
        echo "  flux get all"
        echo ""
        log_warning "After Flux is bootstrapped, run this script again to setup SOPS."
        echo ""
        exit 1
    fi
    
    log_success "Flux is bootstrapped"
    
    # Verify Flux is healthy
    log_info "Checking Flux health..."
    if flux check --pre &> /dev/null; then
        log_success "Flux is healthy"
    else
        log_warning "Flux check returned warnings (this might be okay)"
    fi
}

# Generate age key
generate_age_key() {
    if [ -f "$AGE_KEY_FILE" ]; then
        log_warning "Age key file '$AGE_KEY_FILE' already exists"
        read -p "Do you want to use the existing key? (y/n): " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            log_info "Generating new age key..."
            mv "$AGE_KEY_FILE" "${AGE_KEY_FILE}.backup.$(date +%s)"
            log_warning "Backed up existing key to ${AGE_KEY_FILE}.backup.*"
            age-keygen -o "$AGE_KEY_FILE"
            log_success "Generated new age key: $AGE_KEY_FILE"
        else
            log_success "Using existing age key"
        fi
    else
        log_info "Generating age key..."
        age-keygen -o "$AGE_KEY_FILE"
        log_success "Generated age key: $AGE_KEY_FILE"
    fi
    
    # Extract public key
    AGE_PUBLIC_KEY=$(grep "# public key:" "$AGE_KEY_FILE" | awk '{print $4}')
    log_info "Age public key: $AGE_PUBLIC_KEY"
}

# Create Kubernetes secret for SOPS
create_sops_secret() {
    log_info "Creating SOPS age secret in cluster..."
    
    if kubectl get secret -n "$FLUX_NAMESPACE" "$SECRET_NAME" &> /dev/null; then
        log_warning "Secret '$SECRET_NAME' already exists in namespace '$FLUX_NAMESPACE'"
        read -p "Do you want to replace it? (y/n): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            kubectl delete secret -n "$FLUX_NAMESPACE" "$SECRET_NAME"
            log_info "Deleted existing secret"
        else
            log_info "Keeping existing secret"
            return 0
        fi
    fi
    
    cat "$AGE_KEY_FILE" | kubectl create secret generic "$SECRET_NAME" \
        --namespace="$FLUX_NAMESPACE" \
        --from-file=age.agekey=/dev/stdin
    
    log_success "Created secret '$SECRET_NAME' in namespace '$FLUX_NAMESPACE'"
}

# Update .sops.yaml configuration
update_sops_config() {
    log_info "Updating .sops.yaml configuration..."
    
    if [ ! -f ".sops.yaml" ]; then
        log_warning ".sops.yaml not found, creating new file"
        cat > .sops.yaml <<EOF
# .sops.yaml - SOPS configuration for FluxCD
creation_rules:
  # FluxCD secrets - encrypt all YAML files with 'secret' in the path
  - path_regex: .*/flux/.*secret.*\.ya?ml$
    encrypted_regex: ^(data|stringData)$
    age: $AGE_PUBLIC_KEY
  
  # General secrets in catalog
  - path_regex: .*/(secrets?|secret-.*)\.ya?ml$
    encrypted_regex: ^(data|stringData)$
    age: $AGE_PUBLIC_KEY
EOF
        log_success "Created .sops.yaml with age public key"
    else
        log_warning ".sops.yaml already exists"
        if ! grep -q "$AGE_PUBLIC_KEY" .sops.yaml; then
            log_warning "Your age public key is not in .sops.yaml"
            log_info "Please add it manually: $AGE_PUBLIC_KEY"
        else
            log_success ".sops.yaml already contains your age public key"
        fi
    fi
}

# Update .gitignore
update_gitignore() {
    log_info "Updating .gitignore..."
    
    if [ ! -f ".gitignore" ]; then
        touch .gitignore
    fi
    
    # Add age key files to gitignore if not already present
    if ! grep -q "age.agekey" .gitignore; then
        echo "" >> .gitignore
        echo "# SOPS age encryption keys" >> .gitignore
        echo "age.agekey" >> .gitignore
        echo "*.agekey" >> .gitignore
        log_success "Added age key patterns to .gitignore"
    else
        log_success "Age key patterns already in .gitignore"
    fi
}

# Update Flux kustomizations with SOPS decryption
update_flux_kustomizations() {
    log_info "Checking Flux kustomizations for SOPS decryption config..."
    
    local infrastructure_kustomization="$CLUSTER_PATH/infrastructure.yaml"
    local apps_kustomization="$CLUSTER_PATH/apps.yaml"
    
    local updated_files=()
    
    # Function to add SOPS config to kustomization
    add_sops_to_kustomization() {
        local file=$1
        local basename=$(basename "$file")
        
        if [ ! -f "$file" ]; then
            log_warning "$basename not found, skipping"
            return
        fi
        
        if grep -q "decryption:" "$file"; then
            log_success "$basename already has SOPS config"
            return
        fi
        
        log_info "Adding SOPS decryption config to $basename..."
        
        # Create backup
        cp "$file" "${file}.backup"
        
        # Add decryption config before the spec section
        if grep -q "spec:" "$file"; then
            # Insert after spec: line
            sed -i.tmp '/spec:/a\
  decryption:\
    provider: sops\
    secretRef:\
      name: '"$SECRET_NAME"'
' "$file"
            rm "${file}.tmp" 2>/dev/null || true
            updated_files+=("$basename")
            log_success "Updated $basename with SOPS config"
        else
            log_error "$basename doesn't have expected format, please update manually"
            rm "${file}.backup"
        fi
    }
    
    # Update infrastructure kustomization
    add_sops_to_kustomization "$infrastructure_kustomization"
    
    # Update apps kustomization  
    add_sops_to_kustomization "$apps_kustomization"
    
    if [ ${#updated_files[@]} -gt 0 ]; then
        echo ""
        log_success "Updated ${#updated_files[@]} kustomization file(s) with SOPS decryption config"
        log_warning "Backup files created with .backup extension"
        log_info "Review the changes and commit them to Git:"
        echo ""
        for file in "${updated_files[@]}"; do
            echo "  git diff $CLUSTER_PATH/$file"
        done
        echo ""
        echo "  git add $CLUSTER_PATH/"
        echo "  git commit -m 'feat: add SOPS decryption to kustomizations'"
        echo "  git push origin $BRANCH"
        echo ""
    else
        log_success "All kustomizations already have SOPS config"
    fi
}

# Test SOPS encryption
test_sops_encryption() {
    log_info "Testing SOPS encryption..."
    
    local test_file="test-secret-$$.yaml"
    
    # Create test secret
    cat > "$test_file" <<EOF
apiVersion: v1
kind: Secret
metadata:
  name: test-sops
  namespace: default
type: Opaque
stringData:
  username: admin
  password: test123
EOF
    
    log_info "Encrypting test secret..."
    if sops --encrypt --in-place "$test_file"; then
        log_success "Encryption successful"
        
        # Verify encryption
        if grep -q "ENC\[AES256_GCM" "$test_file"; then
            log_success "File is properly encrypted"
        else
            log_error "File doesn't appear to be encrypted"
            rm "$test_file"
            return 1
        fi
        
        # Test decryption
        log_info "Testing decryption..."
        if sops --decrypt "$test_file" > /dev/null 2>&1; then
            log_success "Decryption successful"
        else
            log_error "Decryption failed"
            rm "$test_file"
            return 1
        fi
        
        rm "$test_file"
        log_success "SOPS encryption/decryption test passed"
    else
        log_error "Encryption failed"
        rm "$test_file"
        return 1
    fi
}

# Verify Flux can decrypt secrets
verify_flux_decryption() {
    log_info "Verifying Flux SOPS integration..."
    
    # Check if secret exists
    if kubectl get secret -n "$FLUX_NAMESPACE" "$SECRET_NAME" &> /dev/null; then
        log_success "SOPS secret exists in cluster"
        
        # Check if secret has the age key
        if kubectl get secret -n "$FLUX_NAMESPACE" "$SECRET_NAME" -o jsonpath='{.data.age\.agekey}' | base64 -d | grep -q "AGE-SECRET-KEY"; then
            log_success "SOPS secret contains valid age key"
        else
            log_error "SOPS secret doesn't contain valid age key"
            return 1
        fi
    else
        log_error "SOPS secret not found in cluster"
        return 1
    fi
}

# Display summary
display_summary() {
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    log_success "SOPS Setup Complete!"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""
    log_info "Configuration Summary:"
    echo "  • Age key file: $AGE_KEY_FILE"
    echo "  • Age public key: $AGE_PUBLIC_KEY"
    echo "  • Kubernetes secret: $FLUX_NAMESPACE/$SECRET_NAME"
    echo "  • SOPS config: .sops.yaml"
    echo ""
    log_info "Server-side components configured:"
    echo "  ✓ Flux kustomize-controller (has built-in SOPS support)"
    echo "  ✓ Age private key stored in cluster as secret"
    echo "  ✓ Kustomizations configured with decryption provider"
    echo "  ✓ All encrypted secrets will be decrypted by Flux automatically"
    echo ""
    log_info "Next steps:"
    echo "  1. Encrypt your secrets:"
    echo "     sops --encrypt --in-place path/to/secret.yaml"
    echo ""
    echo "  2. Verify encryption:"
    echo "     sops --decrypt path/to/secret.yaml"
    echo ""
    echo "  3. Commit and push encrypted secrets to Git"
    echo ""
    echo "  4. Flux will automatically decrypt them in the cluster"
    echo ""
    log_warning "Security reminders:"
    echo "  • Keep $AGE_KEY_FILE secure and never commit it to Git"
    echo "  • Back up $AGE_KEY_FILE in a secure location"
    echo "  • Use different age keys for different environments"
    echo ""
}

# Main execution
main() {
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "  FluxCD SOPS Age Encryption Setup"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""
    
    check_prerequisites
    check_cluster_access
    check_flux_bootstrap
    verify_flux_sops_support
    generate_age_key
    create_sops_secret
    update_sops_config
    update_gitignore
    update_flux_kustomizations
    test_sops_encryption
    verify_flux_decryption
    display_summary
}

# Run main function
main "$@"
