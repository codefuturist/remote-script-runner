#!/usr/bin/env bash
# Validation script for FluxCD production cluster restructure
# Verifies kustomization builds and file structure

set -e

CLUSTER_PATH="catalog/gitops/flux/clusters/production"
ERRORS=0

echo "🔍 Validating FluxCD Production Cluster Structure"
echo "=================================================="
echo ""

# Function to check if file exists
check_file() {
    if [ -f "$1" ]; then
        echo "✅ $1"
    else
        echo "❌ Missing: $1"
        ((ERRORS++))
    fi
}

# Function to check if directory exists
check_dir() {
    if [ -d "$1" ]; then
        echo "✅ $1/"
    else
        echo "❌ Missing: $1/"
        ((ERRORS++))
    fi
}

# Function to validate kustomization builds
validate_kustomize() {
    local path=$1
    local name=$2

    if kubectl kustomize "$path" > /dev/null 2>&1; then
        echo "✅ Kustomize build: $name"
    else
        echo "❌ Kustomize build failed: $name"
        echo "   Path: $path"
        kubectl kustomize "$path" 2>&1 | head -5 | sed 's/^/   /'
        ((ERRORS++))
    fi
}

echo "📁 Checking Directory Structure"
echo "--------------------------------"

# Root directories
check_dir "$CLUSTER_PATH/flux-system"
check_dir "$CLUSTER_PATH/infrastructure"
check_dir "$CLUSTER_PATH/apps"
check_dir "$CLUSTER_PATH/tenants"
check_dir "$CLUSTER_PATH/policies"
check_dir "$CLUSTER_PATH/patches"

# Infrastructure subdirectories
check_dir "$CLUSTER_PATH/infrastructure/sources"
check_dir "$CLUSTER_PATH/infrastructure/namespaces"
check_dir "$CLUSTER_PATH/infrastructure/configs"
check_dir "$CLUSTER_PATH/infrastructure/network"
check_dir "$CLUSTER_PATH/infrastructure/security"
check_dir "$CLUSTER_PATH/infrastructure/storage"
check_dir "$CLUSTER_PATH/infrastructure/utility"
check_dir "$CLUSTER_PATH/infrastructure/monitoring"
check_dir "$CLUSTER_PATH/infrastructure/logging"
check_dir "$CLUSTER_PATH/infrastructure/database"
check_dir "$CLUSTER_PATH/infrastructure/backup"

# Security subdirectories
check_dir "$CLUSTER_PATH/infrastructure/security/crowdsec"
check_dir "$CLUSTER_PATH/infrastructure/security/rbac"
check_dir "$CLUSTER_PATH/infrastructure/security/external-secrets"

# App tier directories
check_dir "$CLUSTER_PATH/apps/namespaces"
check_dir "$CLUSTER_PATH/apps/backend"
check_dir "$CLUSTER_PATH/apps/frontend"
check_dir "$CLUSTER_PATH/apps/data"
check_dir "$CLUSTER_PATH/apps/jobs"

echo ""
echo "📄 Checking Key Files"
echo "----------------------"

# Root files
check_file "$CLUSTER_PATH/kustomization.yaml"
check_file "$CLUSTER_PATH/notifications.yaml"
check_file "$CLUSTER_PATH/README.md"
check_file "$CLUSTER_PATH/MIGRATION_GUIDE.md"
check_file "$CLUSTER_PATH/IMPLEMENTATION_SUMMARY.md"

# flux-system files
check_file "$CLUSTER_PATH/flux-system/kustomization.yaml"
check_file "$CLUSTER_PATH/flux-system/gotk-components.yaml"
check_file "$CLUSTER_PATH/flux-system/gotk-sync.yaml"

# New granular Kustomization CRDs
check_file "$CLUSTER_PATH/flux-system/infrastructure-sources-kustomization.yaml"
check_file "$CLUSTER_PATH/flux-system/infrastructure-namespaces-kustomization.yaml"
check_file "$CLUSTER_PATH/flux-system/infrastructure-configs-kustomization.yaml"
check_file "$CLUSTER_PATH/flux-system/infrastructure-network-kustomization.yaml"
check_file "$CLUSTER_PATH/flux-system/infrastructure-security-kustomization.yaml"
check_file "$CLUSTER_PATH/flux-system/infrastructure-storage-kustomization.yaml"
check_file "$CLUSTER_PATH/flux-system/infrastructure-utility-kustomization.yaml"
check_file "$CLUSTER_PATH/flux-system/infrastructure-monitoring-kustomization.yaml"
check_file "$CLUSTER_PATH/flux-system/infrastructure-logging-kustomization.yaml"
check_file "$CLUSTER_PATH/flux-system/infrastructure-database-kustomization.yaml"
check_file "$CLUSTER_PATH/flux-system/infrastructure-backup-kustomization.yaml"
check_file "$CLUSTER_PATH/flux-system/apps-kustomization.yaml"
check_file "$CLUSTER_PATH/flux-system/policies-kustomization.yaml"
check_file "$CLUSTER_PATH/flux-system/tenants-kustomization.yaml"

# Infrastructure kustomizations
check_file "$CLUSTER_PATH/infrastructure/network/kustomization.yaml"
check_file "$CLUSTER_PATH/infrastructure/security/kustomization.yaml"
check_file "$CLUSTER_PATH/infrastructure/security/rbac/kustomization.yaml"
check_file "$CLUSTER_PATH/infrastructure/security/external-secrets/kustomization.yaml"

# App tier kustomizations
check_file "$CLUSTER_PATH/apps/kustomization.yaml"
check_file "$CLUSTER_PATH/apps/backend/kustomization.yaml"
check_file "$CLUSTER_PATH/apps/frontend/kustomization.yaml"
check_file "$CLUSTER_PATH/apps/data/kustomization.yaml"
check_file "$CLUSTER_PATH/apps/jobs/kustomization.yaml"

# README files
check_file "$CLUSTER_PATH/infrastructure/network/README.md"
check_file "$CLUSTER_PATH/infrastructure/security/README.md"
check_file "$CLUSTER_PATH/apps/backend/README.md"
check_file "$CLUSTER_PATH/apps/frontend/README.md"
check_file "$CLUSTER_PATH/apps/data/README.md"
check_file "$CLUSTER_PATH/apps/jobs/README.md"

echo ""
echo "🔨 Validating Kustomize Builds"
echo "-------------------------------"

# Validate infrastructure kustomizations that should build
validate_kustomize "$CLUSTER_PATH/infrastructure/network" "infrastructure/network"
validate_kustomize "$CLUSTER_PATH/infrastructure/security" "infrastructure/security"
validate_kustomize "$CLUSTER_PATH/infrastructure/security/rbac" "infrastructure/security/rbac"
# external-secrets has HelmRelease which needs sources, skip for now

# Validate app tier kustomizations
validate_kustomize "$CLUSTER_PATH/apps/backend" "apps/backend"
validate_kustomize "$CLUSTER_PATH/apps/frontend" "apps/frontend"
validate_kustomize "$CLUSTER_PATH/apps/data" "apps/data"
validate_kustomize "$CLUSTER_PATH/apps/jobs" "apps/jobs"

# Note: flux-system kustomization includes Kustomization CRDs which are not
# meant to be built with kubectl kustomize, they are Flux resources

echo ""
echo "📊 Validation Summary"
echo "====================="

if [ $ERRORS -eq 0 ]; then
    echo "✅ All validations passed!"
    echo ""
    echo "✨ The FluxCD production cluster structure is ready for deployment."
    echo ""
    echo "Next steps:"
    echo "1. Review MIGRATION_GUIDE.md for deployment process"
    echo "2. Commit changes: git add . && git commit -m 'feat: restructure FluxCD production cluster'"
    echo "3. Push to repository: git push"
    echo "4. Monitor Flux reconciliation: flux get kustomizations"
    exit 0
else
    echo "❌ Found $ERRORS error(s)"
    echo ""
    echo "Please fix the errors above before proceeding."
    exit 1
fi

