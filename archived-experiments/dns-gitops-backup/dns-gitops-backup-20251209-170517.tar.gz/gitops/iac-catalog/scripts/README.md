# Scripts - Automation & Tools

## Purpose

Executable scripts and tools for deployment, automation, and management tasks.

## Structure

```text
scripts/
├── automation/                   # Automated deployment & operations
│   ├── deploy.sh                # Automated deployment
│   ├── rollback.sh              # Rollback deployments
│   ├── setup-flux-sops.sh       # FluxCD SOPS age encryption setup
│   └── validate.sh              # Validation automation
├── cli/                          # Command-line interface tools
│   ├── configure.sh             # Configure template → instance
│   ├── deploy.sh                # Manual deployment
│   └── list.sh                  # List deployments
├── migrations/                   # Migration utilities
│   ├── k8s-version-upgrade/
│   ├── module-migration/
│   └── terraform-upgrade/
└── utilities/                    # Helper utilities
    ├── cost-calculator/
    ├── documentation-builder/
    └── inventory-generator/
```

## Quick Reference

| Task | Script | Example |
|------|--------|---------|
| Configure deployment | `cli/configure.sh` | `./scripts/cli/configure.sh --template catalog/self-hosted/databases/postgresql --instance my-db` |
| Deploy manually | `cli/deploy.sh` | `./scripts/cli/deploy.sh --instance my-db --environment production` |
| List deployments | `cli/list.sh` | `./scripts/cli/list.sh --environment production` |
| Setup Flux SOPS | `automation/setup-flux-sops.sh` | `./scripts/automation/setup-flux-sops.sh` |
| Automated deploy | `automation/deploy.sh` | `./scripts/automation/deploy.sh --all` |
| Rollback | `automation/rollback.sh` | `./scripts/automation/rollback.sh --instance my-db` |
| Validate | `automation/validate.sh` | `./scripts/automation/validate.sh --instance my-db` |

## Directory Details

### `cli/` - Command-Line Tools

Interactive command-line tools for manual operations.

**Key Scripts:**

- **configure.sh** - Configure a template into a deployment instance
- **deploy.sh** - Manually trigger deployment
- **list.sh** - List all deployments or filter by environment

**When to use:** Manual operations, testing, one-off tasks.

### `automation/` - Automated Operations

Scripts designed for automated execution (CI/CD, cron jobs, GitOps agents).

**Key Scripts:**

- **setup-flux-sops.sh** - Set up FluxCD with SOPS age encryption for secrets management
- **deploy.sh** - Automated deployment of all or specific instances
- **rollback.sh** - Automated rollback to previous version
- **validate.sh** - Validate deployments before or after deployment

**When to use:** CI/CD pipelines, automated workflows, GitOps, initial setup.

### `migrations/` - Migration Utilities

Scripts for upgrading infrastructure and tools.

**Subdirectories:**

- **k8s-version-upgrade/** - Kubernetes cluster upgrades
- **module-migration/** - Template/module version migrations
- **terraform-upgrade/** - Terraform version upgrades

**When to use:** Upgrading infrastructure, tools, or dependencies.

### `utilities/` - Helper Utilities

Supporting utilities for various tasks.

**Subdirectories:**

- **cost-calculator/** - Calculate infrastructure costs
- **documentation-builder/** - Generate documentation
- **inventory-generator/** - Generate inventory from cloud providers

**When to use:** Supporting tasks, reporting, documentation.

## Common Usage Patterns

### Setup FluxCD with SOPS (One-time setup)

```bash
# Prerequisites: Flux must be bootstrapped first
# Bootstrap Flux (if not already done)
export GITHUB_TOKEN=ghp_your_token_here
flux bootstrap github \
  --owner=your-github-username \
  --repository=iac-catalog \
  --branch=develop \
  --path=catalog/gitops/flux/clusters/production \
  --personal \
  --components-extra=image-reflector-controller,image-automation-controller

# Run SOPS setup script
./scripts/automation/setup-flux-sops.sh

# The script will:
# - Generate age encryption key (age.agekey)
# - Create Kubernetes secret (flux-system/sops-age)
# - Update .sops.yaml configuration
# - Update .gitignore
# - Test encryption/decryption
# - Verify Flux integration

# After setup, encrypt your secrets:
sops --encrypt --in-place path/to/secret.yaml

# Commit encrypted secrets to Git
git add path/to/secret.yaml
git commit -m "feat: add encrypted secret"
git push

# Flux will automatically decrypt in the cluster
```

### Configure and Deploy

```bash
# 1. Configure deployment from template
./scripts/cli/configure.sh \
  --template catalog/self-hosted/databases/postgresql \
  --instance prod-db-01 \
  --environment production \
  --target db-server-01 \
  --param db_name=production

# 2. Review generated files
ls -la deployments/production/prod-db-01/

# 3. Commit to Git (GitOps deploys automatically)
git add deployments/production/prod-db-01/
git commit -m "feat: add production database"
git push

# OR deploy manually
./scripts/cli/deploy.sh \
  --instance prod-db-01 \
  --environment production
```

### List and Manage

```bash
# List all deployments
./scripts/cli/list.sh

# List production only
./scripts/cli/list.sh --environment production

# List with details
./scripts/cli/list.sh --environment production --verbose
```

### Validate Before Deploying

```bash
# Validate configuration
./scripts/automation/validate.sh \
  --instance prod-db-01 \
  --environment production

# Returns exit code 0 if valid, non-zero if invalid
```

### Rollback if Needed

```bash
# Rollback to previous version
./scripts/automation/rollback.sh \
  --instance prod-db-01 \
  --environment production

# Rollback to specific version
./scripts/automation/rollback.sh \
  --instance prod-db-01 \
  --environment production \
  --version 1.2.3
```

## Script Standards

All scripts in this repository follow these standards:

### 1. Bash Shebang

```bash
#!/usr/bin/env bash
```

### 2. Error Handling

```bash
set -euo pipefail
# -e: exit on error
# -u: exit on undefined variable
# -o pipefail: exit on pipe failure
```

### 3. Help Text

Every script supports `--help`:

```bash
./scripts/cli/configure.sh --help
```

### 4. Consistent Options

Common options across scripts:

- `-h, --help` - Show help message
- `-e, --environment` - Specify environment (production, staging, development)
- `-v, --verbose` - Verbose output
- `--dry-run` - Show what would be done without doing it

### 5. Exit Codes

- `0` - Success
- `1` - General error
- `2` - Invalid arguments
- `3` - Configuration error
- `4` - Deployment error

### 6. Logging

Scripts log to stdout/stderr appropriately:

- **stdout**: Normal output, results
- **stderr**: Errors, warnings

## Development

### Creating New Scripts

1. Choose appropriate directory:
   - `cli/` for interactive tools
   - `automation/` for automated operations
   - `utilities/` for helper scripts
   - `migrations/` for upgrade/migration scripts

2. Create script:

```bash
touch scripts/cli/my-new-script.sh
chmod +x scripts/cli/my-new-script.sh
```

3. Use the template:

```bash
#!/usr/bin/env bash
set -euo pipefail

# Script: My New Script
# Description: What this script does
# Usage: ./scripts/cli/my-new-script.sh [options]

show_help() {
    cat << EOF
Usage: ${0##*/} [OPTIONS]

Description of what this script does.

OPTIONS:
    -h, --help          Show this help message
    -e, --environment   Environment (production, staging, development)
    -v, --verbose       Verbose output
    --dry-run           Show what would be done

EXAMPLES:
    ${0##*/} --environment production
    ${0##*/} --help

EOF
}

# Parse arguments
ENVIRONMENT=""
VERBOSE=false
DRY_RUN=false

while [[ $# -gt 0 ]]; do
    case $1 in
        -h|--help)
            show_help
            exit 0
            ;;
        -e|--environment)
            ENVIRONMENT="$2"
            shift 2
            ;;
        -v|--verbose)
            VERBOSE=true
            shift
            ;;
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        *)
            echo "Unknown option: $1"
            show_help
            exit 2
            ;;
    esac
done

# Validate required parameters
if [[ -z "$ENVIRONMENT" ]]; then
    echo "Error: --environment is required" >&2
    show_help
    exit 2
fi

# Main logic here
echo "Running script for environment: $ENVIRONMENT"

# Add your script logic here
```

4. Test thoroughly:

```bash
# Test help
./scripts/cli/my-new-script.sh --help

# Test dry run
./scripts/cli/my-new-script.sh --environment development --dry-run

# Test actual execution
./scripts/cli/my-new-script.sh --environment development
```

5. Update this README if needed

### Script Testing

```bash
# Test in development first
./script.sh --environment development --dry-run

# Test with verbose output
./script.sh --environment development --verbose

# Test error handling
./script.sh --environment production --instance nonexistent
```

## Integration with CI/CD

### GitLab CI Example

```yaml
deploy:
  stage: deploy
  script:
    - ./scripts/automation/validate.sh --instance $INSTANCE --environment $ENV
    - ./scripts/automation/deploy.sh --instance $INSTANCE --environment $ENV
  only:
    - main
```

### GitHub Actions Example

```yaml
- name: Validate
  run: ./scripts/automation/validate.sh --instance ${{ env.INSTANCE }} --environment production

- name: Deploy
  run: ./scripts/automation/deploy.sh --instance ${{ env.INSTANCE }} --environment production
```

### Jenkins Example

```groovy
stage('Deploy') {
    steps {
        sh './scripts/automation/validate.sh --instance ${INSTANCE} --environment ${ENV}'
        sh './scripts/automation/deploy.sh --instance ${INSTANCE} --environment ${ENV}'
    }
}
```

## Troubleshooting

### Permission Denied

```bash
# Make script executable
chmod +x scripts/cli/configure.sh
```

### Script Not Found

```bash
# Run from repository root
cd /path/to/iac-catalog
./scripts/cli/configure.sh
```

### Environment Not Found

```bash
# Check available environments
ls deployments/
ls inventory/
ls environments/
```

### Command Fails Silently

```bash
# Run with verbose flag
./scripts/cli/configure.sh --environment production --verbose

# Check exit code
echo $?
```

## Related Documentation

- [STRUCTURE.md](../STRUCTURE.md) - Overall repository structure
- [CONTRIBUTING.md](../CONTRIBUTING.md) - Development guidelines
- [examples/](../examples/) - See scripts in action
- [docs/guides/](../docs/guides/) - Detailed guides

## Best Practices

1. **Always test in development first**
2. **Use `--dry-run` for safety**
3. **Check help with `--help` before running**
4. **Use verbose mode (`--verbose`) when debugging**
5. **Run validation before deployment**
6. **Keep scripts idempotent** (safe to run multiple times)
7. **Log important actions**
8. **Handle errors gracefully**

---

**Need help?** Run any script with `--help` or check [examples/](../examples/) for complete workflows.
