#!/usr/bin/env bash
# encrypt-staging-secrets.sh
# Script to encrypt secrets for staging cluster using SOPS

set -e

# Set the age key file location
export SOPS_AGE_KEY_FILE="$(dirname "$0")/../../age.agekey"

# Directory containing the secrets
STAGING_DIR="$(dirname "$0")/catalog/gitops/flux/clusters/staging/apps/production"

echo "🔐 Encrypting staging secrets with SOPS..."
echo ""

# Check if sops is installed
if ! command -v sops &> /dev/null; then
    echo "❌ Error: sops is not installed"
    echo "Install with: brew install sops"
    exit 1
fi

# Check if age key file exists
if [ ! -f "$SOPS_AGE_KEY_FILE" ]; then
    echo "❌ Error: Age key file not found at $SOPS_AGE_KEY_FILE"
    exit 1
fi

echo "Using age key file: $SOPS_AGE_KEY_FILE"
echo ""

# Encrypt authentik secret
echo "📝 Encrypting authentik-secret.yaml..."
if [ -f "$STAGING_DIR/authentik/authentik-secret.yaml" ]; then
    sops --encrypt --in-place "$STAGING_DIR/authentik/authentik-secret.yaml"
    echo "✅ Encrypted authentik-secret.yaml"
else
    echo "⚠️  authentik-secret.yaml not found"
fi

# Encrypt homarr secret
echo "📝 Encrypting homarr-secret.yaml..."
if [ -f "$STAGING_DIR/homarr/homarr-secret.yaml" ]; then
    sops --encrypt --in-place "$STAGING_DIR/homarr/homarr-secret.yaml"
    echo "✅ Encrypted homarr-secret.yaml"
else
    echo "⚠️  homarr-secret.yaml not found"
fi

echo ""
echo "🎉 Done! Remember to update the placeholder values before deploying:"
echo "   1. Edit the secrets with: sops <secret-file.yaml>"
echo "   2. Replace CHANGE_ME_* values with actual secrets"
echo "   3. Save and the file will be automatically re-encrypted"
