#!/usr/bin/env bash
# FluxCD Production Cluster Cleanup Script
# Moves orphaned files to system trash using macOS trash command or creates archive

set -e

CLUSTER_PATH="catalog/gitops/flux/clusters/production"
ARCHIVE_DIR="catalog/gitops/flux/clusters/production-archive/orphaned-$(date +%Y%m%d-%H%M%S)"

echo "╔══════════════════════════════════════════════════════════════════════════════╗"
echo "║          FluxCD Production Cluster - Orphaned Files Cleanup                 ║"
echo "╚══════════════════════════════════════════════════════════════════════════════╝"
echo ""

# Create archive directory
mkdir -p "$ARCHIVE_DIR"

echo "📁 Archive directory: $ARCHIVE_DIR"
echo ""

# Function to move to archive instead of trash (safer)
archive_file() {
    local file=$1
    local target_dir="$ARCHIVE_DIR/$(dirname "$file" | sed "s|$CLUSTER_PATH/||")"
    mkdir -p "$target_dir"
    mv "$file" "$target_dir/"
    echo "  ✅ Archived: $file"
}

archive_dir() {
    local dir=$1
    local target_dir="$ARCHIVE_DIR/$(dirname "$dir" | sed "s|$CLUSTER_PATH/||")"
    mkdir -p "$target_dir"
    mv "$dir" "$target_dir/"
    echo "  ✅ Archived: $dir/"
}

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🧹 Cleaning up orphaned files..."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# 1. Old monolithic infrastructure-kustomization.yaml (replaced by granular ones)
echo "1. Old monolithic infrastructure Kustomization:"
if [ -f "$CLUSTER_PATH/flux-system/infrastructure-kustomization.yaml" ]; then
    archive_file "$CLUSTER_PATH/flux-system/infrastructure-kustomization.yaml"
else
    echo "  ⏭️  Already cleaned up"
fi
echo ""

# 2. Orphaned infrastructure-overlay directory (not referenced in production)
echo "2. Orphaned infrastructure-overlay directory:"
if [ -d "$CLUSTER_PATH/infrastructure-overlay" ]; then
    archive_dir "$CLUSTER_PATH/infrastructure-overlay"
else
    echo "  ⏭️  Already cleaned up"
fi
echo ""

# 3. Duplicate flux-kustomization.yaml in security (kustomization.yaml is authoritative)
echo "3. Duplicate flux-kustomization.yaml in security:"
if [ -f "$CLUSTER_PATH/infrastructure/security/flux-kustomization.yaml" ]; then
    archive_file "$CLUSTER_PATH/infrastructure/security/flux-kustomization.yaml"
else
    echo "  ⏭️  Already cleaned up"
fi
echo ""

# 4. Duplicate kustomization.yaml in mealie (flux-kustomization.yaml is used)
echo "4. Duplicate kustomization.yaml in mealie (flux-kustomization.yaml is authoritative):"
if [ -f "$CLUSTER_PATH/apps/mealie/kustomization.yaml" ]; then
    archive_file "$CLUSTER_PATH/apps/mealie/kustomization.yaml"
else
    echo "  ⏭️  Already cleaned up"
fi
echo ""

# 5. REPLICAS_CONFIGURATION.md - appears to be outdated doc
echo "5. Outdated REPLICAS_CONFIGURATION.md (now documented in README.md):"
if [ -f "$CLUSTER_PATH/REPLICAS_CONFIGURATION.md" ]; then
    archive_file "$CLUSTER_PATH/REPLICAS_CONFIGURATION.md"
else
    echo "  ⏭️  Already cleaned up"
fi
echo ""

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📊 Cleanup Summary"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "Archived files are in: $ARCHIVE_DIR"
echo ""
echo "To permanently delete archived files after verification:"
echo "  rm -rf $ARCHIVE_DIR"
echo ""
echo "To restore if needed:"
echo "  cp -r $ARCHIVE_DIR/* $CLUSTER_PATH/"
echo ""
echo "✅ Cleanup complete!"

