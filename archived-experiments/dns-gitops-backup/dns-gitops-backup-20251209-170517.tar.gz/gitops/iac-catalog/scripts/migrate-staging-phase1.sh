#!/bin/bash
#
# Staging Cluster PVC Migration - Phase 1
# Non-essential resources (test PVC + uptime-kuma)
# 
# Duration: ~30 minutes
# Downtime: None (uptime-kuma is monitoring-only)
# 
# Prerequisites:
# - kubectl configured for k3s-develop (192.168.2.92)
# - Flux installed and operational
# - iac-catalog repo cloned locally
#
# Usage: bash migrate-staging-phase1.sh [--dry-run] [--confirm]

set -euo pipefail

# Configuration
CLUSTER="staging"
CONTEXT="k3s-develop"
BACKUP_DIR="/tmp/pvc-backups/staging"
DRY_RUN=false
AUTO_CONFIRM=false
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Parse arguments
while [[ $# -gt 0 ]]; do
  case $1 in
    --dry-run)
      DRY_RUN=true
      shift
      ;;
    --confirm)
      AUTO_CONFIRM=true
      shift
      ;;
    *)
      echo "Unknown option: $1"
      exit 1
      ;;
  esac
done

# Helper functions
log_info() {
  echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
  echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
  echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
  echo -e "${RED}[ERROR]${NC} $1"
}

log_step() {
  echo ""
  echo -e "${BLUE}=== $1 ===${NC}"
}

confirm() {
  if [ "$AUTO_CONFIRM" = true ]; then
    return 0
  fi
  
  local prompt="$1"
  local response
  read -p "$(echo -e ${YELLOW}$prompt${NC}) (yes/no): " response
  
  [[ "$response" == "yes" || "$response" == "y" ]]
}

run_or_dry() {
  if [ "$DRY_RUN" = true ]; then
    log_info "[DRY RUN] Would execute: $@"
  else
    "$@"
  fi
}

# Main script
main() {
  log_info "Starting Staging Cluster PVC Migration - Phase 1"
  
  if [ "$DRY_RUN" = true ]; then
    log_warning "Running in DRY RUN mode - no changes will be made"
  fi
  
  # Verify context
  log_step "Verifying Kubernetes context"
  current_context=$(kubectl config current-context)
  log_info "Current context: $current_context"
  
  if [[ "$current_context" != *"k3s-develop"* ]]; then
    log_warning "Current context is not k3s-develop. Attempting to switch..."
    if ! kubectl config use-context "$CONTEXT" 2>/dev/null; then
      log_error "Could not switch to context $CONTEXT"
      log_info "Available contexts:"
      kubectl config get-contexts
      exit 1
    fi
    log_success "Switched to context $CONTEXT"
  fi
  
  # Create backup directory
  log_step "Setting up backup directory"
  mkdir -p "$BACKUP_DIR"
  log_success "Backup directory ready: $BACKUP_DIR"
  
  # Phase 1.1: Backup and migrate test-local-path-alt-pvc
  log_step "Phase 1.1: Migrating default/test-local-path-alt-pvc (100Mi)"
  
  log_info "This is a test PVC with no persistent data - safe to delete"
  if ! kubectl get pvc test-local-path-alt-pvc -n default 2>/dev/null; then
    log_warning "Test PVC not found in default namespace - skipping"
  else
    if confirm "Ready to delete test-local-path-alt-pvc?"; then
      log_info "Deleting test PVC..."
      run_or_dry kubectl delete pvc test-local-path-alt-pvc -n default
      log_success "Test PVC deleted"
      
      if [ "$DRY_RUN" = false ]; then
        log_info "Waiting for Flux to recreate PVC with new storage class..."
        sleep 10
        
        # Verify new PVC is bound to openebs-hostpath
        if kubectl get pvc test-local-path-alt-pvc -n default -o jsonpath='{.spec.storageClassName}' | grep -q "openebs-hostpath"; then
          log_success "Test PVC successfully migrated to openebs-hostpath"
        else
          storage_class=$(kubectl get pvc test-local-path-alt-pvc -n default -o jsonpath='{.spec.storageClassName}')
          log_warning "Test PVC storage class is: $storage_class (expected openebs-hostpath)"
        fi
      fi
    else
      log_info "Skipped test PVC migration"
    fi
  fi
  
  # Phase 1.2: Backup and migrate monitoring/uptime-kuma-data
  log_step "Phase 1.2: Migrating monitoring/uptime-kuma-data (2Gi)"
  
  if ! kubectl get pvc uptime-kuma-data -n monitoring 2>/dev/null; then
    log_warning "Uptime Kuma PVC not found in monitoring namespace - skipping"
  else
    # Backup uptime-kuma data
    log_info "Backing up uptime-kuma data..."
    backup_file="$BACKUP_DIR/uptime-kuma-data_${TIMESTAMP}.tar.gz"
    
    if confirm "Ready to backup and migrate uptime-kuma-data?"; then
      # Create backup pod
      log_info "Creating backup pod..."
      run_or_dry kubectl run -n monitoring uptime-kuma-backup-$TIMESTAMP \
        --image=busybox:latest \
        --restart=Never \
        --rm -i \
        --command -- sh -c "tar czf - -C /data ." \
        < <(
          kubectl run -n monitoring uptime-kuma-backup-$TIMESTAMP \
            --image=busybox:latest \
            --restart=Never \
            --rm -i \
            --overrides='{"spec":{"containers":[{"name":"uptime-kuma-backup-'$TIMESTAMP'","image":"busybox:latest","command":["tar","czf","-","-C","/data","."],"volumeMounts":[{"name":"data","mountPath":"/data"}]}],"volumes":[{"name":"data","persistentVolumeClaim":{"claimName":"uptime-kuma-data"}}]}}' \
            2>/dev/null
        ) > "$backup_file" 2>/dev/null || true
      
      if [ "$DRY_RUN" = false ]; then
        if [ -f "$backup_file" ] && [ -s "$backup_file" ]; then
          log_success "Backup created: $backup_file ($(du -h "$backup_file" | cut -f1))"
        else
          log_warning "Backup may be empty or failed - proceeding anyway"
        fi
        
        # Scale down uptime-kuma if running
        log_info "Checking uptime-kuma deployment status..."
        if kubectl get deployment uptime-kuma -n monitoring &>/dev/null; then
          log_info "Scaling down uptime-kuma deployment..."
          kubectl scale deployment uptime-kuma -n monitoring --replicas=0
          sleep 5
        fi
        
        # Delete PVC
        log_info "Deleting uptime-kuma PVC..."
        kubectl delete pvc uptime-kuma-data -n monitoring
        log_success "Uptime Kuma PVC deleted"
        
        # Wait for Flux to recreate with new storage class
        log_info "Waiting for Flux to recreate PVC with new storage class..."
        sleep 15
        
        # Verify migration
        if kubectl get pvc uptime-kuma-data -n monitoring -o jsonpath='{.spec.storageClassName}' | grep -q "openebs-hostpath"; then
          log_success "Uptime Kuma PVC successfully migrated to openebs-hostpath"
          
          # Wait for PVC to be bound
          log_info "Waiting for PVC to be bound..."
          for i in {1..30}; do
            status=$(kubectl get pvc uptime-kuma-data -n monitoring -o jsonpath='{.status.phase}')
            if [ "$status" = "Bound" ]; then
              log_success "PVC is bound"
              break
            fi
            echo -n "."
            sleep 2
          done
          
          # Restore data
          if [ -f "$backup_file" ] && [ -s "$backup_file" ]; then
            log_info "Restoring data to new PVC..."
            kubectl run -n monitoring uptime-kuma-restore-$TIMESTAMP \
              --image=busybox:latest \
              --restart=Never \
              --rm -i \
              --overrides='{"spec":{"containers":[{"name":"uptime-kuma-restore-'$TIMESTAMP'","image":"busybox:latest","command":["tar","xzf","-","-C","/data"],"volumeMounts":[{"name":"data","mountPath":"/data"}]}],"volumes":[{"name":"data","persistentVolumeClaim":{"claimName":"uptime-kuma-data"}}]}}' \
              < "$backup_file" 2>/dev/null || log_warning "Restore may have had issues"
            log_success "Data restored"
          fi
          
          # Scale back up
          if kubectl get deployment uptime-kuma -n monitoring &>/dev/null; then
            log_info "Scaling up uptime-kuma deployment..."
            kubectl scale deployment uptime-kuma -n monitoring --replicas=1
            sleep 10
            
            # Verify pod is running
            if kubectl get pods -n monitoring -l app.kubernetes.io/name=uptime-kuma -o jsonpath='{.items[0].status.phase}' | grep -q "Running"; then
              log_success "Uptime Kuma is running"
            else
              log_warning "Uptime Kuma pod status unknown - check manually"
            fi
          fi
        else
          storage_class=$(kubectl get pvc uptime-kuma-data -n monitoring -o jsonpath='{.spec.storageClassName}')
          log_warning "Uptime Kuma PVC storage class is: $storage_class (expected openebs-hostpath)"
        fi
      fi
    else
      log_info "Skipped uptime-kuma migration"
    fi
  fi
  
  # Summary
  log_step "Phase 1 Migration Summary"
  log_success "Phase 1 migration process completed"
  log_info "Next steps:"
  log_info "  1. Verify all applications are functioning normally"
  log_info "  2. Check monitoring dashboards for any anomalies"
  log_info "  3. Review backup files in: $BACKUP_DIR"
  log_info "  4. When ready, proceed to Phase 2: application PVCs"
  log_info ""
  log_info "See DOCS/PVC-MIGRATION-STAGING.md for complete documentation"
}

# Run main function
main "$@"
