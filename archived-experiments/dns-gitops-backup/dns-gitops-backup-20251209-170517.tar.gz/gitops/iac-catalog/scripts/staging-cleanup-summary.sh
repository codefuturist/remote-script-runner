#!/usr/bin/env bash
# Staging Cluster Cleanup Summary
# Display what was cleaned up from staging applications

cat << 'EOF'
╔══════════════════════════════════════════════════════════════════════════════╗
║               Staging Cluster Cleanup - COMPLETE ✅                          ║
╚══════════════════════════════════════════════════════════════════════════════╝

📊 CLEANUP SUMMARY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🗑️  MOVED TO SYSTEM TRASH: 15 items (77 total files)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Duplicate Application Directories:
   1. ✅ compass-web-app/           → production: compass-web/
   2. ✅ home-assistant-app/        → production: home-assistant/
   3. ✅ mailrise-app/              → production: mailrise/
   4. ✅ mealie/                    → production: mealie/
   5. ✅ mealie-app/                → production: mealie/
   6. ✅ metube-app/                → production: metube/
   7. ✅ paperless-ngx-app/         → production: paperless-ngx/
   8. ✅ proxmox-backup-server-app/ → production: proxmox-backup-server/
   9. ✅ redisinsight-app/          → production: redisinsight/
  10. ✅ shlink-app/                → production: shlink/
  11. ✅ wordpress/                 → production: wordpress/
  12. ✅ wordpress-test/            → production: wordpress-test/

Duplicate Kustomization Files:
  13. ✅ mealie-kustomization.yaml          → production: mealie/
  14. ✅ wordpress-kustomization.yaml       → production: wordpress/
  15. ✅ wordpress-test-kustomization.yaml  → production: wordpress-test/

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📁 STAGING CLUSTER STATUS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

catalog/gitops/flux/clusters/staging/applications/
   └── (empty - all duplicates removed)

REMAINING STAGING-SPECIFIC STRUCTURE:
   ├── apps/                    # Staging app organization
   ├── apps-overlay/           # Staging overlays
   ├── infrastructure/         # Staging infrastructure
   ├── infrastructure-overlay/ # Staging infrastructure overlays
   └── flux-system/            # Staging FluxCD system

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🎯 BENEFITS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✅ Eliminated Duplication
   - No more maintaining same apps in both staging and production
   - Single source of truth for each application

✅ Cleaner Repository Structure
   - Staging cluster focuses on staging-specific needs
   - Production cluster is the authoritative source for apps

✅ Simplified Maintenance
   - App updates only need to happen in production
   - Reduced cognitive load when navigating repository

✅ Better Resource Management
   - Staging cluster can focus on infrastructure testing
   - Production cluster manages application lifecycle

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💾 RECOVERY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

All moved items are in macOS Trash and can be recovered if needed:
   1. Open Finder
   2. Empty Trash (⌘⇧⌫) or browse Trash to recover specific items
   3. Alternatively: git checkout <file> to restore from git

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📋 NEXT STEPS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. Review the changes:
   git status | grep "staging/applications"

2. Commit the cleanup:
   git add -u  # Add deleted files
   git commit -m "cleanup: remove duplicate apps from staging cluster

   Moved 15 duplicate items to system trash:
   - 12 application directories already in production
   - 3 kustomization files for apps in production

   Staging cluster applications/ directory is now clean.
   Production cluster remains authoritative source for all apps."

3. Consider staging cluster purpose:
   - Focus on infrastructure testing
   - Test new FluxCD features
   - Validate cluster configurations before production

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✨ Staging cluster is now clean and focused on its intended purpose!
   Production cluster is the single source of truth for applications.

EOF
