#!/usr/bin/env bash
#
# MinIO Backup Infrastructure Setup Script
# =========================================
# This script configures MinIO buckets, policies, and service accounts
# for backup infrastructure following security best practices.
#
# Prerequisites:
#   - MinIO Client (mc) installed: brew install minio-mc
#   - Admin credentials with policy management permissions
#
# Usage:
#   ./minio-backup-setup.sh [--dry-run] [--skip-credentials]
#
# Environment Variables (required):
#   MINIO_ADMIN_ACCESS_KEY - Admin access key
#   MINIO_ADMIN_SECRET_KEY - Admin secret key
#
# Environment Variables (optional):
#   MINIO_ENDPOINT         - MinIO endpoint (default: https://minio.pandia.io:9000)
#   MINIO_ALIAS            - MC alias name (default: pandia-minio)
#

set -euo pipefail

# =============================================================================
# Configuration
# =============================================================================

readonly SCRIPT_NAME="$(basename "$0")"
readonly SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
readonly LOG_FILE="${SCRIPT_DIR}/../../log/minio-setup-$(date +%Y%m%d-%H%M%S).log"

# MinIO Configuration
readonly MINIO_ENDPOINT="${MINIO_ENDPOINT:-https://minio.pandia.io:9000}"
readonly MINIO_ALIAS="${MINIO_ALIAS:-pandia-minio}"
readonly MINIO_REGION="${MINIO_REGION:-us-east-1}"

# Bucket Configuration
declare -A BUCKETS=(
    ["openebs-velero-backups"]="Kubernetes Velero volume backups"
    ["portainer-backups"]="Docker Swarm Portainer data backups"
    ["etcd-backups"]="K3s etcd cluster state backups"
    ["database-dumps"]="Database logical dumps (pg_dump, mysqldump)"
)

# Lifecycle Rules (days until expiration)
declare -A BUCKET_LIFECYCLE=(
    ["openebs-velero-backups"]=90
    ["portainer-backups"]=30
    ["etcd-backups"]=30
    ["database-dumps"]=60
)

# Service Account Configuration
declare -A SERVICE_ACCOUNTS=(
    ["velero-backup"]="openebs-velero-backups"
    ["portainer-backup"]="portainer-backups"
    ["etcd-backup"]="etcd-backups"
    ["database-backup"]="database-dumps"
)

# Flags
DRY_RUN=false
SKIP_CREDENTIALS=false
VERBOSE=false

# Colors for output
readonly RED='\033[0;31m'
readonly GREEN='\033[0;32m'
readonly YELLOW='\033[1;33m'
readonly BLUE='\033[0;34m'
readonly NC='\033[0m' # No Color

# =============================================================================
# Helper Functions
# =============================================================================

log() {
    local level="$1"
    shift
    local message="$*"
    local timestamp
    timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    
    # Ensure log directory exists
    mkdir -p "$(dirname "$LOG_FILE")"
    
    echo "[$timestamp] [$level] $message" >> "$LOG_FILE"
    
    case "$level" in
        INFO)  echo -e "${GREEN}[INFO]${NC} $message" ;;
        WARN)  echo -e "${YELLOW}[WARN]${NC} $message" ;;
        ERROR) echo -e "${RED}[ERROR]${NC} $message" >&2 ;;
        DEBUG) [[ "$VERBOSE" == "true" ]] && echo -e "${BLUE}[DEBUG]${NC} $message" ;;
    esac
}

die() {
    log ERROR "$1"
    exit 1
}

run_mc() {
    local cmd="$*"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log INFO "[DRY-RUN] Would execute: mc $cmd"
        return 0
    fi
    
    log DEBUG "Executing: mc $cmd"
    if ! mc "$@" 2>&1; then
        log WARN "Command failed: mc $cmd"
        return 1
    fi
}

check_prerequisites() {
    log INFO "Checking prerequisites..."
    
    # Check mc is installed
    if ! command -v mc &> /dev/null; then
        die "MinIO Client (mc) is not installed. Install with: brew install minio-mc"
    fi
    
    # Check required environment variables
    if [[ -z "${MINIO_ADMIN_ACCESS_KEY:-}" ]]; then
        die "MINIO_ADMIN_ACCESS_KEY environment variable is required"
    fi
    
    if [[ -z "${MINIO_ADMIN_SECRET_KEY:-}" ]]; then
        die "MINIO_ADMIN_SECRET_KEY environment variable is required"
    fi
    
    log INFO "Prerequisites check passed"
}

# =============================================================================
# MinIO Setup Functions
# =============================================================================

setup_alias() {
    log INFO "Setting up MinIO alias: $MINIO_ALIAS"
    
    # Remove existing alias if present (to update credentials)
    mc alias remove "$MINIO_ALIAS" &>/dev/null || true
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log INFO "[DRY-RUN] Would create alias $MINIO_ALIAS -> $MINIO_ENDPOINT"
        return 0
    fi
    
    if ! mc alias set "$MINIO_ALIAS" "$MINIO_ENDPOINT" \
        "$MINIO_ADMIN_ACCESS_KEY" "$MINIO_ADMIN_SECRET_KEY" \
        --api S3v4 2>&1; then
        die "Failed to set up MinIO alias"
    fi
    
    # Verify connection
    if ! mc admin info "$MINIO_ALIAS" &>/dev/null; then
        die "Failed to connect to MinIO at $MINIO_ENDPOINT"
    fi
    
    log INFO "Successfully connected to MinIO"
}

create_bucket() {
    local bucket="$1"
    local description="$2"
    
    log INFO "Creating bucket: $bucket ($description)"
    
    # Check if bucket exists
    if mc ls "$MINIO_ALIAS/$bucket" &>/dev/null; then
        log INFO "Bucket $bucket already exists"
    else
        run_mc mb "$MINIO_ALIAS/$bucket" --region "$MINIO_REGION"
        log INFO "Created bucket: $bucket"
    fi
}

enable_versioning() {
    local bucket="$1"
    
    log INFO "Enabling versioning on bucket: $bucket"
    run_mc version enable "$MINIO_ALIAS/$bucket"
}

set_lifecycle_rule() {
    local bucket="$1"
    local expiry_days="$2"
    
    log INFO "Setting lifecycle rule on $bucket: expire after $expiry_days days"
    
    # Create lifecycle configuration JSON
    local lifecycle_json
    lifecycle_json=$(cat <<EOF
{
    "Rules": [
        {
            "ID": "auto-expire-old-backups",
            "Status": "Enabled",
            "Filter": {
                "Prefix": ""
            },
            "Expiration": {
                "Days": $expiry_days
            }
        },
        {
            "ID": "expire-noncurrent-versions",
            "Status": "Enabled",
            "Filter": {
                "Prefix": ""
            },
            "NoncurrentVersionExpiration": {
                "NoncurrentDays": 7
            }
        },
        {
            "ID": "abort-incomplete-uploads",
            "Status": "Enabled",
            "Filter": {
                "Prefix": ""
            },
            "AbortIncompleteMultipartUpload": {
                "DaysAfterInitiation": 1
            }
        }
    ]
}
EOF
)

    if [[ "$DRY_RUN" == "true" ]]; then
        log INFO "[DRY-RUN] Would set lifecycle rule: $lifecycle_json"
        return 0
    fi
    
    local tmp_file
    tmp_file=$(mktemp)
    echo "$lifecycle_json" > "$tmp_file"
    
    if ! mc ilm import "$MINIO_ALIAS/$bucket" < "$tmp_file" 2>&1; then
        log WARN "Failed to set lifecycle rule on $bucket (may require MinIO version with ILM support)"
    fi
    
    rm -f "$tmp_file"
}

create_bucket_policy() {
    local policy_name="$1"
    local bucket="$2"
    
    log INFO "Creating policy: $policy_name for bucket: $bucket"
    
    # Create least-privilege policy for bucket access
    local policy_json
    policy_json=$(cat <<EOF
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "s3:GetBucketLocation",
                "s3:ListBucket",
                "s3:ListBucketMultipartUploads"
            ],
            "Resource": [
                "arn:aws:s3:::$bucket"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "s3:GetObject",
                "s3:PutObject",
                "s3:DeleteObject",
                "s3:AbortMultipartUpload",
                "s3:ListMultipartUploadParts"
            ],
            "Resource": [
                "arn:aws:s3:::$bucket/*"
            ]
        }
    ]
}
EOF
)

    if [[ "$DRY_RUN" == "true" ]]; then
        log INFO "[DRY-RUN] Would create policy: $policy_name"
        return 0
    fi
    
    local tmp_file
    tmp_file=$(mktemp)
    echo "$policy_json" > "$tmp_file"
    
    # Remove existing policy if present
    mc admin policy remove "$MINIO_ALIAS" "$policy_name" &>/dev/null || true
    
    if ! mc admin policy create "$MINIO_ALIAS" "$policy_name" "$tmp_file" 2>&1; then
        log WARN "Failed to create policy $policy_name"
    fi
    
    rm -f "$tmp_file"
}

create_service_account() {
    local sa_name="$1"
    local bucket="$2"
    local policy_name="${sa_name}-policy"
    
    log INFO "Creating service account: $sa_name"
    
    if [[ "$SKIP_CREDENTIALS" == "true" ]]; then
        log INFO "Skipping credential generation (--skip-credentials flag)"
        return 0
    fi
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log INFO "[DRY-RUN] Would create service account: $sa_name with policy: $policy_name"
        return 0
    fi
    
    # Create the policy first
    create_bucket_policy "$policy_name" "$bucket"
    
    # Generate a secure random access key (20 chars alphanumeric)
    local access_key
    access_key=$(LC_ALL=C tr -dc 'A-Z0-9' < /dev/urandom | head -c 20 || true)
    
    # Generate a secure random secret key (40 chars alphanumeric)
    local secret_key
    secret_key=$(LC_ALL=C tr -dc 'A-Za-z0-9' < /dev/urandom | head -c 40 || true)
    
    # Check if user already exists
    if mc admin user info "$MINIO_ALIAS" "$access_key" &>/dev/null; then
        log INFO "Service account $sa_name already exists"
        return 0
    fi
    
    # Create user with access key/secret key
    if ! mc admin user add "$MINIO_ALIAS" "$access_key" "$secret_key" 2>&1; then
        log WARN "Failed to create service account $sa_name"
        return 1
    fi
    
    # Attach policy to user
    if ! mc admin policy attach "$MINIO_ALIAS" "$policy_name" --user "$access_key" 2>&1; then
        log WARN "Failed to attach policy to service account $sa_name"
        return 1
    fi
    
    # Output credentials
    echo ""
    echo "================================================================"
    echo "Service Account: $sa_name"
    echo "Bucket Access:   $bucket"
    echo "----------------------------------------------------------------"
    echo "Access Key:      $access_key"
    echo "Secret Key:      $secret_key"
    echo "================================================================"
    echo ""
    
    # Output in AWS credentials format (for Kubernetes secrets)
    local creds_dir="${SCRIPT_DIR}/../../.credentials"
    mkdir -p "$creds_dir"
    chmod 700 "$creds_dir"
    
    cat > "$creds_dir/${sa_name}-credentials.txt" <<EOF
# MinIO Service Account: $sa_name
# Bucket: $bucket
# Generated: $(date -u +"%Y-%m-%dT%H:%M:%SZ")

# AWS SDK Format (for Velero/K8s secrets)
[default]
aws_access_key_id=$access_key
aws_secret_access_key=$secret_key

# Environment Variables (for Docker/scripts)
AWS_ACCESS_KEY_ID=$access_key
AWS_SECRET_ACCESS_KEY=$secret_key
AWS_DEFAULT_REGION=$MINIO_REGION
MINIO_ENDPOINT=$MINIO_ENDPOINT

# mc alias command
# mc alias set ${sa_name}-alias $MINIO_ENDPOINT $access_key $secret_key --api S3v4
EOF
    
    chmod 600 "$creds_dir/${sa_name}-credentials.txt"
    log INFO "Credentials saved to: $creds_dir/${sa_name}-credentials.txt"
}

# =============================================================================
# Main Provisioning Logic
# =============================================================================

provision_all() {
    log INFO "Starting MinIO backup infrastructure provisioning"
    log INFO "Endpoint: $MINIO_ENDPOINT"
    log INFO "Region: $MINIO_REGION"
    
    # Set up MinIO alias
    setup_alias
    
    # Create all buckets
    log INFO "Creating buckets..."
    for bucket in "${!BUCKETS[@]}"; do
        create_bucket "$bucket" "${BUCKETS[$bucket]}"
    done
    
    # Enable versioning on all buckets
    log INFO "Enabling versioning..."
    for bucket in "${!BUCKETS[@]}"; do
        enable_versioning "$bucket"
    done
    
    # Set lifecycle rules
    log INFO "Setting lifecycle rules..."
    for bucket in "${!BUCKET_LIFECYCLE[@]}"; do
        set_lifecycle_rule "$bucket" "${BUCKET_LIFECYCLE[$bucket]}"
    done
    
    # Create service accounts
    log INFO "Creating service accounts..."
    for sa_name in "${!SERVICE_ACCOUNTS[@]}"; do
        create_service_account "$sa_name" "${SERVICE_ACCOUNTS[$sa_name]}"
    done
    
    log INFO "MinIO backup infrastructure provisioning complete!"
    
    # Summary
    echo ""
    echo "================================================================"
    echo "                    PROVISIONING SUMMARY"
    echo "================================================================"
    echo "Endpoint:    $MINIO_ENDPOINT"
    echo "Buckets:     ${#BUCKETS[@]} created/verified"
    echo "Accounts:    ${#SERVICE_ACCOUNTS[@]} service accounts"
    echo ""
    echo "Buckets created:"
    for bucket in "${!BUCKETS[@]}"; do
        echo "  - $bucket (${BUCKET_LIFECYCLE[$bucket]} day retention)"
    done
    echo ""
    if [[ "$SKIP_CREDENTIALS" != "true" && "$DRY_RUN" != "true" ]]; then
        echo "Credentials saved to: ${SCRIPT_DIR}/../../.credentials/"
        echo ""
        echo "IMPORTANT: Encrypt credentials with SOPS before committing!"
        echo "  sops -e .credentials/velero-backup-credentials.txt > credentials.enc.yaml"
    fi
    echo "================================================================"
}

show_usage() {
    cat <<EOF
Usage: $SCRIPT_NAME [OPTIONS]

Configure MinIO buckets, policies, and service accounts for backup infrastructure.

OPTIONS:
    --dry-run           Show what would be done without making changes
    --skip-credentials  Skip service account credential generation
    --verbose           Enable verbose debug output
    -h, --help          Show this help message

ENVIRONMENT VARIABLES:
    MINIO_ADMIN_ACCESS_KEY  Admin access key (required)
    MINIO_ADMIN_SECRET_KEY  Admin secret key (required)
    MINIO_ENDPOINT          MinIO endpoint (default: https://minio.pandia.io:9000)
    MINIO_ALIAS             MC alias name (default: pandia-minio)
    MINIO_REGION            AWS region (default: us-east-1)

EXAMPLES:
    # Dry run to see what would be created
    export MINIO_ADMIN_ACCESS_KEY=admin
    export MINIO_ADMIN_SECRET_KEY=adminpassword
    $SCRIPT_NAME --dry-run

    # Full provisioning
    $SCRIPT_NAME

    # Skip credential generation (buckets only)
    $SCRIPT_NAME --skip-credentials

BUCKETS CREATED:
    - openebs-velero-backups  (90 day retention, Velero K8s backups)
    - portainer-backups       (30 day retention, Docker Swarm backups)
    - etcd-backups            (30 day retention, K3s etcd backups)
    - database-dumps          (60 day retention, logical DB dumps)

SERVICE ACCOUNTS:
    - velero-backup     -> openebs-velero-backups
    - portainer-backup  -> portainer-backups
    - etcd-backup       -> etcd-backups
    - database-backup   -> database-dumps

EOF
}

# =============================================================================
# Main Entry Point
# =============================================================================

main() {
    # Parse arguments
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --dry-run)
                DRY_RUN=true
                shift
                ;;
            --skip-credentials)
                SKIP_CREDENTIALS=true
                shift
                ;;
            --verbose)
                VERBOSE=true
                shift
                ;;
            -h|--help)
                show_usage
                exit 0
                ;;
            *)
                die "Unknown option: $1. Use --help for usage."
                ;;
        esac
    done
    
    log INFO "MinIO Backup Setup Script"
    log INFO "========================="
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log WARN "Running in DRY-RUN mode - no changes will be made"
    fi
    
    check_prerequisites
    provision_all
}

main "$@"
