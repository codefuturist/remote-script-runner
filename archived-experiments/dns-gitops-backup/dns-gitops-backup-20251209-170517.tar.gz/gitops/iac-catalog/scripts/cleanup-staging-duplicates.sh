#!/usr/bin/env bash
# Move duplicate staging apps to system trash
# Apps that are already in production cluster

set -e

STAGING_APPS_DIR="catalog/gitops/flux/clusters/staging/applications"
PRODUCTION_APPS_DIR="catalog/gitops/flux/clusters/production/apps"

echo "╔══════════════════════════════════════════════════════════════════════════════╗"
echo "║           Moving Duplicate Staging Apps to System Trash                     ║"
echo "╚══════════════════════════════════════════════════════════════════════════════╝"
echo ""

# Function to move to trash (macOS)
move_to_trash() {
    local item=$1
    if command -v trash >/dev/null 2>&1; then
        trash "$item"
        echo "  ✅ Moved to trash: $(basename "$item")"
    elif command -v osascript >/dev/null 2>&1; then
        # Use AppleScript as fallback
        osascript -e "tell application \"Finder\" to delete POSIX file \"$(pwd)/$item\"" 2>/dev/null
        echo "  ✅ Moved to trash: $(basename "$item")"
    else
        echo "  ⚠️  Cannot move to trash: $(basename "$item") - no trash command available"
        echo "      You can manually delete: $item"
    fi
}

echo "🔍 Scanning for duplicate apps..."
echo ""

duplicates_found=0

# Check each app in staging/applications
for app_path in "$STAGING_APPS_DIR"/*; do
    if [ -d "$app_path" ]; then
        app_name=$(basename "$app_path")

        # Check if it exists in production (exact match or without -app suffix)
        if [ -d "$PRODUCTION_APPS_DIR/$app_name" ] || [ -d "$PRODUCTION_APPS_DIR/${app_name%-app}" ]; then
            echo "📦 Found duplicate: $app_name"
            production_name=""
            if [ -d "$PRODUCTION_APPS_DIR/$app_name" ]; then
                production_name="$app_name"
            elif [ -d "$PRODUCTION_APPS_DIR/${app_name%-app}" ]; then
                production_name="${app_name%-app}"
            fi
            echo "   Production equivalent: $production_name"
            move_to_trash "$app_path"
            ((duplicates_found++))
            echo ""
        fi
    fi
done

# Also check standalone kustomization files that reference moved apps
echo "🔍 Checking standalone kustomization files..."
echo ""

kustomization_files=(
    "$STAGING_APPS_DIR/mealie-kustomization.yaml"
    "$STAGING_APPS_DIR/wordpress-kustomization.yaml"
    "$STAGING_APPS_DIR/wordpress-test-kustomization.yaml"
)

for kustom_file in "${kustomization_files[@]}"; do
    if [ -f "$kustom_file" ]; then
        base_name=$(basename "$kustom_file" "-kustomization.yaml")
        if [ -d "$PRODUCTION_APPS_DIR/$base_name" ] || [ -d "$PRODUCTION_APPS_DIR/${base_name%-app}" ]; then
            echo "📄 Found duplicate kustomization: $(basename "$kustom_file")"
            move_to_trash "$kustom_file"
            ((duplicates_found++))
            echo ""
        fi
    fi
done

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📊 Summary"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "🗑️  Moved $duplicates_found duplicate items to system trash"
echo ""
echo "✅ Staging cluster is now clean of production duplicates"
echo ""
echo "Remaining staging-specific items:"
ls -1 "$STAGING_APPS_DIR" 2>/dev/null | head -10 || echo "   (none)"
