#!/usr/bin/env bash
# generate-and-encrypt-secrets.sh
# Generate secure values and encrypt secrets for staging cluster

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
export SOPS_AGE_KEY_FILE="$REPO_ROOT/age.agekey"

echo "🔐 Generate and Encrypt Staging Secrets"
echo "========================================"
echo ""

# Check prerequisites
if ! command -v sops &> /dev/null; then
    echo "❌ Error: sops is not installed"
    echo "Install with: brew install sops"
    exit 1
fi

if ! command -v openssl &> /dev/null; then
    echo "❌ Error: openssl is not installed"
    exit 1
fi

if [ ! -f "$SOPS_AGE_KEY_FILE" ]; then
    echo "❌ Error: Age key file not found at $SOPS_AGE_KEY_FILE"
    exit 1
fi

echo "✅ Prerequisites check passed"
echo ""

# Generate secure random values
echo "🎲 Generating secure random values..."
REDIS_PASSWORD=$(</dev/random LC_ALL=C tr -dc '[:graph:]' | head -c32)
POSTGRESQL_PASSWORD=$(</dev/random LC_ALL=C tr -dc '[:graph:]' | head -c32)
AUTHENTIK_SECRET_KEY=$(</dev/random LC_ALL=C tr -dc '[:graph:]' | head -c32)
HOMARR_DB_KEY=$(</dev/random LC_ALL=C tr -dc '[:graph:]' | head -c32)
WORDPRESS_DB_PASSWORD=$(</dev/random LC_ALL=C tr -dc '[:graph:]' | head -c32)
WORDPRESS_TEST_DB_PASSWORD=$(</dev/random LC_ALL=C tr -dc '[:graph:]' | head -c32)

echo "✅ Generated secure values"
echo ""

# Update authentik secret
AUTHENTIK_SECRET="$REPO_ROOT/catalog/gitops/flux/clusters/staging/apps/production/authentik/authentik-secret.yaml"
echo "📝 Updating authentik secret..."

# Create temporary unencrypted file
cat > "$AUTHENTIK_SECRET.tmp" <<EOF
apiVersion: v1
kind: Secret
metadata:
    name: authentik
    namespace: access-control
type: Opaque
stringData:
    redis-password: "$REDIS_PASSWORD"
    postgresql-password: "$POSTGRESQL_PASSWORD"
    authentik-secret-key: "$AUTHENTIK_SECRET_KEY"
    smtp-password: ""
EOF

# Encrypt the file
sops --encrypt "$AUTHENTIK_SECRET.tmp" > "$AUTHENTIK_SECRET"
rm "$AUTHENTIK_SECRET.tmp"

echo "✅ Encrypted authentik-secret.yaml"
echo ""

# Update homarr secret
HOMARR_SECRET="$REPO_ROOT/catalog/gitops/flux/clusters/staging/apps/production/homarr/homarr-secret.yaml"
echo "📝 Updating homarr secret..."

# Create temporary unencrypted file
cat > "$HOMARR_SECRET.tmp" <<EOF
apiVersion: v1
kind: Secret
metadata:
    name: homarr-db
    namespace: dashboard
type: Opaque
stringData:
    db-encryption-key: "$HOMARR_DB_KEY"
EOF

# Encrypt the file
sops --encrypt "$HOMARR_SECRET.tmp" > "$HOMARR_SECRET"
rm "$HOMARR_SECRET.tmp"

echo "✅ Encrypted homarr-secret.yaml"
echo ""

# Update wordpress secret
WORDPRESS_SECRET="$REPO_ROOT/catalog/gitops/flux/clusters/staging/apps/production/wordpress/wordpress-secret.yaml"
echo "📝 Updating wordpress secret..."

cat > "$WORDPRESS_SECRET.tmp" <<EOF
apiVersion: v1
kind: Secret
metadata:
    name: wordpress-db-password
    namespace: database
type: Opaque
stringData:
    password: "$WORDPRESS_DB_PASSWORD"
EOF

sops --encrypt "$WORDPRESS_SECRET.tmp" > "$WORDPRESS_SECRET"
rm "$WORDPRESS_SECRET.tmp"

echo "✅ Encrypted wordpress-secret.yaml"
echo ""

# Update wordpress-test secret
WORDPRESS_TEST_SECRET="$REPO_ROOT/catalog/gitops/flux/clusters/staging/apps/production/wordpress-test/wordpress-secret.yaml"
echo "📝 Updating wordpress-test secret..."

cat > "$WORDPRESS_TEST_SECRET.tmp" <<EOF
apiVersion: v1
kind: Secret
metadata:
    name: wordpress-test-db-password
    namespace: database
type: Opaque
stringData:
    password: "$WORDPRESS_TEST_DB_PASSWORD"
EOF

sops --encrypt "$WORDPRESS_TEST_SECRET.tmp" > "$WORDPRESS_TEST_SECRET"
rm "$WORDPRESS_TEST_SECRET.tmp"

echo "✅ Encrypted wordpress-test-secret.yaml"
echo ""

# Save credentials to a secure temporary file for reference
CREDS_FILE="$REPO_ROOT/.staging-secrets-$(date +%Y%m%d-%H%M%S).txt"
cat > "$CREDS_FILE" <<EOF
# Staging Cluster Secrets
# Generated on: $(date)
# 
# ⚠️  IMPORTANT: Store these securely and delete this file after saving to password manager
# ⚠️  These values are also encrypted in the SOPS files

=== Authentik Credentials ===
Redis Password: $REDIS_PASSWORD
PostgreSQL Password: $POSTGRESQL_PASSWORD
Authentik Secret Key: $AUTHENTIK_SECRET_KEY

=== Homarr Credentials ===
Database Encryption Key: $HOMARR_DB_KEY

=== WordPress Credentials ===
Main WordPress DB Password: $WORDPRESS_DB_PASSWORD
Test WordPress DB Password: $WORDPRESS_TEST_DB_PASSWORD

EOF

echo "🎉 Done!"
echo ""
echo "📋 Summary:"
echo "  ✅ Generated secure random values"
echo "  ✅ Encrypted authentik-secret.yaml with SOPS"
echo "  ✅ Encrypted homarr-secret.yaml with SOPS"
echo "  ✅ Encrypted wordpress-secret.yaml with SOPS"
echo "  ✅ Encrypted wordpress-test-secret.yaml with SOPS"
echo "  ✅ Saved credentials reference to: $CREDS_FILE"
echo ""
echo "⚠️  Next steps:"
echo "  1. Store credentials from $CREDS_FILE in your password manager"
echo "  2. Delete the credentials file: rm $CREDS_FILE"
echo "  3. Commit the encrypted secrets to Git"
echo "  4. Deploy with: kubectl apply -k catalog/gitops/flux/clusters/staging"
echo ""
