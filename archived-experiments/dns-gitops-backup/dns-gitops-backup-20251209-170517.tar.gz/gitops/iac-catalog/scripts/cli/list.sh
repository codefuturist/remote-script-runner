#!/bin/bash
# IaC CLI - List Deployments
# Usage: ./list.sh [--environment <env>]

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

ENVIRONMENT="all"

while [[ $# -gt 0 ]]; do
    case $1 in
        --environment)
            ENVIRONMENT="$2"
            shift 2
            ;;
        *)
            shift
            ;;
    esac
done

echo "=== Deployed Instances ==="
echo ""

if [[ "$ENVIRONMENT" == "all" ]]; then
    ENVIRONMENTS=("production" "staging" "development")
else
    ENVIRONMENTS=("$ENVIRONMENT")
fi

for env in "${ENVIRONMENTS[@]}"; do
    DEPLOY_DIR="$REPO_ROOT/deployments/$env"
    if [[ -d "$DEPLOY_DIR" ]]; then
        echo "Environment: $env"
        for instance in "$DEPLOY_DIR"/*/; do
            if [[ -d "$instance" ]] && [[ -f "$instance/manifest.yml" ]]; then
                instance_name=$(basename "$instance")
                echo "  - $instance_name"
            fi
        done
        echo ""
    fi
done
