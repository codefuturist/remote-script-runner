#!/bin/bash
# IaC CLI - Configure Template into Instance
# Usage: ./configure.sh --template <path> --instance <id> --environment <env> [options]

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

# Default values
ENVIRONMENT="production"
TARGET_TYPE="docker-compose"
DRY_RUN=false
USE_JINJA=false

# Color output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Check if jinja2-cli is available
if command -v jinja2 &> /dev/null; then
    JINJA2_AVAILABLE=true
else
    JINJA2_AVAILABLE=false
fi

function usage() {
    cat <<EOF
Usage: $0 [OPTIONS]

Configure a template into a deployable instance.
Supports Jinja2 templating for dynamic configuration.

OPTIONS:
    --template PATH         Path to template (required)
    --instance ID           Instance identifier (required)
    --environment ENV       Environment (production|staging|development) [default: production]
    --target HOST|GROUP     Deployment target - single host or group name (required)
    --target-type TYPE      Target type (docker-compose|kubernetes) [default: docker-compose]
    --param KEY=VALUE       Template parameter (can be specified multiple times)
    --jinja                 Enable Jinja2 template rendering
    --dry-run               Show what would be created without creating it
    -h, --help              Show this help message

JINJA2 TEMPLATING:
    If template files have .j2 extension, they will be automatically rendered with Jinja2.
    Use --param to pass variables to the template.
    Requires: jinja2-cli (install via: pipx install jinja2-cli)

EXAMPLES:
    # Simple deployment (no templating)
    $0 --template catalog/containers/docker/compose-stacks/wordpress \\
       --instance app-wordpress-server01 \\
       --environment production \\
       --target server-web-01

    # With Jinja2 templating
    $0 --template catalog/containers/docker/compose-stacks/wordpress \\
       --instance app-wordpress-server01 \\
       --environment production \\
       --target server-web-01 \\
       --jinja \\
       --param domain=blog.example.com \\
       --param db_password=secret123 \\
       --param replicas=3

    # Multi-server deployment
    $0 --template catalog/containers/docker/compose-stacks/monitoring-stack \\
       --instance monitoring-stack \\
       --environment production \\
       --target monitoring-nodes \\
       --param grafana_password=admin123

EOF
    exit 1
}

# Parse arguments
PARAMS=()
PARAM_DICT=()
while [[ $# -gt 0 ]]; do
    case $1 in
        --template)
            TEMPLATE_PATH="$2"
            shift 2
            ;;
        --instance)
            INSTANCE_ID="$2"
            shift 2
            ;;
        --environment)
            ENVIRONMENT="$2"
            shift 2
            ;;
        --target)
            TARGET="$2"
            shift 2
            ;;
        --target-type)
            TARGET_TYPE="$2"
            shift 2
            ;;
        --param)
            PARAMS+=("$2")
            # Parse key=value for Jinja2 - store in format for jinja2 -D flag
            if [[ "$2" =~ ^([^=]+)=(.+)$ ]]; then
                PARAM_DICT+=("${BASH_REMATCH[1]}=${BASH_REMATCH[2]}")
            fi
            shift 2
            ;;
        --jinja)
            USE_JINJA=true
            shift
            ;;
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        -h|--help)
            usage
            ;;
        *)
            echo "Unknown option: $1"
            usage
            ;;
    esac
done

# Validate required arguments
if [[ -z "$TEMPLATE_PATH" ]] || [[ -z "$INSTANCE_ID" ]] || [[ -z "$TARGET" ]]; then
    echo -e "${RED}Error: Missing required arguments${NC}"
    usage
fi

# Build paths
DEPLOYMENT_DIR="$REPO_ROOT/deployments/$ENVIRONMENT/$INSTANCE_ID"
TEMPLATE_FULL_PATH="$REPO_ROOT/$TEMPLATE_PATH"

echo -e "${GREEN}=== IaC CLI - Configure Template ===${NC}"
echo "Template:    $TEMPLATE_PATH"
echo "Instance:    $INSTANCE_ID"
echo "Environment: $ENVIRONMENT"
echo "Target:      $TARGET"
echo "Target Type: $TARGET_TYPE"
echo "Jinja2:      $USE_JINJA"
echo "Dry Run:     $DRY_RUN"
if [[ ${#PARAMS[@]} -gt 0 ]]; then
    echo "Parameters:"
    for param in "${PARAMS[@]}"; do
        echo "  - $param"
    done
fi
echo ""

# Check if Jinja2 is needed and available
if [[ "$USE_JINJA" == "true" ]] && [[ "$JINJA2_AVAILABLE" == "false" ]]; then
    echo -e "${RED}Error: Jinja2 templating requested but jinja2-cli is not installed${NC}"
    echo -e "${YELLOW}Install with: pipx install jinja2-cli${NC}"
    exit 1
fi

# Auto-detect Jinja2 templates (.j2 extension)
if [[ -f "$TEMPLATE_FULL_PATH/docker-compose.yml.j2" ]] || [[ -f "$TEMPLATE_FULL_PATH/docker-compose.yaml.j2" ]]; then
    if [[ "$JINJA2_AVAILABLE" == "true" ]]; then
        USE_JINJA=true
        echo -e "${BLUE}ℹ Auto-detected Jinja2 template (.j2 extension)${NC}"
    else
        echo -e "${YELLOW}Warning: Jinja2 template detected but jinja2-cli is not installed${NC}"
        echo -e "${YELLOW}Template will be copied as-is without rendering${NC}"
    fi
fi

# Check if template exists
if [[ ! -d "$TEMPLATE_FULL_PATH" ]]; then
    echo -e "${RED}Error: Template not found at $TEMPLATE_PATH${NC}"
    exit 1
fi

# Check if instance already exists
if [[ -d "$DEPLOYMENT_DIR" ]]; then
    echo -e "${YELLOW}Warning: Instance already exists at $DEPLOYMENT_DIR${NC}"
    read -p "Overwrite? (y/N) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "Aborted."
        exit 1
    fi
fi

if [[ "$DRY_RUN" == "true" ]]; then
    echo -e "${YELLOW}Dry run mode - no files will be created${NC}"
    echo ""
    echo "Would create:"
    echo "  $DEPLOYMENT_DIR/manifest.yml"
    echo "  $DEPLOYMENT_DIR/docker-compose.yml"
    echo "  $DEPLOYMENT_DIR/.env"
    echo "  $DEPLOYMENT_DIR/target.yml or targets.yml"
    exit 0
fi

# Create instance directory
echo -e "${GREEN}Creating instance directory...${NC}"
mkdir -p "$DEPLOYMENT_DIR"

# Generate manifest.yml
echo -e "${GREEN}Generating manifest.yml...${NC}"
cat > "$DEPLOYMENT_DIR/manifest.yml" <<EOF
# Instance Manifest
# Generated by iac-cli configure

instance:
  id: $INSTANCE_ID
  name: "$INSTANCE_ID"
  description: "Generated from template $TEMPLATE_PATH"
  
template:
  source: $TEMPLATE_PATH
  version: 1.0.0
  type: $TARGET_TYPE

environment: $ENVIRONMENT

metadata:
  created: $(date -u +"%Y-%m-%dT%H:%M:%SZ")
  updated: $(date -u +"%Y-%m-%dT%H:%M:%SZ")
  created_by: iac-cli
  
labels:
  managed-by: gitops
EOF

# Copy/render template files
echo -e "${GREEN}Copying template files...${NC}"

# Function to render Jinja2 template
render_jinja2() {
    local input_file="$1"
    local output_file="$2"
    
    # Build jinja2 command with parameters
    local cmd="jinja2"
    
    # Add parameters
    for param_def in "${PARAM_DICT[@]}"; do
        cmd="$cmd -D $param_def"
    done
    
    # Add strict mode (fail on undefined variables)
    cmd="$cmd --strict"
    
    # Add input file
    cmd="$cmd \"$input_file\""
    
    echo -e "${BLUE}  Rendering Jinja2 template: $(basename "$input_file") → $(basename "$output_file")${NC}"
    
    # Execute rendering
    if eval "$cmd" > "$output_file"; then
        echo -e "${GREEN}  ✓ Rendered successfully${NC}"
        return 0
    else
        echo -e "${RED}  ✗ Failed to render template${NC}"
        return 1
    fi
}

# Process docker-compose file
if [[ "$USE_JINJA" == "true" ]] && [[ "$JINJA2_AVAILABLE" == "true" ]]; then
    # Try .j2 variants first
    if [[ -f "$TEMPLATE_FULL_PATH/docker-compose.yml.j2" ]]; then
        render_jinja2 "$TEMPLATE_FULL_PATH/docker-compose.yml.j2" "$DEPLOYMENT_DIR/docker-compose.yml"
    elif [[ -f "$TEMPLATE_FULL_PATH/docker-compose.yaml.j2" ]]; then
        render_jinja2 "$TEMPLATE_FULL_PATH/docker-compose.yaml.j2" "$DEPLOYMENT_DIR/docker-compose.yaml"
    elif [[ -f "$TEMPLATE_FULL_PATH/docker-compose.yml" ]]; then
        cp "$TEMPLATE_FULL_PATH/docker-compose.yml" "$DEPLOYMENT_DIR/docker-compose.yml"
    elif [[ -f "$TEMPLATE_FULL_PATH/docker-compose.yaml" ]]; then
        cp "$TEMPLATE_FULL_PATH/docker-compose.yaml" "$DEPLOYMENT_DIR/docker-compose.yaml"
    fi
    
    # Process .env file
    if [[ -f "$TEMPLATE_FULL_PATH/.env.example.j2" ]]; then
        render_jinja2 "$TEMPLATE_FULL_PATH/.env.example.j2" "$DEPLOYMENT_DIR/.env"
    elif [[ -f "$TEMPLATE_FULL_PATH/.env.j2" ]]; then
        render_jinja2 "$TEMPLATE_FULL_PATH/.env.j2" "$DEPLOYMENT_DIR/.env"
    elif [[ -f "$TEMPLATE_FULL_PATH/.env.example" ]]; then
        cp "$TEMPLATE_FULL_PATH/.env.example" "$DEPLOYMENT_DIR/.env"
    fi
else
    # Standard copy mode (no Jinja2)
    if [[ -f "$TEMPLATE_FULL_PATH/docker-compose.yml" ]]; then
        cp "$TEMPLATE_FULL_PATH/docker-compose.yml" "$DEPLOYMENT_DIR/docker-compose.yml"
    elif [[ -f "$TEMPLATE_FULL_PATH/docker-compose.yaml" ]]; then
        cp "$TEMPLATE_FULL_PATH/docker-compose.yaml" "$DEPLOYMENT_DIR/docker-compose.yaml"
    fi

    if [[ -f "$TEMPLATE_FULL_PATH/.env.example" ]]; then
        cp "$TEMPLATE_FULL_PATH/.env.example" "$DEPLOYMENT_DIR/.env"
    fi
fi

# Generate target configuration
echo -e "${GREEN}Generating target configuration...${NC}"

# Check if target is a single host or group (simple heuristic: groups have dashes)
if [[ "$TARGET" == *"-nodes"* ]] || [[ "$TARGET" == *"-servers"* ]]; then
    # Multi-server (group)
    cat > "$DEPLOYMENT_DIR/targets.yml" <<EOF
# Deployment Targets Configuration - Multi-server deployment
targets:
  - type: $TARGET_TYPE
    group: $TARGET
    inventory: inventory/$ENVIRONMENT/servers.yml
    strategy: rolling
    max_unavailable: 1
    delay_between_servers: 30s
    labels:
      managed-by: gitops
EOF
else
    # Single server
    cat > "$DEPLOYMENT_DIR/target.yml" <<EOF
# Deployment Target Configuration
targets:
  - type: $TARGET_TYPE
    host: $TARGET
    inventory: inventory/$ENVIRONMENT/servers.yml
    labels:
      managed-by: gitops
EOF
fi

echo -e "${GREEN}✓ Instance configured successfully!${NC}"
echo ""
echo "Instance created at: $DEPLOYMENT_DIR"
echo ""
echo "Next steps:"
echo "  1. Review and edit the generated files"
echo "  2. Update .env with actual configuration values"
echo "  3. Commit to Git: git add $DEPLOYMENT_DIR && git commit -m 'feat: add $INSTANCE_ID'"
echo "  4. Push to trigger GitOps deployment: git push"
