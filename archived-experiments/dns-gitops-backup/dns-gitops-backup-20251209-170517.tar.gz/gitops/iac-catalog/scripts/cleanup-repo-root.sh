#!/usr/bin/env bash
# Comprehensive Cleanup Script for iac-catalog repository
# Archives orphaned files, temporary scripts, and one-time fix documentation

set -e

REPO_ROOT="/Users/colin/Developer/Projects/personal/iac-catalog"
ARCHIVE_DIR="$REPO_ROOT/archive-for-reference-only/cleanup-$(date +%Y%m%d)"
DRY_RUN=${1:-"--dry-run"}

echo "╔══════════════════════════════════════════════════════════════════════════════╗"
echo "║               iac-catalog Repository Cleanup                                 ║"
echo "╚══════════════════════════════════════════════════════════════════════════════╝"
echo ""

if [ "$DRY_RUN" == "--dry-run" ]; then
    echo "🔍 DRY RUN MODE - No files will be moved"
    echo "   Run with --execute to actually move files"
    echo ""
fi

cd "$REPO_ROOT"

# Create archive directory
mkdir -p "$ARCHIVE_DIR/root-scripts"
mkdir -p "$ARCHIVE_DIR/root-docs"
mkdir -p "$ARCHIVE_DIR/root-configs"
mkdir -p "$ARCHIVE_DIR/flux-production"

move_file() {
    local src=$1
    local dest=$2
    if [ -f "$src" ]; then
        if [ "$DRY_RUN" == "--dry-run" ]; then
            echo "  Would archive: $src -> $dest"
        else
            mv "$src" "$dest"
            echo "  ✅ Archived: $src"
        fi
    fi
}

move_dir() {
    local src=$1
    local dest=$2
    if [ -d "$src" ]; then
        if [ "$DRY_RUN" == "--dry-run" ]; then
            echo "  Would archive: $src/ -> $dest/"
        else
            mv "$src" "$dest"
            echo "  ✅ Archived: $src/"
        fi
    fi
}

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "1. One-time fix scripts (root directory)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
move_file "apply-wildcard-cert-fix.sh" "$ARCHIVE_DIR/root-scripts/"
move_file "check-flux-secrets.sh" "$ARCHIVE_DIR/root-scripts/"
move_file "commit-changes.sh" "$ARCHIVE_DIR/root-scripts/"
move_file "commit-sops-fix.sh" "$ARCHIVE_DIR/root-scripts/"
move_file "create-wildcard-cert.sh" "$ARCHIVE_DIR/root-scripts/"
move_file "debug-flux-sops.sh" "$ARCHIVE_DIR/root-scripts/"
move_file "demo-openebs-velero-backup.sh" "$ARCHIVE_DIR/root-scripts/"
move_file "fix-cert-manager.sh" "$ARCHIVE_DIR/root-scripts/"
move_file "fix-sops-decryption.sh" "$ARCHIVE_DIR/root-scripts/"
move_file "import-manual-cert.sh" "$ARCHIVE_DIR/root-scripts/"
move_file "prepare-flux-decryption.sh" "$ARCHIVE_DIR/root-scripts/"
move_file "regenerate-secrets.sh" "$ARCHIVE_DIR/root-scripts/"
move_file "run-complete-fix.sh" "$ARCHIVE_DIR/root-scripts/"
move_file "test-flux-sops.sh" "$ARCHIVE_DIR/root-scripts/"
move_file "validate-e2e.sh" "$ARCHIVE_DIR/root-scripts/"
echo ""

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "2. One-time fix documentation (root directory)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
move_file "CERT_MANAGER_FIX.md" "$ARCHIVE_DIR/root-docs/"
move_file "COMMIT_THESE_CHANGES.md" "$ARCHIVE_DIR/root-docs/"
move_file "DATABASE_STRATEGY_ANALYSIS.md" "$ARCHIVE_DIR/root-docs/"
move_file "MANUAL_CERT_CREATION.md" "$ARCHIVE_DIR/root-docs/"
move_file "PRODUCTION_MIGRATION_SUMMARY.md" "$ARCHIVE_DIR/root-docs/"
move_file "QUICK_START_SOPS_FIX.md" "$ARCHIVE_DIR/root-docs/"
move_file "QUICKSTART_WILDCARD_FIX.md" "$ARCHIVE_DIR/root-docs/"
move_file "RUN_THIS_NOW.md" "$ARCHIVE_DIR/root-docs/"
move_file "SOPS_FIX_INSTRUCTIONS.md" "$ARCHIVE_DIR/root-docs/"
move_file "WILDCARD_CERT_FIX.md" "$ARCHIVE_DIR/root-docs/"
move_file "suggested-1-README.md" "$ARCHIVE_DIR/root-docs/"
move_file "flux-univeral-helm-deployment copy.md" "$ARCHIVE_DIR/root-docs/"
move_file "proxmox-import-vhdx.md" "$ARCHIVE_DIR/root-docs/"
echo ""

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "3. Temporary/test config files (root directory)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
move_file "docker-compose-testt.yml" "$ARCHIVE_DIR/root-configs/"
move_file "test-openebs-expansion.yaml" "$ARCHIVE_DIR/root-configs/"
move_file "test-pgadmin-values.yaml" "$ARCHIVE_DIR/root-configs/"
move_file "values.yaml" "$ARCHIVE_DIR/root-configs/"
echo ""

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "4. FluxCD production orphaned files"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
FLUX_PROD="catalog/gitops/flux/clusters/production"

# Old monolithic infrastructure kustomization (replaced by granular ones)
move_file "$FLUX_PROD/flux-system/infrastructure-kustomization.yaml" "$ARCHIVE_DIR/flux-production/"

# Orphaned infrastructure-overlay (not referenced in production)
move_dir "$FLUX_PROD/infrastructure-overlay" "$ARCHIVE_DIR/flux-production/"

# Duplicate flux-kustomization.yaml in security
move_file "$FLUX_PROD/infrastructure/security/flux-kustomization.yaml" "$ARCHIVE_DIR/flux-production/"

# Old REPLICAS doc (superseded by README)
move_file "$FLUX_PROD/REPLICAS_CONFIGURATION.md" "$ARCHIVE_DIR/flux-production/"
echo ""

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📊 Files to KEEP (not archived)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  ✓ README.md          - Main project documentation"
echo "  ✓ QUICKSTART.md      - Quick start guide"
echo "  ✓ CONTRIBUTING.md    - Contribution guidelines"
echo "  ✓ STRUCTURE.md       - Project structure documentation"
echo "  ✓ TESTING_GUIDE.md   - Testing documentation"
echo "  ✓ todo.md            - Project tasks"
echo "  ✓ univeral-helm-deployment.md - Reference documentation"
echo "  ✓ .sops.yaml         - SOPS encryption configuration"
echo "  ✓ .pre-commit-config.yaml - Git hooks configuration"
echo "  ✓ install.sh         - Core installation script"
echo "  ✓ regenerate_secrets.py - Python secrets regeneration"
echo "  ✓ Makefile           - Build automation"
echo "  ✓ ansible.cfg        - Ansible configuration"
echo "  ✓ age.agekey         - SOPS encryption key"
echo ""

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📁 Summary"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if [ "$DRY_RUN" == "--dry-run" ]; then
    echo ""
    echo "🔍 This was a DRY RUN - no files were moved"
    echo ""
    echo "To execute the cleanup, run:"
    echo "  ./scripts/cleanup-repo-root.sh --execute"
else
    echo ""
    echo "✅ Cleanup complete!"
    echo ""
    echo "Archived files are in: $ARCHIVE_DIR"
    echo ""
    echo "To restore any file:"
    echo "  cp $ARCHIVE_DIR/<subdir>/<filename> ./"
fi

