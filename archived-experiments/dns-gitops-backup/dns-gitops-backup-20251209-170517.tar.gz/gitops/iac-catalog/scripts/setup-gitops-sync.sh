#!/usr/bin/env bash
# GitOps Auto-Sync Setup Script
# Deploys the GitOps synchronization system to a server

set -euo pipefail

# Configuration
SERVER="${1:-}"
SUDO_PASSWORD="${2:-}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

# Usage
if [ -z "$SERVER" ]; then
    echo "Usage: $0 <server> [sudo_password]"
    echo ""
    echo "Example: $0 192.168.2.57 mypassword"
    echo "         $0 user@server.com"
    exit 1
fi

echo "=== GitOps Auto-Sync Setup ==="
echo "Target server: $SERVER"
echo ""

# Check age key exists
if [ ! -f "$REPO_ROOT/age.agekey" ]; then
    echo "ERROR: age.agekey not found in repository root"
    exit 1
fi

# Prepare sudo command
SUDO_CMD="sudo"
if [ -n "$SUDO_PASSWORD" ]; then
    SUDO_CMD="echo '$SUDO_PASSWORD' | sudo -S"
fi

# Create remote directories
echo "Creating directories on server..."
ssh "$SERVER" "$SUDO_CMD mkdir -p /opt/gitops && $SUDO_CMD chown \$USER:\$USER /opt/gitops"

# Copy age key
echo "Deploying age encryption key..."
scp "$REPO_ROOT/age.agekey" "$SERVER:/tmp/.age.key.tmp"
ssh "$SERVER" "mv /tmp/.age.key.tmp /opt/gitops/.age.key && chmod 600 /opt/gitops/.age.key"

# Check if SOPS is installed
echo "Checking SOPS installation..."
if ! ssh "$SERVER" "command -v sops >/dev/null 2>&1"; then
    echo "Installing SOPS..."
    ssh "$SERVER" "
        cd /tmp && \
        wget -q https://github.com/getsops/sops/releases/download/v3.8.1/sops-v3.8.1.linux.amd64 && \
        $SUDO_CMD mv sops-v3.8.1.linux.amd64 /usr/local/bin/sops && \
        $SUDO_CMD chmod +x /usr/local/bin/sops && \
        sops --version
    "
else
    echo "✓ SOPS already installed"
fi

# Copy sync script
echo "Deploying sync script..."
scp "$SCRIPT_DIR/gitops-sync.sh" "$SERVER:/opt/gitops/"
ssh "$SERVER" "chmod +x /opt/gitops/gitops-sync.sh"

# Copy systemd units
echo "Installing systemd service and timer..."
scp "$SCRIPT_DIR/gitops-sync.service" "$SERVER:/tmp/"
scp "$SCRIPT_DIR/gitops-sync.timer" "$SERVER:/tmp/"
ssh "$SERVER" "
    $SUDO_CMD mv /tmp/gitops-sync.service /etc/systemd/system/ && \
    $SUDO_CMD mv /tmp/gitops-sync.timer /etc/systemd/system/ && \
    $SUDO_CMD systemctl daemon-reload && \
    $SUDO_CMD systemctl enable gitops-sync.timer && \
    $SUDO_CMD systemctl start gitops-sync.timer
"

# Check status
echo ""
echo "Checking timer status..."
ssh "$SERVER" "systemctl status gitops-sync.timer --no-pager" || true

# Run initial sync
echo ""
echo "Running initial sync..."
ssh "$SERVER" "$SUDO_CMD /opt/gitops/gitops-sync.sh" || true

echo ""
echo "=== Setup Complete ==="
echo ""
echo "The GitOps auto-sync is now running on $SERVER"
echo ""
echo "Commands:"
echo "  Check timer:  ssh $SERVER systemctl status gitops-sync.timer"
echo "  Manual sync:  ssh $SERVER sudo /opt/gitops/gitops-sync.sh"
echo "  View logs:    ssh $SERVER tail -f /tmp/gitops-sync.log"
echo "  Repo path:    /opt/gitops/iac-catalog"
echo ""
