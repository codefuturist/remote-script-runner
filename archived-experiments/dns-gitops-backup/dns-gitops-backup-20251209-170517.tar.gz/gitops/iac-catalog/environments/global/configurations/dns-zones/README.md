# DNS Zone Files

This directory contains standard BIND zone files that are automatically synchronized to Pi-hole + Unbound via GitOps.

## Format

All `.zone` files in this directory are automatically processed and converted to Pi-hole configuration.

## Supported Record Types

- **A Records**: IPv4 addresses
- **AAAA Records**: IPv6 addresses  
- **CNAME Records**: Canonical names (automatically resolved)
- **Wildcard Records**: `*.subdomain` notation

## Example Zone File

```bind
$ORIGIN example.com.
@                     900       IN  SOA           ns1 admin 1 900 300 604800 900
@                     3600      IN  NS            ns1

; Infrastructure
server1               3600      IN  A             192.168.1.10
server2               3600      IN  A             192.168.1.20

; Services
www                   3600      IN  CNAME         server1
api                   3600      IN  CNAME         server2

; Wildcards
*.apps                3600      IN  A             192.168.1.50
```

## Adding New Entries

1. Edit the appropriate zone file (or create a new one)
2. Add your DNS records following BIND format
3. Commit and push to GitHub
4. Changes sync automatically within 3 minutes

## See Also

- `/opt/gitops/DNS-GITOPS-README.md` - Complete documentation
- `/var/log/gitops-sync.log` - Sync activity log
