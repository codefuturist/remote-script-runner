# Environments - Environment Configurations

## Purpose

This directory contains **environment-specific configurations**, defaults, and overrides that apply across all deployments in each environment.

## Structure

```text
environments/
├── production/
│   ├── defaults.yml              # Environment-wide default values
│   ├── secrets/                  # Secret references (not actual secrets!)
│   ├── overrides/                # Service-specific overrides
│   └── values/                   # Additional configuration values
├── staging/
│   ├── defaults.yml
│   ├── secrets/
│   ├── overrides/
│   └── values/
├── development/
│   ├── defaults.yml
│   ├── secrets/
│   ├── overrides/
│   └── values/
├── dr-site/                      # Disaster recovery environment
│   ├── primary/
│   └── secondary/
└── global/                       # Global configurations (all environments)
    ├── configurations/
    └── terraform/
```

## Key Concepts

### Environments vs Inventory

- **environments/** = **Configuration values** (HOW things are configured)
- **inventory/** = **Infrastructure targets** (WHERE things are deployed)

### How They Work Together

```text
Deployment references:
1. Template from catalog/
2. Environment config from environments/[env]/
3. Infrastructure target from inventory/[env]/
```

## Directory Contents

### `defaults.yml` - Environment Defaults

Default configuration values that apply to all deployments in the environment.

**Example - production/defaults.yml:**

```yaml
# Logging configuration
log_level: info
log_retention_days: 30

# Monitoring
monitoring_enabled: true
metrics_retention_days: 90
alerts_enabled: true

# Backups
backup_enabled: true
backup_retention_days: 30
backup_schedule: "0 2 * * *"  # 2 AM daily

# Security
tls_enabled: true
tls_min_version: "1.2"
security_scanning_enabled: true

# Resource limits (defaults)
default_cpu_limit: "1000m"
default_memory_limit: "1Gi"
```

### `secrets/` - Secret References

⚠️ **Important**: This does NOT contain actual secrets!

Contains **references** to secrets stored in secret managers (Vault, AWS Secrets Manager, etc.).

**Example - secrets/secret-refs.yml:**

```yaml
secrets:
  # Database passwords
  postgres_admin_password:
    type: vault
    path: secret/production/database/postgres_admin
    
  mysql_root_password:
    type: aws-secrets-manager
    name: production/mysql/root-password
    region: us-east-1
  
  # API keys
  monitoring_api_key:
    type: vault
    path: secret/production/monitoring/api-key
  
  # TLS certificates
  tls_certificate:
    type: aws-secrets-manager
    name: production/certificates/wildcard
    region: us-east-1
```

### `overrides/` - Service-Specific Overrides

Override default values for specific services.

**Example - overrides/databases.yml:**

```yaml
# Database-specific overrides
databases:
  postgresql:
    log_level: debug              # Override: more detailed logging
    backup_retention_days: 90     # Override: longer retention
    connection_pool_size: 100
    max_connections: 200
    
  mysql:
    log_level: warning
    backup_retention_days: 60
    innodb_buffer_pool_size: "2G"
```

**Example - overrides/monitoring.yml:**

```yaml
# Monitoring stack overrides
monitoring:
  prometheus:
    retention_days: 180           # Longer than default 90
    scrape_interval: "15s"
    storage_size: "100Gi"
    
  grafana:
    session_lifetime: "24h"
    plugins:
      - grafana-piechart-panel
      - grafana-worldmap-panel
```

### `values/` - Additional Configuration

Additional configuration files that don't fit in defaults or overrides.

**Example - values/network.yml:**

```yaml
network:
  vpc_cidr: "10.0.0.0/16"
  subnets:
    public:
      - "10.0.1.0/24"
      - "10.0.2.0/24"
    private:
      - "10.0.10.0/24"
      - "10.0.11.0/24"
  dns_servers:
    - "10.0.0.2"
    - "8.8.8.8"
```

## Environment Profiles

### Production

**Characteristics:**
- Highest resource allocations
- Longest retention periods
- Strictest security policies
- Full monitoring and alerting
- Automated backups
- High availability configurations

**Example defaults:**

```yaml
log_level: info
backup_enabled: true
backup_retention_days: 30
monitoring_enabled: true
alerts_enabled: true
ha_enabled: true
resource_limits:
  cpu: "2000m"
  memory: "4Gi"
```

### Staging

**Characteristics:**
- Medium resource allocations
- Shorter retention periods
- Production-like configuration
- Full monitoring (optional alerting)
- Regular backups

**Example defaults:**

```yaml
log_level: debug
backup_enabled: true
backup_retention_days: 14
monitoring_enabled: true
alerts_enabled: false
ha_enabled: false
resource_limits:
  cpu: "1000m"
  memory: "2Gi"
```

### Development

**Characteristics:**
- Minimal resource allocations
- Short retention periods
- Relaxed security (for development only!)
- Basic monitoring
- Optional backups

**Example defaults:**

```yaml
log_level: debug
backup_enabled: false
backup_retention_days: 7
monitoring_enabled: true
alerts_enabled: false
ha_enabled: false
resource_limits:
  cpu: "500m"
  memory: "1Gi"
```

## Using Environment Configurations

### 1. Configuration Precedence

Order of precedence (highest to lowest):

1. **Deployment-specific** (in `deployments/[env]/[instance]/`)
2. **Environment override** (in `environments/[env]/overrides/`)
3. **Environment default** (in `environments/[env]/defaults.yml`)
4. **Global default** (in `environments/global/`)
5. **System default** (hardcoded)

### 2. Referencing Configurations

In deployment configurations, reference environment values:

```yaml
# deployments/production/my-app/config.yml
app:
  log_level: ${env.log_level}              # From defaults.yml
  backup_enabled: ${env.backup_enabled}    # From defaults.yml
  api_key: ${env.secrets.monitoring_api_key}  # From secrets/
```

### 3. Variable Substitution

The system supports variable substitution:

```yaml
# Environment variable
backup_path: "/backups/${ENVIRONMENT}/${SERVICE_NAME}"

# Resolves to: /backups/production/my-app
```

## Common Workflows

### Adding Environment Defaults

1. Edit the defaults file:

```bash
vim environments/production/defaults.yml
```

2. Add or modify values:

```yaml
# Add new default
new_feature_enabled: true
new_feature_timeout: 30
```

3. Commit changes:

```bash
git add environments/production/defaults.yml
git commit -m "feat: add new feature configuration defaults"
git push
```

4. New deployments automatically use these defaults
5. Existing deployments may need updating

### Adding Secret References

1. Store actual secret in secret manager (Vault, AWS SM, etc.)

2. Add reference:

```bash
vim environments/production/secrets/secret-refs.yml
```

```yaml
secrets:
  new_api_key:
    type: vault
    path: secret/production/new-service/api-key
```

3. Commit and push (only the reference, not the actual secret!)

### Creating Service Overrides

1. Create override file:

```bash
vim environments/production/overrides/new-service.yml
```

```yaml
new_service:
  log_level: trace              # Override for this service
  connection_timeout: 60
  retry_attempts: 5
```

2. Commit and push

3. Service deployments will use these overrides

## Disaster Recovery (dr-site/)

The `dr-site/` directory contains DR-specific configurations:

```text
dr-site/
├── primary/                      # Primary DR site config
│   ├── defaults.yml
│   └── values/
└── secondary/                    # Secondary DR site config
    ├── defaults.yml
    └── values/
```

**Use case:** When failing over to disaster recovery site with different configurations.

## Global Configurations (global/)

The `global/` directory contains configurations that apply across all environments:

```text
global/
├── configurations/               # Cross-environment config
│   ├── common.yml
│   └── policies.yml
└── terraform/                    # Global Terraform config
    ├── backend.tf
    └── providers.tf
```

**Use case:** Configuration that should be consistent across all environments.

## Best Practices

### 1. Never Commit Secrets

❌ **Never:**

```yaml
database_password: "my-secret-password-123"
api_key: "sk-1234567890abcdef"
```

✅ **Always use references:**

```yaml
database_password:
  type: vault
  path: secret/production/db/password
```

### 2. Document All Configurations

Add comments explaining what each configuration does:

```yaml
# Connection timeout in seconds
# Default: 30, Range: 10-300
# Increase for slow networks, decrease for fast fail
connection_timeout: 60
```

### 3. Use Meaningful Names

❌ Bad:

```yaml
val1: 100
param2: true
```

✅ Good:

```yaml
max_connections: 100
monitoring_enabled: true
```

### 4. Group Related Configurations

```yaml
# Database configuration
database:
  host: db.example.com
  port: 5432
  pool_size: 20
  timeout: 30

# Cache configuration
cache:
  host: redis.example.com
  port: 6379
  ttl: 3600
```

### 5. Test in Development First

1. Add configuration to `environments/development/`
2. Test with development deployments
3. Promote to staging
4. Test in staging
5. Promote to production

### 6. Version Control Everything

All environment configurations should be in Git:

- Defaults
- Overrides
- Secret references (not actual secrets!)
- Network configurations
- Resource limits

## Troubleshooting

### Configuration Not Applied

1. **Check precedence** - Is it being overridden?

```bash
# Check all configuration sources
cat environments/production/defaults.yml | grep setting_name
cat environments/production/overrides/service.yml | grep setting_name
cat deployments/production/instance/config.yml | grep setting_name
```

2. **Check syntax** - YAML is sensitive to indentation

```bash
# Validate YAML syntax
yamllint environments/production/defaults.yml
```

3. **Check variable substitution** - Are variables being resolved?

```bash
# Check deployment logs for variable resolution
cat .deployments/state/production/instance.log
```

### Secret Not Found

1. **Verify secret exists** in secret manager

```bash
# Vault example
vault kv get secret/production/db/password

# AWS Secrets Manager example
aws secretsmanager get-secret-value --secret-id production/db/password
```

2. **Check reference is correct**

```yaml
# Ensure path/name matches exactly
database_password:
  type: vault
  path: secret/production/db/password  # Must match vault path
```

3. **Check permissions** - Does deployment have access to secret manager?

### Which Value Is Being Used?

Use the configuration resolution tool:

```bash
./tools/config-resolver.sh \
  --environment production \
  --service my-app \
  --key log_level
```

Output:

```text
Configuration Key: log_level
Resolved Value: debug
Source: environments/production/overrides/my-app.yml (line 12)

Resolution Chain:
1. environments/production/overrides/my-app.yml: debug  ← USED
2. environments/production/defaults.yml: info
3. environments/global/configurations/common.yml: info
```

## Related Documentation

- [STRUCTURE.md](../STRUCTURE.md) - Overall structure guide
- [inventory/README.md](../inventory/README.md) - Infrastructure definitions
- [deployments/README.md](../deployments/README.md) - Deployment instances
- [SECURITY.md](../SECURITY.md) - Security best practices

## Security Notes

⚠️ **Critical Security Reminders:**

1. **Never commit actual secrets** to Git
2. Use secret managers (Vault, AWS Secrets Manager, etc.)
3. Rotate secrets regularly
4. Use least-privilege access for secret retrieval
5. Audit secret access
6. Encrypt secrets at rest in secret managers
7. Use separate secrets per environment

---

**Questions?** See [docs/guides/](../docs/guides/) for detailed guides.

mkdir -p /mnt/pool-0/apps/nextcloud/{config,data,postgres,redis}
chown -R apps:apps /mnt/pool-0/apps/nextcloud
chmod -R 770 /mnt/pool-0/apps/nextcloud
