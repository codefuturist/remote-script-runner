# Workspace Template

This repository serves as a workspace template for developing and deploying applications using Docker and Docker Compose. It provides a structured approach to manage configurations, deployments, and operational scripts, ensuring best practices and industry standards are followed.

## Project Structure

The project is organized into several key directories and files:

- **.env.example**: A template for environment variables, providing a reference for required configurations.
- **.meta.yml**: Application metadata for documentation generation and service discovery.
- **.meta.yml.template**: Template version of metadata file with placeholders for customization.
- **.gitignore**: Specifies files and directories that should be ignored by Git.
- **Makefile**: Contains directives for automating common tasks using the make build automation tool.
- **README.md**: Documentation for the project, including setup instructions and usage guidelines.
- **docker-compose.yml**: The main orchestration file for Docker Compose, defining services, networks, and volumes.
- **compose/**: Contains configurations for core services, networks, volumes, and environment-specific settings.
- **deploy/**: Contains deployment configurations for Docker Swarm and Kubernetes.
- **config/**: Configuration files for various components, including application settings and monitoring configurations.
- **scripts/**: Operational scripts for lifecycle management, backup, security, monitoring, and utilities.
- **docs/**: Documentation files covering architecture, deployment, operations, troubleshooting, migration, and security best practices.
- **tests/**: Test configurations for Docker Compose tests, integration tests, and smoke tests.
- **templates/**: Template files for environment variables and secrets.
- **data/**: Intended for runtime data storage.
- **backups/**: Used for backup storage, containing scheduled, manual, and archived backups.
- **secrets/**: Directory for storing secret files securely.

## Getting Started

To get started with this workspace template, follow these steps:

1. **Clone the Repository**: Clone this repository to your local machine.

   ```bash
   git clone <repository-url>
   cd workspace-template
   ```

2. **Configure Environment Variables**: Copy the `.env.example` file to `.env` and fill in the required values.

   ```bash
   cp .env.example .env
   ```

3. **Configure Application Metadata**: Customize the `.meta.yml` file with your application details for documentation generation.

   ```bash
   # Edit the metadata file with your application information
   vim .meta.yml
   ```

4. **Build and Start Services**: Use Docker Compose to build and start the services defined in `docker-compose.yml`.

   ```bash
   docker-compose up -d
   ```

5. **Generate Documentation**: Use the documentation system to generate comprehensive documentation.

   ```bash
   # Generate application documentation
   make generate-docs

   # Generate individual README files
   make generate-individual-docs
   ```

6. **Run Scripts**: Utilize the scripts in the `scripts/` directory for various operational tasks, such as deploying, backing up, or managing secrets.

7. **Access Documentation**: Refer to the documentation in the `docs/` directory for detailed information on architecture, deployment, and operations.

## Application Metadata

The `.meta.yml` file contains comprehensive metadata about your application that powers:

- **Documentation Generation**: Automatic README and index generation
- **Service Discovery**: Integration with monitoring and management tools
- **Categorization**: Organized application browsing and searching
- **Dependency Tracking**: Understanding service relationships

### Key Metadata Sections

- **App Information**: Name, version, description, repository links
- **Categorization**: Primary/secondary categories and searchable tags
- **Technical Details**: Ports, resource requirements, setup complexity
- **Dependencies**: Required, optional, and complementary services
- **Security**: Authentication, access, and security considerations

For detailed metadata schema information, see the [Documentation System Guide](../../docs/future-ideas/documentation-system-enhancements.md).

## Contributing

Contributions are welcome! Please follow the standard Git Flow process for feature development and ensure that all changes are well-documented.

## License

This project is licensed under the MIT License. See the LICENSE file for more details.
