# README for Docker Swarm Deployment

This document provides instructions for deploying the workspace template application using Docker Swarm. It outlines the necessary steps to set up and manage the application in a Swarm environment.

## Prerequisites

Before proceeding with the deployment, ensure that you have the following:

- Docker installed on your machine.
- Docker Swarm initialized. You can initialize Swarm with the command:
  ```
  docker swarm init
  ```

## Deployment Steps

1. **Clone the Repository**

   Clone the workspace template repository to your local machine:

   ```
   git clone <repository-url>
   cd workspace-template
   ```

2. **Configure Environment Variables**

   Copy the example environment file and modify it according to your needs:

   ```
   cp .env.example .env
   ```

   Edit the `.env` file to set the required environment variables.

3. **Deploy the Stack**

   Use the following command to deploy the stack defined in `stack.yml`:

   ```
   docker stack deploy -c deploy/swarm/stack.yml <stack-name>
   ```

   Replace `<stack-name>` with your desired name for the stack.

4. **Verify the Deployment**

   Check the status of the services in the stack:

   ```
   docker stack services <stack-name>
   ```

   This command will list all services and their current state.

5. **Access the Application**

   Depending on your configuration, access the application via the specified ports or domain names. Refer to the `docker-compose.yml` and `nginx/default.conf` for routing details.

## Updating the Stack

To update the stack with changes made to the configuration or application code, use the following command:

```
docker stack deploy -c deploy/swarm/stack.yml <stack-name>
```

## Removing the Stack

To remove the deployed stack, use the command:

```
docker stack rm <stack-name>
```

## Additional Information

For more details on the application architecture, refer to the [ARCHITECTURE.md](../docs/ARCHITECTURE.md) file.

For troubleshooting and operational guidelines, consult the [TROUBLESHOOTING.md](../docs/TROUBLESHOOTING.md) and [OPERATIONS.md](../docs/OPERATIONS.md) files.

## Conclusion

This README provides a concise guide for deploying the workspace template application using Docker Swarm. Follow the steps outlined above to ensure a successful deployment.
