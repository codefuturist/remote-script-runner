# Kubernetes Deployment Documentation

This README provides an overview of the Kubernetes deployment configurations for the workspace template project. It outlines the structure of the Kubernetes deployment files and provides guidance on how to deploy the application in a Kubernetes environment.

## Directory Structure

The `kubernetes` directory contains the following files and subdirectories:

- **namespace.yml**: Defines the Kubernetes namespace for the application.
- **configmap.yml**: Contains configuration data that can be consumed by the application.
- **secrets.yml**: Defines sensitive information that should be kept secure, such as passwords and API keys.
- **deployments/**: Contains deployment configurations for the application components.
  - **app.yml**: Deployment configuration for the main application.
- **services/**: Contains service configurations for the application components.
  - **app.yml**: Service configuration for the main application.

## Deployment Steps

1. **Set Up Kubernetes Cluster**: Ensure you have a running Kubernetes cluster. You can use a local setup like Minikube or a cloud provider like GKE, EKS, or AKS.

2. **Create Namespace**: Apply the namespace configuration to create a dedicated namespace for the application.

   ```bash
   kubectl apply -f namespace.yml
   ```

3. **Deploy ConfigMap**: Apply the ConfigMap configuration to set up application configuration data.

   ```bash
   kubectl apply -f configmap.yml
   ```

4. **Deploy Secrets**: Apply the Secrets configuration to set up sensitive information.

   ```bash
   kubectl apply -f secrets.yml
   ```

5. **Deploy Application**: Apply the deployment configuration for the application.

   ```bash
   kubectl apply -f deployments/app.yml
   ```

6. **Expose Application**: Apply the service configuration to expose the application.
   ```bash
   kubectl apply -f services/app.yml
   ```

## Additional Information

- **Monitoring**: Ensure that monitoring configurations are set up to track the health and performance of the application.
- **Scaling**: You can scale the application by modifying the replicas in the deployment configuration and reapplying it.
- **Updates**: To update the application, modify the deployment configuration and reapply it.

## Troubleshooting

If you encounter issues during deployment, check the following:

- Use `kubectl get pods` to check the status of the application pods.
- Use `kubectl logs <pod-name>` to view logs for a specific pod.
- Ensure that all required configurations are correctly applied.

For more detailed information, refer to the documentation files in the `docs` directory, such as `DEPLOYMENT.md` and `TROUBLESHOOTING.md`.
