#!/bin/bash

# Update script for the workspace template application

# Load environment variables
if [ -f .env ]; then
    export $(cat .env | xargs)
fi

# Function to update services
update_services() {
    echo "Updating services..."
    docker-compose pull
    docker-compose up -d
}

# Function to run database migrations
run_migrations() {
    echo "Running database migrations..."
    # Assuming a migration service is defined in docker-compose.yml
    docker-compose run --rm app migrate
}

# Function to clean up unused images and containers
cleanup() {
    echo "Cleaning up unused images and containers..."
    docker system prune -f
}

# Execute update steps
update_services
run_migrations
cleanup

echo "Update completed successfully."