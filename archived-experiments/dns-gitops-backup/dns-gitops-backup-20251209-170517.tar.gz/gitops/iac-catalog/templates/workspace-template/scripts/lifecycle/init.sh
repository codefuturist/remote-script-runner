#!/bin/bash

# Initialize the application environment
echo "Initializing application environment..."

# Load environment variables
if [ -f .env ]; then
    export $(cat .env | xargs)
else
    echo ".env file not found. Please create one from .env.example."
    exit 1
fi

# Create necessary directories
mkdir -p data/assets
mkdir -p data/logs
mkdir -p data/sites
mkdir -p backups/scheduled
mkdir -p backups/manual
mkdir -p backups/archives

# Run database initialization script if it exists
if [ -f init.sql ]; then
    echo "Running database initialization script..."
    # Assuming a PostgreSQL database is being used
    psql -U "$DB_USER" -d "$DB_NAME" -f init.sql
else
    echo "No initialization script found."
fi

echo "Application environment initialized successfully."