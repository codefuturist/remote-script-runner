#!/bin/bash

# Health check script for the application
# This script checks the health of the application services and reports their status.

# Define the services to check
SERVICES=("app" "database" "cache")

# Function to check the health of a service
check_service_health() {
    local service=$1
    local status

    # Check if the service is running
    status=$(docker inspect -f '{{.State.Health.Status}}' "${service}" 2>/dev/null)

    if [ "$status" == "healthy" ]; then
        echo "Service ${service} is healthy."
    elif [ "$status" == "unhealthy" ]; then
        echo "Service ${service} is unhealthy!"
    else
        echo "Service ${service} is not running."
    fi
}

# Loop through each service and check its health
for service in "${SERVICES[@]}"; do
    check_service_health "$service"
done

# Exit with success status
exit 0