#!/bin/bash

# Debugging script for the workspace template project

# Function to print usage information
usage() {
    echo "Usage: $0 [options]"
    echo "Options:"
    echo "  -h, --help        Show this help message"
    echo "  -v, --verbose     Enable verbose output"
    echo "  -c, --check       Check the status of services"
    echo "  -l, --logs        Display logs for services"
}

# Function to check the status of services
check_services() {
    echo "Checking the status of services..."
    docker-compose ps
}

# Function to display logs for services
show_logs() {
    echo "Displaying logs for services..."
    docker-compose logs
}

# Parse command line arguments
VERBOSE=0
CHECK=0
LOGS=0

while [[ "$#" -gt 0 ]]; do
    case $1 in
        -h|--help) usage; exit 0 ;;
        -v|--verbose) VERBOSE=1 ;;
        -c|--check) CHECK=1 ;;
        -l|--logs) LOGS=1 ;;
        *) echo "Unknown option: $1"; usage; exit 1 ;;
    esac
    shift
done

# Enable verbose output if requested
if [[ $VERBOSE -eq 1 ]]; then
    set -x
fi

# Execute requested actions
if [[ $CHECK -eq 1 ]]; then
    check_services
fi

if [[ $LOGS -eq 1 ]]; then
    show_logs
fi

# Disable verbose output if it was enabled
if [[ $VERBOSE -eq 1 ]]; then
    set +x
fi