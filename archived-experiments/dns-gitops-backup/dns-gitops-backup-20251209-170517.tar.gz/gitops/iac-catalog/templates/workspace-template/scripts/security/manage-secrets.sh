#!/bin/bash

# This script manages secrets for the workspace template project.

set -e

# Define the secrets directory
SECRETS_DIR="./secrets"

# Function to create a new secret
create_secret() {
    local secret_name="$1"
    local secret_value="$2"

    echo "$secret_value" > "$SECRETS_DIR/$secret_name.txt"
    echo "Secret '$secret_name' created."
}

# Function to rotate an existing secret
rotate_secret() {
    local secret_name="$1"
    local new_secret_value="$2"

    if [ -f "$SECRETS_DIR/$secret_name.txt" ]; then
        echo "$new_secret_value" > "$SECRETS_DIR/$secret_name.txt"
        echo "Secret '$secret_name' rotated."
    else
        echo "Secret '$secret_name' does not exist."
    fi
}

# Function to delete a secret
delete_secret() {
    local secret_name="$1"

    if [ -f "$SECRETS_DIR/$secret_name.txt" ]; then
        rm "$SECRETS_DIR/$secret_name.txt"
        echo "Secret '$secret_name' deleted."
    else
        echo "Secret '$secret_name' does not exist."
    fi
}

# Function to list all secrets
list_secrets() {
    echo "Listing all secrets:"
    ls "$SECRETS_DIR"
}

# Main script logic
case "$1" in
    create)
        create_secret "$2" "$3"
        ;;
    rotate)
        rotate_secret "$2" "$3"
        ;;
    delete)
        delete_secret "$2"
        ;;
    list)
        list_secrets
        ;;
    *)
        echo "Usage: $0 {create|rotate|delete|list} [args]"
        exit 1
        ;;
esac