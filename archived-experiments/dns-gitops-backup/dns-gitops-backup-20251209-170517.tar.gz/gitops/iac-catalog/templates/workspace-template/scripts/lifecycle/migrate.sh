#!/bin/bash

# This script is responsible for migrating the application database.
# It should be executed in the context of the application's Docker container.

set -e

# Load environment variables
if [ -f .env ]; then
    export $(cat .env | xargs)
fi

# Define the database migration command
MIGRATE_CMD="docker-compose exec app_name migrate"

# Run the migration command
echo "Starting database migration..."
$MIGRATE_CMD

echo "Database migration completed successfully."