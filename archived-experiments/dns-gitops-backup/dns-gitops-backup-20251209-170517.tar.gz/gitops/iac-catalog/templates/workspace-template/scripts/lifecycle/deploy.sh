#!/bin/bash

# This script deploys the application using Docker Compose.

set -e

# Load environment variables from the .env file if it exists
if [ -f .env ]; then
    export $(grep -v '^#' .env | xargs)
fi

# Define the environment to deploy
ENVIRONMENT=${1:-development}

# Check if the specified environment file exists
if [ ! -f "compose/environments/${ENVIRONMENT}.yml" ]; then
    echo "Environment file compose/environments/${ENVIRONMENT}.yml does not exist."
    exit 1
fi

# Deploy the application using Docker Compose
echo "Deploying application in ${ENVIRONMENT} environment..."
docker-compose -f docker-compose.yml -f compose/environments/${ENVIRONMENT}.yml up -d

echo "Deployment completed successfully."