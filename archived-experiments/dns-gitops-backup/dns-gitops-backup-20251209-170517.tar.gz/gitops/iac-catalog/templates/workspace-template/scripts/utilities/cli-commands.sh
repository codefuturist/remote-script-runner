#!/bin/bash

# CLI commands for workspace-template project

function app() {
    docker-compose -f docker-compose.yml exec app "$@"
}

function db() {
    docker-compose -f docker-compose.yml exec db "$@"
}

function nginx() {
    docker-compose -f docker-compose.yml exec nginx "$@"
}

function backup() {
    docker-compose -f docker-compose.yml exec backup "$@"
}

function monitoring() {
    docker-compose -f docker-compose.yml exec monitoring "$@"
}

function logs() {
    docker-compose -f docker-compose.yml logs "$@"
}

function up() {
    docker-compose -f docker-compose.yml up -d
}

function down() {
    docker-compose -f docker-compose.yml down
}

function restart() {
    docker-compose -f docker-compose.yml restart
}

function status() {
    docker-compose -f docker-compose.yml ps
}

function shell() {
    docker-compose -f docker-compose.yml exec app /bin/bash
}