apiVersion: v1
kind: Secret
metadata:
  name: home-assistant-postgres-creds
  namespace: ix-home-assistant
  uid: 11633531-6321-482f-b2cf-53d505960965
  resourceVersion: '20536433'
  creationTimestamp: '2024-03-19T09:52:32Z'
  labels:
    app: home-assistant-2.0.20
    app.kubernetes.io/instance: home-assistant
    app.kubernetes.io/managed-by: Helm
    app.kubernetes.io/name: home-assistant
    app.kubernetes.io/version: 2024.4.4
    helm-revision: '11'
    helm.sh/chart: home-assistant-2.0.20
    release: home-assistant
  annotations:
    meta.helm.sh/release-name: home-assistant
    meta.helm.sh/release-namespace: ix-home-assistant
  managedFields:
    - manager: helm
      operation: Update
      apiVersion: v1
      time: '2024-04-25T08:35:43Z'
      fieldsType: FieldsV1
      fieldsV1:
        f:data:
          .: {}
          f:POSTGRES_DB: {}
          f:POSTGRES_HOST: {}
          f:POSTGRES_PASSWORD: {}
          f:POSTGRES_URL: {}
          f:POSTGRES_USER: {}
        f:metadata:
          f:annotations:
            .: {}
            f:meta.helm.sh/release-name: {}
            f:meta.helm.sh/release-namespace: {}
          f:labels:
            .: {}
            f:app: {}
            f:app.kubernetes.io/instance: {}
            f:app.kubernetes.io/managed-by: {}
            f:app.kubernetes.io/name: {}
            f:app.kubernetes.io/version: {}
            f:helm-revision: {}
            f:helm.sh/chart: {}
            f:release: {}
        f:type: {}
  selfLink: /api/v1/namespaces/ix-home-assistant/secrets/home-assistant-postgres-creds
data:
  POSTGRES_DB: ""
  POSTGRES_HOST: ""
  POSTGRES_PASSWORD: ""
  POSTGRES_URL: ""
  POSTGRES_USER: ""
type: Opaque
