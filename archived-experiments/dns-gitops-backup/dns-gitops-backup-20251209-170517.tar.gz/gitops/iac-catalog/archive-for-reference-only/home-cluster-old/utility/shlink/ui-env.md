SHLINK_SERVER_URL: The fully qualified URL for the Shlink server.

SHLINK_SERVER_API_KEY: The API key.

SHLINK_SERVER_NAME: The name to be displayed. Defaults to Shlink if not provided.

https://hub.docker.com/r/shlinkio/shlink-web-client