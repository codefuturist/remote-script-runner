# Secrets Generation + Enryption

### Encrypt SOPS Secret in Place
```zsh
sops --encrypt --age $(cat $SOPS_AGE_KEY_FILE_PUB) --encrypted-regex '^(data|stringData)$' --in-place ./secret.yaml
```

### Decrypt SOPS Secret in Place
```zsh
sops --decrypt --age $(cat $SOPS_AGE_KEY_FILE_PUB) --encrypted-regex '^(data|stringData)$' --in-place ./secret.yaml
```
### Decrypt SOPS Secret
```zsh
sops --encrypt --in-place basic-auth.yaml
```
### Create Sealed Secret
```zsh
kubeseal --format=yaml --cert=pub-sealed-secrets.pem \
< basic-auth.yaml > basic-auth-sealed.yaml
```

### Create Secret
```zsh
kubectl -n default create secret generic basic-auth \
--from-literal=user=admin \
--from-literal=password=change-me \
--dry-run=client \
-o yaml > X.yaml
```
### Encrypt Secret into new file
```zsh

sops --encrypt --age $(cat $SOPS_AGE_KEY_FILE_PUB) --encrypted-regex '^(data|stringData)$' ./plain/X.yaml > ./encrypted/X.yaml
```

### Base64 Encode
```zsh

echo -n "X" | base64
```

### Batch Decrypt
```zsh
cd ./encrypted

for file in *; do
    if [[ -f $file ]]; then
        echo "Decrypt File $file"
        echo "------------------------------------"
        sops --decrypt --age $(cat $SOPS_AGE_KEY_FILE_PUB) --encrypted-regex '^(data|stringData)$'  "./$file" > "../plain/$file"
    fi
done
```

### Batch Encrypt
```zsh

cd ./plain

for file in *; do
    if [[ -f $file ]]; then
        echo "Encrypt File $file"
        echo "------------------------------------"
        sops --encrypt --age $(cat $SOPS_AGE_KEY_FILE_PUB) --encrypted-regex '^(data|stringData)$'  "./$file" > "../encrypted/$file"
    fi
done
```

## Flux

### Sync Kustomization
```zsh
flux reconcile kustomization flux-system --with-source
```

### Get Kustomization
```zsh
flux get kustomizations --watch
```