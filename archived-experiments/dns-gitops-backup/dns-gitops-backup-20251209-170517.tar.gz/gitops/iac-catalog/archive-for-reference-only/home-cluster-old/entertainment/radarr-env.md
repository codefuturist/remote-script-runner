Parameters
Containers are configured using parameters passed at runtime (such as those above). These parameters are separated by a colon and indicate <external>:<internal> respectively. For example, -p 8080:80 would expose port 80 from inside the container to be accessible from the host's IP on port 8080 outside the container.

Parameter	Function
-p 7878	The port for the Radarr Web UI
-e PUID=1000	for UserID - see below for explanation
-e PGID=1000	for GroupID - see below for explanation
-e TZ=Etc/UTC	specify a timezone to use, see this list.
-v /config	Database and Radarr configs
-v /movies	Location of Movie library on disk (See note in Application setup)
-v /downloads	Location of download managers output directory (See note in Application setup)

https://hub.docker.com/r/linuxserver/radarr