Parameters
Containers are configured using parameters passed at runtime (such as those above). These parameters are separated by a colon and indicate <external>:<internal> respectively. For example, -p 8080:80 would expose port 80 from inside the container to be accessible from the host's IP on port 8080 outside the container.

Parameter	Function
-p 5055	Port for Overseerr's web interface.
-e PUID=1000	for UserID - see below for explanation
-e PGID=1000	for GroupID - see below for explanation
-e TZ=Etc/UTC	specify a timezone to use, see this list.
-v /config	Persistent config files

https://hub.docker.com/r/linuxserver/tautulli