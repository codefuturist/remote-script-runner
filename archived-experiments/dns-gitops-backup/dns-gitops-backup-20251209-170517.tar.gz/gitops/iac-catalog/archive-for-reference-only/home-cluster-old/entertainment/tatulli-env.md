services:
tautulli:
image: lscr.io/linuxserver/tautulli:latest
container_name: tautulli
environment:
- PUID=1000
- PGID=1000
- TZ=Etc/UTC
volumes:
- /path/to/tautulli/config:/config
ports:
- 8181:8181
restart: unless-stopped

https://hub.docker.com/r/linuxserver/tautulli