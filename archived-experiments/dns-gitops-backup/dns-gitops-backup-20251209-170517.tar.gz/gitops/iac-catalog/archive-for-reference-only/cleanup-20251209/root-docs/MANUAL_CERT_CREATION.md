# Manual Wildcard Certificate Creation

This guide shows how to manually create a wildcard certificate on `colin@192.168.2.57` and import it to Kubernetes.

## Quick Start

### On 192.168.2.57 Server

```bash
# Copy the script to the server
scp create-wildcard-cert.sh colin@192.168.2.57:/tmp/

# SSH to the server
ssh colin@192.168.2.57

# Run the script with sudo
sudo bash /tmp/create-wildcard-cert.sh
```

The script will:
1. Install certbot if not present
2. Request Cloudflare API token if credentials don't exist
3. Backup existing certificate
4. Create wildcard certificate for `*.pandia.io`
5. Save to `/etc/letsencrypt/live/pandia.io/`

### Import to Kubernetes

After creating the certificate on the server:

```bash
# On your local machine
chmod +x import-manual-cert.sh
./import-manual-cert.sh
```

This will:
1. Copy certificate from server
2. Create Kubernetes secret `pandia.io-tls` in `cert-manager` namespace
3. Add reflector annotations for automatic distribution
4. Clean up local files

## Manual Steps (If Scripts Don't Work)

### Step 1: Create Certificate on Server

```bash
ssh colin@192.168.2.57

# Install certbot
sudo apt update
sudo apt install -y certbot python3-certbot-dns-cloudflare

# Create Cloudflare credentials
sudo mkdir -p /root/.secrets
sudo nano /root/.secrets/cloudflare.ini
```

Add this content (replace with your token):
```ini
dns_cloudflare_api_token = your_cloudflare_api_token_here
```

Secure the file:
```bash
sudo chmod 600 /root/.secrets/cloudflare.ini
```

Request the certificate:
```bash
sudo certbot certonly \
  --dns-cloudflare \
  --dns-cloudflare-credentials /root/.secrets/cloudflare.ini \
  --dns-cloudflare-propagation-seconds 60 \
  -d pandia.io \
  -d "*.pandia.io" \
  --non-interactive \
  --agree-tos \
  --email cloudflare.mck6r@allcloud.dev \
  --preferred-challenges dns-01
```

### Step 2: Verify Certificate

```bash
# Check certificate files
sudo ls -lh /etc/letsencrypt/live/pandia.io/

# View certificate details
sudo openssl x509 -in /etc/letsencrypt/live/pandia.io/fullchain.pem -noout -text | grep -A3 "Subject:"
sudo openssl x509 -in /etc/letsencrypt/live/pandia.io/fullchain.pem -noout -text | grep -A10 "Subject Alternative Name"
```

### Step 3: Copy Certificate to Local Machine

```bash
# On your local machine
scp colin@192.168.2.57:/etc/letsencrypt/live/pandia.io/fullchain.pem .
scp colin@192.168.2.57:/etc/letsencrypt/live/pandia.io/privkey.pem .
```

### Step 4: Create Kubernetes Secret

```bash
# Create the secret
kubectl create secret tls pandia.io-tls \
  --cert=fullchain.pem \
  --key=privkey.pem \
  -n cert-manager \
  --dry-run=client -o yaml | kubectl apply -f -

# Add reflector annotations for auto-distribution
kubectl annotate secret pandia.io-tls \
  -n cert-manager \
  reflector.v1.k8s.emberstack.com/reflection-allowed="true" \
  reflector.v1.k8s.emberstack.com/reflection-auto-enabled="true" \
  reflector.v1.k8s.emberstack.com/reflection-auto-namespaces="cert-manager,ci-cd,database,development,experimental,flux-system,ingress,logging,monitoring,home-assistant,compass-web,mailrise,mealie,redisinsight,web" \
  --overwrite
```

### Step 5: Verify in Kubernetes

```bash
# Check secret exists
kubectl get secret pandia.io-tls -n cert-manager

# View certificate details
kubectl get secret pandia.io-tls -n cert-manager -o jsonpath='{.data.tls\.crt}' | base64 -d | openssl x509 -noout -text | grep -A3 "Subject:"

# Check if reflected to other namespaces
kubectl get secret pandia.io-tls --all-namespaces
```

## Certificate Renewal

The certificate on the server will auto-renew. To import renewed certificates:

```bash
# Test renewal
ssh colin@192.168.2.57 "sudo certbot renew --dry-run"

# After renewal, re-run the import script
./import-manual-cert.sh
```

## Troubleshooting

### Cloudflare API Token

Ensure your Cloudflare API token has these permissions:
- Zone - DNS - Edit
- Zone - Zone - Read

Create token at: https://dash.cloudflare.com/profile/api-tokens

### Certificate Not Created

Check logs:
```bash
sudo tail -50 /var/log/letsencrypt/letsencrypt.log
```

### DNS Propagation Issues

Increase propagation time:
```bash
sudo certbot certonly \
  --dns-cloudflare \
  --dns-cloudflare-credentials /root/.secrets/cloudflare.ini \
  --dns-cloudflare-propagation-seconds 120 \
  -d pandia.io \
  -d "*.pandia.io" \
  --non-interactive \
  --agree-tos \
  --email cloudflare.mck6r@allcloud.dev
```

### Rate Limiting

If you hit Let's Encrypt rate limits, use staging:
```bash
sudo certbot certonly \
  --dns-cloudflare \
  --dns-cloudflare-credentials /root/.secrets/cloudflare.ini \
  --dns-cloudflare-propagation-seconds 60 \
  -d pandia.io \
  -d "*.pandia.io" \
  --server https://acme-staging-v02.api.letsencrypt.org/directory \
  --non-interactive \
  --agree-tos \
  --email cloudflare.mck6r@allcloud.dev
```

## Alternative: Using Existing Kubernetes Certificate

If you prefer to wait for the Kubernetes cert-manager fix instead:

1. Follow the instructions in `RUN_THIS_NOW.md`
2. Wait 10-20 minutes for automatic certificate issuance
3. No manual intervention needed

## Files Created

- `create-wildcard-cert.sh` - Automated certificate creation on server
- `import-manual-cert.sh` - Automated import to Kubernetes
- `MANUAL_CERT_CREATION.md` - This guide
