apiVersion: v1
kind: Secret
metadata:
  name: mealie
  namespace: experimental
data:
  admin-user: YWRtaW4=
  admin-password: RnJvc3RtYWdlMQ==
---
apiVersion: image.toolkit.fluxcd.io/v1beta2
kind: ImagePolicy
metadata:
  name: mealie
  namespace: flux-system
spec:
  imageRepositoryRef:
    name: mealie
  policy:
    semver:
      range: v2.x.x
---
apiVersion: image.toolkit.fluxcd.io/v1beta2
kind: ImageRepository
metadata:
  name: mealie
  namespace: flux-system
spec:
  image: ghcr.io/mealie-recipes/mealie
  interval: 100m
---
apiVersion: helm.toolkit.fluxcd.io/v2
kind: HelmRelease
metadata:
  name: mealie
  namespace: experimental
spec:
  suspend: false
  maxHistory: 3
  interval: 1m
  timeout: 15m
  chart:
    spec:
      chart: application
      version: '6.0.0'
      sourceRef:
        kind: HelmRepository
        name: stakaterr
      interval: 5m
  releaseName: mealie
  install:
    remediation:
      retries: 3
    disableWait: true
  upgrade:
    remediation:
      retries: 3
    disableWait: true
  test:
    enable: false
  values:
    applicationName: "mealie"
    deployment:
      enabled: true
      strategy:
        type: RollingUpdate
        rollingUpdate:
          maxSurge: 1
          maxUnavailable: 1
      reloadOnChange: true
      nodeSelector:
      initContainers:
        volume-permissions:
          image: busybox
          imagePullPolicy: IfNotPresent
          command: ["sh", "-c"]
          args:
            - chown -R 1000:1000 /mnt/* && ls -lRa /mnt/*
          securityContext:
            runAsUser: 0
            runAsGroup: 0
            runAsNonRoot: false
            readOnlyRootFilesystem: false
          volumeMounts:
            - name: mealie-data
              mountPath: /mnt/mealie-data
      replicas: 1
      imagePullSecrets: ""
      envFrom:
      env:
        PUID:
          value: "1000"
        PGID:
          value: "1000"
        TZ:
          value: "Europe/Zurich"
        ALLOW_SIGNUP:
          value: 'true'
        UMASK:
          value: "002"
        UMASK_SET:
          value: "002"
        NVIDIA_VISIBLE_DEVICES:
          value: "void"
        S6_READ_ONLY_ROOT:
          value: "1"
        MAX_WORKERS:
          value: '1'
        WEB_CONCURRENCY:
          value: '1'
          # Custom
        BASE_URL:
          value: "https://mealie.pandia.io"
        SECURITY_MAX_LOGIN_ATTEMPTS:
          value: '5'
        SECURITY_USER_LOCKOUT_TIME:
          value: '24'
        LDAP_AUTH_ENABLED:
          value: 'false'
        LDAP_SERVER_URL:
          value: "ldap://192.168.2.80"
        LDAP_TLS_INSECURE:
          value: 'true'
        LDAP_BASE_DN:
          value: 'cn=users,cn=accounts,dc=pandia,dc=io'
        LDAP_QUERY_BIND:
          value: "uid=admin,cn=users,cn=accounts,dc=pandia,dc=io"
        LDAP_QUERY_PASSWORD:
          value: '12345678'
        LDAP_USER_FILTER:
          value: ">- (&(|(objectclass=inetOrgPerson))(|(memberof=cn=appmealie,cn=groups,cn=accounts,dc=pandia,dc=io)))"
        LDAP_ADMIN_FILTER:
          value: ">- (&(|(objectclass=inetOrgPerson))(|(memberof=cn=appadmin,cn=groups,cn=accounts,dc=pandia,dc=io)))"
        LDAP_ID_ATTRIBUTE:
          value: "uid"
        LDAP_NAME_ATTRIBUTE:
          value: "givenName"
        LDAP_MAIL_ATTRIBUTE:
          value: "mail"
        OIDC_AUTH_ENABLED:
          value: "true"
        OIDC_SIGNUP_ENABLED:
          value: "true"
        OIDC_CONFIGURATION_URL:
          valueFrom:
            secretKeyRef:
              key: OIDC_CONFIGURATION_URL
              name: mealien
              optional: false
        OIDC_CLIENT_ID:
          valueFrom:
            secretKeyRef:
              key: OIDC_CLIENT_ID
              name: mealien
              optional: false
              #            OIDC_USER_GROUP:
              #              valueFrom:
              #                secretKeyRef:
              #                  key: OIDC_USER_GROUP
              #                  name: mealie
              #                  optional: false
              #            OIDC_ADMIN_GROUP:
              #              valueFrom:
              #                secretKeyRef:
              #                  key: mealie
              #                  name: mealien
              #                  optional: false
        OIDC_AUTO_REDIRECT:
          value: 'false'
        OIDC_PROVIDER_NAME:
          value: "Authentik"
        OIDC_USER_CLAIM:
          value: "preferred_username"
        OIDC_ADMIN_GROUP:
          value: "Appadmin"
        DB_ENGINE:
          value: "postgres"
        POSTGRES_USER:
          value: "mealie"
        POSTGRES_PASSWORD:
          value: '5iHWuruj6n7g9Sq4'
        POSTGRES_SERVER:
          value: "postgresql-primary.database.svc.cluster.local"
        POSTGRES_PORT:
          value: "5432"
        POSTGRES_DB:
          value: "mealie"
          #            DB_ENGINE	sqlite	Optional: 'sqlite', 'postgres'
          #            POSTGRES_USER	mealie	Postgres database user
          #            POSTGRES_PASSWORD	mealie	Postgres database password
          #            POSTGRES_SERVER	postgres	Postgres database server address
          #            POSTGRES_PORT	5432	Postgres database port
          #            POSTGRES_DB	mealie	Postgres database name
          #            POSTGRES_URL_OVERRIDE	None	Optional Postgres URL override to use instead of POSTGRES_* variables
        SMTP_HOST:
          valueFrom:
            secretKeyRef:
              key: smtp-host
              name: smtp-credentials
              optional: false
        SMTP_PORT:
          valueFrom:
            secretKeyRef:
              key: smtp-port
              name: smtp-credentials
              optional: false
        SMTP_FROM_NAME:
          value: Mealie
        SMTP_AUTH_STRATEGY:
          value: TLS
        SMTP_FROM_EMAIL:
          valueFrom:
            secretKeyRef:
              key: smtp-user
              name: smtp-credentials
              optional: false
        SMTP_USER:
          valueFrom:
            secretKeyRef:
              key: smtp-user
              name: smtp-credentials
              optional: false
        SMTP_PASSWORD:
          valueFrom:
            secretKeyRef:
              key: smtp-password
              name: smtp-credentials
              optional: false
              #  SMTP_HOST	None	Required For email
              #  SMTP_PORT	587	Required For email
              #  SMTP_FROM_NAME	Mealie	Required For email
              # SMTP_AUTH_STRATEGY	TLS	Required For email, Options: 'TLS', 'SSL', 'NONE'
              #   SMTP_FROM_EMAIL	None	Required For email
              #  SMTP_USER	None	Required if SMTP_AUTH_STRATEGY is 'TLS' or 'SSL'
              #  SMTP_PASSWORD	None	Required if SMTP_AUTH_STRATEGY is 'TLS' or 'SSL'
              #          envFrom:
              #            - secretRef:
              #                name: mealie-mealie
              #            - configMapRef:
              #                name: mealie-mealie
      volumes:
        mealie-data:
          persistentVolumeClaim:
            claimName: '{{ template "application.name" . }}p-pvc'
        tmp:
          emptyDir: {}
      volumeMounts:
        mealie-data:
          mountPath: /app/data/
      topologySpreadConstraints:
      revisionHistoryLimit: 2
      image:
        repository: ghcr.io/mealie-recipes/mealie # {"$imagepolicy": "flux-system:mealie:image"}
        tag: "v2.8.0" # {"$imagepolicy": "flux-system:mealie:tag"}
        digest: '' # if set to a non empty value, digest takes precedence on the tag
        pullPolicy: IfNotPresent
      dnsConfig:
      startupProbe:
        enabled: true
        failureThreshold: 60
        initialDelaySeconds: 10
        periodSeconds: 5
        successThreshold: 1
        timeoutSeconds: 2
        httpGet:
          path: /
          port: http-webui
          scheme: HTTP
      #        exec: {}
      #        tcpSocket: {}
      #        grpc: {}
      readinessProbe:
        enabled: true
        failureThreshold: 5
        initialDelaySeconds: 10
        periodSeconds: 10
        successThreshold: 2
        timeoutSeconds: 5
        httpGet:
          path: /
          port: http-webui
          scheme: HTTP
      #        exec: {}
      #        tcpSocket: {}
      #        grpc: {}
      livenessProbe:
        enabled: true
        failureThreshold: 5
        initialDelaySeconds: 10
        periodSeconds: 10
        successThreshold: 1
        timeoutSeconds: 5
        httpGet:
          path: /
          port: http-webui
          scheme: HTTP
      #        exec: {}
      #        tcpSocket: {}
      #        grpc: {}
      resources:
        requests:
          cpu: 10m
          memory: 50Mi
        limits:
          cpu: "4"
          memory: 1Gi
      containerSecurityContext:
        allowPrivilegeEscalation: false
        capabilities:
          drop: ["ALL"]
        privileged: false
        readOnlyRootFilesystem: false
        runAsGroup: 1000
        runAsNonRoot: true
        runAsUser: 1000
        seccompProfile:
          type: RuntimeDefault
      securityContext:
        fsGroup: 1000
        fsGroupChangePolicy: OnRootMismatch
      command: []
      args: []
      ports:
        - containerPort: 9000
          name: http-webui
          protocol: TCP
      hostNetwork:
      terminationGracePeriodSeconds: 300
      lifecycle: {}
    service:
      enabled: true
      additionalLabels:
      annotations:
      ports:
        - name: http-webui
          port: 9000
          protocol: TCP
          targetPort: http-webui
      type: ClusterIP
      clusterIP:
    ingress:
      # -- (bool) Enable Ingress.
      # @section -- Ingress Parameters
      enabled: true
      # -- (string) Name of the ingress class.
      # @section -- Ingress Parameters
      ingressClassName: "nginx"
      hosts:
        - # -- (tpl/string) Hostname.
          # @section -- Ingress Parameters
          host: '{{ template "application.name" . }}.pandia.io'
          paths:
            - # -- (string) Path.
              # @section -- Ingress Parameters
              path: /
              # -- (string) Path type.
              # @default -- `ImplementationSpecific`
              # @section -- Ingress Parameters
              pathType: ImplementationSpecific
              # -- (string) Service name.
              # @default -- `{{ include "application.name" $ }}`
              # @section -- Ingress Parameters
              # serviceName:
              # -- (string) Service port.
              # @default -- `http`
              # @section -- Ingress Parameters
              servicePort: http-webui
      # -- (object) Additional labels for ingress.
      # @section -- Ingress Parameters
      additionalLabels:
      # -- (object) Annotations for ingress.
      # @section -- Ingress Parameters
      annotations:
        gethomepage.dev/enabled: "true"
        gethomepage.dev/name: "Mealie"
        gethomepage.dev/description: ""
        gethomepage.dev/group: "Productivity"
        gethomepage.dev/icon: "mealie.png"
      # kubernetes.io/ingress.class: external-ingress
      # ingress.kubernetes.io/rewrite-target: /
      # ingress.kubernetes.io/force-ssl-redirect: true
      # -- (list) TLS configuration for ingress.
      # Secrets must exist in the namespace.
      # You may also configure Certificate resource to generate the secret.
      # @section -- Ingress Parameters
      tls:
        - secretName: pandia.io-tls
          hosts:
            - '{{ template "application.name" . }}.pandia.io'
    rbac:
      enabled: true
      serviceAccount:
        enabled: false
        name: ""
        additionalLabels:
        annotations:
      roles:
---
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: mealiep-pvc
  namespace: experimental
  labels:
    app: mealie
    velero-backup: true
  annotations:
    velero.io/csi-volumesnapshot-class: "ceph-filesystem"
spec:
  storageClassName: ceph-filesystem
  accessModes:
    - ReadWriteMany
  resources:
    requests:
      storage: 100Mi
---
apiVersion: velero.io/v1
kind: Schedule
metadata:
  name: mealie-daily
  namespace: velero
spec:
  schedule: 0 21 * * *
  skipImmediately: false
  template:
    csiSnapshotTimeout: 3000s
    hooks: {}
    includedNamespaces:
      - 'experimental'
    itemOperationTimeout: 3000s
    snapshotVolumes: true
    snapshotMoveData: true
    labelSelector:
      matchLabels:
        app: mealie
    metadata: {}
    ttl: 0s
    volumeSnapshotLocations:
      - minio-snapshot
  useOwnerReferencesInBackup: false