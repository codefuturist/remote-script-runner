# Quick Start: Get Valid Wildcard Certificates

## The configuration has been updated. Now execute these commands:

### 1. Commit and Push the Changes
```bash
cd /Users/colin/Developer/Projects/personal/iac-catalog
git add catalog/gitops/flux/clusters/staging/cert-manager-config/cert-manager-extras.yaml
git commit -m "fix: add DNS zone selectors and CNAME strategy to ClusterIssuers"
git push
```

### 2. Apply Changes Immediately (Don't Wait for Flux)
```bash
kubectl apply -f catalog/gitops/flux/clusters/staging/cert-manager-config/cert-manager-extras.yaml
```

### 3. Restart cert-manager
```bash
kubectl rollout restart deployment cert-manager -n cert-manager
kubectl rollout status deployment cert-manager -n cert-manager
```

### 4. Clean Up Stuck Challenges
```bash
kubectl delete challenges --all -A
```

### 5. Recreate the Certificate
```bash
kubectl delete certificate pandia-io-production -n cert-manager
kubectl apply -f catalog/gitops/flux/clusters/staging/cert-manager-config/cert-manager-extras.yaml
```

### 6. Monitor Progress
```bash
# Watch certificate status
watch -n 5 'kubectl get certificate -n cert-manager | grep pandia'

# In another terminal, watch challenges
watch -n 5 'kubectl get challenges -A'

# Check logs
kubectl logs -n cert-manager deploy/cert-manager --tail=50 -f
```

### 7. Verify Success (After ~10 minutes)
```bash
kubectl get certificate pandia-io-production -n cert-manager
# Should show READY: True

kubectl get secret pandia.io-tls -n cert-manager
# Should exist with certificate data
```

## What Was Fixed

The ClusterIssuers now have:
- `cnameStrategy: Follow` - Properly follows CNAME records
- Explicit DNS zone selectors - Tells cert-manager which zones to manage
- Combined with existing DNS config (1.1.1.1, 8.8.8.8) for proper validation

## Expected Result

After 10-20 minutes, you should have:
- ✅ Certificate `pandia-io-production` with READY: True
- ✅ Secret `pandia.io-tls` with valid Let's Encrypt certificate
- ✅ Certificate covers both `pandia.io` and `*.pandia.io`
- ✅ All apps can use this certificate via reflector
