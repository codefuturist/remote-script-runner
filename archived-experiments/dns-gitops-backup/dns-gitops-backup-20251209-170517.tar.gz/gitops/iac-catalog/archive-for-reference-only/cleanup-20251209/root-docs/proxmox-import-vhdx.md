# Import Windows VHDX to Proxmox

## Quick Steps

1. **Transfer VHDX to Proxmox** (if not already there)
   ```bash
   # Already on server in this case: /root/
   ```

2. **Create VM with UEFI/TPM**
   ```bash
   VMID=356
   qm create $VMID --name "WindowsServer2025" --memory 4096 --cores 2 \
     --net0 virtio,bridge=vmbr0 --ostype win11 \
     --bios ovmf --machine q35 --cpu host
   ```

3. **Add EFI disk**
   ```bash
   qm set $VMID --efidisk0 local-zfs:1,efitype=4m,pre-enrolled-keys=1
   ```

4. **Import VHDX** (converts to raw on ZFS)
   ```bash
   qm importdisk $VMID file.vhdx local-zfs
   ```

5. **Attach disk as SATA** (not SCSI for pre-installed Windows)
   ```bash
   qm set $VMID --sata0 local-zfs:vm-$VMID-disk-1
   ```

6. **Set boot order and add TPM**
   ```bash
   qm set $VMID --boot order=sata0 --tpmstate0 local-zfs:1,version=v2.0
   ```

7. **Start VM**
   ```bash
   qm start $VMID
   ```

## Key Points
- Use **SATA** interface for pre-installed Windows images (not SCSI/VirtIO)
- UEFI + TPM required for Windows Server 2025/Windows 11
- ZFS auto-converts qcow2 to raw format
- File was: `26100.1742.amd64fre.ge_release_svc_refresh.240906-0331_server_serverdatacentereval_en-us.vhdx`
