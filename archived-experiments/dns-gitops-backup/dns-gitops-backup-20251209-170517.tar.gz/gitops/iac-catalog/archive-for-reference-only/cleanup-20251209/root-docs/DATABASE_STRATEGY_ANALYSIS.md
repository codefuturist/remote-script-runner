# Analysis: Non-Single-Database-Strategy Deployments

## Executive Summary

Across both **production** and **staging** clusters, **only 1 deployment** deviates from the centralized single-database strategy: **ERPNext**.

### Single Database Strategy Status
- ✅ **32 HelmReleases analyzed**
- ✅ **31 deployments** follow single-database strategy (96.9%)
- ⚠️ **1 deployment** uses bundled databases (3.1%)

---

## Deployments Following Single-Database Strategy

All other deployments properly disable bundled databases and use centralized external services.

### Applications with External Databases (Both Clusters)
| Application | Database Type | External Service | Status |
|------------|---------------|-----------------|--------|
| WordPress (colins-blog) | MariaDB | mariadb-single | ✅ Centralized |
| WordPress (rey-it-solutions) | MariaDB | mariadb-single | ✅ Centralized |
| Gitea | PostgreSQL | postgres-single-rw | ✅ Centralized |
| PicoShare | SQLite (embedded) | N/A | ✅ Single-instance |
| Mealie | Embedded DB | N/A | ✅ Single-instance |
| N8N | PostgreSQL | postgres-single-rw | ✅ Centralized |
| PhopmyAdmin | External MySQL/MariaDB | User-configured | ✅ Flexible |
| Homarr | SQLite (internal) | N/A | ✅ Single-instance |
| Homepage | None | N/A | ✅ Stateless |
| Mattermost Operator | Manages own DB | External | ✅ Centralized |

### Infrastructure Components
- **No bundled databases** in infrastructure tier
- Cert-Manager, Traefik, Prometheus, Loki, etc. all stateless
- Operators (CloudNative-PG, MariaDB) manage external resources

---

## ⚠️ Non-Conforming Deployment: ERPNext

### Location
- **File**: `catalog/gitops/flux/clusters/production/apps/erpnext/erpnext-helmrelease.yaml`
- **Namespace**: `erpnext`
- **Cluster**: Production only (not in staging)

### Issue: Bundled Redis Components

ERPNext deploys **two internal Redis instances** instead of using centralized services:

#### 1. **redis-cache** (Lines 73-87)
```yaml
redis-cache:
  enabled: true                    # ⚠️ BUNDLED - NOT CENTRALIZED
  architecture: standalone
  master:
    resources:
      requests:
        cpu: 10m
        memory: 32Mi
      limits:
        cpu: 200m
        memory: 128Mi
    persistence:
      enabled: false              # No persistence for cache
```

**Characteristics**:
- Standalone cache Redis instance
- No persistence (appropriate for cache)
- Minimal resources: 10m CPU / 32Mi memory
- No HA configuration

#### 2. **redis-queue** (Lines 89-105)
```yaml
redis-queue:
  enabled: true                    # ⚠️ BUNDLED - NOT CENTRALIZED
  architecture: standalone
  master:
    resources:
      requests:
        cpu: 10m
        memory: 32Mi
      limits:
        cpu: 200m
        memory: 128Mi
    persistence:
      enabled: true
      size: 1Gi
      storageClass: openebs-hostpath  # HAS PERSISTENCE
```

**Characteristics**:
- Standalone queue Redis instance
- With 1Gi persistent storage
- Minimal resources: 10m CPU / 32Mi memory
- Data survives pod restarts (appropriate for queue)

### Database Configuration (Correct)
ERPNext **correctly uses external MariaDB**:
```yaml
mariadb:
  enabled: false  # ✅ External DB used

dbHost: "mariadb-single.database.svc.cluster.local"
dbPort: 3306
```

### Root Cause Analysis

**Why ERPNext uses bundled Redis**:
1. **ERPNext architecture requires Redis** for:
   - **Cache**: Session storage, caching (redis-cache)
   - **Queue**: Background job processing (redis-queue)

2. **Business requirement**: ERPNext needs these services to function
   - Cannot operate without Redis
   - Chart provides convenient bundled option

3. **Current trade-offs**:
   - ✅ Simple deployment (no external config needed)
   - ✅ Per-instance isolation (each ERPNext can have own Redis)
   - ❌ Not shared/centralized
   - ❌ Less efficient resource usage
   - ❌ No Redis connection pooling across instances
   - ❌ No centralized monitoring/backup

---

## Impact Assessment

### Resource Overhead
- **redis-cache**: 10m CPU + 32Mi memory (non-persistent)
- **redis-queue**: 10m CPU + 32Mi memory + 1Gi storage
- **Total**: 20m CPU + 64Mi memory + 1Gi storage per ERPNext instance

### Single Point of Failures
- Each ERPNext instance has its own Redis
- Redis pod crash → ERPNext functionality degraded
- No cross-instance Redis availability

### Operational Complexity
- No centralized Redis monitoring
- No shared Redis backups
- Multiple Redis instances to manage
- Different retention policies (cache vs. queue)

---

## Recommendations

### Option 1: Migrate to Centralized Redis (Recommended)
**Effort**: Medium | **Benefit**: High

**Steps**:
1. Deploy centralized Redis instance in `infrastructure/cache/`
2. Create HelmRelease with:
   - 2 Redis instances (one for cache, one for queue)
   - Persistent storage for queue
   - Proper resource allocation
3. Update ERPNext to use external Redis:
   ```yaml
   redis-cache:
     enabled: false
   redis-queue:
     enabled: false
   externalRedis:
     cache:
       host: redis-cache.cache.svc.cluster.local
       port: 6379
     queue:
       host: redis-queue.cache.svc.cluster.local
       port: 6379
   ```
4. Test functionality
5. Deploy centralized Redis before updating ERPNext

**Benefits**:
- ✅ Aligns with single-database strategy
- ✅ Shared resource pool
- ✅ Centralized monitoring/backups
- ✅ Resource efficiency
- ✅ Connection pooling opportunity

### Option 2: Keep Bundled with Documentation
**Effort**: Low | **Benefit**: Low

**If kept**:
- Document explicit exception in architecture
- Add monitoring for Redis instances
- Implement backup strategy
- Set resource quotas in erpnext namespace

**When to use**:
- If centralized Redis causes ERPNext performance issues
- If isolated Redis is intentional for performance reasons

### Option 3: Hybrid Approach
**Effort**: High | **Benefit**: Medium

- Bundled **redis-cache** (acceptable for session cache)
- Centralized **redis-queue** with persistence

**Trade-offs**:
- Still supports single-database strategy for stateful data
- Keeps lightweight cache isolated
- More complex to manage

---

## Implementation Path (Option 1 - Recommended)

### Step 1: Create Centralized Redis Infrastructure
**File**: `catalog/gitops/flux/clusters/production/infrastructure/cache/redis.yaml`

```yaml
apiVersion: source.toolkit.fluxcd.io/v1
kind: HelmRepository
metadata:
  name: bitnami
  namespace: cache
spec:
  interval: 12h
  url: https://charts.bitnami.com/bitnami
---
apiVersion: helm.toolkit.fluxcd.io/v2
kind: HelmRelease
metadata:
  name: redis-cache
  namespace: cache
spec:
  interval: 30m
  timeout: 15m
  chart:
    spec:
      chart: redis
      version: "18.*"
      sourceRef:
        kind: HelmRepository
        name: bitnami
      interval: 12h
  values:
    architecture: standalone
    auth:
      enabled: false
    master:
      persistence:
        enabled: false
      resources:
        requests:
          cpu: 50m
          memory: 128Mi
        limits:
          cpu: 500m
          memory: 256Mi
---
apiVersion: helm.toolkit.fluxcd.io/v2
kind: HelmRelease
metadata:
  name: redis-queue
  namespace: cache
spec:
  interval: 30m
  timeout: 15m
  chart:
    spec:
      chart: redis
      version: "18.*"
      sourceRef:
        kind: HelmRepository
        name: bitnami
      interval: 12h
  values:
    architecture: standalone
    auth:
      enabled: false
    master:
      persistence:
        enabled: true
        size: 10Gi
        storageClass: openebs-hostpath
      resources:
        requests:
          cpu: 100m
          memory: 256Mi
        limits:
          cpu: 500m
          memory: 512Mi
```

### Step 2: Update ERPNext HelmRelease
Disable bundled Redis and add external references:
```yaml
redis-cache:
  enabled: false
redis-queue:
  enabled: false

externalRedis:
  cache:
    host: redis-cache.cache.svc.cluster.local
    port: 6379
  queue:
    host: redis-queue.cache.svc.cluster.local
    port: 6379
```

### Step 3: Testing
- Deploy centralized Redis first
- Wait for Redis pods to be Ready
- Update ERPNext values
- Monitor ERPNext logs for Redis connectivity
- Test ERPNext functionality
- Monitor background jobs

### Step 4: Documentation
- Update architecture documentation
- Document Redis SLA expectations
- Add runbooks for Redis troubleshooting
- Update disaster recovery procedures

---

## Verification Checklist

- [ ] All 32 HelmReleases reviewed
- [ ] ERPNext identified as sole non-conforming deployment
- [ ] Redis bundling reason documented
- [ ] Migration plan created
- [ ] Resource projections calculated
- [ ] Testing strategy defined
- [ ] Rollback plan established
- [ ] Documentation updated

---

## Related Documents

- **Centralized Database Guide**: `catalog/gitops/flux/clusters/production/infrastructure/database/docs/centralized-*-guide.md`
- **Current Infrastructure**: `catalog/gitops/flux/clusters/production/infrastructure/`
- **ERPNext Configuration**: `catalog/gitops/flux/clusters/production/apps/erpnext/`
- **Redis Architecture**: See bitnami/redis Helm chart documentation
