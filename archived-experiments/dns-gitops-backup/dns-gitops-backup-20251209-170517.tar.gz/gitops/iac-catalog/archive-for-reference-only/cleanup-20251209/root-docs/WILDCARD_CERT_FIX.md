# Wildcard Certificate Fix - Steps to Valid Certificates

## Current Status

**Problem Identified:** DNS propagation checks failing even though DNS records are correctly created in Cloudflare.

**Root Cause:** ClusterIssuers lacked explicit DNS zone configuration and CNAME strategy settings.

## Changes Made

Updated `catalog/gitops/flux/clusters/staging/cert-manager-config/cert-manager-extras.yaml`:

### For letsencrypt-staging ClusterIssuer:
```yaml
solvers:
  - dns01:
      cloudflare:
        apiTokenSecretRef:
          key: cloudflare-token
          name: cloudflare-token-secret
        email: cloudflare.mck6r@allcloud.dev
      # Use public DNS servers for propagation checks
      cnameStrategy: Follow
    selector:
      dnsZones:
        - "colinrey.ch"
        - "colinrey.com"
        - "reyitsolutions.ch"
        - "reyitsolutions.com"
        - "pandia.io"
```

### For letsencrypt-production ClusterIssuer:
Same configuration as staging (see above).

## Steps to Get Valid Wildcard Certificates

### 1. Commit and Push Changes
```bash
cd /Users/colin/Developer/Projects/personal/iac-catalog
git add catalog/gitops/flux/clusters/staging/cert-manager-config/cert-manager-extras.yaml
git commit -m "fix: add DNS zone selectors and CNAME strategy to ClusterIssuers"
git push origin main
```

### 2. Verify Flux Reconciliation
Wait for Flux to pick up the changes (usually 1-5 minutes):
```bash
# Watch Flux sync status
flux get kustomizations

# Check specific reconciliation
flux reconcile kustomization cert-manager-config --with-source
```

### 3. Verify ClusterIssuer Update
```bash
kubectl get clusterissuer letsencrypt-production -o yaml | grep -A20 "solvers:"
```

Should show the new `cnameStrategy: Follow` and `selector.dnsZones`.

### 4. Restart cert-manager (Optional but Recommended)
Force immediate pickup of new configuration:
```bash
kubectl rollout restart deployment cert-manager -n cert-manager
kubectl rollout status deployment cert-manager -n cert-manager
```

### 5. Delete Failed Challenges
Clean up existing stuck challenges:
```bash
# Delete all challenges in cert-manager namespace
kubectl delete challenges --all -n cert-manager

# Delete challenges in other namespaces if needed
kubectl delete challenges --all -A
```

### 6. Trigger Certificate Renewal
Force recreation of certificate requests:
```bash
# Delete the certificate to trigger reissuance
kubectl delete certificate pandia-io-production -n cert-manager

# Flux will recreate it automatically, or manually reapply:
kubectl apply -f catalog/gitops/flux/clusters/staging/cert-manager-config/cert-manager-extras.yaml
```

### 7. Monitor Certificate Issuance

Watch the certificate status:
```bash
# Watch certificate status
watch -n 5 'kubectl get certificate -A | grep pandia'

# Check specific certificate
kubectl describe certificate pandia-io-production -n cert-manager

# Check challenges
kubectl get challenges -A

# Check orders
kubectl get orders -n cert-manager

# Monitor cert-manager logs
kubectl logs -n cert-manager deploy/cert-manager --tail=50 -f
```

### 8. Verify DNS Records
Ensure DNS TXT records are being created:
```bash
dig +short TXT _acme-challenge.pandia.io @8.8.8.8
dig +short TXT _acme-challenge.redisinsight.pandia.io @8.8.8.8
```

### 9. Check Certificate Ready Status
```bash
kubectl get certificate pandia-io-production -n cert-manager
```

Expected output when successful:
```
NAME                   READY   SECRET          AGE
pandia-io-production   True    pandia.io-tls   5m
```

### 10. Verify Certificate Secret
```bash
kubectl get secret pandia.io-tls -n cert-manager
kubectl describe secret pandia.io-tls -n cert-manager
```

## Expected Timeline

1. **Commit & Push**: Immediate
2. **Flux Sync**: 1-5 minutes
3. **ClusterIssuer Update**: Immediate after sync
4. **Challenge Creation**: 1-2 minutes
5. **DNS Propagation**: 2-5 minutes
6. **Challenge Validation**: 1-2 minutes
7. **Certificate Issuance**: 1-2 minutes

**Total Expected Time**: 10-20 minutes from commit to valid certificate

## Verification Commands Summary

```bash
# Quick status check
kubectl get certificate,certificaterequest,order,challenges -n cert-manager

# Detailed certificate check
kubectl describe certificate pandia-io-production -n cert-manager

# Check if secret exists and is valid
kubectl get secret pandia.io-tls -n cert-manager -o jsonpath='{.data.tls\.crt}' | base64 -d | openssl x509 -noout -text | grep -A2 "Subject:"
```

## Troubleshooting

If certificates still don't issue after 20 minutes:

1. **Check Cloudflare API Token**:
   ```bash
   kubectl get secret cloudflare-token-secret -n cert-manager
   ```

2. **Check cert-manager logs for errors**:
   ```bash
   kubectl logs -n cert-manager deploy/cert-manager --tail=100 | grep -i error
   ```

3. **Verify DNS is reachable from pods**:
   ```bash
   kubectl run -it --rm debug --image=nicolaka/netshoot --restart=Never -- nslookup pandia.io 1.1.1.1
   ```

4. **Check ACME account registration**:
   ```bash
   kubectl describe clusterissuer letsencrypt-production | grep -A5 "Status:"
   ```

## Success Criteria

✅ Certificate shows `READY: True`
✅ Secret `pandia.io-tls` exists with valid certificate data
✅ Certificate includes both `pandia.io` and `*.pandia.io` in SAN
✅ Certificate is issued by Let's Encrypt Production
✅ All application ingresses can reference this certificate

## Current DNS Configuration

cert-manager is already configured to use:
- Cloudflare DNS: 1.1.1.1:53
- Google DNS: 8.8.8.8:53
- Recursive nameservers only: true

This ensures cert-manager always queries public DNS for validation.
