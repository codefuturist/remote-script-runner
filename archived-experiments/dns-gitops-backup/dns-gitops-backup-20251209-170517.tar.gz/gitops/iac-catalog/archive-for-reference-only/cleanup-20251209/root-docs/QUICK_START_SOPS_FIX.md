# Quick Start - SOPS Fix

## Problem
FluxCD can't decrypt secrets because they're encrypted with Yubikeys that the cluster can't access.

## Quick Fix (3 Steps)

### 1. Commit the fixes
```bash
chmod +x commit-sops-fix.sh
./commit-sops-fix.sh
```

### 2. Check for errors
```bash
chmod +x check-flux-secrets.sh
./check-flux-secrets.sh
```

This will:
- Reconcile FluxCD
- Check for decryption errors
- Verify all secrets use the correct encryption key

### 3. Fix any remaining issues
```bash
chmod +x fix-sops-decryption.sh
./fix-sops-decryption.sh
```

## What Changed

✅ `.sops.yaml` - Now uses only software key for FluxCD paths  
✅ `cloudflare-token-secret.yaml` - Re-encrypted with correct key  
✅ Yubikeys commented out (kept for reference)  

## Expected Result

After running the scripts:
- ✅ No "decryption failed" errors in Flux
- ✅ cert-manager pods running
- ✅ Certificates can be issued

## Scripts Overview

| Script | Purpose |
|--------|---------|
| `commit-sops-fix.sh` | Commit and push all SOPS configuration fixes |
| `check-flux-secrets.sh` | Reconcile Flux and check for decryption errors |
| `fix-sops-decryption.sh` | Automated fix for any secrets with wrong keys |

## Manual Check (Optional)

```bash
# Check Flux status
flux get kustomizations

# Check for errors
kubectl get kustomization infrastructure -n flux-system \
  -o jsonpath='{.status.conditions[?(@.type=="Ready")].message}'

# Should NOT contain "decryption failed"
```

## Troubleshooting

**Issue**: Still seeing "decryption failed"  
**Solution**: Run `./fix-sops-decryption.sh` - it will re-encrypt with the correct key

**Issue**: cert-manager not deploying  
**Solution**: Check logs: `kubectl logs -n cert-manager -l app=cert-manager`

**Issue**: Certificates not issuing  
**Solution**: Check ClusterIssuer: `kubectl describe clusterissuer letsencrypt-staging`

## More Details

See `SOPS_FIX_INSTRUCTIONS.md` for comprehensive documentation and troubleshooting.
