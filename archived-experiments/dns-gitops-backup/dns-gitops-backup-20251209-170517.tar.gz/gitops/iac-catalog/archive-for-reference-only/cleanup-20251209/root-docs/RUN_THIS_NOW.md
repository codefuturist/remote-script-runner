# 🚀 Run This Now - Wildcard Certificate Fix

The ClusterIssuer configuration has been updated to fix DNS propagation issues. Follow these steps to get valid wildcard certificates.

## What You Need To Do

### Step 1: Commit Changes
```bash
cd /Users/colin/Developer/Projects/personal/iac-catalog
git add catalog/gitops/flux/clusters/staging/cert-manager-config/cert-manager-extras.yaml
git commit -m "fix: add DNS zone selectors and CNAME strategy to ClusterIssuers"
git push
```

### Step 2: Apply Configuration Immediately
```bash
kubectl apply -f catalog/gitops/flux/clusters/staging/cert-manager-config/cert-manager-extras.yaml
```

### Step 3: Restart cert-manager
```bash
kubectl rollout restart deployment cert-manager -n cert-manager
kubectl rollout status deployment cert-manager -n cert-manager --timeout=3m
```

### Step 4: Clean Up Stuck Challenges
```bash
kubectl delete challenges --all -A
```

### Step 5: Recreate Certificate
```bash
kubectl delete certificate pandia-io-production -n cert-manager
sleep 5
kubectl apply -f catalog/gitops/flux/clusters/staging/cert-manager-config/cert-manager-extras.yaml
```

### Step 6: Monitor Progress
```bash
# Watch certificate status (run this in one terminal)
watch -n 5 'kubectl get certificate -n cert-manager | grep pandia'

# Watch challenges (run this in another terminal)
watch -n 5 'kubectl get challenges -A'

# Watch logs (run this in a third terminal)
kubectl logs -n cert-manager deploy/cert-manager --tail=50 -f
```

## What Was Fixed

### ClusterIssuer Configuration
- **Added**: `cnameStrategy: Follow` to both staging and production issuers
- **Added**: Explicit DNS zone selectors for all managed domains:
  - colinrey.ch
  - colinrey.com  
  - reyitsolutions.ch
  - reyitsolutions.com
  - pandia.io
- **Why**: Fixes DNS propagation validation issues causing certificate issuance to fail

### The Problem
cert-manager was reporting "DNS record not yet propagated" even though DNS TXT records were correctly created in Cloudflare. The issue was that cert-manager's DNS validation couldn't properly detect the records.

### The Solution
Added explicit DNS zone configuration and CNAME strategy to help cert-manager properly validate DNS records using the already-configured public DNS servers (1.1.1.1, 8.8.8.8).

## Expected Timeline

```
Step 1: Commit & Push           → 30 seconds
Step 2: Apply Configuration     → 10 seconds
Step 3: Restart cert-manager    → 30 seconds
Step 4: Clean Challenges        → 10 seconds
Step 5: Recreate Certificate    → 10 seconds
Step 6: Monitor Progress        → Start watching
        - Challenge creation    → 1-2 minutes
        - DNS propagation       → 2-5 minutes
        - Challenge validation  → 1-2 minutes
        - Certificate issuance  → 1-2 minutes
```

**Total Time to Valid Certificate: 10-20 minutes**

## Success Criteria

After 10-20 minutes, you should see:

✅ **Certificate Ready**
```bash
kubectl get certificate pandia-io-production -n cert-manager
# Expected: NAME=pandia-io-production, READY=True
```

✅ **Secret Created**
```bash
kubectl get secret pandia.io-tls -n cert-manager
# Expected: Secret exists with type kubernetes.io/tls
```

✅ **Valid Certificate Data**
```bash
kubectl get secret pandia.io-tls -n cert-manager -o jsonpath='{.data.tls\.crt}' | base64 -d | openssl x509 -noout -text | grep -A3 "Subject:"
# Expected: Shows certificate for *.pandia.io
```

✅ **No Failed Challenges**
```bash
kubectl get challenges -A
# Expected: All challenges either valid or completed
```

## Quick Verification

```bash
# Check current certificate status
kubectl get certificate -n cert-manager | grep pandia

# Check challenges
kubectl get challenges -A

# Check cert-manager logs
kubectl logs -n cert-manager deploy/cert-manager --tail=30

# Verify DNS TXT records are being created
dig +short TXT _acme-challenge.pandia.io @8.8.8.8

# Check ClusterIssuer configuration
kubectl get clusterissuer letsencrypt-production -o yaml | grep -A20 "solvers:"
```

## If Something Goes Wrong

### Certificates Still Not Issuing After 20 Minutes

1. **Check cert-manager logs for specific errors**:
   ```bash
   kubectl logs -n cert-manager deploy/cert-manager --tail=100 | grep -i "error\|fail"
   ```

2. **Verify Cloudflare API token is valid**:
   ```bash
   kubectl get secret cloudflare-token-secret -n cert-manager
   ```

3. **Check if DNS records are reachable**:
   ```bash
   kubectl run -it --rm debug --image=nicolaka/netshoot --restart=Never -- nslookup pandia.io 1.1.1.1
   ```

4. **Restart the entire process**:
   ```bash
   kubectl delete certificate pandia-io-production -n cert-manager
   kubectl delete challenges --all -A
   kubectl rollout restart deployment cert-manager -n cert-manager
   kubectl apply -f catalog/gitops/flux/clusters/staging/cert-manager-config/cert-manager-extras.yaml
   ```

### View Detailed Error Messages
```bash
# Certificate details
kubectl describe certificate pandia-io-production -n cert-manager

# Challenge details
kubectl describe challenges -A

# Order details
kubectl get orders -n cert-manager
kubectl describe order <order-name> -n cert-manager
```

## Summary

| Status | Item |
|--------|------|
| ✅ | ClusterIssuer configuration updated |
| ✅ | DNS zone selectors added |
| ✅ | CNAME strategy configured |
| ✅ | Documentation created |
| ⏳ | Ready to commit and apply |

## Files Modified

- `catalog/gitops/flux/clusters/staging/cert-manager-config/cert-manager-extras.yaml`

## Documentation Created

- `WILDCARD_CERT_FIX.md` - Detailed troubleshooting guide
- `QUICKSTART_WILDCARD_FIX.md` - Quick command reference  
- `apply-wildcard-cert-fix.sh` - Automated script (optional)
- `RUN_THIS_NOW.md` - This file (step-by-step instructions)

## Next Action

**Copy and run these commands in your terminal:**

```bash
cd /Users/colin/Developer/Projects/personal/iac-catalog

# Step 1: Commit
git add catalog/gitops/flux/clusters/staging/cert-manager-config/cert-manager-extras.yaml
git commit -m "fix: add DNS zone selectors and CNAME strategy to ClusterIssuers"
git push

# Step 2-5: Apply and recreate
kubectl apply -f catalog/gitops/flux/clusters/staging/cert-manager-config/cert-manager-extras.yaml
kubectl rollout restart deployment cert-manager -n cert-manager
kubectl delete challenges --all -A
kubectl delete certificate pandia-io-production -n cert-manager
sleep 5
kubectl apply -f catalog/gitops/flux/clusters/staging/cert-manager-config/cert-manager-extras.yaml

# Step 6: Monitor
watch -n 5 'kubectl get certificate -n cert-manager | grep pandia'
```

**Expected result in 10-20 minutes**: Valid wildcard certificate for `*.pandia.io` with READY=True
