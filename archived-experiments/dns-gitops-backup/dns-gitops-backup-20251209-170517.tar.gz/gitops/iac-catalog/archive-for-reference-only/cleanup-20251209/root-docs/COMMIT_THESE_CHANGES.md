# Ready to Commit - SOPS Fix for FluxCD

## Changes Made

The following files have been created/modified to fix SOPS decryption issues:

### 1. `.sops.yaml` (MODIFIED)
**Purpose**: Configure SOPS to use only the software age key for FluxCD-managed secrets

**Changes**:
- FluxCD paths now use ONLY the software key: `age1t8gm5avm9z5pquta4w2kaud7zn3c588mkk2shdpdskvp76wxh3gsxctyst`
- Yubikey age keys are commented out (Flux can't access hardware keys in the cluster)
- Added clear comments explaining why each key is used/disabled

**Why**: FluxCD was unable to decrypt secrets encrypted with Yubikeys, causing reconciliation failures.

---

### 2. `fix-sops-decryption.sh` (NEW)
**Purpose**: Automated script to verify and fix SOPS decryption issues

**Features**:
- Verifies local age key matches expected key
- Checks/updates Flux age secret in cluster  
- Scans all encrypted secrets in Flux directories
- Identifies secrets encrypted with wrong keys
- Re-encrypts secrets with correct key
- Reconciles FluxCD
- Verifies cert-manager deployment
- Checks certificate issuance

**Usage**: `./fix-sops-decryption.sh`

---

### 3. `SOPS_FIX_INSTRUCTIONS.md` (NEW)
**Purpose**: Complete documentation of the fix, including troubleshooting

**Contents**:
- Problem explanation
- Solution details
- Step-by-step instructions (automated and manual)
- Verification procedures
- Troubleshooting guide
- Best practices for future

---

### 4. `catalog/gitops/flux/clusters/staging/infrastructure/cert-manager/cloudflare-token-secret.yaml` (MODIFIED)
**Purpose**: Cloudflare API token secret for cert-manager

**Changes**:
- Re-encrypted with ONLY the software age key
- Now uses single recipient: `age1t8gm5avm9z5pquta4w2kaud7zn3c588mkk2shdpdskvp76wxh3gsxctyst`

**Why**: Was previously encrypted with Yubikey, preventing Flux from decrypting it.

---

## Commit Commands

```bash
# Make the fix script executable
chmod +x fix-sops-decryption.sh

# Stage all changes
git add .sops.yaml \
        fix-sops-decryption.sh \
        SOPS_FIX_INSTRUCTIONS.md \
        COMMIT_THESE_CHANGES.md \
        catalog/gitops/flux/clusters/staging/infrastructure/cert-manager/cloudflare-token-secret.yaml

# Commit with descriptive message
git commit -m "fix: update SOPS configuration for FluxCD compatibility

- Configure .sops.yaml to use only software age key for FluxCD paths
- Comment out Yubikey recipients (Flux can't access hardware keys)
- Re-encrypt cloudflare-token-secret with correct key
- Add automated fix script for verification and remediation
- Add comprehensive documentation and troubleshooting guide

Fixes: decryption failures in Flux kustomization reconciliation
Resolves: cert-manager unable to access Cloudflare API token
Related: FluxCD SOPS integration, age encryption"

# Push to remote
git push origin develop
```

---

## After Committing

Run the verification script to ensure everything works:

```bash
./fix-sops-decryption.sh
```

This will:
1. Verify the age keys are correct in both local and cluster
2. Check all secrets are encrypted properly
3. Reconcile FluxCD to apply changes
4. Verify cert-manager deploys successfully
5. Check that certificates can be issued

---

## Expected Outcome

After committing and running the script, you should see:

✅ Flux successfully reconciles without decryption errors  
✅ cert-manager pods are running  
✅ ClusterIssuers are ready  
✅ Certificates are issued successfully  

---

## Rollback (if needed)

If something goes wrong, you can rollback:

```bash
# Revert the commit
git revert HEAD

# Or reset to previous commit
git reset --hard HEAD~1

# Push the rollback
git push origin develop --force
```

Then investigate the issue using `SOPS_FIX_INSTRUCTIONS.md` troubleshooting section.

---

## Files NOT Modified

These files were analyzed but not changed (already correct):

- `age.agekey` - Local age key (software key)
- `catalog/gitops/flux/clusters/staging/flux-system/kustomization.yaml` - Flux system configuration
- `catalog/gitops/flux/clusters/staging/cert-manager-config/cert-manager-extras.yaml` - ClusterIssuers and Certificates

---

## Summary

**Problem**: FluxCD couldn't decrypt secrets encrypted with Yubikeys  
**Solution**: Configure SOPS to use only software age keys for FluxCD paths  
**Status**: Ready to commit and deploy  

**Next Action**: Run the commit commands above, then execute `./fix-sops-decryption.sh` to verify.
