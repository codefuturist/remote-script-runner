# Cert-Manager SOPS Fix - Best Practices Solution

## Problem Summary

The cert-manager deployment is failing because secrets are encrypted with multiple age keys (including Yubikeys), but FluxCD in the cluster only has access to one software age key. This causes decryption failures.

## Root Cause

The `.sops.yaml` configuration was set to encrypt secrets with multiple keys:
```yaml
age: "age1yubikey1...,age1yubikey2...,age1yubikey3...,age1t8gm5avm9z5pquta4w2kaud7zn3c588mkk2shdpdskvp76wxh3gsxctyst"
```

When SOPS encrypts a file with multiple recipients, **any one of them can decrypt it**. However, FluxCD only has the last key in the cluster's `sops-age` secret. The problem occurs when:

1. SOPS encrypts the secret with the first key in the list (a Yubikey)
2. FluxCD tries to decrypt but only has the software key
3. Decryption fails with: `no identity matched any of the recipients`

## Solution: FluxCD-Optimized SOPS Configuration

### Best Practice Principle
**Separate encryption strategies for FluxCD-managed vs manually-managed secrets**

- **FluxCD secrets**: Use only the software key that's deployed in the cluster
- **Manual secrets**: Can use multiple keys including Yubikeys for added security

### Changes Made

#### 1. Updated `.sops.yaml`
```yaml
# FluxCD-managed secrets: Use ONLY the software key
- path_regex: catalog/gitops/flux/.*\.ya?ml$
  encrypted_regex: ^(data|stringData)$
  age: "age1t8gm5avm9z5pquta4w2kaud7zn3c588mkk2shdpdskvp76wxh3gsxctyst"

# Non-FluxCD secrets: Can use multiple keys
- path_regex: .*/(secrets?|secret-.*)\.ya?ml$
  encrypted_regex: ^(data|stringData)$
  age: "age1yubikey1qv3fxvnkgvn6txfld39ztg2fksqgtqhp29dntdhtwmll39q2z3fs2k3wjcn,age1t8gm5avm9z5pquta4w2kaud7zn3c588mkk2shdpdskvp76wxh3gsxctyst"
```

**Why this works:**
- FluxCD path (`catalog/gitops/flux/`) matches first → uses only software key
- Other paths match second rule → can use Yubikeys + software key
- SOPS uses the first matching rule, providing precise control

#### 2. Split Cert-Manager Deployment

Created a two-phase deployment to ensure CRDs are installed before certificates:

**Phase 1: Infrastructure (`catalog/gitops/flux/clusters/staging/infrastructure/cert-manager/`)**
- HelmRepository for Jetstack
- HelmRelease for cert-manager (installs CRDs)
- Cloudflare API token secret

**Phase 2: Configuration (`catalog/gitops/flux/clusters/staging/cert-manager-config/`)**
- ClusterIssuers (letsencrypt-production, letsencrypt-staging)
- Certificate resources for your domains
- Depends on infrastructure kustomization

### How to Fix

#### Option 1: Use the Automated Script (Recommended)

```bash
# Make the script executable
chmod +x fix-cert-manager.sh

# Run the script - it will:
# 1. Verify age keys match
# 2. Find and re-encrypt secrets with wrong keys
# 3. Commit and push changes
# 4. Reconcile FluxCD
# 5. Verify cert-manager deployment
./fix-cert-manager.sh
```

#### Option 2: Manual Steps

```bash
# 1. Update .sops.yaml (already done above)

# 2. Re-encrypt secrets in the Flux directory
export SOPS_AGE_KEY_FILE=age.agekey
LOCAL_KEY=$(grep "public key" age.agekey | awk '{print $4}')

# Find all SOPS-encrypted secrets in Flux directory
find catalog/gitops/flux/clusters/staging -name "*.yaml" -type f | while read file; do
    if grep -q "sops:" "$file"; then
        echo "Re-encrypting: $file"
        
        # Decrypt
        sops -d "$file" > /tmp/temp-secret.yaml
        
        # Re-encrypt with only the software key
        sops --encrypt --age "$LOCAL_KEY" --encrypted-regex '^(data|stringData)$' /tmp/temp-secret.yaml > "$file"
        
        rm /tmp/temp-secret.yaml
    fi
done

# 3. Commit and push
git add .sops.yaml catalog/gitops/flux/
git commit -m "fix: configure SOPS for FluxCD compatibility"
git push origin develop

# 4. Reconcile FluxCD
flux reconcile source git flux-system
flux reconcile kustomization infrastructure
flux reconcile kustomization cert-manager-config

# 5. Verify
kubectl get pods -n cert-manager
kubectl get certificates -n cert-manager
kubectl get clusterissuers
```

## Verification Steps

### 1. Check FluxCD age key
```bash
kubectl get secret sops-age -n flux-system -o jsonpath='{.data.age\.agekey}' | base64 -d | grep "public key"
```

Should show: `age1t8gm5avm9z5pquta4w2kaud7zn3c588mkk2shdpdskvp76wxh3gsxctyst`

### 2. Check secret encryption
```bash
grep -A 2 "age:" catalog/gitops/flux/clusters/staging/infrastructure/cert-manager/cloudflare-token-secret.yaml | grep "recipient:"
```

Should show only ONE recipient matching the cluster key.

### 3. Check cert-manager deployment
```bash
# Pods should be running
kubectl get pods -n cert-manager

# HelmRelease should be ready
kubectl get helmrelease cert-manager -n cert-manager

# ClusterIssuers should be ready
kubectl get clusterissuers

# Certificates should be issued
kubectl get certificates -n cert-manager
```

### 4. Monitor certificate issuance
```bash
# Watch certificate status
kubectl get certificates -A -w

# Check certificate details
kubectl describe certificate colinrey-ch-production -n cert-manager

# View cert-manager logs
kubectl logs -n cert-manager -l app.kubernetes.io/name=cert-manager -f
```

## Expected Results

After the fix:

1. ✅ **Infrastructure kustomization**: Ready (True)
2. ✅ **Cert-Manager pods**: 3 pods running (controller, webhook, cainjector)
3. ✅ **ClusterIssuers**: 2 issuers ready (letsencrypt-production, letsencrypt-staging)
4. ✅ **Certificates**: All certificates issued and ready
5. ✅ **TLS Secrets**: Created in cert-manager namespace and reflected to application namespaces

## Troubleshooting

### If secrets still fail to decrypt

**Check which key the secret is encrypted with:**
```bash
grep -A 2 "age:" <secret-file> | grep "recipient:"
```

**Re-encrypt manually:**
```bash
export SOPS_AGE_KEY_FILE=age.agekey
sops -d <secret-file> > /tmp/decrypted.yaml
sops --encrypt --age age1t8gm5avm9z5pquta4w2kaud7zn3c588mkk2shdpdskvp76wxh3gsxctyst \
     --encrypted-regex '^(data|stringData)$' /tmp/decrypted.yaml > <secret-file>
rm /tmp/decrypted.yaml
```

### If cert-manager pods don't start

**Check HelmRelease status:**
```bash
kubectl describe helmrelease cert-manager -n cert-manager
```

**Check Flux logs:**
```bash
kubectl logs -n flux-system -l app=helm-controller -f
```

### If certificates don't issue

**Check ClusterIssuer:**
```bash
kubectl describe clusterissuer letsencrypt-production
```

**Check certificate events:**
```bash
kubectl describe certificate <cert-name> -n cert-manager
```

**Verify Cloudflare API token:**
```bash
kubectl get secret cloudflare-token-secret -n cert-manager -o jsonpath='{.data.cloudflare-token}' | base64 -d
```

## Best Practices for Future

### 1. Key Management Strategy

- **Production clusters**: Use software age keys only for FluxCD
- **Backup**: Store age key securely (password manager, encrypted storage)
- **Rotation**: When rotating keys, update both cluster secret AND re-encrypt all secrets
- **Yubikeys**: Reserve for local/manual operations, not for automated systems

### 2. SOPS Configuration

- **Path-based rules**: Use specific paths for different encryption strategies
- **Most specific first**: SOPS uses the first matching rule
- **Test locally**: Decrypt after encrypting to verify the right key is used

### 3. FluxCD Secrets

- **Single key**: Always use one age key for FluxCD-managed secrets
- **Consistent encryption**: Verify all secrets use the same key
- **Documentation**: Document which key is used in the cluster

### 4. Certificate Management

- **Staging first**: Test with letsencrypt-staging before using production
- **Rate limits**: Be aware of Let's Encrypt rate limits (50 certs/domain/week)
- **Monitoring**: Set up alerts for expiring certificates
- **Reflection**: Use reflector to copy TLS secrets to application namespaces

## Additional Resources

- [SOPS Documentation](https://github.com/mozilla/sops)
- [Cert-Manager Documentation](https://cert-manager.io/docs/)
- [FluxCD SOPS Guide](https://fluxcd.io/flux/guides/mozilla-sops/)
- [Age Encryption](https://age-encryption.org/)

## Summary

The core issue was a mismatch between SOPS encryption configuration (multiple keys including Yubikeys) and FluxCD's decryption capability (single software key). By updating `.sops.yaml` to use path-based rules that specify only the software key for FluxCD-managed secrets, we ensure FluxCD can successfully decrypt all secrets in the cluster while still allowing Yubikey usage for manual operations.
