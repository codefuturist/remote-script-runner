# SOPS Decryption Fix - Instructions

## Current State

✅ **Configuration Fixed**:
- `.sops.yaml` now uses only the software age key for FluxCD paths
- Yubikeys are commented out (Flux can't access hardware keys in the cluster)
- `cloudflare-token-secret.yaml` is correctly encrypted with the software key only

✅ **Created Files**:
- `fix-sops-decryption.sh` - Automated verification and fix script
- `.sops.yaml` - Updated with correct age key configuration

## What Was Wrong

The original `.sops.yaml` configuration encrypted secrets with multiple age keys including Yubikeys:
```yaml
age: "age1yubikey1...,age1yubikey1...,age1t8gm5avm9z5pquta4w2kaud7zn3c588mkk2shdpdskvp76wxh3gsxctyst"
```

**Problem**: When SOPS encrypted files, it often used the first key (a Yubikey). FluxCD running in the cluster only has access to the software key (`age1t8gm5avm9z5pquta4w2kaud7zn3c588mkk2shdpdskvp76wxh3gsxctyst`), so it couldn't decrypt secrets encrypted with Yubikeys.

## Solution Applied

### 1. Updated `.sops.yaml` Configuration

```yaml
# FluxCD-managed secrets: Use ONLY the software key
- path_regex: catalog/gitops/flux/.*\.ya?ml$
  encrypted_regex: ^(data|stringData)$
  age: "age1t8gm5avm9z5pquta4w2kaud7zn3c588mkk2shdpdskvp76wxh3gsxctyst"
  # Yubikeys commented out - Flux can't access them in cluster
```

### 2. Re-encrypted Cloudflare Secret

The `cloudflare-token-secret.yaml` was re-encrypted with ONLY the software key:
```bash
sops --encrypt \
  --age age1t8gm5avm9z5pquta4w2kaud7zn3c588mkk2shdpdskvp76wxh3gsxctyst \
  --encrypted-regex '^(data|stringData)$' \
  secret.yaml
```

## Next Steps

### Option 1: Run Automated Fix Script

```bash
# Make script executable
chmod +x fix-sops-decryption.sh

# Run the script (it will verify and fix everything)
./fix-sops-decryption.sh
```

The script will:
1. ✓ Verify local age key matches expected key
2. ✓ Verify/update Flux age secret in cluster
3. ✓ Scan for encrypted secrets in Flux directories
4. ✓ Check each secret uses correct encryption
5. ✓ Re-encrypt any secrets with wrong keys
6. ✓ Reconcile FluxCD
7. ✓ Verify cert-manager deployment
8. ✓ Check certificate issuance

### Option 2: Manual Steps

If you prefer to do it manually:

```bash
# 1. Verify Flux has the correct age key
kubectl get secret sops-age -n flux-system -o jsonpath='{.data.age\.agekey}' | base64 -d

# 2. Update if needed
kubectl create secret generic sops-age \
  --from-file=age.agekey=age.agekey \
  --namespace=flux-system \
  --dry-run=client -o yaml | kubectl apply -f -

# 3. Commit the configuration changes
git add .sops.yaml fix-sops-decryption.sh SOPS_FIX_INSTRUCTIONS.md
git commit -m "fix: update SOPS configuration to use only software key for FluxCD"
git push origin develop

# 4. Reconcile Flux
flux reconcile source git flux-system
flux reconcile kustomization infrastructure

# 5. Monitor cert-manager deployment
kubectl get pods -n cert-manager -w
```

## Verification

### Check Flux can decrypt the secret:

```bash
# Check kustomization status
kubectl get kustomization infrastructure -n flux-system -o jsonpath='{.status.conditions[?(@.type=="Ready")].message}'

# Should NOT show "decryption failed" errors anymore
```

### Check cert-manager is running:

```bash
# Check pods
kubectl get pods -n cert-manager

# Should show:
# cert-manager-xxxxx                1/1     Running
# cert-manager-cainjector-xxxxx     1/1     Running  
# cert-manager-webhook-xxxxx        1/1     Running
```

### Check certificates can be issued:

```bash
# List certificates
kubectl get certificates -A

# Check certificate details
kubectl describe certificate <name> -n <namespace>

# Should show:
# Status: True
# Message: Certificate is up to date and has not expired
```

## Troubleshooting

### If Flux still can't decrypt:

1. **Check the age key in the secret file**:
   ```bash
   grep -A 3 "age:" catalog/gitops/flux/clusters/staging/infrastructure/cert-manager/cloudflare-token-secret.yaml
   ```
   Should show only: `recipient: age1t8gm5avm9z5pquta4w2kaud7zn3c588mkk2shdpdskvp76wxh3gsxctyst`

2. **Re-encrypt manually**:
   ```bash
   export SOPS_AGE_KEY_FILE=age.agekey
   sops -d cloudflare-token-secret.yaml > /tmp/decrypted.yaml
   sops --encrypt --age age1t8gm5avm9z5pquta4w2kaud7zn3c588mkk2shdpdskvp76wxh3gsxctyst --encrypted-regex '^(data|stringData)$' /tmp/decrypted.yaml > cloudflare-token-secret.yaml
   rm /tmp/decrypted.yaml
   ```

### If cert-manager pods don't start:

1. **Check HelmRelease status**:
   ```bash
   kubectl get helmreleases -n cert-manager
   kubectl describe helmrelease cert-manager -n cert-manager
   ```

2. **Check Helm repository**:
   ```bash
   kubectl get helmrepositories -A
   ```

3. **Force reconciliation**:
   ```bash
   flux reconcile helmrelease cert-manager -n cert-manager
   ```

### If certificates don't issue:

1. **Check ClusterIssuer**:
   ```bash
   kubectl get clusterissuers
   kubectl describe clusterissuer letsencrypt-staging
   ```

2. **Check cert-manager logs**:
   ```bash
   kubectl logs -n cert-manager -l app=cert-manager --tail=100
   ```

3. **Check Cloudflare API token is valid**:
   - Log into Cloudflare dashboard
   - Verify the API token has DNS edit permissions
   - Check token hasn't expired

## Best Practices Going Forward

### For FluxCD-managed secrets:

1. **Always use the software key only**:
   ```bash
   export SOPS_AGE_KEY_FILE=age.agekey
   sops --encrypt \
     --age age1t8gm5avm9z5pquta4w2kaud7zn3c588mkk2shdpdskvp76wxh3gsxctyst \
     --encrypted-regex '^(data|stringData)$' \
     your-secret.yaml
   ```

2. **Place secrets in the correct directory structure**:
   ```
   catalog/gitops/flux/clusters/staging/
   ├── infrastructure/
   │   ├── cert-manager/
   │   │   └── cloudflare-token-secret.yaml  # Secret here, with HelmRelease
   │   └── other-service/
   └── cert-manager-config/                   # Certificates and ClusterIssuers here
   ```

3. **Verify encryption before committing**:
   ```bash
   grep "age:" your-secret.yaml
   # Should show ONLY the software key
   ```

### For non-FluxCD secrets (local use):

You can use multiple keys including Yubikeys:
```yaml
- path_regex: .*/(secrets?|secret-.*)\.ya?ml$
  age: "age1yubikey1...,age1t8gm5avm9z5pquta4w2kaud7zn3c588mkk2shdpdskvp76wxh3gsxctyst"
```

This provides extra security for secrets that aren't deployed via Flux.

## Summary

✅ **Fixed**: `.sops.yaml` configuration to use only software key for FluxCD paths  
✅ **Fixed**: `cloudflare-token-secret.yaml` re-encrypted with correct key  
✅ **Created**: Automated fix script for verification and remediation  
✅ **Documented**: Best practices and troubleshooting guide  

**Status**: Ready to commit and deploy. Run `./fix-sops-decryption.sh` to verify everything is working correctly.
