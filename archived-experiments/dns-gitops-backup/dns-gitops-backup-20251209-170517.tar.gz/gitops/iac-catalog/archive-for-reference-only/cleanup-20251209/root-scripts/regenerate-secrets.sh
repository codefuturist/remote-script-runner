#!/bin/bash

# Script to regenerate secrets with random 30-character values (alphanumeric only)
# Usage: ./regenerate-secrets.sh

set -e

# Function to generate random 32-character secure string
generate_secret() {
    </dev/random LC_ALL=C tr -dc '[:graph:]' | head -c32
}

# Function to create secret YAML with SOPS encryption
create_encrypted_secret() {
    local file=$1
    local app_name=$2
    
    echo "Processing: $file"
    
    # Generate random secrets
    SECRET_KEY=$(generate_secret)
    POSTGRES_PASSWORD=$(generate_secret)
    POSTGRES_USER="authentik"
    POSTGRES_DB="authentik"
    
    # Create temporary unencrypted file
    cat > "${file}.tmp" <<EOF
apiVersion: v1
kind: Secret
metadata:
  name: ${app_name}-secret
  namespace: ${app_name}
type: Opaque
stringData:
  AUTHENTIK_SECRET_KEY: "${SECRET_KEY}"
  AUTHENTIK_POSTGRESQL__PASSWORD: "${POSTGRES_PASSWORD}"
  AUTHENTIK_POSTGRESQL__USER: "${POSTGRES_USER}"
  AUTHENTIK_POSTGRESQL__NAME: "${POSTGRES_DB}"
EOF
    
    # Encrypt with SOPS using the correct FluxCD age key
    if command -v sops &> /dev/null; then
        sops --encrypt --age age1t8gm5avm9z5pquta4w2kaud7zn3c588mkk2shdpdskvp76wxh3gsxctyst "${file}.tmp" > "$file"
        rm "${file}.tmp"
        echo "✓ Created and encrypted: $file"
    else
        echo "⚠ SOPS not found, creating unencrypted secret at ${file}.tmp"
        mv "${file}.tmp" "$file"
    fi
}

# Find and process all secret files
SECRET_FILES=$(find catalog/gitops/flux/clusters/staging/apps -name "*secret*.yaml" -o -name "*Secret*.yaml" | grep -v ".decrypted~")

for secret_file in $SECRET_FILES; do
    # Extract app name from path
    app_name=$(basename $(dirname "$secret_file"))
    
    # Backup original
    if [ -f "$secret_file" ]; then
        cp "$secret_file" "${secret_file}.bak"
        echo "📦 Backed up: ${secret_file}.bak"
    fi
    
    # Create new secret
    create_encrypted_secret "$secret_file" "$app_name"
done

echo ""
echo "✅ All secrets regenerated with random 30-character values"
echo "📦 Original files backed up with .bak extension"
