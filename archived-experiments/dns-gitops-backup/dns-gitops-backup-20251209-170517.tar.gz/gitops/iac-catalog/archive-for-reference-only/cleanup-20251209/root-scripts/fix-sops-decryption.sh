#!/bin/bash
set -euo pipefail

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}=== SOPS Decryption Fix for FluxCD ===${NC}\n"

# Configuration
FLUX_NAMESPACE="flux-system"
AGE_KEY_FILE="age.agekey"
EXPECTED_AGE_KEY="age1t8gm5avm9z5pquta4w2kaud7zn3c588mkk2shdpdskvp76wxh3gsxctyst"

# Step 1: Verify local age key
echo -e "${YELLOW}Step 1: Verifying local age key...${NC}"
if [[ ! -f "$AGE_KEY_FILE" ]]; then
    echo -e "${RED}Error: age.agekey file not found${NC}"
    exit 1
fi

LOCAL_AGE_KEY=$(grep "^# public key:" "$AGE_KEY_FILE" | awk '{print $4}')
echo "Local age key: $LOCAL_AGE_KEY"

if [[ "$LOCAL_AGE_KEY" != "$EXPECTED_AGE_KEY" ]]; then
    echo -e "${RED}Warning: Local age key doesn't match expected key${NC}"
    echo "Expected: $EXPECTED_AGE_KEY"
    echo "Found: $LOCAL_AGE_KEY"
    read -p "Continue anyway? (y/n) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

# Step 2: Verify Flux age secret
echo -e "\n${YELLOW}Step 2: Verifying Flux age secret in cluster...${NC}"
CLUSTER_AGE_KEY=$(kubectl get secret sops-age -n "$FLUX_NAMESPACE" -o jsonpath='{.data.age\.agekey}' 2>/dev/null | base64 -d | grep "^# public key:" | awk '{print $4}' || echo "")

if [[ -z "$CLUSTER_AGE_KEY" ]]; then
    echo -e "${RED}Error: Cannot get age key from cluster${NC}"
    echo "Creating/updating sops-age secret in cluster..."
    kubectl create secret generic sops-age \
        --from-file=age.agekey="$AGE_KEY_FILE" \
        --namespace="$FLUX_NAMESPACE" \
        --dry-run=client -o yaml | kubectl apply -f -
    echo -e "${GREEN}✓ Secret created/updated${NC}"
else
    echo "Cluster age key: $CLUSTER_AGE_KEY"
    
    if [[ "$CLUSTER_AGE_KEY" != "$LOCAL_AGE_KEY" ]]; then
        echo -e "${YELLOW}Warning: Cluster and local age keys don't match${NC}"
        echo "Updating cluster secret to match local key..."
        kubectl create secret generic sops-age \
            --from-file=age.agekey="$AGE_KEY_FILE" \
            --namespace="$FLUX_NAMESPACE" \
            --dry-run=client -o yaml | kubectl apply -f -
        echo -e "${GREEN}✓ Secret updated${NC}"
    else
        echo -e "${GREEN}✓ Keys match${NC}"
    fi
fi

# Step 3: Find and check encrypted secrets
echo -e "\n${YELLOW}Step 3: Scanning for encrypted secrets in Flux directories...${NC}"
FLUX_SECRETS=$(find catalog/gitops/flux -name "*.yaml" -type f -exec grep -l "sops:" {} \; 2>/dev/null || true)

if [[ -z "$FLUX_SECRETS" ]]; then
    echo "No encrypted secrets found"
else
    echo "Found encrypted secrets:"
    echo "$FLUX_SECRETS" | while read -r secret_file; do
        echo "  - $secret_file"
    done
fi

# Step 4: Check each secret for correct encryption
echo -e "\n${YELLOW}Step 4: Checking encryption keys used in secrets...${NC}"
NEEDS_REENCRYPT=()

while IFS= read -r secret_file; do
    if [[ -n "$secret_file" ]]; then
        # Extract age recipient from the file
        AGE_RECIPIENTS=$(grep -A 5 "^sops:" "$secret_file" | grep "age:" | sed 's/.*age: //' | tr ',' '\n')
        
        # Check if our expected key is the ONLY key
        KEY_COUNT=$(echo "$AGE_RECIPIENTS" | wc -l | tr -d ' ')
        CONTAINS_EXPECTED=$(echo "$AGE_RECIPIENTS" | grep -c "$EXPECTED_AGE_KEY" || echo "0")
        
        if [[ "$KEY_COUNT" -ne 1 ]] || [[ "$CONTAINS_EXPECTED" -ne 1 ]]; then
            echo -e "${YELLOW}  ⚠ $secret_file needs re-encryption${NC}"
            echo "    Current keys: $AGE_RECIPIENTS"
            NEEDS_REENCRYPT+=("$secret_file")
        else
            echo -e "${GREEN}  ✓ $secret_file is correctly encrypted${NC}"
        fi
    fi
done <<< "$FLUX_SECRETS"

# Step 5: Re-encrypt secrets if needed
if [[ ${#NEEDS_REENCRYPT[@]} -gt 0 ]]; then
    echo -e "\n${YELLOW}Step 5: Re-encrypting secrets with correct key...${NC}"
    export SOPS_AGE_KEY_FILE="$AGE_KEY_FILE"
    
    for secret_file in "${NEEDS_REENCRYPT[@]}"; do
        echo "Re-encrypting: $secret_file"
        
        # Create backup
        cp "$secret_file" "$secret_file.backup"
        
        # Decrypt and re-encrypt with only the software key
        if sops -d "$secret_file" > /tmp/decrypted.yaml 2>/dev/null; then
            sops --encrypt \
                --age "$EXPECTED_AGE_KEY" \
                --encrypted-regex '^(data|stringData)$' \
                /tmp/decrypted.yaml > "$secret_file"
            rm -f /tmp/decrypted.yaml
            echo -e "${GREEN}  ✓ Re-encrypted successfully${NC}"
        else
            echo -e "${RED}  ✗ Failed to decrypt (may need different key)${NC}"
            mv "$secret_file.backup" "$secret_file"
        fi
    done
    
    # Clean up backups
    find catalog/gitops/flux -name "*.backup" -delete
else
    echo -e "\n${GREEN}All secrets are correctly encrypted!${NC}"
fi

# Step 6: Reconcile Flux
echo -e "\n${YELLOW}Step 6: Reconciling FluxCD...${NC}"
echo "Reconciling source..."
flux reconcile source git flux-system --timeout=2m

echo "Reconciling infrastructure kustomization..."
flux reconcile kustomization infrastructure --timeout=3m

# Step 7: Verify cert-manager
echo -e "\n${YELLOW}Step 7: Verifying cert-manager deployment...${NC}"
sleep 5

echo "Checking cert-manager pods:"
kubectl get pods -n cert-manager 2>/dev/null || echo "No cert-manager pods found yet"

echo -e "\nChecking HelmReleases:"
kubectl get helmreleases -n cert-manager 2>/dev/null || echo "No HelmReleases found yet"

# Step 8: Check certificates
echo -e "\n${YELLOW}Step 8: Checking certificate status...${NC}"
sleep 10

kubectl get certificates -A 2>/dev/null || echo "No certificates found yet"

echo -e "\n${GREEN}=== Fix Complete ===${NC}"
echo -e "\n${BLUE}Next steps:${NC}"
echo "1. Monitor Flux reconciliation: flux get kustomizations"
echo "2. Check cert-manager logs: kubectl logs -n cert-manager -l app=cert-manager"
echo "3. Verify certificates: kubectl get certificates -A"
echo "4. Check certificate details: kubectl describe certificate <name> -n <namespace>"
