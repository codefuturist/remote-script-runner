#!/bin/bash
set -e

echo "=========================================="
echo "Prepare Flux for SOPS Decryption"
echo "=========================================="
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

export SOPS_AGE_KEY_FILE=age.agekey

# Step 1: Verify age keys
echo "Step 1: Verifying age keys..."
CLUSTER_KEY=$(kubectl get secret sops-age -n flux-system -o jsonpath='{.data.age\.agekey}' | base64 -d | grep "public key" | awk '{print $4}')
LOCAL_KEY=$(grep "public key" age.agekey | awk '{print $4}')

echo "  Cluster key: $CLUSTER_KEY"
echo "  Local key:   $LOCAL_KEY"

if [ "$CLUSTER_KEY" != "$LOCAL_KEY" ]; then
    echo -e "${RED}✗ Keys don't match!${NC}"
    echo ""
    echo "The cluster has a different age key. This will be fixed."
    echo ""
    read -p "Update cluster sops-age secret? (yes/no): " answer
    
    if [ "$answer" = "yes" ]; then
        echo "  Updating cluster secret..."
        kubectl delete secret sops-age -n flux-system
        kubectl create secret generic sops-age -n flux-system --from-file=age.agekey=./age.agekey
        echo -e "${GREEN}✓ Cluster secret updated${NC}"
    else
        echo -e "${RED}Aborted. Cannot proceed without matching keys.${NC}"
        exit 1
    fi
else
    echo -e "${GREEN}✓ Keys match${NC}"
fi
echo ""

# Step 2: Find secrets encrypted with wrong keys
echo "Step 2: Finding secrets encrypted with wrong age keys..."
echo ""

SECRETS_TO_FIX=()
TOTAL_SECRETS=0

while IFS= read -r file; do
    if [ -f "$file" ] && grep -q "sops:" "$file"; then
        TOTAL_SECRETS=$((TOTAL_SECRETS + 1))
        
        # Get the first age recipient
        FIRST_RECIPIENT=$(grep -A 5 "age:" "$file" | grep "recipient:" | head -1 | awk '{print $3}')
        
        # Check if it's a Yubikey (starts with age1yubikey) or different key
        if [[ "$FIRST_RECIPIENT" == age1yubikey* ]] || [[ "$FIRST_RECIPIENT" != "$LOCAL_KEY" ]]; then
            SECRETS_TO_FIX+=("$file")
            echo -e "  ${YELLOW}⚠${NC} $file"
            echo "     Encrypted with: $FIRST_RECIPIENT"
        else
            echo -e "  ${GREEN}✓${NC} $file"
        fi
    fi
done < <(find catalog/gitops/flux/clusters/staging -name "*.yaml" -type f)

echo ""
echo "Summary:"
echo "  Total secrets found: $TOTAL_SECRETS"
echo "  Secrets needing re-encryption: ${#SECRETS_TO_FIX[@]}"
echo ""

if [ ${#SECRETS_TO_FIX[@]} -eq 0 ]; then
    echo -e "${GREEN}✓ All secrets are correctly encrypted!${NC}"
    echo ""
    echo "Flux should be able to decrypt all secrets."
    exit 0
fi

# Step 3: Re-encrypt secrets
echo "Step 3: Re-encrypting secrets with correct age key..."
echo ""
read -p "Proceed with re-encryption? (yes/no): " answer

if [ "$answer" != "yes" ]; then
    echo "Skipped re-encryption."
    exit 0
fi

SUCCESS=0
FAILED=0

for file in "${SECRETS_TO_FIX[@]}"; do
    echo -n "  Processing: $file ... "
    
    TEMP_FILE="/tmp/sops-reencrypt-$$.yaml"
    
    # Try to decrypt
    if sops -d "$file" > "$TEMP_FILE" 2>/dev/null; then
        # Re-encrypt with only the software key
        if sops --encrypt --age "$LOCAL_KEY" --encrypted-regex '^(data|stringData)$' "$TEMP_FILE" > "$file" 2>/dev/null; then
            echo -e "${GREEN}✓${NC}"
            git add "$file"
            SUCCESS=$((SUCCESS + 1))
        else
            echo -e "${RED}✗ Failed to encrypt${NC}"
            FAILED=$((FAILED + 1))
        fi
    else
        echo -e "${RED}✗ Failed to decrypt${NC}"
        FAILED=$((FAILED + 1))
    fi
    
    # Clean up temp file
    rm -f "$TEMP_FILE"
done

echo ""
echo "Re-encryption complete:"
echo "  Success: $SUCCESS"
echo "  Failed: $FAILED"
echo ""

if [ $SUCCESS -gt 0 ]; then
    # Step 4: Commit changes
    echo "Step 4: Committing changes..."
    
    if ! git diff --cached --quiet; then
        git commit -m "fix: re-encrypt Flux secrets with software age key

- Re-encrypted ${SUCCESS} secrets to use age1t8gm5avm9z5pquta4w2kaud7zn3c588mkk2shdpdskvp76wxh3gsxctyst
- Removed Yubikey encryption from FluxCD-managed secrets
- Ensures Flux can decrypt all secrets in the cluster

This allows FluxCD to successfully decrypt secrets without requiring
Yubikey access, following best practices for automated GitOps."
        
        echo -e "${GREEN}✓ Changes committed${NC}"
        echo ""
        
        read -p "Push changes to remote? (yes/no): " push_answer
        
        if [ "$push_answer" = "yes" ]; then
            git push origin develop
            echo -e "${GREEN}✓ Changes pushed${NC}"
            echo ""
            
            # Step 5: Reconcile Flux
            echo "Step 5: Reconciling Flux..."
            flux reconcile source git flux-system
            echo ""
            echo -e "${GREEN}✓ Flux will sync the changes${NC}"
            echo ""
            echo "Monitor with: flux get kustomizations"
        else
            echo ""
            echo "Changes committed locally but not pushed."
            echo "Push with: git push origin develop"
        fi
    else
        echo "No changes to commit."
    fi
fi

echo ""
echo "=========================================="
echo "Summary"
echo "=========================================="
echo ""
echo "✓ Age keys verified/updated in cluster"
echo "✓ Secrets re-encrypted with correct key"
echo "✓ Changes committed (and possibly pushed)"
echo ""
echo -e "${BLUE}Next steps:${NC}"
echo "1. Wait for Flux to reconcile (or run: flux reconcile kustomization infrastructure)"
echo "2. Check infrastructure status: kubectl get kustomization infrastructure -n flux-system"
echo "3. Verify cert-manager: kubectl get pods -n cert-manager"
echo "4. Check certificates: kubectl get certificates -A"
echo ""
echo "For detailed monitoring, run: ./fix-cert-manager.sh"
