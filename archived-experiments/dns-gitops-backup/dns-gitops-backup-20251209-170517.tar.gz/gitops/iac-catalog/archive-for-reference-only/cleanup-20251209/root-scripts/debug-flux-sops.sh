#!/usr/bin/env bash
# Debug FluxCD + SOPS Integration Issues
# Provides detailed diagnostics and troubleshooting steps

set -uo pipefail

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

print_header() {
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo -e "${BLUE}$1${NC}"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
}

print_info() {
    echo -e "${CYAN}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[OK]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

# Debug Section 1: Environment Check
debug_environment() {
    print_header "1. Environment Check"
    
    echo "Current Directory: $(pwd)"
    echo "User: $USER"
    echo "Date: $(date)"
    echo ""
    
    # Check for required files
    print_info "Checking required files..."
    local files=(".sops.yaml" "age.agekey" "iac-manager/config/preferences/default.yaml")
    for file in "${files[@]}"; do
        if [ -f "$file" ]; then
            print_success "$file exists"
        else
            print_error "$file NOT found"
        fi
    done
}

# Debug Section 2: SOPS Configuration
debug_sops_config() {
    print_header "2. SOPS Configuration Details"
    
    if [ ! -f ".sops.yaml" ]; then
        print_error ".sops.yaml not found"
        return
    fi
    
    print_info "Contents of .sops.yaml:"
    echo ""
    cat .sops.yaml
    echo ""
    
    print_info "Age recipients configured:"
    grep "age:" .sops.yaml | head -3
    echo ""
}

# Debug Section 3: Age Key Information
debug_age_key() {
    print_header "3. Age Key Information"
    
    if [ ! -f "age.agekey" ]; then
        print_error "age.agekey not found"
        return
    fi
    
    # Extract public key from private key
    print_info "Deriving public key from private key..."
    local public_key=$(grep "AGE-SECRET-KEY-" age.agekey | age-keygen -y 2>/dev/null)
    
    if [ -n "$public_key" ]; then
        print_success "Public key: $public_key"
        
        # Check if this key is in .sops.yaml
        if grep -q "$public_key" .sops.yaml; then
            print_success "This public key is configured in .sops.yaml"
        else
            print_error "This public key is NOT found in .sops.yaml"
            print_warning "Add it to .sops.yaml for FluxCD paths"
        fi
    else
        print_error "Failed to derive public key"
    fi
    
    echo ""
    print_info "File permissions:"
    ls -l age.agekey
}

# Debug Section 4: Test Secret Encryption/Decryption
debug_sops_operations() {
    print_header "4. SOPS Encryption/Decryption Test"
    
    local test_file="debug-test-secret.yaml"
    
    print_info "Creating test secret..."
    cat > "$test_file" <<EOF
apiVersion: v1
kind: Secret
metadata:
  name: debug-test-secret
  namespace: default
type: Opaque
stringData:
  test-key: test-value-$(date +%s)
EOF
    
    print_success "Test secret created"
    echo ""
    
    print_info "Encrypting with SOPS..."
    if sops -e -i "$test_file" 2>&1; then
        print_success "Encryption successful"
    else
        print_error "Encryption failed"
        rm -f "$test_file"
        return
    fi
    echo ""
    
    print_info "Encrypted file preview:"
    head -20 "$test_file"
    echo ""
    
    print_info "Checking encryption markers..."
    if grep -q "sops:" "$test_file"; then
        print_success "SOPS metadata found"
    fi
    if grep -q "ENC\[" "$test_file"; then
        print_success "Encrypted data markers found"
    fi
    echo ""
    
    print_info "Attempting decryption..."
    if sops -d "$test_file" > /dev/null 2>&1; then
        print_success "Decryption successful"
        echo ""
        print_info "Decrypted content:"
        sops -d "$test_file"
    else
        print_error "Decryption failed"
    fi
    
    echo ""
    rm -f "$test_file"
    print_info "Test file cleaned up"
}

# Debug Section 5: FluxCD Cluster Status
debug_flux_cluster() {
    print_header "5. FluxCD Cluster Status"
    
    if ! kubectl cluster-info &> /dev/null; then
        print_warning "Kubernetes cluster not accessible"
        print_info "Make sure kubectl is configured and cluster is running"
        return
    fi
    
    print_success "Kubernetes cluster is accessible"
    echo ""
    
    # Check flux-system namespace
    print_info "Checking flux-system namespace..."
    if kubectl get namespace flux-system &> /dev/null; then
        print_success "flux-system namespace exists"
    else
        print_error "flux-system namespace NOT found"
        print_warning "Install Flux with: flux bootstrap github ..."
        return
    fi
    echo ""
    
    # Check SOPS secret
    print_info "Checking sops-age secret..."
    if kubectl get secret sops-age -n flux-system &> /dev/null; then
        print_success "sops-age secret exists"
        
        # Check secret contents
        echo ""
        print_info "Secret details:"
        kubectl get secret sops-age -n flux-system -o yaml | grep -A5 "data:"
    else
        print_error "sops-age secret NOT found"
        print_warning "Create it with:"
        echo "  kubectl create secret generic sops-age \\"
        echo "    --from-file=age.agekey=./age.agekey \\"
        echo "    -n flux-system"
    fi
    echo ""
    
    # List all Flux resources
    print_info "Flux GitRepository sources:"
    kubectl get gitrepository -A 2>/dev/null || print_warning "No GitRepositories found"
    echo ""
    
    print_info "Flux HelmRepository sources:"
    kubectl get helmrepository -A 2>/dev/null || print_warning "No HelmRepositories found"
    echo ""
    
    print_info "Flux Kustomizations:"
    kubectl get kustomization -A 2>/dev/null || print_warning "No Kustomizations found"
    echo ""
    
    print_info "Flux HelmReleases:"
    kubectl get helmrelease -A 2>/dev/null || print_warning "No HelmReleases found"
    echo ""
}

# Debug Section 6: Check Kustomization Decryption
debug_kustomization_decryption() {
    print_header "6. Kustomization Decryption Configuration"
    
    if ! kubectl cluster-info &> /dev/null; then
        print_warning "Skipping - cluster not accessible"
        return
    fi
    
    print_info "Checking Kustomizations for SOPS decryption..."
    echo ""
    
    local kustomizations=$(kubectl get kustomization -n flux-system -o name 2>/dev/null)
    
    if [ -z "$kustomizations" ]; then
        print_warning "No Kustomizations found"
        return
    fi
    
    for kust in $kustomizations; do
        local name=$(basename "$kust")
        print_info "Kustomization: $name"
        
        # Check for decryption config
        if kubectl get "$kust" -n flux-system -o yaml | grep -q "decryption:"; then
            print_success "  ✓ Decryption configured"
            
            # Show decryption details
            kubectl get "$kust" -n flux-system -o yaml | grep -A10 "decryption:" | grep -v "^--$"
        else
            print_warning "  ✗ No decryption configuration"
        fi
        echo ""
    done
}

# Debug Section 7: Recent Flux Events
debug_flux_events() {
    print_header "7. Recent Flux Events"
    
    if ! kubectl cluster-info &> /dev/null; then
        print_warning "Skipping - cluster not accessible"
        return
    fi
    
    print_info "Recent events in flux-system namespace:"
    echo ""
    kubectl get events -n flux-system --sort-by='.lastTimestamp' | tail -20
}

# Debug Section 8: Encrypted Secrets in Repository
debug_encrypted_secrets() {
    print_header "8. Encrypted Secrets in Repository"
    
    print_info "Searching for SOPS-encrypted secrets..."
    echo ""
    
    local flux_path="catalog/gitops/flux"
    if [ ! -d "$flux_path" ]; then
        print_warning "Flux path not found: $flux_path"
        return
    fi
    
    # Find and analyze encrypted files
    local count=0
    while IFS= read -r file; do
        ((count++))
        print_info "[$count] $file"
        
        # Check if file can be decrypted
        if sops -d "$file" > /dev/null 2>&1; then
            print_success "    ✓ Can decrypt"
        else
            print_error "    ✗ Cannot decrypt"
        fi
    done < <(find "$flux_path" -type f \( -name "*.yaml" -o -name "*.yml" \) -exec grep -l "sops:" {} \; 2>/dev/null)
    
    echo ""
    print_info "Total encrypted secrets found: $count"
}

# Debug Section 9: Default Preferences Analysis
debug_preferences() {
    print_header "9. Default Preferences Analysis"
    
    local config="iac-manager/config/preferences/default.yaml"
    
    if [ ! -f "$config" ]; then
        print_error "Config not found: $config"
        return
    fi
    
    print_info "External secret preferences:"
    echo ""
    grep -n "existingSecret" "$config" | head -20
    
    echo ""
    print_info "Conditional rules for secrets:"
    echo ""
    grep -A3 "existingSecret" "$config" | grep -E "(path:|operator:|apply:)" | head -20
}

# Debug Section 10: Recommendations
debug_recommendations() {
    print_header "10. Troubleshooting Recommendations"
    
    echo "Common issues and solutions:"
    echo ""
    
    echo "1. Secret not decrypting in cluster:"
    echo "   • Verify sops-age secret exists in flux-system namespace"
    echo "   • Check Kustomization has decryption provider configured"
    echo "   • Ensure age.agekey is the same one used for encryption"
    echo ""
    
    echo "2. SOPS encryption fails:"
    echo "   • Check .sops.yaml path_regex matches your file path"
    echo "   • Verify age recipient key is correct"
    echo "   • Test with: sops -e -i your-secret.yaml"
    echo ""
    
    echo "3. Helm chart not using external secret:"
    echo "   • Check default.yaml has appropriate conditional rules"
    echo "   • Verify existingSecret pattern matches your app name"
    echo "   • Review HelmRelease spec.values in deployed manifest"
    echo ""
    
    echo "4. Check Flux logs for errors:"
    echo "   kubectl logs -n flux-system deploy/kustomize-controller -f"
    echo "   kubectl logs -n flux-system deploy/helm-controller -f"
    echo "   kubectl logs -n flux-system deploy/source-controller -f"
    echo ""
    
    echo "5. Force reconciliation:"
    echo "   flux reconcile kustomization <name> --with-source"
    echo "   flux reconcile helmrelease <name> -n <namespace>"
    echo ""
}

# Main execution
main() {
    print_header "FluxCD + SOPS Integration Debug Tool"
    echo "Comprehensive diagnostics for secrets management"
    echo ""
    
    debug_environment
    debug_sops_config
    debug_age_key
    debug_sops_operations
    debug_flux_cluster
    debug_kustomization_decryption
    debug_flux_events
    debug_encrypted_secrets
    debug_preferences
    debug_recommendations
    
    print_header "Debug Complete"
    echo "Review the output above for any issues"
    echo ""
}

# Run if executed directly
if [ "${BASH_SOURCE[0]}" = "${0}" ]; then
    main "$@"
fi
