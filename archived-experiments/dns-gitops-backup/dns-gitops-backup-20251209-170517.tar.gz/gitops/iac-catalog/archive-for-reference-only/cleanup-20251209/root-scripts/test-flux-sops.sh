#!/usr/bin/env bash
# Test and Debug FluxCD + SOPS Integration
# Tests the default.yaml preferences for external secrets

set -uo pipefail

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Counters
TESTS_PASSED=0
TESTS_FAILED=0
TESTS_TOTAL=0

# Test results array
declare -a TEST_RESULTS

# Helper functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[PASS]${NC} $1"
    ((TESTS_PASSED++))
    ((TESTS_TOTAL++))
    TEST_RESULTS+=("✓ $1")
}

log_error() {
    echo -e "${RED}[FAIL]${NC} $1"
    ((TESTS_FAILED++))
    ((TESTS_TOTAL++))
    TEST_RESULTS+=("✗ $1")
}

log_warning() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_header() {
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo -e "${BLUE}$1${NC}"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""
}

# Test 1: Check required tools
test_required_tools() {
    print_header "Test 1: Check Required Tools"
    
    local tools=("sops" "flux" "kubectl" "age" "yq")
    local all_present=true
    
    for tool in "${tools[@]}"; do
        if command -v "$tool" &> /dev/null; then
            log_success "$tool is installed"
        else
            log_error "$tool is NOT installed"
            all_present=false
        fi
    done || true
    
    if [ "$all_present" = false ]; then
        log_warning "Some tools are missing. Install with:"
        log_warning "  brew install sops age flux kubectl yq"
    fi
}

# Test 2: Validate SOPS configuration
test_sops_configuration() {
    print_header "Test 2: Validate SOPS Configuration"
    
    if [ ! -f ".sops.yaml" ]; then
        log_error ".sops.yaml not found"
        return
    fi
    log_success ".sops.yaml exists"
    
    # Check for FluxCD-specific rules
    if grep -q "path_regex.*catalog/gitops/flux" .sops.yaml; then
        log_success "FluxCD path regex found in .sops.yaml"
    else
        log_error "FluxCD path regex NOT found in .sops.yaml"
    fi
    
    # Check for software key only (no Yubikeys for Flux)
    if grep -A5 "catalog/gitops/flux" .sops.yaml | grep -q "age1t8gm5avm9z5pquta4w2kaud7zn3c588mkk2shdpdskvp76wxh3gsxctyst"; then
        log_success "FluxCD software key configured"
    else
        log_error "FluxCD software key NOT configured properly"
    fi
    
    # Verify encrypted_regex
    if grep -q 'encrypted_regex.*data.*stringData' .sops.yaml; then
        log_success "encrypted_regex includes data and stringData"
    else
        log_error "encrypted_regex not properly configured"
    fi
}

# Test 3: Validate age key
test_age_key() {
    print_header "Test 3: Validate AGE Key"
    
    if [ ! -f "age.agekey" ]; then
        log_error "age.agekey not found"
        return
    fi
    log_success "age.agekey exists"
    
    # Check key format
    if grep -q "AGE-SECRET-KEY-" age.agekey; then
        log_success "age.agekey has valid format"
    else
        log_error "age.agekey format is invalid"
    fi
    
    # Check permissions
    local perms=$(stat -f "%A" age.agekey 2>/dev/null || stat -c "%a" age.agekey 2>/dev/null)
    if [ "$perms" = "600" ] || [ "$perms" = "400" ]; then
        log_success "age.agekey has secure permissions ($perms)"
    else
        log_warning "age.agekey permissions ($perms) should be 600 or 400"
    fi
}

# Test 4: Validate default.yaml preferences
test_default_preferences() {
    print_header "Test 4: Validate default.yaml Preferences"
    
    local config="iac-manager/config/preferences/default.yaml"
    
    if [ ! -f "$config" ]; then
        log_error "$config not found"
        return
    fi
    log_success "default.yaml exists"
    
    # Check for external secret preferences
    if grep -q "existingSecret" "$config"; then
        log_success "existingSecret preferences found"
    else
        log_error "existingSecret preferences NOT found"
    fi
    
    # Check for specific secret patterns
    local patterns=(
        "auth.existingSecret"
        "spec.values.existingSecret"
        "database.existingSecret"
    )
    
    for pattern in "${patterns[@]}"; do
        if grep -q "$pattern" "$config"; then
            log_success "Pattern '$pattern' found in preferences"
        else
            log_warning "Pattern '$pattern' not found in preferences"
        fi
    done
    
    # Check conditional rules for secrets
    if grep -A100 "conditional_rules:" "$config" | grep -q "existingSecret"; then
        log_success "Conditional rules for external secrets found"
    else
        log_warning "No conditional rules for external secrets"
    fi
}

# Test 5: Test SOPS encryption/decryption
test_sops_encryption() {
    print_header "Test 5: Test SOPS Encryption/Decryption"
    
    # Create test secret
    local test_file="test-secret.yaml"
    cat > "$test_file" <<EOF
apiVersion: v1
kind: Secret
metadata:
  name: test-secret
  namespace: default
type: Opaque
stringData:
  username: testuser
  password: testpass123
EOF
    
    log_info "Created test secret file"
    
    # Encrypt with SOPS
    if sops -e -i "$test_file" 2>/dev/null; then
        log_success "SOPS encryption successful"
    else
        log_error "SOPS encryption failed"
        rm -f "$test_file"
        return
    fi
    
    # Check if encrypted
    if grep -q "sops:" "$test_file" && grep -q "ENC\[" "$test_file"; then
        log_success "File is properly encrypted"
    else
        log_error "File encryption verification failed"
        rm -f "$test_file"
        return
    fi
    
    # Decrypt with SOPS
    if sops -d "$test_file" > /dev/null 2>&1; then
        log_success "SOPS decryption successful"
    else
        log_error "SOPS decryption failed"
    fi
    
    # Cleanup
    rm -f "$test_file"
    log_info "Test file cleaned up"
}

# Test 6: Check for existing SOPS secrets in Flux paths
test_existing_flux_secrets() {
    print_header "Test 6: Check Existing Flux SOPS Secrets"
    
    local flux_path="catalog/gitops/flux"
    
    if [ ! -d "$flux_path" ]; then
        log_warning "Flux path not found: $flux_path"
        return
    fi
    
    # Find encrypted secrets
    local encrypted_count=$(find "$flux_path" -type f \( -name "*.yaml" -o -name "*.yml" \) -exec grep -l "sops:" {} \; 2>/dev/null | wc -l | tr -d ' ')
    
    if [ "$encrypted_count" -gt 0 ]; then
        log_success "Found $encrypted_count encrypted secret(s) in Flux path"
        
        # List them
        find "$flux_path" -type f \( -name "*.yaml" -o -name "*.yml" \) -exec grep -l "sops:" {} \; 2>/dev/null | while read -r file; do
            log_info "  → $file"
        done
    else
        log_warning "No encrypted secrets found in Flux path"
    fi
}

# Test 7: Validate secret naming conventions
test_secret_naming() {
    print_header "Test 7: Validate Secret Naming Conventions"
    
    local config="iac-manager/config/preferences/default.yaml"
    
    # Check for variable substitution patterns
    if grep -q '\${app-name}' "$config"; then
        log_success "Variable substitution pattern '\${app-name}' found"
    else
        log_error "Variable substitution pattern NOT found"
    fi
    
    # Check for consistent naming patterns
    local naming_patterns=(
        '${app-name}-secret'
        '${app-name}-postgresql-secret'
        '${app-name}-mariadb-secret'
        '${app-name}-redis-secret'
        '${app-name}-mongodb-secret'
        '${app-name}-database-secret'
    )
    
    for pattern in "${naming_patterns[@]}"; do
        if grep -q "$pattern" "$config"; then
            log_success "Naming pattern '$pattern' found"
        else
            log_warning "Naming pattern '$pattern' not found"
        fi
    done
}

# Test 8: Check Flux namespace and decryption setup
test_flux_decryption_setup() {
    print_header "Test 8: Check Flux Decryption Setup"
    
    log_info "Checking if kubectl is configured and cluster is accessible..."
    
    if ! kubectl cluster-info &> /dev/null; then
        log_warning "Kubernetes cluster not accessible - skipping cluster tests"
        return
    fi
    
    log_success "Kubernetes cluster is accessible"
    
    # Check if flux-system namespace exists
    if kubectl get namespace flux-system &> /dev/null; then
        log_success "flux-system namespace exists"
    else
        log_warning "flux-system namespace does NOT exist"
        return
    fi
    
    # Check for SOPS secret in flux-system
    if kubectl get secret sops-age -n flux-system &> /dev/null; then
        log_success "sops-age secret exists in flux-system"
    else
        log_error "sops-age secret NOT found in flux-system"
        log_info "Create it with: kubectl create secret generic sops-age --from-file=age.agekey=./age.agekey -n flux-system"
    fi
    
    # Check Flux Kustomization for decryption
    local kustomizations=$(kubectl get kustomization -n flux-system -o name 2>/dev/null | wc -l | tr -d ' ')
    if [ "$kustomizations" -gt 0 ]; then
        log_success "Found $kustomizations Flux Kustomization(s)"
        
        # Check if any have decryption enabled
        if kubectl get kustomization -n flux-system -o yaml 2>/dev/null | grep -q "decryption:"; then
            log_success "SOPS decryption is configured in Kustomization"
        else
            log_warning "No SOPS decryption found in Kustomizations"
        fi
    else
        log_warning "No Flux Kustomizations found"
    fi
}

# Test 9: Validate preference merge strategies
test_merge_strategies() {
    print_header "Test 9: Validate Preference Merge Strategies"
    
    local config="iac-manager/config/preferences/default.yaml"
    
    # Check merge strategies
    local strategies=$(grep "merge_strategy:" "$config" | wc -l | tr -d ' ')
    log_info "Found $strategies merge_strategy declarations"
    
    if [ "$strategies" -gt 0 ]; then
        log_success "Merge strategies are defined"
        
        # Check for override strategy (should be most common)
        local override_count=$(grep 'merge_strategy: "override"' "$config" | wc -l | tr -d ' ')
        log_info "  → $override_count 'override' strategies"
        
        if [ "$override_count" -gt 0 ]; then
            log_success "Override strategies found (used for secrets)"
        fi
    else
        log_error "No merge strategies defined"
    fi
}

# Test 10: Check for sensitive data exposure
test_sensitive_data() {
    print_header "Test 10: Check for Sensitive Data Exposure"
    
    local config="iac-manager/config/preferences/default.yaml"
    
    # Check that no actual passwords are in the config
    if grep -iE "(password|secret|key|token).*:" "$config" | grep -v "^[[:space:]]*#" | grep -vE "(existingSecret|secretKeys|PasswordKey|secretName)" | grep -qE ":\s*['\"]?[a-zA-Z0-9]"; then
        log_error "Potential sensitive data found in config"
        log_warning "Review these lines:"
        grep -iE "(password|secret|key|token).*:" "$config" | grep -v "^[[:space:]]*#" | grep -vE "(existingSecret|secretKeys|PasswordKey|secretName)" | head -5
    else
        log_success "No sensitive data exposed in config"
    fi
    
    # Verify we're using references, not values
    if grep -q "existingSecret:" "$config" && ! grep -qE "password:\s*['\"]?[a-zA-Z0-9]" "$config"; then
        log_success "Config uses secret references (not embedded values)"
    fi
}

# Summary
print_summary() {
    print_header "Test Summary"
    
    echo ""
    for result in "${TEST_RESULTS[@]}"; do
        echo "$result"
    done
    echo ""
    
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo -e "${BLUE}Total Tests:${NC} $TESTS_TOTAL"
    echo -e "${GREEN}Passed:${NC} $TESTS_PASSED"
    echo -e "${RED}Failed:${NC} $TESTS_FAILED"
    
    local pass_rate=0
    if [ "$TESTS_TOTAL" -gt 0 ]; then
        pass_rate=$((TESTS_PASSED * 100 / TESTS_TOTAL))
    fi
    
    echo -e "${BLUE}Pass Rate:${NC} ${pass_rate}%"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""
    
    if [ "$TESTS_FAILED" -eq 0 ]; then
        echo -e "${GREEN}✓ All tests passed!${NC}"
        exit 0
    else
        echo -e "${RED}✗ Some tests failed. Please review the output above.${NC}"
        exit 1
    fi
}

# Main execution
main() {
    print_header "FluxCD + SOPS Integration Test Suite"
    echo "Testing default.yaml preferences and SOPS configuration"
    echo ""
    
    test_required_tools
    test_sops_configuration
    test_age_key
    test_default_preferences
    test_sops_encryption
    test_existing_flux_secrets
    test_secret_naming
    test_flux_decryption_setup
    test_merge_strategies
    test_sensitive_data
    
    print_summary
}

# Run if executed directly
if [ "${BASH_SOURCE[0]}" = "${0}" ]; then
    main "$@"
fi
