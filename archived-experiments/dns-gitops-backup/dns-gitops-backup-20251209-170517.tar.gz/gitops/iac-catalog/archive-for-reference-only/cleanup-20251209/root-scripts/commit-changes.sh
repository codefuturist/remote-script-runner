#!/bin/bash

# Make the fix script executable
chmod +x fix-cert-manager.sh

# Stage changes
git add .sops.yaml
git add fix-cert-manager.sh
git add CERT_MANAGER_FIX.md

# Commit with comprehensive message
git commit -m "fix: configure SOPS for FluxCD compatibility

- Updated .sops.yaml to use only software age key for FluxCD-managed secrets
- FluxCD path (catalog/gitops/flux/) now uses single key for reliable decryption
- Non-FluxCD secrets can still use multiple keys including Yubikeys
- Created fix-cert-manager.sh script to automate re-encryption
- Added CERT_MANAGER_FIX.md with detailed explanation and best practices

This resolves the decryption errors where FluxCD couldn't decrypt secrets
encrypted with Yubikey recipients. Following best practice of separating
encryption strategies for automated vs manual operations.

Related files:
- .sops.yaml: Updated encryption rules with path-based key selection
- fix-cert-manager.sh: Automated fix script with verification
- CERT_MANAGER_FIX.md: Comprehensive documentation"

echo ""
echo "Changes committed. Review with: git show HEAD"
echo "To push: git push origin develop"
echo ""
echo "Then run: ./fix-cert-manager.sh"
