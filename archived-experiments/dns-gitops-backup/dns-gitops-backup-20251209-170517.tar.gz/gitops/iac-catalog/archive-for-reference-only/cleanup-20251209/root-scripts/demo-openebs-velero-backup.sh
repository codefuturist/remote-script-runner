#!/bin/bash
set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
echo_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
echo_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
echo_error() { echo -e "${RED}[ERROR]${NC} $1"; }

NAMESPACE="default"
PVC_NAME="demo-openebs-pvc"
POD_NAME="demo-openebs-pod"
BACKUP_NAME="demo-openebs-backup-$(date +%Y%m%d-%H%M%S)"
STORAGE_CLASS="openebs-hostpath"

cleanup() {
    echo_info "Cleaning up demo resources..."
    kubectl delete pod $POD_NAME -n $NAMESPACE --ignore-not-found=true --wait=false
    kubectl delete pvc $PVC_NAME -n $NAMESPACE --ignore-not-found=true --wait=false
    echo_success "Cleanup initiated"
}

trap cleanup EXIT

echo_info "=========================================="
echo_info "OpenEBS + Velero Backup Demo"
echo_info "=========================================="
echo ""

# Step 1: Create PVC and Pod with data
echo_info "Step 1: Creating OpenEBS PVC and Pod with test data..."
cat <<EOF | kubectl apply -f -
---
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: $PVC_NAME
  namespace: $NAMESPACE
spec:
  storageClassName: $STORAGE_CLASS
  accessModes:
    - ReadWriteOnce
  resources:
    requests:
      storage: 100Mi
---
apiVersion: v1
kind: Pod
metadata:
  name: $POD_NAME
  namespace: $NAMESPACE
  annotations:
    backup.velero.io/backup-volumes: data
spec:
  containers:
  - name: app
    image: busybox:latest
    command: 
      - sh
      - -c
      - |
        echo "Demo data created at \$(date)" > /data/demo.txt
        echo "This demonstrates OpenEBS backup" > /data/readme.txt
        dd if=/dev/urandom of=/data/testfile.bin bs=1M count=5 2>/dev/null
        echo "=== Data Created ==="
        ls -lh /data/
        du -sh /data/
        tail -f /dev/null
    volumeMounts:
    - name: data
      mountPath: /data
  volumes:
  - name: data
    persistentVolumeClaim:
      claimName: $PVC_NAME
EOF

echo_info "Waiting for pod to be ready..."
kubectl wait --for=condition=ready pod/$POD_NAME -n $NAMESPACE --timeout=60s

echo_success "Pod is ready"
echo ""

# Step 2: Show initial data
echo_info "Step 2: Displaying initial data..."
kubectl exec $POD_NAME -n $NAMESPACE -- ls -lh /data/
echo ""
echo_info "Content of demo.txt:"
kubectl exec $POD_NAME -n $NAMESPACE -- cat /data/demo.txt
echo ""

# Step 3: Show PVC details
echo_info "Step 3: PVC Details (note: 100Mi is advisory, not enforced)..."
kubectl get pvc $PVC_NAME -n $NAMESPACE
echo ""

# Step 4: Try to expand PVC
echo_info "Step 4: Attempting to expand PVC from 100Mi to 200Mi..."
kubectl get storageclass $STORAGE_CLASS -o jsonpath='{.allowVolumeExpansion}' | grep -q "true" || {
    echo_warning "Storage class doesn't support expansion, patching..."
    kubectl patch storageclass $STORAGE_CLASS -p '{"allowVolumeExpansion":true}'
}

kubectl patch pvc $PVC_NAME -n $NAMESPACE -p '{"spec":{"resources":{"requests":{"storage":"200Mi"}}}}'
sleep 5

echo_info "PVC expansion status:"
echo "  Requested: $(kubectl get pvc $PVC_NAME -n $NAMESPACE -o jsonpath='{.spec.resources.requests.storage}')"
echo "  Actual: $(kubectl get pvc $PVC_NAME -n $NAMESPACE -o jsonpath='{.status.capacity.storage}')"
echo_warning "Note: OpenEBS LocalPV hostpath doesn't enforce quotas - expansion is metadata only"
echo ""

# Step 5: Create Velero backup
echo_info "Step 5: Creating Velero backup..."
velero backup create $BACKUP_NAME --include-namespaces $NAMESPACE --wait
echo_success "Backup created: $BACKUP_NAME"
echo ""

# Step 6: Show backup details
echo_info "Step 6: Backup details..."
velero backup describe $BACKUP_NAME --details | grep -A 5 "Pod Volume Backups"
echo ""

# Step 7: Simulate disaster - delete everything
echo_info "Step 7: Simulating disaster - deleting pod and PVC..."
kubectl delete pod $POD_NAME -n $NAMESPACE
kubectl delete pvc $PVC_NAME -n $NAMESPACE
echo_info "Waiting for resources to be fully deleted..."
kubectl wait --for=delete pod/$POD_NAME -n $NAMESPACE --timeout=60s 2>/dev/null || true
sleep 5
echo_success "Resources deleted"
echo ""

# Step 8: Restore from backup
echo_info "Step 8: Restoring from Velero backup..."
RESTORE_NAME="${BACKUP_NAME}-restore"
velero restore create $RESTORE_NAME --from-backup $BACKUP_NAME --wait
echo_success "Restore completed: $RESTORE_NAME"
echo ""

# Step 9: Verify restored data
echo_info "Step 9: Waiting for restored pod to be ready..."
kubectl wait --for=condition=ready pod/$POD_NAME -n $NAMESPACE --timeout=90s
echo ""

echo_info "Verifying restored data..."
kubectl exec $POD_NAME -n $NAMESPACE -c app -- ls -lh /data/
echo ""
echo_info "Content of restored demo.txt:"
kubectl exec $POD_NAME -n $NAMESPACE -c app -- cat /data/demo.txt
echo ""

# Step 10: Show volume location on host
echo_info "Step 10: Checking volume location on host filesystem..."
PV_NAME=$(kubectl get pvc $PVC_NAME -n $NAMESPACE -o jsonpath='{.spec.volumeName}')
PV_PATH=$(kubectl get pv $PV_NAME -o jsonpath='{.spec.local.path}')
NODE_NAME=$(kubectl get pod $POD_NAME -n $NAMESPACE -o jsonpath='{.spec.nodeName}')
echo_info "Volume stored on node: $NODE_NAME"
echo_info "Host path: $PV_PATH"
echo ""

# Step 11: Delete volume from host filesystem
echo_info "Step 11: Deleting volume data from host filesystem (192.168.2.50)..."
echo_info "Checking if path exists on host..."
if ssh 192.168.2.50 "sudo test -d $PV_PATH" 2>/dev/null; then
    echo_info "Path exists, listing contents before deletion:"
    ssh 192.168.2.50 "sudo ls -lah $PV_PATH/"
    echo ""
    echo_info "Deleting $PV_PATH from host..."
    ssh 192.168.2.50 "sudo rm -rf $PV_PATH"
    echo_success "Volume deleted from host filesystem"
    echo ""
    echo_info "Verifying deletion:"
    if ssh 192.168.2.50 "sudo test -d $PV_PATH" 2>/dev/null; then
        echo_warning "Path still exists!"
    else
        echo_success "Path successfully removed from host"
    fi
else
    echo_warning "Path not found on host (may have been auto-cleaned)"
fi
echo ""

# Step 12: Summary
echo_success "=========================================="
echo_success "Demo Complete!"
echo_success "=========================================="
echo ""
echo_info "Summary:"
echo "  ✓ Created OpenEBS PVC with 100Mi (advisory quota)"
echo "  ✓ Created pod with 5MB of data"
echo "  ✓ Expanded PVC to 200Mi (metadata only - no enforcement)"
echo "  ✓ Backed up volume using Velero filesystem backup"
echo "  ✓ Deleted pod and PVC (simulated disaster)"
echo "  ✓ Restored from backup successfully"
echo "  ✓ Verified all data was restored"
echo "  ✓ Located volume on host filesystem: $PV_PATH"
echo "  ✓ Manually deleted volume data from host (192.168.2.50)"
echo ""
echo_info "Key Takeaways:"
echo "  • OpenEBS LocalPV hostpath storage quotas are NOT enforced"
echo "  • Volumes use the underlying node's filesystem directly at /var/openebs/local/"
echo "  • PVC size values are metadata for Kubernetes resource tracking"
echo "  • Velero can backup/restore OpenEBS volumes using filesystem backups"
echo "  • Data integrity is maintained regardless of quota settings"
echo "  • Host filesystem data persists after PVC deletion (manual cleanup needed)"
echo ""
echo_info "Cleanup:"
echo "  - Backup: velero backup delete $BACKUP_NAME --confirm"
echo "  - Restore: velero restore delete $RESTORE_NAME --confirm"
echo "  - Resources will be cleaned up automatically on exit"
echo ""
