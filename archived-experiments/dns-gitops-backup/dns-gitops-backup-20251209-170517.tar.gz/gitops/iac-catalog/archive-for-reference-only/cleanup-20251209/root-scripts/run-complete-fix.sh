#!/bin/bash
set -euo pipefail

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}╔═══════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║  FluxCD SOPS Fix - Complete Automated Process            ║${NC}"
echo -e "${BLUE}╚═══════════════════════════════════════════════════════════╝${NC}"
echo

# Make all scripts executable
echo -e "${YELLOW}Preparing scripts...${NC}"
chmod +x commit-sops-fix.sh
chmod +x check-flux-secrets.sh
chmod +x fix-sops-decryption.sh
echo -e "${GREEN}✓ Scripts ready${NC}"
echo

# Step 1: Show what will be committed
echo -e "${BLUE}═══ Step 1: Review Changes ═══${NC}"
echo
echo "Files to be committed:"
git status --short | grep -E "(\.sops\.yaml|fix-sops|check-flux|SOPS_FIX|COMMIT_THESE|cloudflare-token-secret)"
echo

read -p "Continue with commit? (y/n) " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Aborted."
    exit 0
fi

# Step 2: Commit
echo
echo -e "${BLUE}═══ Step 2: Committing Changes ═══${NC}"
echo
git add .sops.yaml \
        fix-sops-decryption.sh \
        check-flux-secrets.sh \
        SOPS_FIX_INSTRUCTIONS.md \
        COMMIT_THESE_CHANGES.md \
        QUICK_START_SOPS_FIX.md \
        RUN_THIS_NOW.md \
        commit-sops-fix.sh \
        run-complete-fix.sh \
        catalog/gitops/flux/clusters/staging/infrastructure/cert-manager/cloudflare-token-secret.yaml

git commit -m "fix: update SOPS configuration for FluxCD compatibility

- Configure .sops.yaml to use only software age key for FluxCD paths
- Comment out Yubikey recipients (Flux can't access hardware keys)
- Re-encrypt cloudflare-token-secret with correct key
- Add automated fix scripts for verification and remediation
- Add comprehensive documentation and troubleshooting guides

Fixes: decryption failures in Flux kustomization reconciliation
Resolves: cert-manager unable to access Cloudflare API token
Related: FluxCD SOPS integration, age encryption"

echo -e "${GREEN}✓ Committed${NC}"
echo

read -p "Push to remote? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    git push origin develop
    echo -e "${GREEN}✓ Pushed${NC}"
else
    echo -e "${YELLOW}⚠ Not pushed (you can push later with: git push origin develop)${NC}"
    exit 0
fi

# Step 3: Wait a moment for push to complete
echo
echo "Waiting for Git push to complete..."
sleep 3

# Step 4: Reconcile and check
echo
echo -e "${BLUE}═══ Step 3: Reconciling FluxCD ═══${NC}"
echo

echo "Reconciling Git source..."
if flux reconcile source git flux-system --timeout=2m; then
    echo -e "${GREEN}✓ Git source reconciled${NC}"
else
    echo -e "${RED}✗ Failed to reconcile Git source${NC}"
    exit 1
fi
echo

echo "Reconciling flux-system kustomization..."
if flux reconcile kustomization flux-system --timeout=2m; then
    echo -e "${GREEN}✓ flux-system reconciled${NC}"
else
    echo -e "${RED}✗ Failed to reconcile flux-system${NC}"
    exit 1
fi
echo

echo "Reconciling infrastructure kustomization..."
if flux reconcile kustomization infrastructure --timeout=3m; then
    echo -e "${GREEN}✓ infrastructure reconciled${NC}"
else
    echo -e "${YELLOW}⚠ infrastructure reconciliation had issues (checking details...)${NC}"
fi
echo

# Step 5: Check for errors
echo -e "${BLUE}═══ Step 4: Checking for Errors ═══${NC}"
echo

INFRA_MESSAGE=$(kubectl get kustomization infrastructure -n flux-system -o jsonpath='{.status.conditions[?(@.type=="Ready")].message}' 2>/dev/null || echo "")

if echo "$INFRA_MESSAGE" | grep -q "decryption failed"; then
    echo -e "${RED}✗ DECRYPTION ERRORS FOUND${NC}"
    echo
    echo "Error details:"
    echo "$INFRA_MESSAGE" | grep "decryption failed" | head -5
    echo
    echo -e "${YELLOW}Running automated fix...${NC}"
    echo
    ./fix-sops-decryption.sh
else
    echo -e "${GREEN}✓ No decryption errors${NC}"
fi
echo

# Step 6: Verify cert-manager
echo -e "${BLUE}═══ Step 5: Verifying cert-manager ═══${NC}"
echo

if kubectl get namespace cert-manager &>/dev/null; then
    echo "cert-manager namespace: ✓"
    echo
    echo "cert-manager pods:"
    kubectl get pods -n cert-manager
    echo
    
    RUNNING_PODS=$(kubectl get pods -n cert-manager --no-headers 2>/dev/null | grep -c "Running" || echo "0")
    if [[ $RUNNING_PODS -ge 3 ]]; then
        echo -e "${GREEN}✓ cert-manager is running ($RUNNING_PODS pods)${NC}"
    else
        echo -e "${YELLOW}⚠ cert-manager not fully ready yet ($RUNNING_PODS/3 pods running)${NC}"
        echo "This may take a few more minutes..."
    fi
else
    echo -e "${YELLOW}⚠ cert-manager namespace not found yet${NC}"
    echo "It may still be deploying..."
fi
echo

# Step 7: Final status
echo -e "${BLUE}═══ Final Status ═══${NC}"
echo

READY_KUSTOMIZATIONS=$(kubectl get kustomizations -n flux-system -o jsonpath='{.items[?(@.status.conditions[0].status=="True")].metadata.name}' | wc -w | tr -d ' ')
TOTAL_KUSTOMIZATIONS=$(kubectl get kustomizations -n flux-system -o jsonpath='{.items[*].metadata.name}' | wc -w | tr -d ' ')

echo "Kustomizations ready: $READY_KUSTOMIZATIONS/$TOTAL_KUSTOMIZATIONS"
echo

if [[ "$INFRA_MESSAGE" == *"decryption failed"* ]]; then
    echo -e "${RED}Status: Some decryption errors remain${NC}"
    echo "Check logs: kubectl logs -n flux-system -l app=kustomize-controller --tail=50"
elif [[ $READY_KUSTOMIZATIONS -eq $TOTAL_KUSTOMIZATIONS ]]; then
    echo -e "${GREEN}✅ SUCCESS - All systems operational!${NC}"
    echo
    echo "✓ Configuration committed and pushed"
    echo "✓ FluxCD reconciled successfully"
    echo "✓ No SOPS decryption errors"
    echo "✓ All kustomizations ready"
else
    echo -e "${YELLOW}Status: Partial success - some kustomizations not ready yet${NC}"
    echo "This is normal during initial deployment."
fi

echo
echo -e "${BLUE}═══════════════════════════════════════════════════════════${NC}"
echo -e "${BLUE}  Complete! Monitor with: flux get kustomizations${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════════════${NC}"
echo
