#!/usr/bin/env bash
# End-to-End Validation: Create, Encrypt, and Deploy a Test Secret

set -uo pipefail

GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BLUE}End-to-End SOPS Secret Validation${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

# 1. Create test secret
TEST_SECRET="catalog/gitops/flux/clusters/staging/apps/test/e2e-test-secret.yaml"
mkdir -p "$(dirname "$TEST_SECRET")"

echo -e "${BLUE}Step 1: Creating test secret${NC}"
cat > "$TEST_SECRET" <<EOF
apiVersion: v1
kind: Secret
metadata:
  name: e2e-test-secret
  namespace: test
  labels:
    app: e2e-test
type: Opaque
stringData:
  username: testuser
  password: testpass123
  api-key: test-api-key-$(date +%s)
EOF

echo -e "${GREEN}✓ Created: $TEST_SECRET${NC}"
echo ""

# 2. Show unencrypted content
echo -e "${BLUE}Step 2: Unencrypted content${NC}"
cat "$TEST_SECRET"
echo ""

# 3. Encrypt with SOPS
echo -e "${BLUE}Step 3: Encrypting with SOPS${NC}"
if sops -e -i "$TEST_SECRET" 2>&1; then
    echo -e "${GREEN}✓ Encryption successful${NC}"
else
    echo -e "${RED}✗ Encryption failed${NC}"
    exit 1
fi
echo ""

# 4. Show encrypted content (first 20 lines)
echo -e "${BLUE}Step 4: Encrypted content (preview)${NC}"
head -20 "$TEST_SECRET"
echo ""

# 5. Verify encryption markers
echo -e "${BLUE}Step 5: Verifying encryption markers${NC}"
if grep -q "sops:" "$TEST_SECRET"; then
    echo -e "${GREEN}✓ SOPS metadata found${NC}"
else
    echo -e "${RED}✗ SOPS metadata not found${NC}"
    exit 1
fi

if grep -q "ENC\[" "$TEST_SECRET"; then
    echo -e "${GREEN}✓ Encrypted data markers found${NC}"
else
    echo -e "${RED}✗ Encrypted data markers not found${NC}"
    exit 1
fi
echo ""

# 6. Test decryption
echo -e "${BLUE}Step 6: Testing decryption${NC}"
if sops -d "$TEST_SECRET" > /dev/null 2>&1; then
    echo -e "${GREEN}✓ Decryption successful${NC}"
else
    echo -e "${RED}✗ Decryption failed${NC}"
    exit 1
fi
echo ""

# 7. Show decrypted content
echo -e "${BLUE}Step 7: Decrypted content (verification)${NC}"
sops -d "$TEST_SECRET"
echo ""

# 8. Check if cluster is available
echo -e "${BLUE}Step 8: Cluster deployment test${NC}"
if kubectl cluster-info &> /dev/null; then
    echo -e "${GREEN}✓ Cluster is accessible${NC}"
    
    # Create namespace if not exists
    kubectl create namespace test --dry-run=client -o yaml | kubectl apply -f - > /dev/null 2>&1
    
    # Try to apply the secret
    if sops -d "$TEST_SECRET" | kubectl apply -f - 2>&1 | grep -q "secret.*configured\|secret.*created"; then
        echo -e "${GREEN}✓ Secret successfully deployed to cluster${NC}"
        
        # Verify secret exists
        if kubectl get secret e2e-test-secret -n test &> /dev/null; then
            echo -e "${GREEN}✓ Secret verified in cluster${NC}"
            
            # Show secret (encrypted in cluster)
            echo ""
            echo -e "${BLUE}Secret in cluster (base64 encoded):${NC}"
            kubectl get secret e2e-test-secret -n test -o yaml | grep -A5 "^data:" | head -8
        fi
    else
        echo -e "${YELLOW}⚠ Could not deploy to cluster (may require permissions)${NC}"
    fi
else
    echo -e "${YELLOW}⚠ Cluster not accessible - skipping deployment test${NC}"
fi
echo ""

# 9. Clean up
echo -e "${BLUE}Step 9: Cleanup${NC}"
rm -f "$TEST_SECRET"
rmdir "$(dirname "$TEST_SECRET")" 2>/dev/null || true
if kubectl cluster-info &> /dev/null; then
    kubectl delete secret e2e-test-secret -n test &> /dev/null || true
fi
echo -e "${GREEN}✓ Test files cleaned up${NC}"
echo ""

echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${GREEN}✓ End-to-End validation complete!${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
