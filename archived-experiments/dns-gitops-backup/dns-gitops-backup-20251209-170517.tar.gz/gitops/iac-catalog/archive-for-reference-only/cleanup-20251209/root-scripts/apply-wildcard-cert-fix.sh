#!/bin/bash
# Script to apply wildcard certificate fix and monitor progress

set -e

echo "=== Wildcard Certificate Fix Script ==="
echo ""

# Step 1: Commit changes
echo "Step 1: Committing ClusterIssuer configuration changes..."
cd /Users/colin/Developer/Projects/personal/iac-catalog
git add catalog/gitops/flux/clusters/staging/cert-manager-config/cert-manager-extras.yaml
git commit -m "fix: add DNS zone selectors and CNAME strategy to ClusterIssuers

- Add cnameStrategy: Follow to both staging and production issuers
- Add explicit DNS zone selectors for all managed domains
- Improves DNS propagation detection for wildcard certificates
- Fixes DNS validation issues for *.pandia.io certificates" || echo "Changes already committed"

echo "✓ Changes committed"
echo ""

# Step 2: Push changes
echo "Step 2: Pushing to origin..."
git push origin main || git push origin develop || echo "Push failed or already up to date"
echo "✓ Changes pushed"
echo ""

# Step 3: Wait for Flux
echo "Step 3: Waiting for Flux to reconcile (30 seconds)..."
sleep 30
echo "✓ Wait complete"
echo ""

# Step 4: Restart cert-manager
echo "Step 4: Restarting cert-manager..."
kubectl rollout restart deployment cert-manager -n cert-manager
kubectl rollout status deployment cert-manager -n cert-manager --timeout=2m
echo "✓ cert-manager restarted"
echo ""

# Step 5: Clean up stuck challenges
echo "Step 5: Cleaning up stuck challenges..."
kubectl delete challenges --all -A --ignore-not-found=true
echo "✓ Challenges cleaned up"
echo ""

# Step 6: Delete and recreate certificate
echo "Step 6: Triggering certificate recreation..."
kubectl delete certificate pandia-io-production -n cert-manager --ignore-not-found=true
sleep 5
kubectl apply -f catalog/gitops/flux/clusters/staging/cert-manager-config/cert-manager-extras.yaml
echo "✓ Certificate recreated"
echo ""

# Step 7: Monitor progress
echo "Step 7: Monitoring certificate issuance..."
echo "Waiting for certificate to be created..."
sleep 10

echo ""
echo "=== Current Status ==="
kubectl get certificate -n cert-manager | grep pandia
echo ""

echo "=== Certificate Details ==="
kubectl describe certificate pandia-io-production -n cert-manager | tail -20
echo ""

echo "=== Challenges ==="
kubectl get challenges -n cert-manager
echo ""

echo "=== DNS Records ==="
echo "Checking DNS TXT records..."
dig +short TXT _acme-challenge.pandia.io @8.8.8.8 || echo "No record yet"
echo ""

echo "=== Next Steps ==="
echo "Monitor certificate status with:"
echo "  watch -n 5 'kubectl get certificate -n cert-manager | grep pandia'"
echo ""
echo "Check cert-manager logs:"
echo "  kubectl logs -n cert-manager deploy/cert-manager --tail=50 -f"
echo ""
echo "Expected time to completion: 10-20 minutes"
