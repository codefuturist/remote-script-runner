#!/bin/bash
# Import Manual Certificate to Kubernetes
# Run this after creating the certificate on 192.168.2.57

set -e

echo "=========================================="
echo "Import Manual Certificate to Kubernetes"
echo "=========================================="
echo ""

# Check if certificate files exist locally
if [ ! -f "fullchain.pem" ] || [ ! -f "privkey.pem" ]; then
    echo "Certificate files not found locally."
    echo "Copying from server..."
    echo ""
    
    scp colin@192.168.2.57:/etc/letsencrypt/live/pandia.io/fullchain.pem .
    scp colin@192.168.2.57:/etc/letsencrypt/live/pandia.io/privkey.pem .
    
    echo "✓ Files copied"
    echo ""
fi

echo "Creating Kubernetes secret..."
echo ""

# Create or update the secret
kubectl create secret tls pandia.io-tls \
  --cert=fullchain.pem \
  --key=privkey.pem \
  -n cert-manager \
  --dry-run=client -o yaml | kubectl apply -f -

if [ $? -eq 0 ]; then
    echo ""
    echo "✓ Secret created/updated: pandia.io-tls"
    echo ""
    
    # Add reflector annotations
    echo "Adding reflector annotations..."
    kubectl annotate secret pandia.io-tls \
      -n cert-manager \
      reflector.v1.k8s.emberstack.com/reflection-allowed="true" \
      reflector.v1.k8s.emberstack.com/reflection-auto-enabled="true" \
      reflector.v1.k8s.emberstack.com/reflection-auto-namespaces="cert-manager,ci-cd,database,development,experimental,flux-system,ingress,logging,monitoring,home-assistant,compass-web,mailrise,mealie,redisinsight,web" \
      --overwrite
    
    echo "✓ Reflector annotations added"
    echo ""
    
    echo "=========================================="
    echo "Certificate Imported Successfully!"
    echo "=========================================="
    echo ""
    
    # Show certificate details
    echo "Certificate details:"
    kubectl get secret pandia.io-tls -n cert-manager -o jsonpath='{.data.tls\.crt}' | base64 -d | openssl x509 -noout -text | grep -A3 "Subject:"
    echo ""
    
    echo "The certificate is now available and will be automatically reflected to other namespaces."
    echo ""
    
    # Clean up local files
    read -p "Delete local certificate files? (y/n) " -n 1 -r
    echo ""
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        rm -f fullchain.pem privkey.pem
        echo "✓ Local files deleted"
    fi
else
    echo ""
    echo "✗ Failed to create secret"
    exit 1
fi
