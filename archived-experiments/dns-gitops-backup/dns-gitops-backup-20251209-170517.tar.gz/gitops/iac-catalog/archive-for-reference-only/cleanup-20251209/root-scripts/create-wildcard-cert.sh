#!/bin/bash
# Manual Wildcard Certificate Creation for *.pandia.io
# Run this script on colin@192.168.2.57

set -e

echo "=========================================="
echo "Manual Wildcard Certificate Creation"
echo "Domain: *.pandia.io"
echo "=========================================="
echo ""

# Check if running as root or with sudo
if [ "$EUID" -ne 0 ]; then 
    echo "This script needs sudo privileges."
    echo "Please run: sudo bash create-wildcard-cert.sh"
    exit 1
fi

# Check if certbot is installed
if ! command -v certbot &> /dev/null; then
    echo "certbot not found. Installing certbot..."
    apt update
    apt install -y certbot python3-certbot-dns-cloudflare
fi

echo "✓ certbot is available"
echo ""

# Check for Cloudflare credentials
CLOUDFLARE_CREDENTIALS="/root/.secrets/cloudflare.ini"
CLOUDFLARE_CREDENTIALS_ALT="/etc/letsencrypt/cloudflare.ini"

if [ ! -f "$CLOUDFLARE_CREDENTIALS" ] && [ ! -f "$CLOUDFLARE_CREDENTIALS_ALT" ]; then
    echo "=========================================="
    echo "Cloudflare credentials not found!"
    echo "=========================================="
    echo ""
    echo "Creating credentials file at: $CLOUDFLARE_CREDENTIALS"
    echo ""
    read -p "Enter your Cloudflare API Token: " CF_TOKEN
    
    mkdir -p "$(dirname $CLOUDFLARE_CREDENTIALS)"
    cat > "$CLOUDFLARE_CREDENTIALS" << EOF
# Cloudflare API token
dns_cloudflare_api_token = $CF_TOKEN
EOF
    chmod 600 "$CLOUDFLARE_CREDENTIALS"
    echo "✓ Credentials file created"
    echo ""
else
    if [ -f "$CLOUDFLARE_CREDENTIALS" ]; then
        echo "✓ Using credentials from: $CLOUDFLARE_CREDENTIALS"
    else
        CLOUDFLARE_CREDENTIALS="$CLOUDFLARE_CREDENTIALS_ALT"
        echo "✓ Using credentials from: $CLOUDFLARE_CREDENTIALS"
    fi
fi

# Create backup directory if it doesn't exist
BACKUP_DIR="/root/cert-backups/$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP_DIR"

# Backup existing certificate if it exists
if [ -d "/etc/letsencrypt/live/pandia.io" ]; then
    echo "Backing up existing certificate to: $BACKUP_DIR"
    cp -r /etc/letsencrypt/live/pandia.io "$BACKUP_DIR/"
    cp -r /etc/letsencrypt/archive/pandia.io "$BACKUP_DIR/" 2>/dev/null || true
    cp -r /etc/letsencrypt/renewal/pandia.io.conf "$BACKUP_DIR/" 2>/dev/null || true
    echo "✓ Backup complete"
    echo ""
fi

echo "=========================================="
echo "Obtaining Wildcard Certificate"
echo "=========================================="
echo ""
echo "This will request a certificate for:"
echo "  - pandia.io"
echo "  - *.pandia.io"
echo ""
echo "Using DNS-01 challenge with Cloudflare"
echo ""

# Request the certificate
certbot certonly \
  --dns-cloudflare \
  --dns-cloudflare-credentials "$CLOUDFLARE_CREDENTIALS" \
  --dns-cloudflare-propagation-seconds 60 \
  -d pandia.io \
  -d "*.pandia.io" \
  --non-interactive \
  --agree-tos \
  --email cloudflare.mck6r@allcloud.dev \
  --preferred-challenges dns-01 \
  --force-renewal

if [ $? -eq 0 ]; then
    echo ""
    echo "=========================================="
    echo "✓ Certificate Created Successfully!"
    echo "=========================================="
    echo ""
    echo "Certificate location:"
    echo "  /etc/letsencrypt/live/pandia.io/"
    echo ""
    echo "Files:"
    ls -lh /etc/letsencrypt/live/pandia.io/
    echo ""
    
    echo "=========================================="
    echo "Certificate Details:"
    echo "=========================================="
    openssl x509 -in /etc/letsencrypt/live/pandia.io/fullchain.pem -noout -text | grep -A3 "Subject:"
    echo ""
    openssl x509 -in /etc/letsencrypt/live/pandia.io/fullchain.pem -noout -text | grep -A10 "Subject Alternative Name"
    echo ""
    
    echo "=========================================="
    echo "Next Steps:"
    echo "=========================================="
    echo ""
    echo "1. Create Kubernetes secret from this certificate:"
    echo "   kubectl create secret tls pandia.io-tls \\"
    echo "     --cert=/etc/letsencrypt/live/pandia.io/fullchain.pem \\"
    echo "     --key=/etc/letsencrypt/live/pandia.io/privkey.pem \\"
    echo "     -n cert-manager \\"
    echo "     --dry-run=client -o yaml | kubectl apply -f -"
    echo ""
    echo "2. Or copy certificate to local machine:"
    echo "   scp colin@192.168.2.57:/etc/letsencrypt/live/pandia.io/fullchain.pem ."
    echo "   scp colin@192.168.2.57:/etc/letsencrypt/live/pandia.io/privkey.pem ."
    echo ""
    echo "3. Certificate will auto-renew. Check with:"
    echo "   certbot renew --dry-run"
    echo ""
else
    echo ""
    echo "=========================================="
    echo "✗ Certificate Creation Failed"
    echo "=========================================="
    echo ""
    echo "Check the error messages above for details."
    echo ""
    echo "Common issues:"
    echo "  - Invalid Cloudflare API token"
    echo "  - DNS propagation timeout"
    echo "  - Rate limiting from Let's Encrypt"
    echo ""
    echo "You can check logs at:"
    echo "  /var/log/letsencrypt/letsencrypt.log"
    exit 1
fi
