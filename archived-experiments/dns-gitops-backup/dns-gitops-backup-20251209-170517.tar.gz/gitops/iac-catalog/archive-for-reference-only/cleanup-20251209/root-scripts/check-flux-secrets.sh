#!/bin/bash
set -euo pipefail

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}=== FluxCD Secret Decryption Check ===${NC}"
echo

# Step 1: Reconcile Git source
echo -e "${YELLOW}Step 1: Reconciling Git source...${NC}"
flux reconcile source git flux-system --timeout=2m
echo

# Step 2: Reconcile kustomizations
echo -e "${YELLOW}Step 2: Reconciling kustomizations...${NC}"
flux reconcile kustomization flux-system --timeout=2m
echo
flux reconcile kustomization infrastructure --timeout=3m
echo

# Step 3: Check for decryption errors in infrastructure
echo -e "${YELLOW}Step 3: Checking for SOPS decryption errors...${NC}"
echo

INFRA_MESSAGE=$(kubectl get kustomization infrastructure -n flux-system -o jsonpath='{.status.conditions[?(@.type=="Ready")].message}' 2>/dev/null || echo "")

if echo "$INFRA_MESSAGE" | grep -q "decryption failed"; then
    echo -e "${RED}✗ DECRYPTION ERRORS DETECTED${NC}"
    echo
    echo "Error details:"
    echo "$INFRA_MESSAGE" | grep -o "decryption failed.*" | head -10
    echo
    
    echo "Affected files:"
    echo "$INFRA_MESSAGE" | grep -oP "decryption failed for '\K[^']+'" | sort -u
    echo
    
    echo -e "${YELLOW}Analysis:${NC}"
    for file in $(echo "$INFRA_MESSAGE" | grep -oP "decryption failed for '\K[^']+'" | sort -u); do
        if [[ -f "catalog/gitops/flux/clusters/staging/infrastructure/$file" ]]; then
            SECRET_FILE="catalog/gitops/flux/clusters/staging/infrastructure/$file"
            echo "  $file:"
            RECIPIENTS=$(grep -A 10 "^sops:" "$SECRET_FILE" | grep "recipient:" | awk '{print $3}')
            echo "    Recipients: $RECIPIENTS"
            if echo "$RECIPIENTS" | grep -q "age1yubikey"; then
                echo -e "    ${RED}Issue: Encrypted with Yubikey${NC}"
            fi
        fi
    done
    echo
    
    echo -e "${BLUE}Solution:${NC}"
    echo "Run: ./fix-sops-decryption.sh"
    echo
    exit 1
else
    echo -e "${GREEN}✓ No decryption errors found${NC}"
fi
echo

# Step 4: Check all kustomizations
echo -e "${YELLOW}Step 4: Checking all kustomizations...${NC}"
kubectl get kustomizations -n flux-system -o custom-columns=\
NAME:.metadata.name,\
READY:.status.conditions[0].status,\
MESSAGE:.status.conditions[0].message
echo

# Step 5: Check encrypted secrets
echo -e "${YELLOW}Step 5: Verifying encrypted secret files...${NC}"
EXPECTED_KEY="age1t8gm5avm9z5pquta4w2kaud7zn3c588mkk2shdpdskvp76wxh3gsxctyst"
WRONG_KEYS=0

while IFS= read -r file; do
    if [[ -n "$file" ]]; then
        RECIPIENTS=$(grep -A 10 "^sops:" "$file" 2>/dev/null | grep "recipient:" | awk '{print $3}' | head -1)
        
        if [[ "$RECIPIENTS" == "$EXPECTED_KEY" ]]; then
            echo -e "  ${GREEN}✓${NC} $file"
        elif [[ "$RECIPIENTS" == age1yubikey* ]]; then
            echo -e "  ${RED}✗${NC} $file (Yubikey: $RECIPIENTS)"
            WRONG_KEYS=$((WRONG_KEYS + 1))
        else
            echo -e "  ${YELLOW}⚠${NC} $file (Key: $RECIPIENTS)"
            WRONG_KEYS=$((WRONG_KEYS + 1))
        fi
    fi
done < <(find catalog/gitops/flux/clusters/staging -name "*.yaml" -type f -exec grep -l "^sops:" {} \;)

echo
if [[ $WRONG_KEYS -gt 0 ]]; then
    echo -e "${RED}Found $WRONG_KEYS secrets with wrong encryption keys${NC}"
    echo "Run: ./fix-sops-decryption.sh to fix them"
    echo
else
    echo -e "${GREEN}All secrets correctly encrypted${NC}"
    echo
fi

# Step 6: Check cert-manager
echo -e "${YELLOW}Step 6: Checking cert-manager status...${NC}"
if kubectl get namespace cert-manager &>/dev/null; then
    echo "cert-manager pods:"
    kubectl get pods -n cert-manager
    echo
    
    if kubectl get helmrelease cert-manager -n cert-manager &>/dev/null; then
        echo "cert-manager HelmRelease:"
        kubectl get helmrelease cert-manager -n cert-manager
        echo
    fi
else
    echo -e "${YELLOW}cert-manager namespace not found${NC}"
    echo
fi

# Step 7: Summary
echo -e "${BLUE}=== Summary ===${NC}"
echo

READY=$(kubectl get kustomizations -n flux-system -o json | jq -r '.items[] | select(.status.conditions[0].status=="True") | .metadata.name' | wc -l | tr -d ' ')
TOTAL=$(kubectl get kustomizations -n flux-system -o json | jq -r '.items[] | .metadata.name' | wc -l | tr -d ' ')

echo "Kustomizations ready: $READY/$TOTAL"

if echo "$INFRA_MESSAGE" | grep -q "decryption failed"; then
    echo -e "${RED}Status: SOPS decryption errors present${NC}"
    echo
    echo "Next steps:"
    echo "1. Review errors above"
    echo "2. Run: ./fix-sops-decryption.sh"
    exit 1
elif [[ $WRONG_KEYS -gt 0 ]]; then
    echo -e "${YELLOW}Status: Secrets need re-encryption${NC}"
    echo
    echo "FluxCD may work but secrets should be re-encrypted with the correct key."
    echo "Run: ./fix-sops-decryption.sh"
    exit 1
else
    echo -e "${GREEN}Status: All secrets decrypting successfully${NC}"
    echo
    echo "✓ FluxCD is working correctly"
    echo "✓ No SOPS decryption errors"
    echo "✓ All secrets encrypted with correct key"
fi

echo
echo -e "${BLUE}=== Complete ===${NC}"
