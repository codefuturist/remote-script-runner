#!/bin/bash
set -e

echo "==================================="
echo "Cert-Manager & SOPS Fix Script"
echo "==================================="
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Step 1: Verify the age key in the cluster matches local
echo "Step 1: Checking age keys..."
CLUSTER_AGE_KEY=$(kubectl get secret sops-age -n flux-system -o jsonpath='{.data.age\.agekey}' | base64 -d | grep "public key" | awk '{print $4}')
LOCAL_AGE_KEY=$(grep "public key" age.agekey | awk '{print $4}')

echo "Cluster age key: $CLUSTER_AGE_KEY"
echo "Local age key:   $LOCAL_AGE_KEY"

if [ "$CLUSTER_AGE_KEY" != "$LOCAL_AGE_KEY" ]; then
    echo -e "${RED}ERROR: Age keys don't match!${NC}"
    echo "The cluster has a different SOPS age key than your local age.agekey file."
    echo ""
    echo "Solution: Update the cluster's sops-age secret with your local key:"
    echo "  kubectl delete secret sops-age -n flux-system"
    echo "  kubectl create secret generic sops-age -n flux-system --from-file=age.agekey=./age.agekey"
    echo ""
    read -p "Do you want to update the cluster secret now? (yes/no): " answer
    if [ "$answer" = "yes" ]; then
        kubectl delete secret sops-age -n flux-system
        kubectl create secret generic sops-age -n flux-system --from-file=age.agekey=./age.agekey
        echo -e "${GREEN}✓ Cluster secret updated${NC}"
    else
        echo "Skipping secret update. You'll need to re-encrypt secrets with the cluster's key."
        exit 1
    fi
else
    echo -e "${GREEN}✓ Age keys match${NC}"
fi
echo ""

# Step 2: Find and re-encrypt secrets that have wrong keys
echo "Step 2: Finding secrets encrypted with wrong age keys..."
export SOPS_AGE_KEY_FILE=age.agekey

SECRETS_TO_FIX=()
while IFS= read -r -d '' file; do
    # Check if file contains sops metadata
    if grep -q "sops:" "$file"; then
        # Get the first age recipient
        FIRST_KEY=$(grep -A 5 "age:" "$file" | grep "recipient:" | head -1 | awk '{print $3}')
        
        if [ "$FIRST_KEY" != "$LOCAL_AGE_KEY" ]; then
            SECRETS_TO_FIX+=("$file")
            echo -e "${YELLOW}  ⚠ $file - encrypted with: $FIRST_KEY${NC}"
        fi
    fi
done < <(find catalog/gitops/flux/clusters/staging -name "*.yaml" -type f -print0)

if [ ${#SECRETS_TO_FIX[@]} -eq 0 ]; then
    echo -e "${GREEN}✓ All secrets use correct age key${NC}"
else
    echo ""
    echo "Found ${#SECRETS_TO_FIX[@]} secrets to re-encrypt"
    read -p "Re-encrypt these secrets? (yes/no): " answer
    
    if [ "$answer" = "yes" ]; then
        for file in "${SECRETS_TO_FIX[@]}"; do
            echo "  Re-encrypting: $file"
            
            # Decrypt to temp file
            TEMP_FILE="/tmp/sops-reencrypt-$$.yaml"
            sops -d "$file" > "$TEMP_FILE"
            
            # Re-encrypt with only the software key
            sops --encrypt --age "$LOCAL_AGE_KEY" --encrypted-regex '^(data|stringData)$' "$TEMP_FILE" > "$file"
            
            # Clean up
            rm "$TEMP_FILE"
            
            # Stage the file
            git add "$file"
        done
        
        echo -e "${GREEN}✓ All secrets re-encrypted${NC}"
        
        # Commit if there are changes
        if ! git diff --cached --quiet; then
            git commit -m "fix: re-encrypt Flux secrets with software age key only

- Updated secrets to use only age1t8gm5avm9z5pquta4w2kaud7zn3c588mkk2shdpdskvp76wxh3gsxctyst
- Removes Yubikey dependencies for Flux-managed secrets
- Ensures Flux can decrypt all secrets in the cluster"
            
            echo ""
            read -p "Push changes to remote? (yes/no): " push_answer
            if [ "$push_answer" = "yes" ]; then
                git push origin develop
                echo -e "${GREEN}✓ Changes pushed${NC}"
            fi
        fi
    fi
fi
echo ""

# Step 3: Check current Flux revision
echo "Step 3: Checking Flux sync status..."
FLUX_REVISION=$(kubectl get gitrepository flux-system -n flux-system -o jsonpath='{.status.artifact.revision}')
LOCAL_COMMIT=$(git rev-parse HEAD)

echo "Flux is at:    $FLUX_REVISION"
echo "Local HEAD is: develop@sha1:$LOCAL_COMMIT"

if [[ ! "$FLUX_REVISION" =~ "$LOCAL_COMMIT" ]]; then
    echo -e "${YELLOW}⚠ Flux is behind. Forcing reconciliation...${NC}"
    flux reconcile source git flux-system
    sleep 5
    echo -e "${GREEN}✓ Git source reconciled${NC}"
else
    echo -e "${GREEN}✓ Flux is up to date${NC}"
fi
echo ""

# Step 4: Reconcile infrastructure
echo "Step 4: Reconciling infrastructure..."
flux reconcile kustomization infrastructure --timeout=3m &
INFRA_PID=$!

# Show progress
for i in {1..30}; do
    if ! kill -0 $INFRA_PID 2>/dev/null; then
        break
    fi
    echo -n "."
    sleep 2
done
echo ""

wait $INFRA_PID
echo -e "${GREEN}✓ Infrastructure reconciled${NC}"
echo ""

# Step 5: Check cert-manager deployment
echo "Step 5: Checking cert-manager deployment..."
sleep 15

CERT_MANAGER_PODS=$(kubectl get pods -n cert-manager --no-headers 2>/dev/null | wc -l | xargs)
if [ "$CERT_MANAGER_PODS" -gt 0 ]; then
    echo -e "${GREEN}✓ Cert-manager pods running:${NC}"
    kubectl get pods -n cert-manager
    
    # Wait for pods to be ready
    echo "  Waiting for pods to be ready..."
    kubectl wait --for=condition=ready pod -l app.kubernetes.io/instance=cert-manager -n cert-manager --timeout=120s 2>/dev/null || true
else
    echo -e "${YELLOW}⚠ No cert-manager pods yet${NC}"
    echo "Checking HelmRelease status..."
    kubectl get helmrelease -n cert-manager 2>/dev/null || echo "  No HelmRelease found"
    
    echo ""
    echo "Infrastructure status:"
    kubectl get kustomization infrastructure -n flux-system -o jsonpath='{.status.conditions[?(@.type=="Ready")].message}' | head -200
fi
echo ""

# Step 6: Reconcile cert-manager-config and check certificates
echo "Step 6: Deploying ClusterIssuers and Certificates..."
flux reconcile kustomization cert-manager-config --timeout=2m 2>/dev/null || echo "Cert-manager-config not ready yet"

sleep 10

ISSUERS=$(kubectl get clusterissuers --no-headers 2>/dev/null | wc -l | xargs)
CERTS=$(kubectl get certificates -n cert-manager --no-headers 2>/dev/null | wc -l | xargs)

if [ "$ISSUERS" -gt 0 ]; then
    echo -e "${GREEN}✓ ClusterIssuers deployed:${NC}"
    kubectl get clusterissuers -o custom-columns=NAME:.metadata.name,READY:.status.conditions[0].status
fi

if [ "$CERTS" -gt 0 ]; then
    echo ""
    echo -e "${GREEN}✓ Certificates found:${NC}"
    kubectl get certificates -n cert-manager -o custom-columns=NAME:.metadata.name,READY:.status.conditions[0].status,SECRET:.spec.secretName,AGE:.metadata.creationTimestamp
    
    echo ""
    echo "Certificate details:"
    kubectl describe certificates -n cert-manager | grep -A 3 "Status:" | head -20
else
    echo -e "${YELLOW}⚠ No certificates found yet${NC}"
fi
echo ""

# Step 7: Summary
echo "==================================="
echo "Summary"
echo "==================================="

echo -n "Infrastructure: "
INFRA_STATUS=$(kubectl get kustomization infrastructure -n flux-system -o jsonpath='{.status.conditions[?(@.type=="Ready")].status}')
if [ "$INFRA_STATUS" = "True" ]; then
    echo -e "${GREEN}✓ Ready${NC}"
else
    echo -e "${RED}✗ Not Ready${NC}"
    kubectl get kustomization infrastructure -n flux-system -o jsonpath='{.status.conditions[?(@.type=="Ready")].message}'
    echo ""
fi

echo -n "Cert-Manager-Config: "
CONFIG_STATUS=$(kubectl get kustomization cert-manager-config -n flux-system -o jsonpath='{.status.conditions[?(@.type=="Ready")].status}' 2>/dev/null)
if [ "$CONFIG_STATUS" = "True" ]; then
    echo -e "${GREEN}✓ Ready${NC}"
elif [ -z "$CONFIG_STATUS" ]; then
    echo -e "${YELLOW}⚠ Not reconciled yet${NC}"
else
    echo -e "${RED}✗ Not Ready${NC}"
fi

echo ""
echo "Cert-Manager Pods: $CERT_MANAGER_PODS"
echo "ClusterIssuers: $ISSUERS"
echo "Certificates: $CERTS"
echo ""
echo -e "${GREEN}Done!${NC}"
echo ""
echo "Next steps:"
echo "  1. Monitor certificate status: kubectl get certificates -A -w"
echo "  2. Check certificate details: kubectl describe certificate <name> -n cert-manager"
echo "  3. View cert-manager logs: kubectl logs -n cert-manager -l app.kubernetes.io/name=cert-manager -f"
