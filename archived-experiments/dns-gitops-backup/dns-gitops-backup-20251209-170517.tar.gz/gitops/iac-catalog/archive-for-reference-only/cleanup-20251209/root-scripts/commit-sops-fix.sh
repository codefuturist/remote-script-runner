#!/bin/bash
set -euo pipefail

echo "=== Committing SOPS Fix for FluxCD ==="
echo

# Make scripts executable
echo "Making scripts executable..."
chmod +x fix-sops-decryption.sh
chmod +x commit-sops-fix.sh
chmod +x check-flux-secrets.sh

# Show what will be committed
echo
echo "Changes to be committed:"
git status --short

echo
read -p "Continue with commit? (y/n) " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Commit cancelled"
    exit 0
fi

# Stage all changes
echo
echo "Staging changes..."
git add .sops.yaml \
        fix-sops-decryption.sh \
        check-flux-secrets.sh \
        SOPS_FIX_INSTRUCTIONS.md \
        COMMIT_THESE_CHANGES.md \
        commit-sops-fix.sh \
        catalog/gitops/flux/clusters/staging/infrastructure/cert-manager/cloudflare-token-secret.yaml

# Commit
echo "Committing..."
git commit -m "fix: update SOPS configuration for FluxCD compatibility

- Configure .sops.yaml to use only software age key for FluxCD paths
- Comment out Yubikey recipients (Flux can't access hardware keys)
- Re-encrypt cloudflare-token-secret with correct key
- Add automated fix script for verification and remediation
- Add comprehensive documentation and troubleshooting guide

Fixes: decryption failures in Flux kustomization reconciliation
Resolves: cert-manager unable to access Cloudflare API token
Related: FluxCD SOPS integration, age encryption"

echo
echo "✓ Committed successfully"
echo

# Ask about pushing
read -p "Push to remote? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "Pushing to origin develop..."
    git push origin develop
    echo
    echo "✓ Pushed successfully"
    echo
    echo "Next steps:"
    echo "1. Run: ./check-flux-secrets.sh (to reconcile and check for errors)"
    echo "2. If errors found, run: ./fix-sops-decryption.sh"
else
    echo "Not pushed. You can push later with: git push origin develop"
fi

echo
echo "=== Complete ==="
