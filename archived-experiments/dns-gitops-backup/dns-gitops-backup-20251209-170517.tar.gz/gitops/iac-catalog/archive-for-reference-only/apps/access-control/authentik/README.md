# Authentik - Identity Provider

This directory contains the Flux HelmRelease configuration for Authentik in the staging environment.

## Overview

Authentik is an open-source Identity Provider focused on flexibility and versatility.

## Configuration

- **Namespace**: `access-control`
- **Chart Repository**: https://charts.goauthentik.io
- **Ingress**: Enabled with Traefik ingress class

## Dependencies

- PostgreSQL database (external)
- Redis (included via subchart)

## Resources

- Server: 1 replica, 100m CPU / 256Mi memory
- Worker: 1 replica, 100m CPU / 256Mi memory

## Deployment

This application is deployed via FluxCD from the main cluster kustomization.
