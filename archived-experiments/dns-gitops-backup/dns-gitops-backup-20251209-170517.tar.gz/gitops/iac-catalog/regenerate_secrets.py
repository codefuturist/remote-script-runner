#!/usr/bin/env python3
"""
Generate random 30-character secrets (alphanumeric only) and re-encrypt with SOPS
"""

import os
import subprocess
import yaml
from pathlib import Path

def generate_secret(length=32):
    """Generate random secure string using /dev/random"""
    result = subprocess.run(
        "</dev/random LC_ALL=C tr -dc '[:graph:]' | head -c32",
        shell=True,
        capture_output=True,
        text=True
    )
    return result.stdout.strip()

def find_secret_files():
    """Find all secret YAML files in staging apps"""
    base_path = Path("catalog/gitops/flux/clusters/staging/apps")
    secret_files = []
    
    for root, dirs, files in os.walk(base_path):
        for file in files:
            if 'secret' in file.lower() and file.endswith('.yaml'):
                if not file.startswith('.decrypted~'):
                    secret_files.append(Path(root) / file)
    
    return secret_files

def create_secret_data(app_name):
    """Create secret data dictionary with random values"""
    return {
        'apiVersion': 'v1',
        'kind': 'Secret',
        'metadata': {
            'name': f'{app_name}-secret',
            'namespace': app_name
        },
        'type': 'Opaque',
        'stringData': {
            'AUTHENTIK_SECRET_KEY': generate_secret(32),
            'AUTHENTIK_POSTGRESQL__PASSWORD': generate_secret(32),
            'AUTHENTIK_POSTGRESQL__USER': 'authentik',
            'AUTHENTIK_POSTGRESQL__NAME': 'authentik',
            'POSTGRES_PASSWORD': generate_secret(32),
            'POSTGRES_USER': 'app_user',
            'POSTGRES_DB': app_name,
            'SECRET_KEY': generate_secret(32),
            'DATABASE_PASSWORD': generate_secret(32),
            'ADMIN_PASSWORD': generate_secret(32),
        }
    }

def encrypt_with_sops(file_path, age_key):
    """Encrypt file with SOPS using age"""
    try:
        subprocess.run(
            ['sops', '--encrypt', '--age', age_key, '--in-place', str(file_path)],
            check=True,
            capture_output=True
        )
        return True
    except subprocess.CalledProcessError as e:
        print(f"⚠ SOPS encryption failed: {e.stderr.decode()}")
        return False
    except FileNotFoundError:
        print("⚠ SOPS not found in PATH")
        return False

def process_secret_file(secret_file):
    """Process a single secret file"""
    print(f"\n📄 Processing: {secret_file}")
    
    # Extract app name from directory
    app_name = secret_file.parent.name
    
    # Backup original
    backup_file = secret_file.with_suffix('.yaml.bak')
    if secret_file.exists():
        import shutil
        shutil.copy2(secret_file, backup_file)
        print(f"📦 Backed up to: {backup_file}")
    
    # Create new secret data
    secret_data = create_secret_data(app_name)
    
    # Write unencrypted YAML
    with open(secret_file, 'w') as f:
        yaml.dump(secret_data, f, default_flow_style=False, sort_keys=False)
    
    print(f"✓ Created new secret with random values")
    
    # Encrypt with SOPS
    age_key = "age14edukvkd5la9hh359qemp2vs9k4gac9fcr2e77kpugz42fqand4qmklc78"
    if encrypt_with_sops(secret_file, age_key):
        print(f"🔒 Encrypted with SOPS")
    else:
        print(f"⚠ File left unencrypted at: {secret_file}")

def main():
    print("🔄 Starting secret regeneration...")
    print("=" * 60)
    
    # Find all secret files
    secret_files = find_secret_files()
    
    if not secret_files:
        print("No secret files found!")
        return
    
    print(f"Found {len(secret_files)} secret file(s):")
    for f in secret_files:
        print(f"  - {f}")
    
    # Process each file
    for secret_file in secret_files:
        try:
            process_secret_file(secret_file)
        except Exception as e:
            print(f"❌ Error processing {secret_file}: {e}")
    
    print("\n" + "=" * 60)
    print("✅ Secret regeneration complete!")
    print("📦 Original files backed up with .bak extension")

if __name__ == '__main__':
    main()
