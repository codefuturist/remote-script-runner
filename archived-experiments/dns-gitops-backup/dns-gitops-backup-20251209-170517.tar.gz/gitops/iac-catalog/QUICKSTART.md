# IaC Catalog - Quick Start Guide

## Overview

This repository implements a **GitOps-based deployment system** where:
1. **Templates** live in `catalog/`
2. **CLI tool** configures templates into instances in `deployments/`
3. **GitOps agent** watches `deployments/` and auto-deploys to servers

## Quick Commands

### Configure a New Deployment

**Single Server:**
```bash
./scripts/cli/configure.sh \
  --template catalog/containers/docker/compose-stacks/wordpress \
  --instance my-app-server01 \
  --environment production \
  --target server-web-01 \
  --param domain=example.com
```

**Multiple Servers (Group):**
```bash
./scripts/cli/configure.sh \
  --template catalog/containers/docker/compose-stacks/monitoring-stack \
  --instance monitoring-stack \
  --environment production \
  --target monitoring-nodes
```

### Deploy to Git (Triggers Auto-Deployment)

```bash
git add deployments/production/my-app-server01/
git commit -m "feat: deploy my-app to production"
git push
```

### List Deployments

```bash
./scripts/cli/list.sh
./scripts/cli/list.sh --environment production
```

## Directory Cheat Sheet

| Directory | Purpose | Managed By |
|-----------|---------|------------|
| `catalog/` | Template library | Template maintainers |
| `deployments/` | Configured instances | CLI tool + GitOps |
| `inventory/` | Server/cluster definitions | Infrastructure team |
| `environments/` | Environment defaults | DevOps team |
| `.gitops/` | GitOps agent config | Platform team |
| `.deployments/` | State & history | GitOps agent |

## Key Files

### Instance Configuration
```
deployments/production/my-app/
├── manifest.yml          # What template, version, metadata
├── docker-compose.yml    # Application config
├── .env                  # Environment variables (gitignored)
└── target.yml            # Where to deploy (single server)
   OR
└── targets.yml           # Where to deploy (multiple servers)
```

### Single Server Target
```yaml
targets:
  - type: docker-compose
    host: server-web-01    # One specific server
    inventory: inventory/production/servers.yml
```

### Multi-Server Target
```yaml
targets:
  - type: docker-compose
    group: monitoring-nodes  # Server group (ALL members)
    inventory: inventory/production/servers.yml
    strategy: rolling
```

## Workflow

```
┌────────────┐
│  Template  │  catalog/containers/docker/compose-stacks/wordpress
└──────┬─────┘
       │
       │ CLI: ./scripts/cli/configure.sh
       ▼
┌────────────┐
│  Instance  │  deployments/production/my-app/
└──────┬─────┘
       │
       │ Git: commit & push
       ▼
┌────────────┐
│   GitOps   │  Watches deployments/, auto-deploys
│   Agent    │
└──────┬─────┘
       │
       │ SSH/API
       ▼
┌────────────┐
│   Server   │  server-web-01 (from inventory)
└────────────┘
```

## Common Tasks

### Add a New Server to Inventory
```bash
# Edit inventory/production/servers.yml
vim inventory/production/servers.yml

# Add:
# - id: server-web-03
#   hostname: web03.prod.example.com
#   ip: 10.0.1.13
#   platform: docker
```

### Create a Server Group
```bash
# Edit inventory/production/groups.yml
vim inventory/production/groups.yml

# Add:
# groups:
#   web-servers:
#     members:
#       - server-web-01
#       - server-web-02
#       - server-web-03
```

### Deploy to New Environment
```bash
# Configure for staging
./scripts/cli/configure.sh \
  --template catalog/containers/docker/compose-stacks/my-app \
  --instance my-app-staging \
  --environment staging \
  --target server-staging-01

# Commit and push
git add deployments/staging/my-app-staging/
git commit -m "feat: add staging deployment"
git push
```

## Important Notes

⚠️ **Security:**
- `.env` files are gitignored - DO NOT commit secrets
- Use secret management systems (Vault, AWS Secrets Manager)
- Reference secrets in `environments/{env}/secrets/`

📝 **Best Practices:**
- Always specify template versions
- Test in dev/staging before production
- Use descriptive instance IDs
- Document complex deployments

🔍 **Troubleshooting:**
- Check `.deployments/history/` for deployment logs
- Use `--dry-run` flag to validate configurations
- Review GitOps agent logs for errors

## Next Steps

1. Review [ARCHITECTURE.md](./docs/ARCHITECTURE.md) for detailed design
2. Check [deployments/README.md](./deployments/README.md) for deployment patterns
3. See [inventory/README.md](./inventory/README.md) for inventory management
4. Configure GitOps agent in `.gitops/agent-config.yml`

## Getting Help

- **Templates:** See `catalog/` for available templates
- **Examples:** Check `deployments/production/` for working examples
- **Documentation:** Read `docs/ARCHITECTURE.md` for full details
