# FluxCD + SOPS Testing & Debug Guide

This guide provides comprehensive testing and debugging tools for the FluxCD and SOPS integration with external secrets management.

## Quick Start

### Run All Tests
```bash
./test-flux-sops.sh
```

### Debug Issues
```bash
./debug-flux-sops.sh
```

## Test Suite Overview

The `test-flux-sops.sh` script runs 10 comprehensive tests:

### 1. Required Tools Check
- Verifies installation of: `sops`, `flux`, `kubectl`, `age`, `yq`
- **Fix**: Install missing tools with `brew install <tool-name>`

### 2. SOPS Configuration Validation
- Checks `.sops.yaml` exists and is properly configured
- Verifies FluxCD path regex: `catalog/gitops/flux/.*\.ya?ml$`
- Ensures software key is configured for Flux (no Yubikeys)
- **Fix**: Review `.sops.yaml` and ensure FluxCD paths use only software age key

### 3. Age Key Validation
- Verifies `age.agekey` exists and has correct format
- Checks file permissions (should be 600 or 400)
- **Fix**: `chmod 600 age.agekey`

### 4. Default Preferences Validation
- Checks `iac-manager/config/preferences/default.yaml`
- Verifies external secret preferences exist
- Validates patterns: `auth.existingSecret`, `spec.values.existingSecret`
- Checks conditional rules for automatic secret substitution
- **Fix**: Review default.yaml to ensure external secret patterns are defined

### 5. SOPS Encryption/Decryption Test
- Creates a test secret
- Encrypts it with SOPS
- Verifies encryption markers (`sops:`, `ENC[`)
- Tests decryption
- **Fix**: Check SOPS configuration and age key if tests fail

### 6. Existing Flux SOPS Secrets
- Scans `catalog/gitops/flux/` for encrypted secrets
- Lists all SOPS-encrypted files
- **Info**: Shows how many secrets are already encrypted in your Flux paths

### 7. Secret Naming Conventions
- Validates variable substitution patterns (`${app-name}`)
- Checks for consistent naming: `${app-name}-secret`, `${app-name}-postgresql-secret`, etc.
- **Fix**: Ensure naming patterns in default.yaml use template variables

### 8. Flux Decryption Setup (Cluster)
- **Requires**: Active Kubernetes cluster connection
- Checks `flux-system` namespace exists
- Verifies `sops-age` secret is deployed
- Validates Kustomizations have decryption configured
- **Fix**: Create sops-age secret:
  ```bash
  kubectl create secret generic sops-age \
    --from-file=age.agekey=./age.agekey \
    -n flux-system
  ```

### 9. Merge Strategy Validation
- Checks that merge strategies are defined in preferences
- Verifies `override` strategy is used for secrets
- **Info**: Override ensures external secrets take precedence

### 10. Sensitive Data Exposure Check
- Scans configuration for hardcoded passwords/secrets
- Ensures only references are used, not actual values
- **Fix**: Remove any hardcoded credentials and use external secrets

## Debug Tool Features

The `debug-flux-sops.sh` script provides detailed diagnostics:

### Environment Check
- Shows current directory, user, and file availability
- Lists all required configuration files

### SOPS Configuration Details
- Displays complete `.sops.yaml` contents
- Shows all configured age recipients

### Age Key Information
- Derives public key from private key
- Verifies public key is in `.sops.yaml`
- Shows file permissions

### Live Encryption/Decryption Test
- Creates and encrypts a test secret
- Shows encrypted content
- Validates decryption works
- Auto-cleans up test files

### FluxCD Cluster Status
- Shows all Flux resources (GitRepository, HelmRepository, Kustomization, HelmRelease)
- Displays sops-age secret configuration
- Lists Flux events

### Kustomization Decryption Check
- Examines each Kustomization for decryption configuration
- Shows decryption provider details

### Encrypted Secrets Inventory
- Lists all SOPS-encrypted secrets in repository
- Tests if each can be decrypted with current key

### Preferences Analysis
- Shows all external secret preferences
- Displays conditional rules

### Troubleshooting Recommendations
- Provides solutions for common issues
- Includes useful commands for debugging

## Configuration Files

### `.sops.yaml`
Main SOPS configuration file that defines:
- **FluxCD Path**: Uses only software age key (Flux can access this in-cluster)
- **Non-FluxCD Paths**: Can use Yubikeys for additional security
- **Encrypted Fields**: Only encrypts `data` and `stringData` fields

### `age.agekey`
Private age encryption key:
- **Permissions**: Must be 600 or 400
- **Location**: Root of repository
- **Deployment**: Must be deployed to cluster as `sops-age` secret in `flux-system` namespace

### `iac-manager/config/preferences/default.yaml`
Application preferences that prioritize external secrets:
- **Global Preferences**: Apply to all resources
- **Conditional Rules**: Automatically substitute external secrets based on field detection
- **Naming Patterns**: Use `${app-name}` for templating

## Common Scenarios

### Creating a New SOPS Secret

```bash
# 1. Create secret file in Flux path
cat > catalog/gitops/flux/clusters/production/apps/myapp/myapp-secret.yaml <<EOF
apiVersion: v1
kind: Secret
metadata:
  name: myapp-secret
  namespace: myapp
type: Opaque
stringData:
  username: admin
  password: changeme
EOF

# 2. Encrypt with SOPS
sops -e -i catalog/gitops/flux/clusters/production/apps/myapp/myapp-secret.yaml

# 3. Verify encryption
grep "sops:" catalog/gitops/flux/clusters/production/apps/myapp/myapp-secret.yaml

# 4. Commit and push
git add catalog/gitops/flux/clusters/production/apps/myapp/myapp-secret.yaml
git commit -m "feat: add myapp secret"
git push
```

### Using External Secret in HelmRelease

```yaml
apiVersion: helm.toolkit.fluxcd.io/v2beta1
kind: HelmRelease
metadata:
  name: myapp
  namespace: myapp
spec:
  chart:
    spec:
      chart: myapp
      version: 1.0.0
      sourceRef:
        kind: HelmRepository
        name: myrepo
  values:
    # The default.yaml preferences will automatically substitute
    # these with existingSecret if the fields exist in the chart
    auth:
      existingSecret: myapp-secret  # Points to SOPS-encrypted secret
      # password: "hardcoded"  # Don't do this!
```

### Debugging Decryption Issues

```bash
# 1. Check if secret exists in cluster
kubectl get secret myapp-secret -n myapp

# 2. Check if it's encrypted
kubectl get secret myapp-secret -n myapp -o yaml | grep "sops:"

# 3. Check Flux Kustomization
kubectl get kustomization -n flux-system
kubectl describe kustomization <name> -n flux-system

# 4. Check Flux logs
kubectl logs -n flux-system deploy/kustomize-controller -f

# 5. Force reconciliation
flux reconcile kustomization <name> --with-source
```

### Rotating Age Key

```bash
# 1. Generate new age key
age-keygen -o age-new.agekey

# 2. Add new public key to .sops.yaml (keep old one temporarily)
# Edit .sops.yaml and add new key

# 3. Re-encrypt all secrets with both keys
find catalog/gitops/flux -name "*.yaml" -exec grep -l "sops:" {} \; | while read file; do
  sops updatekeys -y "$file"
done

# 4. Update cluster secret
kubectl create secret generic sops-age \
  --from-file=age.agekey=./age-new.agekey \
  -n flux-system \
  --dry-run=client -o yaml | kubectl apply -f -

# 5. Test and verify all secrets decrypt
./test-flux-sops.sh

# 6. Remove old key from .sops.yaml after verification
```

## Best Practices

1. **Always use external secrets** for sensitive data in Helm charts
2. **Keep age.agekey secure** with proper file permissions (600)
3. **Never commit unencrypted secrets** to git
4. **Use software age key only** for FluxCD paths (no Yubikeys)
5. **Test encryption/decryption** before committing
6. **Monitor Flux logs** for decryption errors
7. **Use template variables** (`${app-name}`) in preferences for consistency
8. **Run tests regularly** to catch configuration drift

## Troubleshooting Quick Reference

| Issue | Check | Solution |
|-------|-------|----------|
| Secret not decrypting | `kubectl logs -n flux-system deploy/kustomize-controller` | Verify sops-age secret and Kustomization decryption config |
| SOPS encryption fails | `.sops.yaml` path_regex | Ensure file path matches regex pattern |
| Helm chart ignoring external secret | HelmRelease values | Check if conditional rules in default.yaml match chart fields |
| Age key not working | Public key derivation | Run `age-keygen -y age.agekey` and compare with .sops.yaml |
| Permission denied | File permissions | Run `chmod 600 age.agekey` |

## CI/CD Integration

### GitHub Actions Example

```yaml
name: Test SOPS Configuration
on: [push, pull_request]

jobs:
  test-sops:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Install tools
        run: |
          brew install sops age yq
      
      - name: Setup age key
        run: |
          echo "${{ secrets.AGE_SECRET_KEY }}" > age.agekey
          chmod 600 age.agekey
      
      - name: Run SOPS tests
        run: ./test-flux-sops.sh
```

## Additional Resources

- [SOPS Documentation](https://github.com/mozilla/sops)
- [FluxCD SOPS Guide](https://fluxcd.io/docs/guides/mozilla-sops/)
- [Age Encryption](https://github.com/FiloSottile/age)
- [Helm External Secrets Pattern](https://helm.sh/docs/howto/charts_tips_and_tricks/#using-the-tpl-function)

## Support

If tests fail or you encounter issues:
1. Run `./debug-flux-sops.sh` for detailed diagnostics
2. Check the troubleshooting section above
3. Review Flux logs: `kubectl logs -n flux-system deploy/kustomize-controller -f`
4. Verify age key and SOPS configuration match
