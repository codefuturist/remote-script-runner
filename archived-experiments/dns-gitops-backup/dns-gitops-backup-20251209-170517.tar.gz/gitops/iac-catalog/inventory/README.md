# Infrastructure Inventory - README

This directory contains the **infrastructure inventory** - definitions of all servers, clusters, and groups available for deployment.

## Directory Structure

```
inventory/
├── production/
│   ├── servers.yml    # Physical/virtual servers
│   ├── clusters.yml   # Kubernetes/Swarm clusters
│   └── groups.yml     # Server groups for multi-server deployments
├── staging/
└── development/
```

## Purpose

The inventory defines:
- **Servers**: Individual VMs, bare metal, or cloud instances
- **Clusters**: Kubernetes clusters, Docker Swarm clusters
- **Groups**: Logical groupings of servers for deployment targeting

## Usage

### In Deployment Targets

Reference inventory in `target.yml`:

```yaml
targets:
  - type: docker-compose
    host: server-web-01              # Reference to servers.yml
    inventory: inventory/production/servers.yml
```

Or for multi-server:

```yaml
targets:
  - type: docker-compose
    group: monitoring-nodes          # Reference to groups.yml
    inventory: inventory/production/servers.yml
```

### Server Definition Example

```yaml
servers:
  - id: server-web-01
    hostname: web01.prod.example.com
    ip: 10.0.1.10
    type: vm
    platform: docker
    labels:
      role: web
      zone: us-east-1a
```

### Group Definition Example

```yaml
groups:
  monitoring-nodes:
    description: "Monitoring infrastructure servers"
    members:
      - server-mon-01
      - server-mon-02
      - server-mon-03
```

## Maintenance

- Update inventory when infrastructure changes
- Keep in sync with actual infrastructure (IaC provisioning)
- Use labels for dynamic grouping and filtering

## See Also

- `deployments/` - Instance deployments that reference this inventory
- `environments/` - Environment-specific configurations
