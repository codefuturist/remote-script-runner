# IaC Catalog Architecture - Deployment System

## Overview

This IaC catalog implements a **template-based GitOps deployment system** that supports:
- ✅ Multi-target deployments (single server, multi-server, clusters)
- ✅ Environment separation (production, staging, development)
- ✅ Template library with version control
- ✅ CLI-based configuration workflow
- ✅ Automated GitOps deployments
- ✅ Infrastructure inventory management

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                         Template Library                        │
│                         (catalog/)                              │
│  Reusable, versioned templates for infrastructure & apps       │
└─────────────────────────┬───────────────────────────────────────┘
                          │
                          │ (1) CLI Configure
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│                    Configured Instances                         │
│                    (deployments/)                               │
│  Ready-to-deploy configurations per environment                │
│  - manifest.yml (metadata)                                     │
│  - docker-compose.yml (config)                                 │
│  - .env (variables)                                            │
│  - target.yml (deployment target)                              │
└─────────────────────────┬───────────────────────────────────────┘
                          │
                          │ (2) Git Commit & Push
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│                      GitOps Agent                               │
│                      (.gitops/)                                 │
│  Watches deployments/, reconciles with actual state            │
└─────────────────────────┬───────────────────────────────────────┘
                          │
                          │ (3) Automated Deployment
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│                    Infrastructure                               │
│                    (inventory/)                                 │
│  Physical servers, VMs, clusters                               │
└─────────────────────────────────────────────────────────────────┘
```

## Directory Structure

```
iac-catalog/
│
├── catalog/                          # Template Library (Source of Truth)
│   ├── cloud/                        # Cloud provider templates
│   ├── containers/                   # Container/Docker templates
│   ├── on-premises/                  # On-prem infrastructure templates
│   ├── gitops/                       # GitOps tool configurations
│   ├── self-hosted/                  # Self-hosted service templates
│   └── templates/                    # Application patterns
│
├── deployments/                      # Configured Instances (GitOps Watches)
│   ├── production/
│   │   ├── inventory.yml             # Environment inventory reference
│   │   ├── app-wordpress-server01/   # Single-server deployment
│   │   │   ├── manifest.yml          # Instance metadata
│   │   │   ├── docker-compose.yml    # Application config
│   │   │   ├── .env                  # Environment variables
│   │   │   └── target.yml            # Single server target
│   │   └── monitoring-stack/         # Multi-server deployment
│   │       ├── manifest.yml
│   │       ├── docker-compose.yml
│   │       ├── .env
│   │       └── targets.yml           # Multiple servers (group)
│   ├── staging/
│   └── development/
│
├── inventory/                        # Infrastructure Inventory
│   ├── production/
│   │   ├── servers.yml               # Server definitions
│   │   ├── clusters.yml              # K8s/Swarm clusters
│   │   └── groups.yml                # Server groups
│   ├── staging/
│   └── development/
│
├── environments/                     # Environment Configurations
│   ├── production/
│   │   ├── defaults.yml              # Environment-wide defaults
│   │   ├── secrets/                  # Secret references (not actual secrets)
│   │   └── overrides/                # Service-specific overrides
│   ├── staging/
│   └── development/
│
├── .deployments/                     # Deployment State & History
│   ├── history/                      # Deployment audit trail
│   │   ├── production/
│   │   ├── staging/
│   │   └── development/
│   └── state/                        # Current deployment state
│
├── .gitops/                          # GitOps Agent Configuration
│   └── agent-config.yml              # Agent settings
│
└── scripts/
    └── cli/                          # CLI Tools
        ├── configure.sh              # Configure template → instance
        ├── deploy.sh                 # Manual deployment trigger
        └── list.sh                   # List deployments
```

## Workflow

### 1. Template → Instance Configuration

Use the CLI to configure a template into a deployable instance:

```bash
# Single server deployment
./scripts/cli/configure.sh \
  --template catalog/containers/docker/compose-stacks/wordpress \
  --instance app-wordpress-server01 \
  --environment production \
  --target server-web-01 \
  --param domain=blog.example.com \
  --param db_password=secret123

# Multi-server deployment (group)
./scripts/cli/configure.sh \
  --template catalog/containers/docker/compose-stacks/monitoring-stack \
  --instance monitoring-stack \
  --environment production \
  --target monitoring-nodes \
  --param grafana_password=admin123
```

**This creates:**
```
deployments/production/app-wordpress-server01/
├── manifest.yml              # What template, version, metadata
├── docker-compose.yml        # Application configuration
├── .env                      # Environment variables
└── target.yml                # Where to deploy (single server)
```

### 2. Review & Commit

```bash
# Review generated files
cat deployments/production/app-wordpress-server01/manifest.yml
cat deployments/production/app-wordpress-server01/docker-compose.yml

# Edit as needed
vim deployments/production/app-wordpress-server01/.env

# Commit to Git
git add deployments/production/app-wordpress-server01/
git commit -m "feat: deploy wordpress to server-web-01"
git push
```

### 3. Automatic Deployment

The GitOps agent:
1. Detects changes in `deployments/`
2. Reads `target.yml` to determine deployment target(s)
3. Connects to target server(s)
4. Deploys the configuration
5. Verifies health checks
6. Records deployment history

## Deployment Patterns

### Single Server Deployment

**Use Case:** Deploy to one specific server

**Target Configuration:**
```yaml
# target.yml
targets:
  - type: docker-compose
    host: server-web-01              # Single server ID
    inventory: inventory/production/servers.yml
```

**Directory:**
```
deployments/production/app-wordpress-server01/
└── target.yml    # Points to ONE server
```

### Multi-Server Deployment (Group)

**Use Case:** Deploy to multiple servers (same config replicated)

**Target Configuration:**
```yaml
# targets.yml (note: plural)
targets:
  - type: docker-compose
    group: monitoring-nodes          # Server group
    inventory: inventory/production/servers.yml
    strategy: rolling                # Deployment strategy
    max_unavailable: 1
```

**Directory:**
```
deployments/production/monitoring-stack/
└── targets.yml   # Points to GROUP of servers
```

### Multi-Server Distributed Deployment

**Use Case:** Different services to different server groups

**Directory:**
```
deployments/production/distributed-app/
├── manifest.yml
├── frontend/
│   ├── docker-compose.yml
│   └── targets.yml         # → web-servers group
├── backend/
│   ├── docker-compose.yml
│   └── targets.yml         # → api-servers group
└── database/
    ├── docker-compose.yml
    └── targets.yml         # → db-servers group
```

## Inventory Management

### Server Definition

```yaml
# inventory/production/servers.yml
servers:
  - id: server-web-01
    hostname: web01.prod.example.com
    ip: 10.0.1.10
    type: vm
    platform: docker
    labels:
      role: web
      zone: us-east-1a
```

### Group Definition

```yaml
# inventory/production/groups.yml
groups:
  monitoring-nodes:
    description: "Monitoring infrastructure servers"
    members:
      - server-mon-01
      - server-mon-02
      - server-mon-03
```

## Environment Defaults

Each environment has default settings:

```yaml
# environments/production/defaults.yml
environment: production
resources:
  default:
    cpu_limit: "2000m"
    memory_limit: "4Gi"
replicas:
  default: 3
  minimum: 2
monitoring:
  enabled: true
  retention_days: 90
```

## GitOps Agent

The agent configuration:

```yaml
# .gitops/agent-config.yml
watch:
  directories:
    - deployments/production/
    - deployments/staging/
    
reconciliation:
  interval: 5m
  prune: true
  
deployment:
  platforms:
    - docker-compose
    - kubernetes
```

## Security Considerations

1. **Secrets Management**
   - DO NOT commit `.env` files with real secrets
   - Use secret management systems (Vault, AWS Secrets Manager)
   - Reference secrets in `environments/{env}/secrets/`

2. **Access Control**
   - GitOps agent needs SSH access to target servers
   - Use SSH keys, not passwords
   - Implement RBAC for Git repository access

3. **Audit Trail**
   - All deployments recorded in `.deployments/history/`
   - Git history provides full audit trail

## Best Practices

1. **Template Versioning**
   - Always specify template version in `manifest.yml`
   - Use semantic versioning for templates

2. **Instance Naming**
   - Use descriptive instance IDs: `app-service-location`
   - Examples: `app-wordpress-server01`, `monitoring-stack`

3. **Environment Separation**
   - Never deploy production configs to staging/dev
   - Use different inventory files per environment

4. **Testing**
   - Test in development first
   - Promote through staging to production
   - Use `--dry-run` flag for validation

5. **Documentation**
   - Document each instance in `manifest.yml`
   - Add README.md for complex deployments

## Troubleshooting

### Check Deployment Status

```bash
./scripts/cli/list.sh
./scripts/cli/list.sh --environment production
```

### Manual Deployment

```bash
./scripts/cli/deploy.sh \
  --instance app-wordpress-server01 \
  --environment production
```

### View Deployment History

```bash
ls -la .deployments/history/production/app-wordpress-server01/
```

### Validate Configuration

```bash
# Dry run to see what would be deployed
./scripts/cli/configure.sh \
  --template catalog/containers/docker/compose-stacks/wordpress \
  --instance test \
  --environment production \
  --target server-web-01 \
  --dry-run
```

## Next Steps

1. **Implement GitOps Agent**
   - Build or use existing (Flux, ArgoCD, custom)
   - Configure to watch `deployments/`

2. **Set Up Secret Management**
   - Integrate with Vault or cloud secret managers
   - Update `.env` files to reference secrets

3. **Add Monitoring**
   - Deploy monitoring stack
   - Set up alerts for deployment failures

4. **CI/CD Integration**
   - Add GitHub Actions for validation
   - Automate template testing

## References

- [Deployments README](./deployments/README.md)
- [Inventory README](./inventory/README.md)
- [GitOps Best Practices](https://opengitops.dev/)
- [Docker Compose Specification](https://docs.docker.com/compose/compose-file/)
