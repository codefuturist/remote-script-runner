# GitOps Auto-Sync System

Automated synchronization system that clones your IaC repository, decrypts SOPS-encrypted secrets, and manages multiple Docker Compose applications across servers.

## Features

- **Full Repository Clone**: Maintains complete repo with configs and secrets
- **Multi-Application Support**: Automatically discovers and manages all applications
- **SOPS Encryption**: Secure secret management with age encryption
- **Automatic Discovery**: Finds all `.env.sops` files and docker-compose stacks
- **Smart Restarts**: Only restarts stacks that have decrypted secrets
- **Systemd Timer**: Syncs every 15 minutes automatically
- **Concurrency Protection**: Lock file prevents overlapping syncs

## Architecture

```
/opt/gitops/
├── .age.key                    # Age encryption key
├── gitops-sync.sh             # Main sync script
└── iac-catalog/               # Full repository clone
    └── deployments/
        ├── production/
        │   ├── traefik/
        │   │   ├── secrets/
        │   │   │   ├── cf_dns_api_token.sops       # Encrypted secret
        │   │   │   ├── dashboard_users.sops        # Encrypted secret
        │   │   │   └── ... (decrypted at runtime)
        │   │   ├── .env                            # Non-sensitive config
        │   │   └── docker-compose.yml
        │   ├── mariadb/
        │   │   ├── secrets/
        │   │   │   ├── mysql_root_password.sops
        │   │   │   └── mysql_password.sops
        │   │   └── docker-compose.yml
        │   ├── postgres/                           # Exception: uses .env.sops
        │   │   ├── .env.sops                       # Legacy format
        │   │   └── docker-compose.yml
        │   └── ... (more apps)
        └── staging/
            └── ... (staging apps)
```

## How It Works

1. **Repository Sync**: Clones or pulls latest from GitHub
2. **Secret Discovery**: Finds all `*.sops` files in deployments/ (individual secrets and .env.sops files)
3. **Decryption**: Decrypts each `.sops` file to its original name using age key
4. **Stack Detection**: Finds docker-compose.yml files with decrypted secrets
5. **Restart**: Restarts only running stacks that have updated secrets

## Secret Management Patterns

### File-Based Secrets (Default)

**Recommended for most applications**. Each secret in its own file:

```
myapp/
├── secrets/
│   ├── .gitignore
│   ├── api_key.sops          # Encrypted (in Git)
│   ├── api_key               # Decrypted (runtime only)
│   ├── db_password.sops      # Encrypted (in Git)
│   └── db_password           # Decrypted (runtime only)
└── docker-compose.yml
```

```yaml
# docker-compose.yml
services:
  myapp:
    environment:
      - API_KEY_FILE=/run/secrets/api_key
      - DB_PASSWORD_FILE=/run/secrets/db_password
    secrets:
      - api_key
      - db_password

secrets:
  api_key:
    file: ./secrets/api_key
  db_password:
    file: ./secrets/db_password
```

**Benefits:**
- Docker secrets API (mounted at `/run/secrets/`)
- Granular secret rotation
- Better security isolation
- Clear audit trail per secret

### Legacy .env.sops (Supported)

**For postgres and existing applications**. Single encrypted file:

```
myapp/
├── .env.sops    # All secrets encrypted
├── .env         # Decrypted (runtime only)
└── docker-compose.yml
```

```yaml
# docker-compose.yml
services:
  myapp:
    env_file: .env
```

**When to use:**
- Legacy applications
- postgres (keep as-is)
- Many related secrets that change together

## Quick Start

### 1. Deploy to Server

```bash
# Deploy to single server
cd scripts
./setup-gitops-sync.sh 192.168.2.57 sudo_password

# Deploy to multiple servers
./setup-gitops-sync.sh 192.168.2.57 12345
./setup-gitops-sync.sh 192.168.2.50 12345
```

### 2. Add New Application

To add a new application to auto-sync:

```bash
# 1. Create application directory
mkdir -p deployments/production/myapp

# 2. Create docker-compose.yml
cat > deployments/production/myapp/docker-compose.yml <<EOF
version: '3.8'
services:
  myapp:
    image: myapp:latest
    env_file: .env
EOF

# 3. Create secrets
cat > deployments/production/myapp/.env <<EOF
DATABASE_PASSWORD=secret123
API_KEY=mykey456
EOF

# 4. Encrypt secrets
sops --encrypt deployments/production/myapp/.env > deployments/production/myapp/.env.sops

# 5. Remove plain .env and commit
rm deployments/production/myapp/.env
git add deployments/production/myapp/
git commit -m "feat: add myapp deployment"
git push

# Auto-sync will handle the rest!
```

### 3. Update Secrets

```bash
# 1. Decrypt locally
sops --decrypt deployments/production/myapp/.env.sops > deployments/production/myapp/.env

# 2. Edit secrets
vi deployments/production/myapp/.env

# 3. Re-encrypt
sops --encrypt deployments/production/myapp/.env > deployments/production/myapp/.env.sops

# 4. Commit and push
rm deployments/production/myapp/.env
git add deployments/production/myapp/.env.sops
git commit -m "chore: update myapp secrets"
git push

# Servers will auto-sync within 15 minutes
```

## Management Commands

### Check Status

```bash
# Timer status
ssh user@server systemctl status gitops-sync.timer

# Last run
ssh user@server systemctl status gitops-sync.service

# View logs
ssh user@server tail -f /tmp/gitops-sync.log
```

### Manual Sync

```bash
# Trigger immediate sync
ssh user@server sudo /opt/gitops/gitops-sync.sh

# Or from multiple servers
for server in 192.168.2.57 192.168.2.50; do
  ssh colin@$server "sudo /opt/gitops/gitops-sync.sh"
done
```

### Repository Access

```bash
# Browse repository on server
ssh user@server "ls -la /opt/gitops/iac-catalog/deployments/production"

# Check current commit
ssh user@server "cd /opt/gitops/iac-catalog && git log -1"

# View decrypted secrets (be careful!)
ssh user@server "cat /opt/gitops/iac-catalog/deployments/production/traefik/.env"
```

## Configuration

Environment variables (set in systemd service):

- `REPO_URL`: Git repository URL (default: https://github.com/codefuturist/iac-catalog.git)
- `REPO_BRANCH`: Branch to track (default: develop)
- `GITOPS_ROOT`: Base directory (default: /opt/gitops)
- `AGE_KEY_FILE`: Age encryption key path (default: /opt/gitops/.age.key)
- `LOG_FILE`: Log file location (default: /tmp/gitops-sync.log)

To customize, edit `/etc/systemd/system/gitops-sync.service`:

```bash
ssh user@server sudo vi /etc/systemd/system/gitops-sync.service
# Edit Environment= lines
ssh user@server sudo systemctl daemon-reload
ssh user@server sudo systemctl restart gitops-sync.timer
```

## Sync Frequency

Default: Every 15 minutes

To change frequency, edit `/etc/systemd/system/gitops-sync.timer`:

```bash
# Every 5 minutes
OnCalendar=*:0/5

# Every hour at :00
OnCalendar=hourly

# Every 30 minutes
OnCalendar=*:0/30
```

Then reload:

```bash
ssh user@server sudo systemctl daemon-reload
ssh user@server sudo systemctl restart gitops-sync.timer
```

## Troubleshooting

### Check Sync Status

```bash
# Is timer running?
ssh user@server systemctl is-active gitops-sync.timer

# When is next sync?
ssh user@server systemctl list-timers gitops-sync.timer

# Recent runs
ssh user@server journalctl -u gitops-sync.service -n 50
```

### Test Decryption

```bash
# Test age key works
ssh user@server "export SOPS_AGE_KEY_FILE=/opt/gitops/.age.key && \
  cd /opt/gitops/iac-catalog && \
  sops --decrypt deployments/production/traefik/.env.sops"
```

### Manual Repository Reset

```bash
# If repo gets corrupted
ssh user@server "sudo rm -rf /opt/gitops/iac-catalog && \
  sudo /opt/gitops/gitops-sync.sh"
```

### View What Changed

```bash
# See git log on server
ssh user@server "cd /opt/gitops/iac-catalog && git log -5 --oneline"

# Compare with your local
cd /Users/colin/Developer/Projects/personal/iac-catalog
git log -5 --oneline
```

## Security Considerations

1. **Age Key Protection**: 
   - Stored at `/opt/gitops/.age.key` with 600 permissions
   - Only accessible by user running sync

2. **Decrypted Secrets**:
   - `.env` files created with 600 permissions
   - Never committed to Git
   - Only exist on servers

3. **Git Repository**:
   - Public read access (HTTPS clone)
   - No credentials stored on servers
   - Pull-only access

4. **Lock File**:
   - Prevents concurrent syncs
   - Auto-cleanup of stale locks

## Adding More Servers

```bash
# Just run setup script for each server
./scripts/setup-gitops-sync.sh new-server.local password
```

All servers will independently:
- Clone the repository
- Decrypt their secrets
- Restart their stacks
- Stay in sync with Git

## Webhook Integration (Optional)

For instant deployments on push:

1. Create webhook endpoint (using `webhook-receiver.sh` or similar)
2. Add to GitHub repository settings
3. Trigger sync on push events

```bash
# Example webhook trigger
curl -X POST http://server:9000/hook/gitops-sync
```

## Logs

All operations logged to `/tmp/gitops-sync.log`:

```bash
# Real-time monitoring
ssh user@server tail -f /tmp/gitops-sync.log

# Search for errors
ssh user@server grep ERROR /tmp/gitops-sync.log

# Today's activity
ssh user@server grep "$(date +'%Y-%m-%d')" /tmp/gitops-sync.log
```

## Backup & Recovery

### Backup Age Key

```bash
# From server
scp user@server:/opt/gitops/.age.key ~/backup/age.key.backup

# Keep this safe! Without it, you cannot decrypt secrets
```

### Restore

```bash
# On new/recovered server
./scripts/setup-gitops-sync.sh new-server password
```

## Comparison: Old vs New System

| Feature | Old (Traefik-only) | New (GitOps) |
|---------|-------------------|--------------|
| Scope | Single app | All apps |
| Repository | Temp clone | Persistent clone |
| Discovery | Hardcoded path | Automatic |
| Configs | Not synced | Fully synced |
| Scalability | One app | Unlimited apps |
| Path | `/opt/traefik` | `/opt/gitops/iac-catalog` |

## Migration from Old System

Old Traefik-specific sync still works. To migrate:

```bash
# 1. Deploy new system
./scripts/setup-gitops-sync.sh server password

# 2. Disable old timer
ssh user@server sudo systemctl disable --now traefik-sync.timer

# 3. Verify new system
ssh user@server tail /tmp/gitops-sync.log
```

## Best Practices

1. **Commit Often**: Small, frequent commits are easier to debug
2. **Test Locally**: Always test decryption locally before pushing
3. **Monitor Logs**: Check sync logs after deployments
4. **Version Control**: Tag releases for easy rollback
5. **Document Secrets**: Keep `.env.example` files updated
6. **Use Branches**: Test in staging branch first

## Future Enhancements

Potential improvements:

- [ ] Slack/Discord notifications on sync
- [ ] Rollback capability on failed sync
- [ ] Selective sync (only changed apps)
- [ ] Health checks after restart
- [ ] Prometheus metrics
- [ ] Web dashboard for sync status

---

**Need help?** Check the logs or open an issue in the repository.
