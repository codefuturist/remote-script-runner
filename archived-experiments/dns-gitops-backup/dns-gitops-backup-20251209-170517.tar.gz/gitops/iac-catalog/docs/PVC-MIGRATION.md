# PVC Migration Strategy: local-path → openebs-hostpath

## Status: PLANNED - Ready for Execution

This document outlines the plan to migrate all PersistentVolumeClaims from `local-path` to `openebs-hostpath` storage class across both Kubernetes clusters.

## Executive Summary

- **Current State**: 18 PVCs using `local-path` storage class
- **Target State**: All PVCs using `openebs-hostpath`
- **Risk Level**: Medium (mostly non-critical data)
- **Downtime Impact**: Minimal (can be done during maintenance windows)

## Current Inventory

### Production (k3s-prod) - 2 PVCs
- `monitoring/gatus-pvc` (200Mi) - Status monitoring service
- `pgadmin/pgadmin` (5Gi) - Database administration tool

### Staging (k3s-develop) - 16 PVCs

**Infrastructure:**
- `database/storage-mariadb-single-0` (20Gi) - MariaDB database
- `database/postgres-single-1` (20Gi) - PostgreSQL database
- `access-control/redis-data-authentik-redis-master-0` (1Gi) - Authentik Redis cache
- `ci-cd/valkey-data-gitea-valkey-cluster-0,1,2` (3 × 8Gi) - Gitea Redis cluster
- `ci-cd/gitea-shared-storage` (10Gi) - Gitea application data
- `monitoring/uptime-kuma-data` (2Gi) - Uptime monitoring

**Applications:**
- `dashboard/homarr-data` (1Gi) - Dashboard service
- `mealie/mealie-data` (10Gi) - Recipe management
- `paperless-ngx/data-paperless-ngx-postgresql-0` (8Gi) - Document management DB
- `shlink-test/data-shlink-test-postgresql-0` (8Gi) - URL shortener DB

**WordPress (Suspended):**
- `web/colins-blog-wordpress` (10Gi) - Colin's blog
- `web/rey-it-solutions-wordpress` (10Gi) - Rey IT Solutions site
- `web/wordpress-data` (10Gi) - Shared WordPress data

## Migration Approach

### Constraints

1. **Database Operators**: PostgreSQL and MariaDB operators mark `storageClass` as immutable
   - Cannot be changed after PVC creation
   - Requires recreating entire database cluster (data loss if not backed up)
   - Requires planned maintenance window

2. **WaitForFirstConsumer Binding**: openebs-hostpath requires pod mounting
   - Cannot bind PVCs without a consumer pod
   - pv-migrate tool complexity with this binding mode

3. **Active Data**: Most PVCs are actively used by running applications
   - Must maintain service availability during migration
   - Requires careful coordination

### Recommended Strategy

#### Phase 1: Non-Critical PVCs (Low Risk)

For `monitoring/gatus-pvc` and `pgadmin/pgadmin`:
1. Backup data via kubectl cp
2. Delete old PVCs
3. Update configuration to use openebs-hostpath
4. Let Flux recreate PVCs with new storage class
5. Restore data
6. Verify functionality

**Files to Update:**
- `catalog/gitops/flux/clusters/production/infrastructure/monitoring/gatus.yaml` (line 9)
- New pgadmin entry (if adding to production apps)

#### Phase 2: Database Cluster Migration (Planned Maintenance)

For database PVCs (high risk, requires planning):
1. Schedule maintenance window
2. Back up databases completely
3. Delete old PVCs (forcing database recreation)
4. Delete database operators/statefulsets
5. Update configuration to use openebs-hostpath
6. Redeploy via Flux
7. Verify database integrity and restore if needed

**Files to Update:**
- `catalog/gitops/flux/clusters/staging/infrastructure/database/clusters/mariadb/mariadb-single-node.yaml` (line 29)
- `catalog/gitops/flux/clusters/staging/infrastructure/database/clusters/postgresql/postgres-single-node.yaml` (line 19)
- Production equivalents

#### Phase 3: Application PVCs (Medium Risk)

For application data (mealie, homarr, gitea, etc.):
1. Backup application data
2. Scale down applications to 0 replicas
3. Delete PVCs
4. Update configuration
5. Let Flux recreate and restart applications
6. Restore data if needed

**Files to Update:**
- `catalog/gitops/flux/clusters/staging/apps/ci-cd/gitea/gitea-helmrelease.yaml` (line 76)
- Individual HelmRelease files for each application

## Implementation Steps

### For Non-Critical PVCs (Gatus)

```bash
# 1. Backup data
kubectl run -n monitoring gatus-backup --image=busybox --restart=Never -it --overrides='...'
kubectl cp monitoring/gatus-backup:/tmp/gatus-backup.tar.gz ./gatus-backup.tar.gz

# 2. Update configuration
# Edit catalog/gitops/flux/clusters/production/infrastructure/monitoring/gatus.yaml
# Change storageClassName: local-path to storageClassName: openebs-hostpath

# 3. Delete old PVC
kubectl delete pvc gatus-pvc -n monitoring

# 4. Commit and push
git add -A && git commit -m "chore: migrate gatus-pvc to openebs-hostpath" && git push

# 5. Wait for Flux to recreate PVC with new storage class
kubectl wait --for=condition=Bound pvc/gatus-pvc -n monitoring --timeout=5m

# 6. Restore data
kubectl run -n monitoring gatus-restore --image=busybox --restart=Never -it ...
kubectl cp ./gatus-backup.tar.gz monitoring/gatus-restore:/tmp/
# Inside pod: tar xzf /tmp/gatus-backup.tar.gz -C /data
```

### For Database PVCs

Due to immutability of storage class in database operators:

**Option A: Keep as-is** (Recommended for now)
- Leave databases on local-path
- New applications use openebs-hostpath
- Plan dedicated maintenance window for later

**Option B: Full recreation** (High risk, high disruption)
- Complete database backup
- Delete operator
- Delete PVCs
- Update configuration
- Redeploy from backup

## Rollback Plan

If migration fails:
1. Keep backup files for restoration
2. Revert git changes to restore original storage class
3. Delete partially migrated PVCs
4. Let Flux recreate with original storage class
5. Restore data from backups

## Success Criteria

- [ ] All non-critical PVCs migrated to openebs-hostpath
- [ ] No data loss verified
- [ ] Applications functioning correctly on new storage
- [ ] Database stability confirmed (if migrated)
- [ ] Local-path storage class can be disabled
- [ ] Zero downtime maintenance achieved

## Timeline

- **Phase 1 (Non-critical)**: Can be done anytime - 1-2 hours
- **Phase 2 (Databases)**: Requires scheduled maintenance - 4-6 hours minimum
- **Phase 3 (Applications)**: Can be done during off-hours - 2-3 hours per app

## Related Issues

- All new PVCs should default to openebs-hostpath
- Remove local-path provisioner once migration complete
- Consider volume snapshots for backup strategy post-migration
- Monitor openebs-hostpath performance vs local-path

## Next Steps

1. Execute Phase 1 (gatus, pgadmin) as proof of concept
2. Document any issues and lessons learned
3. Schedule Phase 2 for planned maintenance
4. Plan Phase 3 migrations during off-peak hours
