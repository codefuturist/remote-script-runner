# FluxCD Integration Guide

## Overview

The `iac flux` command group provides comprehensive tools for scaffolding, managing, and validating FluxCD applications in your GitOps clusters. This integration streamlines the process of deploying Helm charts to Kubernetes using FluxCD with automatic preference application and SOPS secret encryption.

## Features

### 1. **Application Scaffolding** (`iac flux scaffold`)
Automatically generate complete FluxCD application structures with:
- HelmRelease manifests with preferences applied
- HelmRepository/OCIRepository definitions
- SOPS-encrypted secret templates
- Namespace manifests
- Kustomization files
- Automatic updates to parent kustomizations

### 2. **Validation** (`iac flux validate`)
Validate FluxCD applications against organizational standards:
- Required FluxCD fields (interval, timeout, retries)
- Resource requests and limits
- SOPS encryption on secrets
- Security contexts

### 3. **Secret Encryption** (`iac flux encrypt`)
Manage SOPS encryption for Kubernetes secrets:
- Automatic encryption with age keys
- Bulk encryption support
- Encryption status checking

### 4. **Secret Import** (`iac flux import-secret`, `iac flux import-secrets`)
Import existing Kubernetes secrets from clusters to FluxCD:
- Fetch secrets directly from running clusters via kubectl
- Clean cluster-specific metadata automatically
- Convert base64 data to stringData for easier editing
- Auto-categorize secrets (database, auth, tls, etc.)
- Automatic SOPS encryption
- Batch import entire namespaces

### 5. **SOPS Configuration** (`iac flux sops-info`)
Display SOPS configuration and validate setup

## Installation

The flux commands are automatically available after installing `iac-manager`:

```bash
cd iac-manager
pip install -e .
```

### Prerequisites

- **SOPS**: Required for secret encryption
  ```bash
  brew install sops
  ```
- **FluxCD clusters**: Configured at `catalog/gitops/flux/clusters/{staging,production}`
- **.sops.yaml**: SOPS configuration in repository root

## Commands

### `iac flux scaffold`

Generate a complete FluxCD application structure.

**Usage:**
```bash
iac flux scaffold \
  --app-name <name> \
  --chart <chart-name> \
  --namespace <namespace> \
  --cluster <staging|production> \
  --repo-url <helm-repo-url> \
  [OPTIONS]
```

**Options:**
- `-n, --app-name`: Application name (required)
- `-c, --chart`: Helm chart (e.g., `bitnami/postgresql`) (required)
- `-ns, --namespace`: Kubernetes namespace (required)
- `--cluster`: Target cluster: `staging` or `production` (required)
- `-r, --repo-url`: Helm repository URL (required unless `--oci`)
- `-v, --version`: Chart version (default: latest)
- `-f, --values-file`: Custom values file path
- `-p, --profile`: Preference profile (default: `default`)
- `-e, --environment`: Environment (default: inferred from cluster)
- `--oci`: Chart is from OCI registry
- `--no-namespace`: Don't create namespace manifest
- `--no-secret`: Don't create secret template
- `--no-encrypt`: Don't auto-encrypt secrets

**Examples:**

```bash
# Basic PostgreSQL app for staging
iac flux scaffold \
  -n postgres \
  -c bitnami/postgresql \
  -ns database \
  --cluster staging \
  -r https://charts.bitnami.com/bitnami

# Production n8n with custom values
iac flux scaffold \
  -n n8n \
  -c n8n/n8n \
  -ns automation \
  --cluster production \
  -r https://riatlas.github.io/chart__n8n \
  -f n8n-values.yaml \
  -p default \
  -e production

# OCI registry chart (Redis)
iac flux scaffold \
  -n redis \
  -c oci://registry-1.docker.io/bitnamicharts/redis \
  -ns database \
  --cluster production \
  --oci
```

**Generated Structure:**
```
catalog/gitops/flux/clusters/{cluster}/apps/production/{app-name}/
├── {app-name}-helmrelease.yaml    # HelmRelease + HelmRepository
├── {app-name}-secret.yaml         # SOPS-encrypted secret (optional)
└── kustomization.yaml             # Kustomize resources

catalog/gitops/flux/clusters/{cluster}/infrastructure/namespaces/
└── {namespace}-namespace.yaml     # Namespace definition (if created)
```

### `iac flux validate`

Validate FluxCD applications against preference standards.

**Usage:**
```bash
iac flux validate <path> [OPTIONS]
```

**Arguments:**
- `path`: Path to app directory or apps folder

**Options:**
- `-p, --profile`: Preference profile (default: `default`)
- `-e, --environment`: Environment context (default: `production`)

**Examples:**

```bash
# Validate single app
iac flux validate catalog/gitops/flux/clusters/staging/apps/production/n8n

# Validate all staging apps
iac flux validate catalog/gitops/flux/clusters/staging/apps

# Validate against hardened profile
iac flux validate apps/production/postgres -p hardened
```

**Validation Checks:**
- ✓ `spec.interval` is set
- ✓ `spec.timeout` is set
- ✓ `spec.maxHistory` is set
- ✓ `spec.install.remediation.retries` is set
- ✓ `spec.upgrade.remediation.retries` is set
- ✓ Resource requests are defined
- ✓ Resource limits are defined
- ✓ Secrets are SOPS encrypted

### `iac flux encrypt`

Encrypt secrets with SOPS.

**Usage:**
```bash
iac flux encrypt <file1> [file2 ...] [OPTIONS]
```

**Arguments:**
- `files`: One or more secret files to encrypt

**Options:**
- `--check-only`: Only check encryption status, don't encrypt

**Examples:**

```bash
# Encrypt a single secret
iac flux encrypt my-app-secret.yaml

# Encrypt multiple secrets
iac flux encrypt app1-secret.yaml app2-secret.yaml

# Check encryption status
iac flux encrypt --check-only **/*-secret.yaml
```

### `iac flux import-secret`

Import a Kubernetes secret from a running cluster to FluxCD with SOPS encryption.

**Usage:**
```bash
iac flux import-secret <secret-name> \
  --namespace <namespace> \
  --cluster <staging|production> \
  [OPTIONS]
```

**Arguments:**
- `secret-name`: Name of the secret to import (required)

**Options:**
- `-ns, --namespace`: Source namespace in cluster (default: `default`)
- `--cluster`: Target FluxCD cluster: `staging` or `production` (required)
- `-cat, --category`: Secret category (auto-detect if not provided)
- `--no-encrypt`: Don't encrypt with SOPS
- `--update-kustomization`: Automatically update kustomization.yaml
- `--repo-root`: Repository root path (auto-detected if not provided)

**Examples:**

```bash
# Import a PostgreSQL secret
iac flux import-secret postgres-credentials \
  --namespace database --cluster production

# Import without encryption (for review first)
iac flux import-secret api-keys \
  --namespace default --cluster staging --no-encrypt

# Import and update kustomization
iac flux import-secret redis-password \
  --namespace cache --cluster production --update-kustomization

# Import with specific category
iac flux import-secret tls-cert \
  --namespace ingress --cluster production --category tls
```

**What it does:**
1. Fetches the secret from cluster via kubectl
2. Cleans cluster-specific metadata (uid, resourceVersion, etc.)
3. Converts base64-encoded `data` to readable `stringData`
4. Auto-categorizes the secret (database, auth, tls, shared, etc.)
5. Encrypts with SOPS
6. Places in FluxCD directory structure
7. Optionally updates kustomization.yaml

**Categories:**
- `database` - PostgreSQL, MySQL, MariaDB, MongoDB, Redis credentials
- `auth` - Authentication tokens, API keys, OAuth secrets
- `tls` - TLS certificates and keys
- `registry` - Docker registry credentials
- `ssh` - SSH keys
- `backup` - Backup credentials
- `shared` - Generic secrets

### `iac flux import-secrets`

Batch import multiple Kubernetes secrets from a namespace.

**Usage:**
```bash
iac flux import-secrets \
  --namespace <namespace> \
  --cluster <staging|production> \
  [OPTIONS]
```

**Options:**
- `-ns, --namespace`: Source namespace in cluster (required)
- `--cluster`: Target FluxCD cluster: `staging` or `production` (required)
- `-l, --label-selector`: Label selector (e.g., `app=myapp`)
- `--include-system`: Include system-managed secrets
- `--no-encrypt`: Don't encrypt with SOPS
- `--dry-run`: Show what would be imported without doing it
- `--repo-root`: Repository root path (auto-detected if not provided)

**Examples:**

```bash
# Import all secrets from a namespace
iac flux import-secrets --namespace database --cluster production

# Import secrets with specific label
iac flux import-secrets --namespace apps \
  --cluster staging --label-selector app=wordpress

# Dry run to see what would be imported
iac flux import-secrets --namespace default \
  --cluster production --dry-run

# Include system secrets (not recommended)
iac flux import-secrets --namespace kube-system \
  --cluster staging --include-system
```

**System secrets excluded by default:**
- Service account tokens (`default-token-*`)
- Helm release secrets (`sh.helm.release.*`)
- Bootstrap tokens
- Docker config secrets

### `iac flux sops-info`

Display SOPS configuration and validation status.

**Usage:**
```bash
iac flux sops-info [OPTIONS]
```

**Options:**
- `--repo-root`: Repository root path (auto-detected if not provided)

**Example:**
```bash
iac flux sops-info
```

**Output:**
- SOPS installation status
- `.sops.yaml` configuration validation
- Age key configuration
- FluxCD path detection rules

## Workflow

### 1. Scaffold a New Application

```bash
# Navigate to repository root
cd /path/to/iac-catalog

# Scaffold the application
iac flux scaffold \
  --app-name grafana \
  --chart grafana/grafana \
  --namespace monitoring \
  --cluster production \
  --repo-url https://grafana.github.io/helm-charts \
  --version 8.5.1 \
  --profile default \
  --environment production
```

**Output:**
```
FluxCD Application Scaffolding

App:       grafana
Chart:     grafana/grafana
Namespace: monitoring
Cluster:   production
Profile:   default

Scaffolding app: grafana in .../production/apps/production/grafana
  → Generating HelmRelease manifest...
  → Applying preferences (profile: default, env: production)...
  → Writing grafana-helmrelease.yaml...
  → Generating HelmRepository manifest...
  → Creating secret template...
  → Encrypting secret with SOPS...
    ✓ Successfully encrypted: grafana-secret.yaml
  → Creating kustomization.yaml...
  → Creating namespace manifest...
  → Updating namespaces kustomization.yaml...
  → Updating parent kustomization.yaml...

✓ Successfully scaffolded grafana!

Created files:
  • helmrelease: .../grafana-helmrelease.yaml
  • secret: .../grafana-secret.yaml
  • kustomization: .../kustomization.yaml
  • namespace: .../monitoring-namespace.yaml
```

### 2. Review and Customize

```bash
# View the generated HelmRelease
cat catalog/gitops/flux/clusters/production/apps/production/grafana/grafana-helmrelease.yaml

# Edit secret values (SOPS will decrypt automatically in editor)
sops catalog/gitops/flux/clusters/production/apps/production/grafana/grafana-secret.yaml

# Customize HelmRelease values if needed
# Edit the spec.values section
```

### 3. Validate

```bash
# Validate the new app
iac flux validate catalog/gitops/flux/clusters/production/apps/production/grafana
```

### 4. Deploy

```bash
# Commit and push to Git
git add catalog/gitops/flux/clusters/production/apps/production/grafana/
git commit -m "feat: add Grafana to production cluster"
git push

# FluxCD will automatically reconcile and deploy within 10 minutes
# Or trigger immediately:
flux reconcile kustomization apps --with-source
```

### 5. Monitor

```bash
# Check FluxCD status
flux get helmreleases -n monitoring

# Watch deployment
kubectl get pods -n monitoring -w

# View logs
kubectl logs -n monitoring deploy/grafana
```

### 6. Import Existing Secrets

If you have secrets already running in your cluster that you want to migrate to FluxCD:

```bash
# Import a single database secret
iac flux import-secret postgres-admin-password \
  --namespace database \
  --cluster production \
  --update-kustomization

# Import all secrets from a namespace
iac flux import-secrets \
  --namespace wordpress \
  --cluster production

# Review imported secrets
ls catalog/gitops/flux/clusters/production/infrastructure/secrets/

# Edit if needed
sops catalog/gitops/flux/clusters/production/infrastructure/secrets/database/postgres-admin-password-secret.yaml

# Commit
git add catalog/gitops/flux/clusters/production/infrastructure/secrets/
git commit -m "feat(secrets): import existing secrets from cluster"
git push
```

**Important:** After importing and deploying via FluxCD:
1. Verify the secrets work in the cluster
2. Update applications to use the new secret names if changed
3. Consider deleting the old manually-created secrets
4. Document the migration in your team's runbook

## Preferences

The scaffolding process automatically applies preferences from the selected profile. Preferences include:

### FluxCD-Specific (HelmRelease)
- `spec.suspend: false` - Keep active
- `spec.maxHistory: 3` - Revision history
- `spec.interval: 30m` - Reconciliation interval
- `spec.timeout: 15m` - Operation timeout
- `spec.install.remediation.retries: 3` - Install retries
- `spec.upgrade.remediation.retries: 3` - Upgrade retries

### Environment-Specific
#### Production
- Hostname: `${app-name}.pandia.io`
- Storage class: `longhorn`
- Resources: CPU 50m-1000m, Memory 128Mi-1Gi

#### Staging
- Hostname: `${app-name}-staging.pandia.io`
- Storage class: `local-path`
- Resources: CPU 25m, Memory 64Mi (minimal)

#### Development
- Hostname: `${app-name}-dev.pandia.io`
- Storage class: `local-path`
- Resources: CPU 10m, Memory 32Mi (minimal)

### Security
- `containerSecurityContext.enabled: true`
- `containerSecurityContext.runAsNonRoot: true`
- `containerSecurityContext.privileged: false`
- `containerSecurityContext.readOnlyRootFilesystem: true`
- `containerSecurityContext.allowPrivilegeEscalation: false`

### Monitoring
- `metrics.enabled: true`
- `serviceMonitor.enabled: true`

### Conditional Rules
- **If ingress enabled**: Add Traefik and cert-manager annotations
- **If metrics enabled**: Enable ServiceMonitor and PrometheusRule

## SOPS Integration

### Automatic Encryption

When scaffolding with `--no-encrypt` flag omitted (default behavior):
1. Secret template is created with placeholder values
2. SOPS automatically encrypts the file using `.sops.yaml` rules
3. Encryption uses the age key configured for FluxCD paths

### Manual Encryption

```bash
# Encrypt a secret
sops --encrypt --in-place my-secret.yaml

# Or use the iac command
iac flux encrypt my-secret.yaml

# Edit encrypted secret
sops my-secret.yaml
```

### FluxCD Path Detection

The tool automatically detects FluxCD-managed paths:
- Pattern: `catalog/gitops/flux/**`
- Uses software age key only (Flux can access)
- Encrypts `data` and `stringData` fields only

### Configuration

SOPS configuration is in `.sops.yaml` at repository root:

```yaml
creation_rules:
  - path_regex: catalog/gitops/flux/.*\.ya?ml$
    encrypted_regex: ^(data|stringData)$
    age: "age1t8gm5avm9z5pquta4w2kaud7zn3c588mkk2shdpdskvp76wxh3gsxctyst"
```

## Troubleshooting

### SOPS not installed
```bash
brew install sops
```

### Missing `.sops.yaml`
Ensure `.sops.yaml` exists in repository root with FluxCD rules.

### Encryption fails
```bash
# Check SOPS configuration
iac flux sops-info

# Verify age key
cat ~/.config/sops/age/keys.txt
```

### Validation errors
```bash
# See what's missing
iac flux validate path/to/app

# Apply preferences to fix
iac preferences apply -p default -e production path/to/app/helmrelease.yaml
```

### App not deploying
```bash
# Check FluxCD logs
flux logs --all-namespaces

# Check HelmRelease status
flux get helmrelease -n <namespace>

# Check for SOPS decryption issues
kubectl get secret -n flux-system sops-age
```

## Best Practices

### 1. Use Profiles Consistently
- `default`: Production-ready settings
- `hardened`: Enhanced security
- `minimal`: Development/testing

### 2. Always Validate Before Committing
```bash
iac flux validate catalog/gitops/flux/clusters/staging/apps
```

### 3. Review Generated Files
- Check HelmRelease values
- Update secret placeholders
- Verify resource limits

### 4. Commit Atomically
```bash
git add catalog/gitops/flux/clusters/production/apps/production/myapp/
git commit -m "feat: add myapp to production"
```

### 5. Monitor Deployment
```bash
watch flux get helmreleases -A
```

## Integration with Existing Tools

### With `iac preferences`
```bash
# Fetch chart values
iac preferences fetch-chart-values bitnami/postgresql --output values.yaml

# Apply preferences
iac preferences apply -p default -e production values.yaml

# Scaffold with custom values
iac flux scaffold -n postgres -c bitnami/postgresql -ns database \
  --cluster production -r https://charts.bitnami.com/bitnami \
  -f values.yaml
```

### With `iac convert`
```bash
# Convert Helm to FluxCD (alternative approach)
iac convert helm-to-flux \
  -c bitnami/postgresql \
  -r postgres \
  -n database \
  --repo https://charts.bitnami.com/bitnami \
  -o ./flux-manifests

# Then move to cluster directory
mv flux-manifests/* catalog/gitops/flux/clusters/production/apps/production/postgres/
```

## Examples

### Example 1: Simple Web Application

```bash
iac flux scaffold \
  -n my-webapp \
  -c bitnami/apache \
  -ns web \
  --cluster staging \
  -r https://charts.bitnami.com/bitnami \
  -v 11.2.0
```

### Example 2: Database with Custom Values

```bash
# Create custom values
cat > postgres-values.yaml <<EOF
primary:
  persistence:
    size: 20Gi
readReplicas:
  replicaCount: 2
EOF

# Scaffold
iac flux scaffold \
  -n postgres \
  -c bitnami/postgresql \
  -ns database \
  --cluster production \
  -r https://charts.bitnami.com/bitnami \
  -f postgres-values.yaml \
  -p hardened
```

### Example 3: OCI Chart

```bash
iac flux scaffold \
  -n redis \
  -c oci://registry-1.docker.io/bitnamicharts/redis \
  -ns cache \
  --cluster production \
  --oci \
  -v 20.3.0
```

### Example 4: Minimal Development App

```bash
iac flux scaffold \
  -n test-app \
  -c my-org/my-chart \
  -ns dev \
  --cluster staging \
  -r https://charts.my-org.com \
  -p minimal \
  -e development \
  --no-secret
```

## Summary

The FluxCD integration provides a streamlined workflow for:
1. ✅ **Scaffolding** - Generate complete app structures in seconds
2. ✅ **Standards** - Automatic preference application
3. ✅ **Security** - SOPS encryption out of the box
4. ✅ **Validation** - Ensure compliance before deployment
5. ✅ **GitOps** - Seamless integration with FluxCD clusters

This reduces deployment time from **~30 minutes to <5 minutes** while ensuring consistency and security across all applications.
