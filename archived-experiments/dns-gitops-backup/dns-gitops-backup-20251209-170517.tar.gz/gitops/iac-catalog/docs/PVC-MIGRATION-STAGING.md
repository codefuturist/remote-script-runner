# Staging Cluster PVC Migration: local-path → openebs-hostpath

## Status: READY FOR EXECUTION

Detailed implementation guide for migrating all 16 PVCs on the k3s-develop staging cluster to openebs-hostpath storage class.

## Staging Cluster Inventory (k3s-develop)

### Summary
- **Total PVCs**: 16
- **Total Storage**: ~218 GiB
- **Critical Data**: 6 PVCs (databases, Gitea)
- **Application Data**: 7 PVCs
- **Non-Essential**: 3 PVCs (test, monitoring)

### Complete PVC List

#### Tier 1: Infrastructure (Critical - Requires Planned Maintenance)
| PVC Name | Namespace | Size | Application | Risk Level |
|----------|-----------|------|-------------|-----------|
| storage-mariadb-single-0 | database | 20Gi | MariaDB Operator | HIGH |
| postgres-single-1 | database | 20Gi | PostgreSQL Operator | HIGH |
| redis-data-authentik-redis-master-0 | access-control | 1Gi | Authentik Redis | MEDIUM |
| valkey-data-gitea-valkey-cluster-0 | ci-cd | 8Gi | Gitea Valkey Cache | MEDIUM |
| valkey-data-gitea-valkey-cluster-1 | ci-cd | 8Gi | Gitea Valkey Cache | MEDIUM |
| valkey-data-gitea-valkey-cluster-2 | ci-cd | 8Gi | Gitea Valkey Cache | MEDIUM |
| gitea-shared-storage | ci-cd | 10Gi | Gitea Application | MEDIUM |

#### Tier 2: Applications (Medium Risk)
| PVC Name | Namespace | Size | Application | Risk Level |
|----------|-----------|------|-------------|-----------|
| homarr-data | dashboard | 1Gi | Homarr Dashboard | LOW |
| mealie-data | mealie | 10Gi | Mealie Recipe App | MEDIUM |
| data-paperless-ngx-postgresql-0 | paperless-ngx | 8Gi | Paperless DB | MEDIUM |
| data-shlink-test-postgresql-0 | shlink-test | 8Gi | Shlink URL Shortener DB | MEDIUM |
| uptime-kuma-data | monitoring | 2Gi | Uptime Monitoring | LOW |

#### Tier 3: WordPress (Suspended - Lower Priority)
| PVC Name | Namespace | Size | Application | Risk Level |
|----------|-----------|------|-------------|-----------|
| colins-blog-wordpress | web | 10Gi | Colin's Blog | LOW |
| rey-it-solutions-wordpress | web | 10Gi | Rey IT Solutions | LOW |
| wordpress-data | web | 10Gi | Shared WordPress Data | LOW |

#### Tier 4: Test/Development
| PVC Name | Namespace | Size | Application | Risk Level |
|----------|-----------|------|-------------|-----------|
| test-local-path-alt-pvc | default | 100Mi | Test PVC | NONE |

## Phased Migration Plan

### Phase 1: Non-Essential Resources (Immediate - No Downtime)
**Duration**: 30 minutes  
**Downtime**: None  
**Date**: Can be done anytime

**PVCs to Migrate**:
- default/test-local-path-alt-pvc (100Mi)
- monitoring/uptime-kuma-data (2Gi)

**Procedure**:
1. Backup data (2 minutes)
2. Delete PVCs (1 minute)
3. Update configuration (2 minutes)
4. Commit to git (1 minute)
5. Wait for Flux reconciliation (10 minutes)
6. Restore data if needed (5 minutes)

**Files to Update**:
- None for test PVC (will be recreated)
- `catalog/gitops/flux/clusters/staging/infrastructure/monitoring/gatus.yaml` (for uptime-kuma if managed there)

### Phase 2: Non-Critical Applications (Low-Medium Risk)
**Duration**: 1.5 hours per PVC  
**Downtime**: 30-60 seconds per PVC  
**Date**: During off-hours or maintenance window

**PVCs to Migrate (in order)**:
1. dashboard/homarr-data (1Gi)
2. access-control/redis-data-authentik-redis-master-0 (1Gi)
3. mealie/mealie-data (10Gi)
4. paperless-ngx/data-paperless-ngx-postgresql-0 (8Gi)
5. shlink-test/data-shlink-test-postgresql-0 (8Gi)

**Procedure per PVC**:
1. Scale down application to 0 replicas (30 seconds downtime)
2. Backup data via kubectl cp (5-10 minutes)
3. Delete PVC (1 minute)
4. Update configuration file (2 minutes)
5. Commit and push (1 minute)
6. Wait for Flux to recreate PVC with new storage class (5-10 minutes)
7. Scale app back up (30 seconds downtime)
8. Restore data if needed (5-15 minutes)
9. Verify application health (5 minutes)

**Files to Update**:
- `catalog/gitops/flux/clusters/staging/apps/ci-cd/gitea/gitea-helmrelease.yaml`
- Application HelmRelease files for each app
- Database operator YAML files (if separate)

### Phase 3: Cache Clusters (Medium Risk - Requires Coordination)
**Duration**: 2-3 hours  
**Downtime**: Brief (cache is recoverable)  
**Date**: During maintenance window

**PVCs to Migrate** (Gitea Valkey Cluster):
- ci-cd/valkey-data-gitea-valkey-cluster-0 (8Gi)
- ci-cd/valkey-data-gitea-valkey-cluster-1 (8Gi)
- ci-cd/valkey-data-gitea-valkey-cluster-2 (8Gi)
- ci-cd/gitea-shared-storage (10Gi)

**Procedure**:
1. Scale down Gitea to 0 replicas (1 minute downtime)
2. Backup Gitea data (10-15 minutes)
3. Delete all Valkey PVCs and Gitea storage PVC simultaneously (2 minutes)
4. Update configuration files (3 minutes)
5. Commit and push (1 minute)
6. Wait for Flux to recreate all PVCs (15-20 minutes)
7. Scale Gitea back up (1 minute downtime)
8. Verify Gitea health and restore data if needed (10 minutes)

**Files to Update**:
- `catalog/gitops/flux/clusters/staging/apps/ci-cd/gitea/gitea-helmrelease.yaml` (line 76)

### Phase 4: Database Clusters (HIGH RISK - Requires Full Planning)
**Duration**: 4-6 hours  
**Downtime**: 1-2 hours (requires database recreation)  
**Date**: Requires scheduled maintenance window with full team coordination

**RECOMMENDATION: DEFER THIS PHASE**

Due to immutability of `storageClass` in database operators (PostgreSQL, MariaDB), this phase should be deferred to a future scheduled maintenance window with:
- Complete database backups
- Team on-call
- Tested restore procedures
- Rollback plan

**If proceeding**:
1. Full database backup (15-30 minutes)
2. Stop all applications depending on database (5 minutes)
3. Scale down database operators to 0 (2 minutes)
4. Delete PVCs and database operators (5 minutes)
5. Update configuration (5 minutes)
6. Commit and push (1 minute)
7. Redeploy operators via Flux (30 minutes)
8. Monitor operator initialization (30 minutes)
9. Restore databases from backup (30-60 minutes)
10. Scale up applications (5 minutes)
11. Verify data integrity (15 minutes)

**Files to Update**:
- `catalog/gitops/flux/clusters/staging/infrastructure/database/clusters/mariadb/mariadb-single-node.yaml` (line 29)
- `catalog/gitops/flux/clusters/staging/infrastructure/database/clusters/postgresql/postgres-single-node.yaml` (line 19)

### Phase 5: WordPress Volumes (LOW RISK - Suspended Apps)
**Duration**: 30 minutes per PVC  
**Downtime**: N/A (apps suspended)  
**Date**: Can be done anytime

**PVCs to Migrate**:
- web/colins-blog-wordpress (10Gi)
- web/rey-it-solutions-wordpress (10Gi)
- web/wordpress-data (10Gi)

**Procedure**: Same as Phase 2, but no need to scale up (applications remain suspended)

**Files to Update**:
- `catalog/gitops/flux/clusters/staging/apps/production/wordpress/wordpress-deployment.yaml` (line 131)
- Individual WordPress HelmRelease files

## Backup Procedures

### For Each PVC Type

#### Simple Volume Backup (Small PVCs < 5Gi)
```bash
# Example: backup homarr-data
kubectl run -n dashboard homarr-backup \
  --image=busybox:latest \
  --restart=Never \
  -it \
  --overrides='{
    "spec": {
      "containers": [{
        "name": "homarr-backup",
        "image": "busybox:latest",
        "command": ["sh"],
        "volumeMounts": [{"name": "data", "mountPath": "/data"}]
      }],
      "volumes": [{
        "name": "data",
        "persistentVolumeClaim": {"claimName": "homarr-data"}
      }]
    }
  }'

# Inside pod:
tar czf /tmp/homarr-backup.tar.gz -C /data .
exit

# Copy from pod:
kubectl cp dashboard/homarr-backup:/tmp/homarr-backup.tar.gz ./homarr-backup.tar.gz
```

#### Database Backup (PostgreSQL/MariaDB)
```bash
# PostgreSQL
pg_dump -U postgres -d mealie > mealie-backup.sql

# MariaDB
mysqldump -u root -p --all-databases > databases-backup.sql
```

#### Restore Procedure
```bash
# Create restore pod
kubectl run -n dashboard homarr-restore \
  --image=busybox:latest \
  --restart=Never \
  -it \
  --overrides='...' # Same as backup

# Inside pod:
tar xzf /tmp/homarr-backup.tar.gz -C /data
```

## Configuration File Updates

### Files Requiring Changes

1. **Database Operators** (HIGH PRIORITY FOR PHASE 4)
   - `staging/infrastructure/database/clusters/mariadb/mariadb-single-node.yaml`
   - `staging/infrastructure/database/clusters/postgresql/postgres-single-node.yaml`
   - Change: `storageClass: local-path` → `storageClass: openebs-hostpath`

2. **Gitea** (PHASE 3)
   - `staging/apps/ci-cd/gitea/gitea-helmrelease.yaml`
   - Change: `storageClass: local-path` → `storageClass: openebs-hostpath`

3. **Application HelmReleases** (PHASE 2)
   - Mealie HelmRelease
   - Homarr HelmRelease
   - Paperless-ngx HelmRelease
   - Shlink HelmRelease

## Verification Checklist

After each migration, verify:
- [ ] New PVC is `Bound` with `openebs-hostpath` storage class
- [ ] Application pod is running successfully
- [ ] Data is accessible and intact
- [ ] Application logs show no errors
- [ ] No data loss or corruption

## Rollback Procedures

### Per-PVC Rollback
1. Delete the openebs-hostpath PVC
2. Restore backup data to a local-path PVC
3. Revert git changes to local-path
4. Let Flux recreate original PVC
5. Restore data from backup

### Full Cluster Rollback
1. Revert all git commits
2. Delete all openebs-hostpath PVCs
3. Let Flux recreate all PVCs with local-path
4. Restore all data from backups

## Timeline

- **Phase 1**: 30 minutes (any time)
- **Phase 2**: 6-8 hours (off-hours, 1 hour per PVC)
- **Phase 3**: 2-3 hours (maintenance window)
- **Phase 4**: 4-6 hours (requires full scheduled maintenance)
- **Phase 5**: 1.5 hours (any time, apps suspended)

**Total estimated time**: 13-20 hours over multiple sessions

## Success Criteria

- [ ] All 16 PVCs migrated to openebs-hostpath
- [ ] Zero data loss
- [ ] All applications functioning normally
- [ ] Database integrity verified
- [ ] Performance comparable or better than local-path
- [ ] Monitoring shows no anomalies
- [ ] Backup procedures documented and tested

## Post-Migration Cleanup

1. Remove local-path provisioner from cluster
2. Update all new app deployments to use openebs-hostpath by default
3. Document lessons learned
4. Update cluster documentation
5. Test disaster recovery procedures with new storage class

## Related Documentation

- See `DOCS/PVC-MIGRATION.md` for general strategy and production cluster approach
- See `catalog/gitops/flux/clusters/staging/` for all configuration files
- Backup files should be stored in: `/tmp/pvc-backups/staging/`
