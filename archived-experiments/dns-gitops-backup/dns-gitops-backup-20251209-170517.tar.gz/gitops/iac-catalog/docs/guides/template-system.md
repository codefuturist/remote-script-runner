# IaC Catalog Template System

Complete guide to the Jinja2-based template system for iac-catalog.

## Overview

The iac-catalog template system uses Jinja2 templates with a layered configuration approach to support multi-environment deployments. This enables:

- ✅ **Reusable Templates** - Write once, deploy anywhere
- ✅ **Environment-Specific Configs** - Dev, staging, production overrides
- ✅ **Consistent Patterns** - Shared macro library
- ✅ **Type Safety** - Structured configuration
- ✅ **Multi-Platform** - Docker Compose, Kubernetes, Terraform

## Architecture

### Directory Structure

```
catalog/containers/docker/compose-stacks/<template>/
├── manifest.yml              # Template metadata
├── README.md                 # Documentation
├── render.py                 # Rendering script
├── requirements.txt          # Python dependencies
├── templates/
│   ├── docker-compose.j2    # Main template
│   ├── macros/              # Template-specific macros
│   └── partials/            # Reusable fragments
│       ├── volumes.j2
│       ├── networks.j2
│       └── configs.j2
├── environments/
│   ├── base.yml             # Base configuration
│   ├── dev.yml              # Development overrides
│   ├── staging.yml          # Staging overrides
│   └── production.yml       # Production overrides
└── values/                  # Additional value files
    └── clouds/
        ├── aws.yml
        ├── azure.yml
        └── gcp.yml
```

### Macro Library Structure

```
catalog/_libraries/
├── base/
│   └── macros/
│       ├── common.j2        # Core Docker Compose macros
│       ├── README.md        # Library documentation
│       └── EXAMPLES.md      # Usage examples
├── cloud-providers/         # Cloud-specific patterns
├── networking/              # Networking macros
├── observability/           # Monitoring, logging, tracing
└── security/                # Security patterns
```

## Quick Start

### 1. Install Dependencies

```bash
pip install Jinja2 PyYAML
```

### 2. Render a Template

```bash
cd catalog/containers/docker/compose-stacks/wordpress

# Development
python render.py --env dev

# Production
python render.py --env production
```

### 3. Deploy

```bash
docker-compose up -d
```

## Creating a New Template

### Step 1: Create Directory Structure

```bash
TEMPLATE_NAME="myapp"
cd catalog/containers/docker/compose-stacks
mkdir -p ${TEMPLATE_NAME}/{templates/{macros,partials},environments,values}
```

### Step 2: Create Manifest

Create `manifest.yml`:

```yaml
apiVersion: template.iac-catalog.io/v1
kind: Application
metadata:
  name: myapp
  description: "My application description"
  version: 1.0.0
  category: web-applications
  tags:
    - webapp
    - nodejs
spec:
  platforms:
    - docker-compose
  requirements:
    min_cpu: "0.5"
    min_memory: "512Mi"
  dependencies:
    - name: redis
      version: ">=6.0"
  parameters:
    - name: APP_PORT
      description: "Application port"
      type: integer
      default: 3000
```

### Step 3: Create Base Configuration

Create `environments/base.yml`:

```yaml
# Base configuration
app_name: myapp
environment: development
compose_version: "3.8"

# Application settings
app_version: latest
app_port: 3000

# Network
network_name: myapp_network
network_driver: bridge

# Logging
log_max_size: "10m"
log_max_file: "3"
```

### Step 4: Create Jinja2 Template

Create `templates/docker-compose.j2`:

```jinja
{% from 'catalog/_libraries/base/macros/common.j2' import
    healthcheck,
    logging_config,
    service_networks,
    ports_mapping,
    compose_networks -%}

version: "{{ compose_version | default('3.8') }}"

services:
  app:
    image: {{ app_image }}:{{ app_version }}
    {{ ports_mapping([app_port ~ ':' ~ app_port]) | indent(4) }}
    {{ service_networks([network_name]) | indent(4) }}
    {{ healthcheck(['CMD', 'curl', '-f', 'http://localhost:' ~ app_port ~ '/health']) | indent(4) }}
    {{ logging_config(service_name='app') | indent(4) }}

{{ compose_networks({
    network_name: {'driver': network_driver}
}) }}
```

### Step 5: Copy Render Script

```bash
cp ../wordpress/render.py .
cp ../wordpress/requirements.txt .
```

### Step 6: Create Environment Overrides

Create `environments/dev.yml`:

```yaml
environment: development
app_port: 8080
```

Create `environments/production.yml`:

```yaml
environment: production
app_version: "1.0.0"
app_port: 80
deployment_mode: swarm
```

### Step 7: Test Rendering

```bash
# Test development
python render.py --env dev --dry-run

# Render production
python render.py --env production --output docker-compose.prod.yml
```

## Using Macros

### Importing Macros

```jinja
{# Import from base library #}
{% from 'catalog/_libraries/base/macros/common.j2' import
    healthcheck,
    deploy_config,
    logging_config %}

{# Import template-specific macros #}
{% import 'macros/myapp.j2' as myapp %}
```

### Common Patterns

#### Health Check

```jinja
{{ healthcheck(
    test=['CMD-SHELL', 'curl -f http://localhost:8080/health'],
    interval='30s',
    timeout='10s',
    retries=3,
    start_period='40s'
) | indent(4) }}
```

#### Deployment Configuration

```jinja
{{ deploy_config(
    replicas=3,
    resources={
        'limits': {'cpus': '1.0', 'memory': '512M'},
        'reservations': {'cpus': '0.5', 'memory': '256M'}
    },
    restart_policy_config={
        'condition': 'on-failure',
        'max_attempts': 3
    }
) | indent(4) }}
```

#### Service Dependencies

```jinja
{{ depends_on_config([
    {'name': 'db', 'condition': 'service_healthy'},
    {'name': 'redis', 'condition': 'service_started'}
]) | indent(4) }}
```

## Configuration Layering

Configuration is loaded in order (later overrides earlier):

1. **`environments/base.yml`** - Default values
2. **`environments/<env>.yml`** - Environment-specific values
3. **`--values <file>`** - Additional values from command line

### Example

**base.yml:**
```yaml
app_port: 3000
db_host: db
```

**production.yml:**
```yaml
app_port: 80
db_host: prod-db.example.com
```

**Result for production:**
```yaml
app_port: 80
db_host: prod-db.example.com
```

## Best Practices

### 1. Use Defaults

Always provide sensible defaults in `base.yml`:

```yaml
# Good
app_port: 3000
healthcheck_interval: "30s"

# Bad - no defaults
app_port: null
healthcheck_interval: null
```

### 2. Separate Concerns

Use partials for reusable sections:

```jinja
{# templates/partials/volumes.j2 #}
volumes:
  app_data:
    driver: local
  logs:
    driver: local
```

```jinja
{# templates/docker-compose.j2 #}
{% include 'partials/volumes.j2' %}
```

### 3. Document Parameters

Always document parameters in `manifest.yml`:

```yaml
parameters:
  - name: APP_PORT
    description: "Application HTTP port"
    type: integer
    default: 3000
    required: false
  - name: DB_PASSWORD
    description: "Database password"
    type: string
    required: true
    secret: true
```

### 4. Use Semantic Versioning

Pin versions in production:

```yaml
# dev.yml
app_version: latest

# production.yml
app_version: "1.2.3"
```

### 5. Test All Environments

Always test rendering for all environments:

```bash
for env in dev staging production; do
  python render.py --env $env --output "test-$env.yml"
  docker-compose -f "test-$env.yml" config
done
```

## Advanced Features

### Conditional Sections

```jinja
{%- if enable_metrics | default(false) %}
  prometheus:
    image: prom/prometheus:latest
    {{ ports_mapping(['9090:9090']) | indent(4) }}
{%- endif %}
```

### Loops

```jinja
{%- for worker in range(1, worker_count + 1) %}
  worker-{{ worker }}:
    image: {{ worker_image }}
    {{ service_networks(['backend']) | indent(4) }}
{%- endfor %}
```

### Custom Macros

Create `templates/macros/myapp.j2`:

```jinja
{% macro myapp_volumes(data_path='/data') -%}
volumes:
  - {{ data_path }}:/app/data
  - logs:/app/logs
{%- endmacro %}

{% macro myapp_env(config) -%}
environment:
  NODE_ENV: {{ config.environment }}
  PORT: {{ config.port }}
  LOG_LEVEL: {{ config.log_level | default('info') }}
{%- endmacro %}
```

Usage:

```jinja
{% from 'macros/myapp.j2' import myapp_volumes, myapp_env %}

services:
  app:
    image: myapp:latest
    {{ myapp_volumes('/opt/data') | indent(4) }}
    {{ myapp_env({'environment': 'production', 'port': 8080}) | indent(4) }}
```

## Troubleshooting

### Template Not Found

**Error:** `jinja2.exceptions.TemplateNotFound`

**Solution:** Check search paths in `render.py`. The script automatically searches:
- `templates/`
- `templates/macros/`
- `templates/partials/`
- `catalog/_libraries/`

### Undefined Variable

**Error:** `jinja2.exceptions.UndefinedError: 'variable_name' is undefined`

**Solution:** 
1. Add default in template: `{{ variable_name | default('default_value') }}`
2. Add to `environments/base.yml`

### Invalid YAML Output

**Error:** YAML parsing error in rendered output

**Solution:**
1. Check indentation: Always use `| indent(X)`
2. Test rendering: `python render.py --dry-run`
3. Validate YAML: `docker-compose config`

## Examples

See the WordPress template for a complete example:
- [WordPress Template](../containers/docker/compose-stacks/wordpress/)
- [Macro Library](../_libraries/base/macros/)
- [Macro Examples](../_libraries/base/macros/EXAMPLES.md)

## Reference

- [Jinja2 Documentation](https://jinja.palletsprojects.com/)
- [Docker Compose File Reference](https://docs.docker.com/compose/compose-file/)
- [IaC Catalog Macro Library](../_libraries/base/macros/README.md)
