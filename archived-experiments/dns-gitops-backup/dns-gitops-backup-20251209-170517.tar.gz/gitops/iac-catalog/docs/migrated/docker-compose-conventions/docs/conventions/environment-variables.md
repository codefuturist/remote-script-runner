# Environment Variables Conventions

This document outlines the conventions for managing environment variables within Docker Compose files. Proper management of environment variables is crucial for ensuring consistency, security, and ease of configuration across different environments.

## Naming Patterns

- **Uppercase with Underscores**: Environment variable names should be defined in uppercase letters with words separated by underscores (e.g., `DATABASE_URL`, `API_KEY`).
- **Service Prefixing**: Use a prefix that corresponds to the service name to avoid naming collisions (e.g., `WEB_APP_PORT`, `DB_PASSWORD`).

## Default Values

- **Default Values**: Always provide default values for environment variables where applicable. This can be done using the syntax `${VARIABLE_NAME:-default_value}` in the Docker Compose file.

  Example:

  ```yaml
  environment:
    DATABASE_URL: ${DATABASE_URL:-postgres://user:password@db:5432/mydb}
  ```

## Security Considerations

- **Sensitive Information**: Do not hard-code sensitive information directly in the Docker Compose files. Instead, use environment files or Docker secrets to manage sensitive data.
- **Environment Files**: Use `.env` files to define environment variables for local development. Ensure that these files are added to `.gitignore` to prevent accidental exposure of sensitive information.

## Example Environment Variable Configuration

Here is an example of how to structure environment variables in a Docker Compose file:

```yaml
version: "3.8"

services:
  web:
    image: myapp:latest
    environment:
      TZ: "${TIMEZONE:-Europe/Zurich}"
      WEB_APP_PORT: ${WEB_APP_PORT:-8080}
      DB_PASSWORD: ${DB_PASSWORD:-changeme}
```

## Overriding Environment Variables

- **Local Overrides**: Use a local `.env` file to override environment variables for development purposes. This file should not be committed to version control.
- **Production Overrides**: For production environments, consider using Docker secrets or environment variables set directly on the host machine.

## Conclusion

Following these conventions for managing environment variables will help maintain a clean, secure, and consistent configuration across your Docker Compose projects. Always review and update your environment variable management practices as your project evolves.
