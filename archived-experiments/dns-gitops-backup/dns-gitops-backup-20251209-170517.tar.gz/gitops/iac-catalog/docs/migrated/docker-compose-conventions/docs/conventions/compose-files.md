# Docker Compose File Conventions

This document outlines the conventions for structuring Docker Compose files within the project. Adhering to these conventions ensures consistency, readability, and maintainability across all Docker Compose configurations.

## Naming Conventions

- **Service Files**: Each service should have its own dedicated YAML file named in the format `{service-name}.yml`. Avoid using generic names like `docker-compose.yml` for individual services.
- **Environment Files**: Use `env.txt` for environment variable templates. This file should be included in each service directory.

- **Override Files**: Use the `overrides/` directory to store alternative configurations. Name these files descriptively, such as `{service-name}-override.yml`.

## File Organization

- **Directory Structure**: Organize services into categorized directories based on their functionality. For example:

  ```
  docker-compose/
  ├── business-management/
  ├── communication-collaboration/
  ├── databases-storage/
  ```

- **Service Directory**: Each service directory should contain:
  - The main compose file (`{service-name}.yml`)
  - An environment variable template (`env.txt`)
  - An `overrides/` directory for alternative configurations
  - A CLI helper script (`add_cli_commands.sh`)

## Best Practices for Service Definitions

- **Environment Variables**: Always use environment variable substitution for configuration values. Provide sensible defaults where applicable. For example:

  ```yaml
  environment:
    TZ: "${TIMEZONE:-Europe/Zurich}"
    SERVICE_PORT: ${SERVICE_PORT:-default}
  ```

- **Health Checks**: Include health checks for services to ensure they are running correctly. This helps with automatic restarts and monitoring.

- **Restart Policies**: Define restart policies for services to enhance reliability. Use the following pattern:

  ```yaml
  restart: unless-stopped
  ```

- **Versioning**: Avoid specifying the version in the compose files. Docker Compose automatically uses the latest format.

## Comments and Documentation

- **Inline Comments**: Use comments within the YAML files to explain complex configurations or important notes. This aids in understanding the purpose of specific settings.

- **README Files**: Each service directory should include a `README.md` file that describes the service, its purpose, and any specific configurations or usage instructions.

## Conclusion

Following these conventions will help maintain a clean and organized Docker Compose setup, making it easier for developers to collaborate and manage services effectively. For more detailed information on specific topics, refer to the other convention documents in this directory.
