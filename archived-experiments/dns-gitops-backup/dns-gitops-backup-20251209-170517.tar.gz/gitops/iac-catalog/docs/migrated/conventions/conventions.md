# Docker Conventions Documentation

## Overview

This document outlines comprehensive best practices and conventions for structuring Docker Compose files, managing environment variables, utilizing Docker secrets, and maintaining consistency across Docker projects. Following these conventions will help ensure security, maintainability, and operational excellence.

## Directory Structure

A well-organized directory structure is crucial for managing Docker Compose projects. The recommended structure follows a **service-per-directory** pattern with **categorical organization**:

```text
docker-compose/
├── {category}/               # Service category (e.g., databases-storage, communication-collaboration)
│   └── {service}/           # Service directory
│       ├── {service}.yml    # Main compose file
│       ├── env.txt          # Environment variable template
│       ├── overrides/       # Directory for override configurations
│       ├── add_cli_commands.sh  # Shell functions for container interaction
│       └── README.md        # Service documentation
├── scripts/                 # Automation and helper scripts
└── docs/                    # Documentation
```

### Category Organization

Services are organized by functional categories:

- `business-management/` - ERP, asset management (erpnext, odoo, snipeit)
- `communication-collaboration/` - Chat, file sharing (nextcloud, mattermost, gotify)
- `databases-storage/` - Data stores (postgres, mongodb, redis, influxdb)
- `development-devops/` - Dev tools (gitea, gitlab, docker-registry)
- `infrastructure/` - Core services (traefik, nginx, portainer)
- `monitoring-analytics/` - Observability (prometheus, grafana, loki)
- `networking/` - Network services (pihole, openvpn, nginx-proxy)
- `security-authentication/` - Auth & security (certbot, crowdsec)

## Service Naming Convention

- Always name service files using the format `{service}.yml` to ensure clarity and consistency.
- Avoid using generic names like `docker-compose.yml` for individual services.

## Core Service Configuration Standards

### Timezone Convention (REQUIRED)

**Always include timezone configuration in every service:**

```yaml
services:
  app:
    environment:
      TZ: "${TIMEZONE:-Europe/Zurich}"
```

**Benefits:**

- Consistent log timestamps across all services
- Proper scheduled task execution
- Predictable application behavior
- Override capability per deployment

### Container Naming

Use consistent container naming with optional project prefix:

```yaml
services:
  postgres:
    container_name: ${COMPOSE_PROJECT_NAME:-postgres}-db
    hostname: postgres
```

### Restart Policies

Always include a restart policy for production services:

```yaml
services:
  app:
    restart: ${RESTART_POLICY:-unless-stopped}
```

### Security Configuration

Apply security best practices:

```yaml
services:
  app:
    security_opt:
      - no-new-privileges:true
```

### Service Profiles

Avoid using service profiles, because it is not compatible with docker swarm. Group related services using profiles for modular deployments:

```yaml
services:
  frontend:
    profiles:
      - web
      - full

  backend:
    profiles:
      - api
      - full
```

```yaml
database:
  profiles:
    - data
    - full
```

**Usage:**

```bash
# Start only web services
docker compose --profile web up

# Start all services
docker compose --profile full up
```

## Environment Variables Management

### Environment File Structure

Use a standardized structure for environment files to separate configurations for different environments:

```text
project-root/
├── envs/
│   ├── .env.base           # Shared settings
│   ├── .env.development    # Development settings
│   ├── .env.staging        # Staging settings
│   ├── .env.production     # Production settings
│   └── .env.test           # Test environment settings
```

### Avoiding env_file Directive (IMPORTANT)

**Never use the `env_file` directive in Docker Compose files** as it is not compatible with Docker Swarm mode:

❌ **Avoid this pattern:**

```yaml
services:
  app:
    env_file:
      - .env
      - .env.production
```

✅ **Use this pattern instead:**

```yaml
services:
  app:
    environment:
      DATABASE_HOST: "${DATABASE_HOST:-postgres}"
      DATABASE_PORT: "${DATABASE_PORT:-5432}"
      DATABASE_USER: "${DATABASE_USER:-admin}"
      DATABASE_PASSWORD: "${DATABASE_PASSWORD:-changeme}"
```

**Why avoid `env_file`:**

- **Swarm Incompatibility**: Docker Swarm does not support the `env_file` directive
- **Portability Issues**: Files must be present on all nodes in a swarm
- **Security Concerns**: Environment files may contain sensitive data that shouldn't be distributed

**Best Practices:**

1. **Use shell environment**: Load variables into the shell before running Docker Compose

```bash
export $(cat .env | xargs) && docker compose up -d
```

2. **Use Docker secrets**: For sensitive data in production

```yaml
services:
  app:
  secrets:
    - db_password
  environment:
    DB_PASSWORD_FILE: /run/secrets/db_password
```

3. **Use environment substitution**: Define variables with defaults directly in the compose file

```yaml
services:
  app:
  environment:
    API_KEY: "${API_KEY:-default_key}"
```

4. **Use Docker Compose CLI**: Pass environment files via command line for local development

```bash
docker compose --env-file .env.production up -d
```

### Environment Variable Naming

- Use uppercase letters with underscores for environment variable names (e.g., `DATABASE_URL`, `API_KEY`).
- Provide default values in the `.env` files to ensure services can run without manual configuration.

### Standard Environment Variables

All services should include these standard environment variables:

```yaml
services:
  app:
    environment:
      TZ: "${TIMEZONE:-Europe/Zurich}"
```

### Image Specification Convention

### Image Specification Convention

**Always use separate environment variables for image name and tag:**

```yaml
services:
  app:
    image: ${APP_REGISTRY:-docker.io}/${APP_IMAGE:-app/image}:${APP_TAG:-latest}
```

**Environment Variable Breakdown:**

- `APP_REGISTRY`: Container registry URL (e.g., `docker.io`, `harbor.company.com`, `ghcr.io`)
- `APP_IMAGE`: Image name and namespace (e.g., `postgres`, `nginx/nginx`, `mycompany/myapp`)
- `APP_TAG`: Version or tag (e.g., `latest`, `16-alpine`, `v2.1.0`)

### Port Configuration

For external port variables, use the naming convention `{SERVICE}_{PROTOCOL}_PORT`:

```yaml
services:
  gitea:
    ports:
      - "${GITEA_HTTP_PORT:-3000}:3000"
      - "${GITEA_SSH_PORT:-2222}:22"

  nextcloud:
    ports:
      - "${NEXTCLOUD_HTTP_PORT:-8080}:80"
```

## Health Checks

### Standard Health Check Configuration

Always include health checks for services to ensure proper monitoring:

```yaml
services:
  app:
    healthcheck:
      test: ["CMD-SHELL", "curl -f http://localhost:8080/health || exit 1"]
      interval: ${HEALTHCHECK_INTERVAL:-30s}
      timeout: ${HEALTHCHECK_TIMEOUT:-10s}
      retries: ${HEALTHCHECK_RETRIES:-5}
      start_period: ${HEALTHCHECK_START:-30s}
```

### Database Health Checks

For database services, use appropriate connection tests:

```yaml
# PostgreSQL
services:
  postgres:
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U ${POSTGRES_USER:-postgres} -d ${POSTGRES_DB:-mydatabase}"]
      interval: 30s
      timeout: 10s
      retries: 5
      start_period: 30s

# Redis
services:
  redis:
    healthcheck:
      test: ["CMD", "redis-cli", "--raw", "ping"]
      interval: 10s
      timeout: 5s
      retries: 5
```

## Docker Secrets Management

### Using Docker Secrets

When handling sensitive data, **always prefer Docker secrets over environment variables whenever the application supports it**. This approach enhances security by preventing sensitive information from being exposed in process listings or environment dumps. If the application does not support Docker secrets (e.g., does not support `_FILE`-suffixed environment variables), use environment variables as a fallback, but provide override files for Docker secrets where possible.

Example configuration for using Docker secrets:

```yaml
services:
  app:
    environment:
      DB_PASSWORD_FILE: /run/secrets/db_password
      API_KEY_FILE: /run/secrets/api_key
    secrets:
      - db_password
      - api_key

secrets:
  db_password:
    external: true
    name: db_password_${SECRETS_VERSION:-v1}
  api_key:
    external: true
    name: api_key_${SECRETS_VERSION:-v1}
```

### Secret Versioning

Utilize environment variables for secret versioning to facilitate easy updates and management:

```yaml
secrets:
  db_password:
    external: true
    name: db_password_${SECRETS_VERSION:-v1}
```

### File-based Secrets

For local development, you can use file-based secrets:

```yaml
secrets:
  db_password:
    file: "${BASE_PATH:-/var/local/docker}/secrets/db_password.txt"
```

## Labels and Annotations

### Standard Service Labels

Use consistent labeling for service identification and management:

```yaml
services:
  app:
    labels:
      - "com.docker.compose.project=${COMPOSE_PROJECT_NAME:-myapp}"
      - "com.docker.compose.service=app"
```

### Traefik Integration Labels

For services using Traefik as a reverse proxy:

```yaml
services:
  app:
    labels:
      - "traefik.enable=${TRAEFIK_ENABLE:-false}"
      - "traefik.http.routers.app.rule=Host(`${APP_DOMAIN:-app.local}`)"
      - "traefik.http.routers.app.entrypoints=https"
      - "traefik.http.routers.app.tls=true"
      - "traefik.http.services.app.loadbalancer.server.port=8080"
      - "traefik.http.routers.app.middlewares=default-chain@file"
```

### Watchtower Auto-Update Labels

For automatic container updates using Watchtower:

```yaml
services:
  app:
    labels:
      - "com.centurylinklabs.watchtower.enable=${WATCHTOWER_AUTO_UPDATE_IMAGE:-false}"
```

## External Database Strategy

### Preference for External Databases

**Always prefer external databases over containerized databases for production environments**. This approach provides better scalability, reliability, and operational flexibility:

**Benefits of External Databases:**

- **Performance**: Dedicated database servers with optimized hardware and tuning
- **Scalability**: Independent scaling without container constraints
- **Backup/Recovery**: Established enterprise backup solutions
- **High Availability**: Database clustering and replication capabilities
- **Operational Excellence**: Dedicated database administration teams

### External Database Network Configuration

When connecting to external databases, use dedicated networks for each database type:

```yaml
# Application service connecting to external PostgreSQL
services:
  app:
    environment:
      DATABASE_HOST: "postgres-server" # External database hostname
      DATABASE_PORT: "${DATABASE_PORT:-5432}"
      DATABASE_NAME: "${DATABASE_NAME:-myapp}"
    networks:
      - app-network
      - postgres # External database network

networks:
  app-network:
    name: ${COMPOSE_PROJECT_NAME:-app}-network
    driver: bridge

  # External database networks
  postgres:
    external: true
    name: postgres
  mariadb:
    external: true
    name: mariadb
  mongodb:
    external: true
    name: mongodb
  redis:
    external: true
    name: redis
```

### Standard Database Networks

Create these standard external networks for database connectivity:

```bash
# Create standard database networks
docker network create --driver bridge postgres
docker network create --driver bridge mariadb
docker network create --driver bridge mongodb
docker network create --driver bridge redis
docker network create --driver bridge influxdb
docker network create --driver bridge opensearch
```

**Network Usage Pattern:**

- Applications join both their service network and the required database network
- External database services only join their dedicated database network
- This provides isolation while enabling necessary connectivity

## Network Configuration

### Standard Network Patterns

Use consistent network naming and configuration:

```yaml
networks:
  app-network:
    name: ${COMPOSE_PROJECT_NAME:-app}-network
    driver: ${NETWORK_DRIVER:-bridge}

  # External networks for service communication
  proxy:
    external: true
    name: proxy
```

### Service-Specific Networks

Create dedicated networks for each service category:

```yaml
networks:
  postgres-net:
    name: postgres-network
    driver: bridge
  redis-net:
    name: redis-network
    driver: bridge
```

## Volume Management

### Named Volumes with Environment Variables

Use configurable volume names for consistency:

```yaml
volumes:
  app-data:
    driver: local
    driver_opts:
      type: none
      o: bind
      device: ${BASE_PATH:-/var/local/docker/volumes}/${SERVICE_NAME}/${ENVIRONMENT:-prod}/app-data
    name: ${SERVICE_NAME}_${COMPONENT}_${ENVIRONMENT:-prod}

    # Optional metadata labels
    labels:
      com.example.description: "Component description"
      com.example.department: "IT"
      com.example.backup: "daily"
```

### Bind Mount Patterns

For development environments, use consistent bind mount patterns:

```yaml
services:
  app:
    volumes:
      - "${BASE_PATH:-/var/local/docker}/volumes/app-data:/var/lib/app"
      - "/etc/localtime:/etc/localtime:ro"
```

## YAML Configuration Best Practices

### Service Dependencies

Use `depends_on` to define service startup order (docker compose only, not swarm):

```yaml
services:
  app:
    depends_on:
      - postgres
      - redis

  postgres:
    # postgres configuration

  redis:
    # redis configuration
```

### Port Mapping Patterns

Use consistent port mapping with environment variables. The short format is generally preferred for simplicity and readability:

```yaml
services:
  app:
    ports:
      # Short format (preferred) - simple and clean
      - "${APP_PORT:-8080}:8080"

      # Long format - use only when you need specific options
      # Long format - use only when you need specific options
      - target: 8080
        published: ${APP_PORT:-8080}
        protocol: tcp
        mode: host

    # Network modes (sorted by commonality):
    # - bridge (default, most common)
    # - host (direct host networking)
    # - overlay (swarm mode)
    # - macvlan (direct MAC assignment)
    # - none (no networking)
```

The short format is generally preferred and should be used unless you need specific configuration options that require the long format.

### Command and Arguments

Format commands for better readability:

```yaml
services:
  redis:
    command: >
      redis-server
      --requirepass ${REDIS_PASSWORD:-changeme}
      --maxmemory 256mb
      --maxmemory-policy allkeys-lru
```

### Environment Variable Patterns

Always provide defaults for environment variables:

```yaml
services:
  app:
    environment:
      # Required timezone
      TZ: "${TIMEZONE:-Europe/Zurich}"

      # Database configuration
      DATABASE_HOST: "${DATABASE_HOST:-postgres}"
      DATABASE_PORT: "${DATABASE_PORT:-5432}"
      DATABASE_NAME: "${DATABASE_NAME:-myapp}"
      DATABASE_USER: "${DATABASE_USER:-postgres}"
      DATABASE_PASSWORD: "${DATABASE_PASSWORD:-changeme}"

      # Application configuration
      LOG_LEVEL: "${LOG_LEVEL:-INFO}"
      DEBUG: "${DEBUG:-false}"
```

### Comments and Documentation

Add comments to explain complex configurations:

```yaml
# PostgreSQL Base Service
# Single Responsibility: Core service definition only
services:
  postgres:
    image: ${POSTGRES_IMAGE:-postgres:16-alpine}
    # Use descriptive container names
    container_name: ${COMPOSE_PROJECT_NAME:-postgres}-db
```

## Service Override Patterns

### Override Directory Structure

Organize override files in a dedicated directory:

```text
service-directory/
├── service.yml              # Base configuration
├── overrides/
│   ├── service-bind-mount.yml    # Development with bind mounts
│   ├── service-secrets.yml       # Production with Docker secrets
│   └── service-swarm.yml         # Docker Swarm configuration
```

### Example Override Usage

```yaml
# Override environment variables with Docker secrets
services:
  app:
    environment:
      DB_PASSWORD_FILE: /run/secrets/db_password
      API_KEY_FILE: /run/secrets/api_key
    secrets:
      - db_password
      - api_key

secrets:
  db_password:
    external: true
    name: db_password_${SECRETS_VERSION:-v1}
  api_key:
    external: true
    name: api_key_${SECRETS_VERSION:-v1}
```

## Logging Configuration (Reference Only)

> **Note**: Container-level logging configuration is generally **discouraged** in favor of centralized logging solutions (ELK stack, Grafana Loki, etc.). This section is kept for reference purposes only.

### Standard Logging Setup

Configure logging for all services to prevent disk space issues:

```yaml
services:
  app:
    logging:
      driver: json-file
      options:
        max-size: "${LOG_MAX_SIZE:-50m}"
        max-file: "${LOG_MAX_FILES:-10}"
```

## Conclusion

Adhering to these conventions will help maintain a clean, secure, and efficient Docker environment. Key benefits include:

- **Consistency**: Standardized patterns across all services
- **Security**: Proper secrets management and security configurations
- **Maintainability**: Clear structure and documentation
- **Scalability**: Environment-specific configurations
- **Monitoring**: Health checks and logging standards
- **Automation**: Watchtower integration and Traefik routing

For further examples and templates, refer to the `examples` and `templates` directories in this documentation.
