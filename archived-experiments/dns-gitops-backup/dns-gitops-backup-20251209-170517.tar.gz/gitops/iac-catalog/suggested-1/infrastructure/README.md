# Infrastructure - Configuration & Targets

## Purpose

This directory contains **environment-specific configurations** and **infrastructure target definitions**.

Think of it as the "control panel" for each environment.

## Structure

```text
infrastructure/
├── production/
│   ├── targets/           # Infrastructure endpoints
│   └── config/            # Environment configuration
├── staging/
└── development/
```

## Two Main Concepts

### 1. `targets/` - Infrastructure Endpoints

**What it is**: Definitions of where infrastructure exists (servers, clusters, cloud accounts).

```text
targets/
├── servers.yml            # Physical/virtual servers
├── clusters.yml           # Kubernetes/Swarm clusters
└── cloud-accounts.yml     # Cloud provider credentials/configs
```

**Example - servers.yml:**

```yaml
servers:
  - id: web-01
    hostname: web01.prod.example.com
    ip: 10.0.1.10
    provider: aws
    region: us-east-1
    ssh_user: deploy
    tags:
      - web
      - production
      - high-memory
```

### 2. `config/` - Environment Configuration

**What it is**: Configuration values, defaults, and overrides for the environment.

```text
config/
├── defaults/              # Environment-wide default values
│   ├── global.yml
│   └── services.yml
├── secrets/               # Secret references (not actual secrets!)
│   └── secret-refs.yml
└── overrides/             # Service-specific overrides
    ├── database.yml
    └── monitoring.yml
```

## How It Works

### Targets Define Infrastructure

Targets tell the system **where** things can be deployed:

```yaml
# infrastructure/production/targets/servers.yml
servers:
  - id: db-server-01
    hostname: db01.prod.example.com
    ip: 10.0.1.20
    memory: 32GB
    cpu: 8
```

### Config Provides Values

Config tells the system **how** things should be configured:

```yaml
# infrastructure/production/config/defaults/global.yml
log_level: info
backup_enabled: true
monitoring_enabled: true
data_retention_days: 90
```

### Deployments Use Both

When deploying, the system uses:

1. **Targets** to know where to deploy
2. **Config** to know what values to use

```yaml
# Example deployment reference
target: db-server-01          # From targets/servers.yml
config:
  log_level: ${global.log_level}    # From config/defaults/global.yml
  backup: ${global.backup_enabled}
```

## Directory Structure Details

### `targets/servers.yml`

Defines individual servers:

```yaml
servers:
  - id: web-01
    hostname: web01.prod.example.com
    ip: 10.0.1.10
    ssh_user: deploy
    ssh_port: 22
    provider: aws
    instance_type: t3.large
    tags:
      - web
      - nginx
      - public-facing

  - id: db-01
    hostname: db01.prod.example.com
    ip: 10.0.1.20
    ssh_user: deploy
    provider: aws
    instance_type: r5.xlarge
    tags:
      - database
      - postgresql
      - private
```

### `targets/clusters.yml`

Defines Kubernetes or Docker Swarm clusters:

```yaml
clusters:
  - id: k8s-prod
    type: kubernetes
    api_endpoint: https://k8s-prod.example.com:6443
    version: 1.28
    nodes: 5
    provider: aws
    region: us-east-1

  - id: swarm-staging
    type: docker-swarm
    manager_nodes:
      - swarm-mgr-01
      - swarm-mgr-02
    worker_nodes:
      - swarm-work-01
      - swarm-work-02
```

### `targets/cloud-accounts.yml`

Cloud provider configurations:

```yaml
cloud_accounts:
  - id: aws-prod
    provider: aws
    account_id: "123456789012"
    region: us-east-1
    credential_ref: aws-prod-creds  # Reference to secret, not actual creds!

  - id: azure-prod
    provider: azure
    subscription_id: "xxxxx"
    region: eastus
    credential_ref: azure-prod-creds
```

### `config/defaults/global.yml`

Environment-wide defaults:

```yaml
# Logging
log_level: info
log_retention_days: 30

# Monitoring
monitoring_enabled: true
metrics_retention_days: 90

# Backups
backup_enabled: true
backup_retention_days: 30
backup_schedule: "0 2 * * *"  # 2 AM daily

# Security
tls_enabled: true
tls_version: "1.3"
```

### `config/overrides/`

Service-specific overrides that supersede defaults:

```yaml
# config/overrides/database.yml
databases:
  postgresql:
    log_level: debug           # Override global log_level
    backup_retention_days: 90  # Override global backup_retention_days
    connection_pool_size: 100
```

### `config/secrets/`

⚠️ **Important**: This does NOT contain actual secrets!

Contains references to secrets stored in a secret manager:

```yaml
# config/secrets/secret-refs.yml
secrets:
  database_password:
    type: vault
    path: secret/production/db/password

  api_key:
    type: aws-secrets-manager
    name: production/api-key
    region: us-east-1
```

## Environment Differences

### Production

- Highest resource allocations
- Longest retention periods
- Most stringent security
- Full monitoring and backups

### Staging

- Medium resource allocations
- Shorter retention periods
- Production-like setup
- Testing ground for changes

### Development

- Minimal resource allocations
- Short retention periods
- Relaxed security (for dev only!)
- Quick iteration

## Common Workflows

### Adding a New Server

1. Edit `targets/servers.yml`:

```yaml
servers:
  - id: new-web-server
    hostname: web03.prod.example.com
    ip: 10.0.1.30
    ssh_user: deploy
```

2. Commit and push:

```bash
git add infrastructure/production/targets/servers.yml
git commit -m "feat: add new-web-server to production"
git push
```

3. Server is now available for deployments!

### Changing Environment Defaults

1. Edit `config/defaults/global.yml`:

```yaml
backup_retention_days: 60  # Changed from 30
```

2. All new deployments will use the new value
3. Existing deployments may need updating

### Adding Service-Specific Config

1. Create override file:

```yaml
# config/overrides/monitoring.yml
monitoring:
  prometheus:
    retention_days: 180      # Longer than default 90
    scrape_interval: 15s
```

2. Reference in deployments when needed

## Best Practices

1. **Document everything** - Use comments in YAML files
2. **Use tags liberally** - Makes querying and filtering easier
3. **Never commit secrets** - Use secret references only
4. **Test in development first** - Then staging, then production
5. **Version your changes** - Use semantic commit messages
6. **Keep defaults sensible** - Not too permissive, not too restrictive

## Relationship with Other Directories

```text
infrastructure/production/
    ↓
    ↓ (provides targets and config to)
    ↓
runtime/production/deployments/
    ↓
    ↓ (uses)
    ↓
catalog/ (templates)
```

## Troubleshooting

### Can't find a target?

Check the appropriate targets file:

```bash
cat infrastructure/production/targets/servers.yml
cat infrastructure/production/targets/clusters.yml
```

### Configuration not being used?

1. Check defaults: `config/defaults/global.yml`
2. Check for overrides: `config/overrides/[service].yml`
3. Check deployment manifest for explicit values

### Which value wins?

Order of precedence (highest to lowest):

1. Deployment-specific value (in deployment manifest)
2. Override value (in `config/overrides/`)
3. Default value (in `config/defaults/`)
4. System default (hardcoded)

## Security Notes

⚠️ **Never commit actual secrets to Git!**

- Use secret references only
- Store actual secrets in: Vault, AWS Secrets Manager, Azure Key Vault, etc.
- Use CI/CD to inject secrets at deployment time

## Related Documentation

- [STRUCTURE.md](../STRUCTURE.md) - Overall structure
- [runtime/README.md](../runtime/README.md) - How deployments use this
- [examples/](../examples/) - See it in action
