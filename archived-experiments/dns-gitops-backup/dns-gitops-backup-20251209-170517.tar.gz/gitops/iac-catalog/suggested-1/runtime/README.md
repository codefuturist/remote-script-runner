# Runtime - Active Deployments & Infrastructure

## Purpose

This directory contains the **live state** of your infrastructure:

- **What's deployed** (`deployments/`)
- **Where it's deployed** (`inventory/`)

GitOps agents watch this directory and automatically reconcile changes.

## Structure

```text
runtime/
├── production/
│   ├── deployments/       # Configured instances ready for deployment
│   └── inventory/         # Infrastructure definitions (servers, clusters)
├── staging/
└── development/
```

## Key Concept: Deployments vs Inventory

### `deployments/` - WHAT is deployed

Contains configured application/service instances ready to be deployed:

```text
deployments/production/app-wordpress-01/
├── manifest.yml           # Instance metadata
├── docker-compose.yml     # Application configuration
├── .env                   # Environment variables
└── target.yml             # Where to deploy (references inventory)
```

### `inventory/` - WHERE to deploy

Contains infrastructure definitions:

```text
inventory/production/
├── servers.yml            # Physical/virtual servers
├── clusters.yml           # Kubernetes/Swarm clusters
└── groups.yml             # Server groups for multi-server deployments
```

## How They Work Together

1. **Deployment** references an **inventory** target:

```yaml
# deployments/production/my-app/target.yml
targets:
  - type: docker-compose
    host: web-server-01           # ← References inventory/production/servers.yml
    inventory: ../../inventory/servers.yml
```

2. **Inventory** defines the infrastructure:

```yaml
# inventory/production/servers.yml
servers:
  - id: web-server-01
    hostname: web01.prod.example.com
    ip: 10.0.1.10
    ssh_user: deploy
    ssh_port: 22
```

## Environment Isolation

Each environment is **completely isolated**:

- Production deployments never reference staging inventory
- Staging changes don't affect production
- Development is a safe sandbox

## GitOps Workflow

```text
1. Configure deployment
   └→ Creates files in deployments/[env]/

2. Commit & push to Git
   └→ git add runtime/production/deployments/my-app
   └→ git commit -m "feat: deploy my-app"
   └→ git push

3. GitOps agent detects change
   └→ Reads deployment configuration
   └→ Looks up target in inventory
   └→ Deploys to infrastructure

4. Service is running!
```

## Creating a New Deployment

Use the CLI tool (don't create files manually):

```bash
./scripts/deploy/configure.sh \
  --template catalog/docker-compose/databases/postgresql \
  --instance my-db-01 \
  --environment production \
  --target db-server-01
```

This creates:

```text
runtime/production/deployments/my-db-01/
├── manifest.yml
├── docker-compose.yml
├── .env
└── target.yml
```

## Defining New Infrastructure

Edit the inventory files to add new servers or clusters:

```bash
vim runtime/production/inventory/servers.yml
```

Add your server:

```yaml
servers:
  - id: new-server-01
    hostname: new01.prod.example.com
    ip: 10.0.1.50
    ssh_user: deploy
    tags:
      - web
      - production
```

## Directory Contents

### Production (`production/`)

- **deployments/**: Production-ready deployments
- **inventory/**: Production infrastructure

⚠️ **WARNING**: Changes here affect production!

### Staging (`staging/`)

- **deployments/**: Pre-production testing
- **inventory/**: Staging infrastructure

Used for final testing before production.

### Development (`development/`)

- **deployments/**: Development/testing deployments
- **inventory/**: Development infrastructure

Safe for experimentation.

## Best Practices

1. **Never edit deployment files manually** - Use CLI tools
2. **Review changes before committing** - Check generated files
3. **Keep inventory up-to-date** - Document all infrastructure
4. **Use descriptive instance names** - `app-wordpress-01` not `test-123`
5. **Tag infrastructure** - Makes querying and grouping easier

## Common Patterns

### Single-Server Deployment

```text
deployments/production/app-nginx-01/
└── target.yml              # Points to ONE server
```

### Multi-Server Deployment

```text
deployments/production/monitoring-stack/
└── targets.yml             # Points to a SERVER GROUP
```

### Cluster Deployment

```text
deployments/production/k8s-app-01/
└── target.yml              # Points to a CLUSTER
```

## Troubleshooting

### Deployment not updating?

1. Check GitOps agent logs: `.iac-system/gitops/logs/`
2. Verify target exists in inventory
3. Check deployment manifest for errors

### Can't find a server?

1. Check `inventory/[env]/servers.yml`
2. Verify server ID matches what's in `target.yml`
3. Check `inventory/[env]/groups.yml` for group memberships

### Deployment in wrong environment?

Each environment is isolated. Make sure you're looking in the right directory:

- Production: `runtime/production/`
- Staging: `runtime/staging/`
- Development: `runtime/development/`

## Related Documentation

- [STRUCTURE.md](../STRUCTURE.md) - Overall structure guide
- [infrastructure/README.md](../infrastructure/README.md) - Configuration management
- [examples/](../examples/) - Complete working examples
