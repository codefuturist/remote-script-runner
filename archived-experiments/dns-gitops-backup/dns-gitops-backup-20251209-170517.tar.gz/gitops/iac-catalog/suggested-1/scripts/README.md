# Scripts - Automation & Tools

## Purpose

Executable scripts and tools organized by **user journey** - what you're trying to accomplish rather than technical implementation.

## Structure

```text
scripts/
├── setup/        # First-time setup and initialization
├── deploy/       # Deployment operations
├── manage/       # Day-2 operations and maintenance
└── migrate/      # Migrations and upgrades
```

## Quick Reference

| Task | Script | Example |
|------|--------|---------|
| First-time setup | `setup/install-dependencies.sh` | `./scripts/setup/install-dependencies.sh` |
| Configure deployment | `deploy/configure.sh` | `./scripts/deploy/configure.sh --template catalog/docker-compose/databases/postgresql --instance my-db` |
| Validate config | `deploy/validate.sh` | `./scripts/deploy/validate.sh --instance my-db` |
| Deploy manually | `deploy/deploy.sh` | `./scripts/deploy/deploy.sh --instance my-db --environment production` |
| Rollback | `deploy/rollback.sh` | `./scripts/deploy/rollback.sh --instance my-db --version 1.2.3` |
| List deployments | `manage/list.sh` | `./scripts/manage/list.sh --environment production` |
| Check status | `manage/status.sh` | `./scripts/manage/status.sh --instance my-db` |
| Cleanup old | `manage/cleanup.sh` | `./scripts/manage/cleanup.sh --older-than 30d` |
| Upgrade Terraform | `migrate/terraform-upgrade.sh` | `./scripts/migrate/terraform-upgrade.sh --from 1.5 --to 1.6` |

## Usage by Journey

### 🚀 Getting Started (First Time)

```bash
# 1. Install dependencies
./scripts/setup/install-dependencies.sh

# 2. Configure Git hooks
./scripts/setup/configure-git-hooks.sh

# 3. Initialize environments
./scripts/setup/initialize-environments.sh
```

### 📦 Deploying Something New

```bash
# 1. Configure deployment from template
./scripts/deploy/configure.sh \
  --template catalog/docker-compose/databases/postgresql \
  --instance my-postgres-db \
  --environment production \
  --target db-server-01 \
  --param db_name=myapp

# 2. Validate configuration
./scripts/deploy/validate.sh --instance my-postgres-db

# 3. Commit to Git (GitOps handles deployment)
git add runtime/production/deployments/my-postgres-db
git commit -m "feat: add postgresql database"
git push

# OR deploy manually if needed
./scripts/deploy/deploy.sh \
  --instance my-postgres-db \
  --environment production
```

### 🔄 Managing Existing Deployments

```bash
# List all deployments
./scripts/manage/list.sh

# List production only
./scripts/manage/list.sh --environment production

# Check specific deployment status
./scripts/manage/status.sh \
  --instance my-postgres-db \
  --environment production

# View deployment logs
./scripts/manage/logs.sh \
  --instance my-postgres-db \
  --environment production

# Cleanup old deployments
./scripts/manage/cleanup.sh --older-than 30d
```

### 🔧 Troubleshooting

```bash
# Validate deployment configuration
./scripts/deploy/validate.sh --instance my-postgres-db

# Check deployment health
./scripts/manage/health-check.sh \
  --instance my-postgres-db \
  --environment production

# View recent logs
./scripts/manage/logs.sh \
  --instance my-postgres-db \
  --lines 100
```

### ⚡ Emergency Operations

```bash
# Rollback to previous version
./scripts/deploy/rollback.sh \
  --instance my-postgres-db \
  --environment production

# Rollback to specific version
./scripts/deploy/rollback.sh \
  --instance my-postgres-db \
  --environment production \
  --version 1.2.3

# Emergency stop
./scripts/manage/stop.sh \
  --instance my-postgres-db \
  --environment production \
  --force
```

### 🔄 Migrations

```bash
# Upgrade Terraform version
./scripts/migrate/terraform-upgrade.sh \
  --from 1.5 \
  --to 1.6

# Upgrade Kubernetes version
./scripts/migrate/k8s-version-upgrade.sh \
  --cluster k8s-prod \
  --from 1.27 \
  --to 1.28

# Migrate module versions
./scripts/migrate/module-migration.sh \
  --module postgresql \
  --from 2.0.0 \
  --to 3.0.0
```

## Directory Details

### `setup/` - First-Time Setup

Scripts for initial repository setup and configuration.

**Key Scripts:**

- `install-dependencies.sh` - Install required tools (Docker, kubectl, terraform, etc.)
- `configure-git-hooks.sh` - Set up pre-commit hooks
- `initialize-environments.sh` - Create environment directories
- `setup-credentials.sh` - Configure cloud provider credentials

**When to use:** First time using the repository, or onboarding new team members.

### `deploy/` - Deployment Operations

Scripts for configuring and deploying applications.

**Key Scripts:**

- `configure.sh` - Configure template into deployment instance
- `validate.sh` - Validate deployment configuration
- `deploy.sh` - Manual deployment (when not using GitOps)
- `rollback.sh` - Rollback to previous version
- `remove.sh` - Remove a deployment

**When to use:** Creating, updating, or removing deployments.

### `manage/` - Day-2 Operations

Scripts for managing running deployments.

**Key Scripts:**

- `list.sh` - List all deployments
- `status.sh` - Check deployment status
- `logs.sh` - View deployment logs
- `health-check.sh` - Run health checks
- `backup.sh` - Backup deployment data
- `restore.sh` - Restore from backup
- `cleanup.sh` - Clean up old resources

**When to use:** Daily operations, monitoring, maintenance.

### `migrate/` - Migrations & Upgrades

Scripts for upgrading infrastructure and tools.

**Key Scripts:**

- `terraform-upgrade.sh` - Upgrade Terraform version
- `k8s-version-upgrade.sh` - Upgrade Kubernetes cluster
- `module-migration.sh` - Migrate to new module version
- `python-upgrade.sh` - Upgrade Python dependencies

**When to use:** Upgrading infrastructure, tools, or dependencies.

## Script Standards

All scripts should:

1. **Use bash shebang**: `#!/usr/bin/env bash`
2. **Be executable**: `chmod +x script.sh`
3. **Have help text**: `./script.sh --help`
4. **Validate inputs**: Check required parameters
5. **Handle errors**: Use `set -euo pipefail`
6. **Log actions**: Print what's happening
7. **Be idempotent**: Safe to run multiple times

## Common Patterns

### Help Text

Every script should support `--help`:

```bash
./scripts/deploy/configure.sh --help
```

### Dry Run

Many scripts support `--dry-run`:

```bash
./scripts/deploy/deploy.sh --instance my-db --dry-run
```

### Verbose Mode

Use `--verbose` for detailed output:

```bash
./scripts/deploy/configure.sh --template ... --verbose
```

### Environment Selection

Specify environment with `--environment`:

```bash
./scripts/manage/list.sh --environment production
```

## Development

### Creating New Scripts

1. Choose appropriate directory (`setup/`, `deploy/`, `manage/`, `migrate/`)
2. Create script with `.sh` extension
3. Add shebang and error handling
4. Implement help text
5. Make executable: `chmod +x script.sh`
6. Test thoroughly
7. Update this README

### Script Template

```bash
#!/usr/bin/env bash
set -euo pipefail

# Script: description
# Usage: ./script.sh [options]

# Help text
show_help() {
    cat << EOF
Usage: ${0##*/} [OPTIONS]

Description of what this script does.

OPTIONS:
    -h, --help          Show this help message
    -e, --environment   Environment (production, staging, development)
    -v, --verbose       Verbose output
    --dry-run           Show what would be done without doing it

EXAMPLES:
    ${0##*/} --environment production
    ${0##*/} --help

EOF
}

# Parse arguments
ENVIRONMENT=""
VERBOSE=false
DRY_RUN=false

while [[ $# -gt 0 ]]; do
    case $1 in
        -h|--help)
            show_help
            exit 0
            ;;
        -e|--environment)
            ENVIRONMENT="$2"
            shift 2
            ;;
        -v|--verbose)
            VERBOSE=true
            shift
            ;;
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        *)
            echo "Unknown option: $1"
            show_help
            exit 1
            ;;
    esac
done

# Validate required parameters
if [[ -z "$ENVIRONMENT" ]]; then
    echo "Error: --environment is required"
    show_help
    exit 1
fi

# Main logic here
echo "Running script for environment: $ENVIRONMENT"
```

## Troubleshooting

### Permission Denied

```bash
chmod +x scripts/deploy/configure.sh
```

### Script Not Found

```bash
# Run from repository root
cd /path/to/iac-catalog
./scripts/deploy/configure.sh
```

### Environment Not Found

```bash
# Check available environments
ls runtime/
```

## Related Documentation

- [STRUCTURE.md](../STRUCTURE.md) - Overall structure
- [examples/](../examples/) - See scripts in action
- [CONTRIBUTING.md](../CONTRIBUTING.md) - Development guidelines
