# IaC Catalog - Infrastructure as Code Template System

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## 📖 Overview

A **template-based GitOps deployment system** for Infrastructure as Code that supports multi-environment, multi-target deployments with automated reconciliation.

### Key Features

- ✅ **Technology-Organized Templates** - Find what you need by deployment tool
- ✅ **GitOps-Driven Deployments** - All changes through Git
- ✅ **Environment Isolation** - Production, staging, development completely separated
- ✅ **Multi-Target Support** - Single server, multi-server, or cluster deployments
- ✅ **Comprehensive Examples** - Get started in minutes with working examples

## 🚀 Quick Start

### 1. Explore Examples

Start with a complete working example:

```bash
cd examples/01-simple-webapp
cat README.md
```

### 2. Configure Your First Deployment

```bash
./scripts/deploy/configure.sh \
  --template catalog/docker-compose/web-servers/nginx \
  --instance my-nginx-01 \
  --environment development \
  --target dev-server-01
```

### 3. Deploy

```bash
git add runtime/development/deployments/my-nginx-01
git commit -m "feat: deploy nginx to development"
git push
```

The GitOps agent automatically deploys your changes!

## 📚 Documentation

- **[STRUCTURE.md](./STRUCTURE.md)** - Complete directory structure guide
- **[docs/ARCHITECTURE.md](./docs/ARCHITECTURE.md)** - Architecture deep dive
- **[CONTRIBUTING.md](./CONTRIBUTING.md)** - How to contribute
- **[examples/](./examples/)** - Working examples

## 🗂️ Repository Structure

```text
iac-catalog/
├── catalog/           # Templates organized by technology
├── runtime/           # Active deployments & infrastructure
├── infrastructure/    # Configuration & targets
├── examples/          # Working examples
├── scripts/           # Automation tools
├── docs/              # Documentation
├── tests/             # Test suites
└── tools/             # Development utilities
```

See [STRUCTURE.md](./STRUCTURE.md) for detailed explanations.

## 💡 Core Concepts

### Templates vs Deployments

- **Templates** (`catalog/`) are reusable, versioned configurations
- **Deployments** (`runtime/[env]/deployments/`) are configured instances ready to run
- **Infrastructure** (`infrastructure/[env]/targets/`) defines where things deploy

### Environment Separation

Each environment (production, staging, development) is completely isolated:

- Separate deployments
- Separate infrastructure
- Separate configurations

### GitOps Workflow

1. Configure deployment using CLI
2. Review generated files
3. Commit to Git
4. GitOps agent auto-deploys

## 🛠️ Available Scripts

```bash
# Setup
./scripts/setup/install-dependencies.sh

# Deploy
./scripts/deploy/configure.sh    # Configure new deployment
./scripts/deploy/validate.sh     # Validate configuration
./scripts/deploy/rollback.sh     # Rollback deployment

# Manage
./scripts/manage/list.sh          # List all deployments
./scripts/manage/status.sh        # Check deployment status
./scripts/manage/cleanup.sh       # Clean up old deployments
```

## 📦 Available Templates

### Docker Compose

- Web servers (Nginx, Apache, Caddy)
- Databases (PostgreSQL, MySQL, MongoDB, Redis)
- Monitoring (Prometheus, Grafana, Loki)
- CI/CD (GitLab, Jenkins, Drone)

### Kubernetes

- Operators (Cert-Manager, External-DNS)
- Applications (WordPress, GitLab)
- Platform services (Ingress, Monitoring)

### Terraform

- AWS modules
- Azure modules
- GCP modules
- Multi-cloud patterns

### Ansible

- System setup playbooks
- Deployment playbooks
- Maintenance tasks

## 🎯 Common Use Cases

### Deploy a Web Application

```bash
./scripts/deploy/configure.sh \
  --template catalog/docker-compose/web-servers/nginx \
  --instance my-webapp \
  --environment production \
  --target web-server-01 \
  --param domain=example.com
```

### Deploy Monitoring Stack to Multiple Servers

```bash
./scripts/deploy/configure.sh \
  --template catalog/docker-compose/monitoring/prometheus-stack \
  --instance monitoring \
  --environment production \
  --target monitoring-cluster \
  --param retention=30d
```

### Deploy Kubernetes Application

```bash
./scripts/deploy/configure.sh \
  --template catalog/kubernetes/applications/wordpress \
  --instance blog-prod \
  --environment production \
  --target k8s-prod-cluster \
  --param replicas=3
```

## 🧪 Testing

```bash
# Unit tests
make test-unit

# Integration tests
make test-integration

# All tests
make test-all
```

## 📊 Project Status

- **Version**: 1.0.0
- **Status**: Active Development
- **License**: MIT

## 🤝 Contributing

We welcome contributions! Please see [CONTRIBUTING.md](./CONTRIBUTING.md) for:

- Code style guidelines
- Naming conventions
- Pull request process
- Development setup

## 📞 Support

- **Documentation**: [docs/](./docs/)
- **Examples**: [examples/](./examples/)
- **Issues**: [GitHub Issues](https://github.com/codefuturist/iac-catalog/issues)

## 🔗 Related Projects

- [Ansible](https://www.ansible.com/)
- [Terraform](https://www.terraform.io/)
- [Kubernetes](https://kubernetes.io/)
- [ArgoCD](https://argoproj.github.io/cd/)
- [FluxCD](https://fluxcd.io/)

---

**Getting Started**: Check out [examples/01-simple-webapp/](./examples/01-simple-webapp/) for a complete walkthrough!
