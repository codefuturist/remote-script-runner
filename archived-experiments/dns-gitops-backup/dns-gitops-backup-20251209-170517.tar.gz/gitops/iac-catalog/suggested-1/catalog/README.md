# Catalog - Template Library

## Purpose

This directory contains **reusable, versioned templates** for all infrastructure and applications. Templates are organized by the **deployment technology**, not by where they run or what they do.

## Structure

```text
catalog/
├── docker-compose/     # Docker Compose stacks
├── kubernetes/         # Kubernetes manifests & Helm charts
├── terraform/          # Terraform modules
├── ansible/            # Ansible playbooks & roles
└── patterns/           # Technology-agnostic patterns
```

## Organization Principle

**By Technology, Not Use Case**

✅ Good: `catalog/docker-compose/databases/postgresql/`
❌ Bad: `catalog/cloud/aws/docker-compose/`

This makes it easy to find templates when you know **how** you want to deploy, not **where**.

## Template Structure

Each template should follow this structure:

```text
template-name/
├── README.md                 # Template documentation
├── template.yml              # Template metadata
├── [deployment-files]        # docker-compose.yml, k8s manifests, etc.
└── examples/                 # Usage examples
```

## Available Technologies

### Docker Compose (`docker-compose/`)

For Docker Compose-based deployments on single or multiple hosts.

**Categories:**
- `databases/` - PostgreSQL, MySQL, MongoDB, Redis, etc.
- `monitoring/` - Prometheus, Grafana, Loki, etc.
- `cicd/` - GitLab, Jenkins, Drone, etc.
- `web-servers/` - Nginx, Apache, Caddy, etc.
- `networking/` - Traefik, HAProxy, etc.

### Kubernetes (`kubernetes/`)

For Kubernetes-based deployments.

**Categories:**
- `operators/` - Cert-Manager, External-DNS, etc.
- `applications/` - Complete applications (WordPress, GitLab, etc.)
- `platform-services/` - Ingress controllers, monitoring, etc.

### Terraform (`terraform/`)

Infrastructure-as-Code modules for cloud providers.

**Categories:**
- `aws/` - AWS resources
- `azure/` - Azure resources
- `gcp/` - GCP resources
- `multi-cloud/` - Multi-cloud patterns

### Ansible (`ansible/`)

Ansible playbooks and roles.

**Categories:**
- `system-setup/` - OS configuration, user setup
- `deployments/` - Application deployments
- `maintenance/` - Backup, updates, cleanup

### Patterns (`patterns/`)

Technology-agnostic architectural patterns.

**Categories:**
- `application/` - 12-factor apps, microservices, etc.
- `infrastructure/` - HA, DR, scaling patterns
- `data/` - Replication, backup, ETL patterns

## Creating a New Template

1. Choose the appropriate technology directory
2. Create a new subdirectory with a descriptive name
3. Add required files (README.md, template.yml, deployment files)
4. Test thoroughly
5. Submit a pull request

See [CONTRIBUTING.md](../CONTRIBUTING.md) for detailed guidelines.

## Using Templates

Templates are consumed by the CLI tool:

```bash
./scripts/deploy/configure.sh \
  --template catalog/docker-compose/databases/postgresql \
  --instance my-db-01 \
  --environment production \
  --target db-server-01
```

## Template Versioning

Each template should maintain a `template.yml` with version information:

```yaml
name: postgresql
version: 1.0.0
technology: docker-compose
description: PostgreSQL database server
```

## Best Practices

1. **Keep templates generic** - Use variables for customization
2. **Document thoroughly** - README should explain everything
3. **Include examples** - Show common use cases
4. **Test extensively** - All templates should pass tests
5. **Version carefully** - Follow semantic versioning

## Related Documentation

- [STRUCTURE.md](../STRUCTURE.md) - Overall repository structure
- [CONTRIBUTING.md](../CONTRIBUTING.md) - Contribution guidelines
- [examples/](../examples/) - See templates in action
