# Repository Structure Guide

## 📖 Overview

This repository implements a **template-based GitOps deployment system** for Infrastructure as Code. This guide explains where everything lives and how it all fits together.

## 🗂️ Directory Structure

```
iac-catalog/
│
├── catalog/                      # 📦 Template Library (Read-Only for Most Users)
├── runtime/                      # 🚀 Active Deployments & Infrastructure
├── infrastructure/               # ⚙️  Configuration & Targets
├── examples/                     # 📚 Working Examples
├── scripts/                      # 🛠️  Tools & Automation
├── docs/                         # 📝 Documentation
├── tests/                        # ✅ Testing Suite
├── tools/                        # 🔧 Development Utilities
└── .iac-system/                  # 🔒 System State (Hidden)
```

## 📦 `catalog/` - Template Library

**Purpose**: Reusable, versioned templates for all infrastructure and applications.

**Organized by deployment technology** (not by where it runs):

```
catalog/
├── docker-compose/               # Docker Compose stacks
│   ├── databases/
│   ├── monitoring/
│   ├── cicd/
│   └── web-servers/
├── kubernetes/                   # Kubernetes manifests & Helm charts
│   ├── operators/
│   ├── applications/
│   └── platform-services/
├── terraform/                    # Terraform modules
│   ├── aws/
│   ├── azure/
│   ├── gcp/
│   └── multi-cloud/
├── ansible/                      # Ansible playbooks & roles
│   ├── system-setup/
│   ├── deployments/
│   └── maintenance/
└── patterns/                     # Reusable patterns (technology-agnostic)
    ├── application/              # App architectures (12-factor, microservices)
    ├── infrastructure/           # Infra patterns (HA, DR, scaling)
    └── data/                     # Data patterns (replication, backup)
```

**When to use**: When creating new templates or browsing available options.

## 🚀 `runtime/` - Active Deployments & Infrastructure

**Purpose**: The live state - what's currently deployed and where.

```
runtime/
├── production/
│   ├── deployments/              # Configured instances ready for deployment
│   │   ├── app-wordpress-01/
│   │   └── monitoring-stack/
│   └── inventory/                # Infrastructure definitions
│       ├── servers.yml
│       ├── clusters.yml
│       └── groups.yml
├── staging/
└── development/
```

**Key Concept**: 
- `deployments/` = **What is deployed** (applications, services)
- `inventory/` = **Where it's deployed** (servers, clusters)

**When to use**: 
- GitOps agents watch `deployments/` for changes
- Deployment tools read from `inventory/` to know where to deploy

## ⚙️ `infrastructure/` - Configuration & Targets

**Purpose**: Environment-specific configurations and infrastructure target definitions.

```
infrastructure/
├── production/
│   ├── targets/                  # Infrastructure endpoints
│   │   ├── servers.yml           # Physical/virtual servers
│   │   ├── clusters.yml          # K8s/Swarm clusters
│   │   └── cloud-accounts.yml    # Cloud provider credentials
│   └── config/                   # Environment configuration
│       ├── defaults/             # Default values
│       ├── secrets/              # Secret references (not actual secrets!)
│       └── overrides/            # Service-specific overrides
├── staging/
└── development/
```

**When to use**: 
- Defining new infrastructure targets
- Setting environment-wide defaults
- Managing configuration overrides

## 📚 `examples/` - Working Examples

**Purpose**: Complete, working examples to help you get started quickly.

```
examples/
├── 01-simple-webapp/
│   ├── README.md                 # Step-by-step guide
│   ├── template/                 # The template used
│   └── deployment/               # Complete deployment config
├── 02-multi-tier-app/
│   ├── README.md
│   ├── templates/                # Multiple templates
│   └── deployment/
└── 03-kubernetes-deployment/
    ├── README.md
    ├── template/
    └── deployment/
```

**When to use**: When learning the system or looking for reference implementations.

## 🛠️ `scripts/` - Tools & Automation

**Purpose**: Executable scripts organized by user journey.

```
scripts/
├── setup/                        # First-time setup
│   ├── install-dependencies.sh
│   ├── configure-git-hooks.sh
│   └── initialize-environments.sh
├── deploy/                       # Deployment operations
│   ├── configure.sh              # Configure template → instance
│   ├── validate.sh               # Validate configuration
│   └── rollback.sh               # Rollback deployment
├── manage/                       # Day-2 operations
│   ├── list.sh                   # List deployments
│   ├── status.sh                 # Check deployment status
│   └── cleanup.sh                # Clean up old deployments
└── migrate/                      # Migrations & upgrades
    ├── terraform-upgrade.sh
    └── k8s-version-upgrade.sh
```

**When to use**: 
- `setup/` - First time using the repository
- `deploy/` - Creating/updating/removing deployments
- `manage/` - Daily operations
- `migrate/` - Upgrading infrastructure or tools

## 📝 `docs/` - Documentation

**Purpose**: Comprehensive documentation for the system.

```
docs/
├── architecture/
│   ├── diagrams/                 # Visual diagrams
│   ├── decision-records/         # ADRs (Architecture Decision Records)
│   └── reference-architectures/  # Reference implementations
├── guides/
│   ├── getting-started/          # Onboarding guides
│   ├── deployment-guides/        # How-to guides
│   └── troubleshooting/          # Common issues & solutions
└── api/
    ├── module-reference/         # Template API docs
    └── service-catalog/          # Available services
```

**When to use**: For understanding concepts, troubleshooting, or reference.

## ✅ `tests/` - Testing Suite

**Purpose**: Automated tests for all aspects of the system.

```
tests/
├── unit/                         # Unit tests for templates
│   ├── terraform/
│   ├── kubernetes/
│   └── ansible/
├── integration/                  # Integration tests
│   ├── infrastructure/
│   ├── applications/
│   └── end-to-end/
├── compliance/                   # Compliance & policy tests
│   ├── security-scanning/
│   ├── policy-validation/
│   └── cost-analysis/
└── performance/                  # Performance tests
    ├── benchmarks/
    ├── load-testing/
    └── stress-testing/
```

**When to use**: Running tests before committing changes.

## 🔧 `tools/` - Development Utilities

**Purpose**: Development and maintenance tools.

```
tools/
├── validators/                   # Template validators
│   ├── docker-compose-validator.py
│   └── kubernetes-validator.py
├── generators/                   # Code generators
│   ├── template-generator.sh
│   └── docs-generator.py
├── converters/                   # Format converters
│   └── compose-to-k8s.py
└── linters/                      # Custom linting rules
    └── template-linter.py
```

**When to use**: When developing new templates or maintaining the system.

## 🔒 `.iac-system/` - System State (Hidden)

**Purpose**: Internal system state and caches (not for manual editing).

```
.iac-system/
├── deployments/
│   ├── state/                    # Current deployment state
│   └── history/                  # Deployment history
│       ├── production/
│       ├── staging/
│       └── development/
├── gitops/
│   └── agent-config.yml          # GitOps agent configuration
└── cache/                        # Temporary files & caches
```

**When to use**: Usually managed by automation. Check logs here for debugging.

---

## 🎯 Decision Tree: "Where Do I Put X?"

### I want to create a new template
→ `catalog/[technology]/`

### I want to deploy something
→ Use `scripts/deploy/configure.sh` (creates in `runtime/[env]/deployments/`)

### I want to define a new server/cluster
→ `infrastructure/[env]/targets/`

### I want to set environment-wide defaults
→ `infrastructure/[env]/config/defaults/`

### I want to see what's deployed
→ Check `runtime/[env]/deployments/`

### I want to know available infrastructure
→ Check `infrastructure/[env]/targets/`

### I want to learn how to use the system
→ Check `examples/` and `docs/guides/getting-started/`

---

## 🔄 How It All Works Together

```
1. Templates (catalog/)
        ↓
2. Configuration (scripts/deploy/configure.sh)
        ↓
3. Configured Instance (runtime/[env]/deployments/)
        ↓
4. Git Commit & Push
        ↓
5. GitOps Agent (.iac-system/gitops/)
        ↓
6. Deployment (using infrastructure/[env]/targets/)
        ↓
7. Running Service (on infrastructure/[env]/targets/)
```

---

## 📋 Key Principles

1. **Separation of Concerns**: Templates, deployments, and infrastructure are separate
2. **Environment Isolation**: Each environment is completely isolated
3. **GitOps-Driven**: All changes go through Git
4. **Technology-Organized**: Catalog organized by deployment technology, not by use case
5. **Documentation-First**: Every directory has a README

---

## 🔍 Quick Reference

| Directory | Purpose | Modified By |
|-----------|---------|-------------|
| `catalog/` | Templates | Template authors |
| `runtime/[env]/deployments/` | Active deployments | CLI + GitOps |
| `runtime/[env]/inventory/` | Infrastructure inventory | Infrastructure team |
| `infrastructure/[env]/` | Config & targets | Ops team |
| `examples/` | Learning materials | Documentation team |
| `scripts/` | Automation tools | Everyone |
| `docs/` | Documentation | Documentation team |
| `tests/` | Test suites | Developers |
| `tools/` | Dev utilities | Developers |
| `.iac-system/` | System state | Automation only |

---

## 📚 Related Documentation

- [QUICKSTART.md](./QUICKSTART.md) - Get started in 5 minutes
- [docs/ARCHITECTURE.md](./docs/ARCHITECTURE.md) - Detailed architecture
- [CONTRIBUTING.md](./CONTRIBUTING.md) - How to contribute
- [examples/](./examples/) - Working examples
